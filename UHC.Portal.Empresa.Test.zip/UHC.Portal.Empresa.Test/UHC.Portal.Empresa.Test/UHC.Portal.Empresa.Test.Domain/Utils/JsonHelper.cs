﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace Test.Middleware.Helper
{
    public class JsonHelper
    {
        public static List<object> DescerealizarObjeto(string json, object objeto)
        {
            //List<object> lista = JsonConvert.DeserializeObject<List<object>>(json).Cast<object>().ToList();
            return JsonConvert.DeserializeObject<List<object>>(json).Cast<object>().ToList();
        }

        public static string SerializarObjeto(object objeto)
        {
            string json = null;

            try
            {
                json = JsonConvert.SerializeObject(objeto);
            }
            catch (System.Exception)
            {

                throw;
            }

            return json;
        }
    }
}
