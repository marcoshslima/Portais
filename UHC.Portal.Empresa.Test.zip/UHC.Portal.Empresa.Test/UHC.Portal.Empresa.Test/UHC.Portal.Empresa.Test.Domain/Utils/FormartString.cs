﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Test.Middleware.Helper
{
    public class FormartString
    {
        public string FormatPhoneDefault(string phoneNumber)
        {
            if (String.IsNullOrEmpty(phoneNumber))
                return phoneNumber;

            Regex phoneParser = null;
            string format = "";

            switch (phoneNumber.Length)
            {
                case 8:
                    phoneParser = new Regex(@"(\d{4})(\d{4})");
                    format = "$1-$2";
                    break;

                case 9:
                    phoneParser = new Regex(@"(\d{5})(\d{4})");
                    format = "$1-$2";
                    break;

                case 10:
                    phoneParser = new Regex(@"(\d{2})(\d{4})(\d{4})");
                    format = "$1-$2-$3";
                    break;

                case 11:
                    phoneParser = new Regex(@"(\d{2})(\d{5})(\d{4})");
                    format = "$1-$2-$3";
                    break;

                default:
                    format = "$1-$2";
                    return phoneNumber;
            }

            return phoneParser.Replace(phoneNumber, format);
        }

        public static string FormatPhonePortal(string phoneNumber)
        {
            if (String.IsNullOrEmpty(phoneNumber))
                return phoneNumber;

            Regex phoneParser = null;
            string format = "";

            switch (phoneNumber.Length)
            {
                //case 8:
                //    phoneParser = new Regex(@"(\d{4})(\d{4})");
                //    format = "$1-$2";
                //    break;

                //case 9:
                //    phoneParser = new Regex(@"(\d{5})(\d{4})");
                //    format = "$1-$2";
                //    break;

                case 10:
                    phoneParser = new Regex(@"(\d{2})(\d{4})(\d{4})");
                    format = "$1-$2-$3";
                    break;

                case 11:
                    phoneParser = new Regex(@"(\d{2})(\d{5})(\d{4})");
                    format = "$1-$2-$3";
                    break;

                default:
                    format = "$1-$2";
                    return phoneNumber;
            }

            return phoneParser.Replace(phoneNumber, format);
        }

    }
}
