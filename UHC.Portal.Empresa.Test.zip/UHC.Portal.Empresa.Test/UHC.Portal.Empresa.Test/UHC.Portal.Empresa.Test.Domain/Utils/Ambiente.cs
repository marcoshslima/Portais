﻿using System.Configuration;

namespace UHC.Portal.Empresa.Test.UI.Util
{
	public static class Ambiente
	{
		public static string UrlFront;
		public static string UrlMiddleware;
		public static string UrlDomain;
		public static string DadosConexao;
		public static string NomeAmbiente = ConfigurationSettings.AppSettings["_ambiente"].ToUpper();

		static Ambiente()
		{
			switch (NomeAmbiente)
			{
				case "LOCAL":
					UrlFront = "https://ogs-dev.amil.com.br/CanaisDigitais-PortalEmpresa/#/";
					UrlMiddleware = "http://ogs-dev-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					UrlDomain = "http://ogs-dev-domain.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					DadosConexao = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=hdsisage-scan.grupoamil.com.br)(PORT=1521))(CONNECT_DATA=(SERVER=dedicated)(SERVICE_NAME=DSISAGE)));User Id=totem;Password=De2015@a1000;";
					break;
				case "DEV":
					UrlFront = "https://ogs-dev.amil.com.br/CanaisDigitais-PortalEmpresa/#/";
					UrlMiddleware = "http://ogs-dev-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					UrlDomain = "http://ogs-dev-domain.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					DadosConexao = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=hdsisage-scan.grupoamil.com.br)(PORT=1521))(CONNECT_DATA=(SERVER=dedicated)(SERVICE_NAME=DSISAGE)));User Id=totem;Password=De2015@a1000;";
					break;
				case "QA":
					UrlFront = "https://ogs-qa.amil.com.br/CanaisDigitais-PortalEmpresa/#/";
					UrlMiddleware = "http://ogs-qa-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					UrlDomain = "http://ogs-qa-domain.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					DadosConexao = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=hdsisage-scan.grupoamil.com.br)(PORT=1521))(CONNECT_DATA=(SERVER=dedicated)(SERVICE_NAME=QSISAGE)));User Id=totem;Password=qtotem;";
					break;
				case "HOM":
					UrlFront = "https://ogs-hom.amil.com.br/CanaisDigitais-PortalEmpresa/#/";
					UrlMiddleware = "http://ogs-hom-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					UrlDomain = "http://ogs-hom-domain.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
					DadosConexao = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=sagendat-scan.grupoamil.com.br)(PORT=1521))(CONNECT_DATA=(SERVER=dedicated)(SERVICE_NAME=TSISAGE)));User Id=totem;Password=9HxJ214LWlogpTtByj81yKZM7JzLdn;";
					break;
				default:
					break;
			}

		}

		public static object ConfigurationManager { get; private set; }
	}
}