﻿using OGS.Framework.Utility;
using System.Text;
using TechTalk.SpecFlow;

namespace Test.Middleware.Helper
{
    public static class WsHepler
    {
        public static void TestarGet(string URI, string[] Params, WebService WS, string[] ResultadoEsperado, int StatusCode)
        {
            StringBuilder pathURL = new StringBuilder();
            pathURL.Append(ScenarioContext.Current.Get<string>(URI));

            foreach (string param in Params)
            {
                pathURL.Append("/" + ScenarioContext.Current.Get<string>(param));
            }

            WS.GetHttpWebRequest(pathURL.ToString(), "json", StatusCode, ResultadoEsperado, null, null);
        }

        public static void TestarPost(string URI, string[] Params, WebService WS, string[] ResultadoEsperado, int StatusCode)
        {
            StringBuilder pathURL = new StringBuilder();
            pathURL.Append(ScenarioContext.Current.Get<string>(URI));

            foreach (string param in Params)
            {
                pathURL.Append("/" + ScenarioContext.Current.Get<string>(param));
            }

            WS.PostHttpWebRequest(pathURL.ToString(), "json", StatusCode, ResultadoEsperado, null, null);
        }

        public static void TestarPut(string URI, string[] Params, WebService WS, string[] ResultadoEsperado, int StatusCode)
        {
            StringBuilder pathURL = new StringBuilder();
            pathURL.Append(ScenarioContext.Current.Get<string>(URI));

            foreach (string param in Params)
            {
                pathURL.Append("/" + ScenarioContext.Current.Get<string>(param));
            }

            WS.PutHttpWebRequest(pathURL.ToString(), "json", StatusCode, ResultadoEsperado, null, null);
        }
    }
}
