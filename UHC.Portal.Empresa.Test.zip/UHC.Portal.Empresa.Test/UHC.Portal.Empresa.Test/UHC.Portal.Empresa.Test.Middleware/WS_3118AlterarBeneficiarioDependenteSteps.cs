﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_3118AlterarBeneficiarioDependenteSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa_Alterar Beneficiário Dependente  ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresa_AlterarBeneficiarioDependente(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Alterar Cadastro de Beneficiários”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralAlterarCadastroDeBeneficiarios()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"selecionei um beneficiário dependente \(devem ser mostrados todos os beneficiários dependentes, independente de serem ativos\)")]
        public void DadoSelecioneiUmBeneficiarioDependenteDevemSerMostradosTodosOsBeneficiariosDependentesIndependenteDeSeremAtivos()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/Opcionais/empresaData.CodTsContrato", "json", 200, null, null, null);

        }

        [Then(@"Verifique a API EstadoCivili sup e execução")]
        public void EntaoVerifiqueAAPIEstadoCiviliSupEExecucao()
        {
            resposta = empresa.GetHttpWebRequest("EstadoCivil", "json", 200, null, null, null);
        }
        
        [Then(@"Verifique a API OrgaoEmissor sup e execução")]
        public void EntaoVerifiqueAAPIOrgaoEmissorSupEExecucao()
        {
            resposta = empresa.GetHttpWebRequest("OrgaoEmissor,", "json", 200, null, null, null);
        }
       
        
        [Then(@"Verifique se a API Tipois está funcionando")]
        public void EntaoVerifiqueSeAAPITipoisEstaFuncionando()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/"+empresaData.Usuario+"/Tipo,", "json", 200, null, null, null);
        }
    }
}
