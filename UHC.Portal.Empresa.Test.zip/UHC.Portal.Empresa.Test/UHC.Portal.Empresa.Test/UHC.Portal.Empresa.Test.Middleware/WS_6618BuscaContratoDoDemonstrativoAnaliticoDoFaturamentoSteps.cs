﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_6618BuscaContratoDoDemonstrativoAnaliticoDoFaturamentoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;
        #endregion
        [Given(@"QUE o sistema mostrouu pelo menos um contrato ""(.*)""")]
        public void DadoQUEOSistemaMostrouuPeloMenosUmContrato(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar em um dos contratos disponiveis")]
        public void QuandoEuClicarEmUmDosContratosDisponiveis()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"clicar em""(.*)""")]
        public void QuandoClicarEm(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema mostrará uma grid com as faturas disponiveis")]
        public void EntaoOSistemaMostraraUmaGridComAsFaturasDisponiveis()
        {
            resposta = empresa.GetHttpWebRequest("Fatura/PesquisarExtratoClienteAnalitico/"+lstEmpresaData.CodTsContrato+"/"+lstEmpresaData.codTipoOperacao, "json", 200, null, null, null);

        }
    }
}
