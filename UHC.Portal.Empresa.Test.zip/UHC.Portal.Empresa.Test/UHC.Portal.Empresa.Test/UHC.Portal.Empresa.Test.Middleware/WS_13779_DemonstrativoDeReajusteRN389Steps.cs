﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_13779_DemonstrativoDeReajusteRN389Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa item de menu Gestao Financeira e Demonstrativos / Demonstrativo de Reajuste RN ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaItemDeMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeReajusteRN(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Acesso com dados de teste obrigatorios do campo contratoo")]
        public void QuandoAcessoComDadosDeTesteObrigatoriosDoCampoContratoo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"Hit o WebService necessario de contrato para obter a resposta")]
        public void EntaoHitOWebServiceNecessarioDeContratoParaObterAResposta()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContrato/" + empresaData.NumContrato + "/" + empresaData.CodTsContrato, "json", 200, null, null, null);
        }
    }
}
