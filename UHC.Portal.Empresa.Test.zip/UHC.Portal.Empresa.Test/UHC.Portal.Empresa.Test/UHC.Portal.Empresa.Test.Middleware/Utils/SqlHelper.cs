﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.Middleware.Utils
{
    class SqlHelper
    {
        #region Pesquisar grupo/contrato
        public string PesquisarGrupoContratoAtivo
        {
            get
            {
                {
                    var temp = new StringBuilder("SELECT u.cod_usuario, ce.COD_GRUPO_HOLDING ");
                    temp.Append("FROM ts.contrato_empresa ce INNER JOIN ts_sec.usuario u ON u.cod_identificacao_ts = TO_CHAR(ce.cod_grupo_empresa) ");
                    temp.Append("WHERE ce.ind_situacao = 'A' AND   u.txt_senha = 'E076259533B781BA7E059D865B646F12' AND   ROWNUM <= 1 AND   EXISTS ");
                    temp.Append("(SELECT 1 FROM authogs.usuario WHERE login_usuario = u.cod_usuario) ");
                    temp.Append("AND u.cod_tipo_usuario in (6,19) ");

                    return temp.ToString();
                }
            }
        }

        public string PesquisarGrupoContratoInativo
        {
            get
            {
                {
                    var temp = new StringBuilder("SELECT u.cod_usuario ");
                    temp.Append("FROM ts.contrato_empresa ce INNER JOIN ts_sec.usuario u ON u.cod_identificacao_ts = TO_CHAR(ce.cod_grupo_empresa) ");
                    temp.Append("WHERE ce.ind_situacao = 'E' AND   u.txt_senha = 'E076259533B781BA7E059D865B646F12' AND   ROWNUM <= 1 AND   EXISTS ");
                    temp.Append("(SELECT 1 FROM authogs.usuario WHERE login_usuario = u.cod_usuario) ");
                    temp.Append("AND u.cod_tipo_usuario in (6,19) ");

                    return temp.ToString();
                }
            }
        }
        #endregion
    }
}
