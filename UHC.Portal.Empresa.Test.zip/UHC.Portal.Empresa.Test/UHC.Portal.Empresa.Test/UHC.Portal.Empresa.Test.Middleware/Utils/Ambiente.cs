﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.Middleware.Utils
{
    public static class Ambiente
    {
        #region variables
        public static string BaseUri;
        public static string BaseUriAuth;
        public static string host;
        public static string port;
        public static string servicename;
        public static string user;
        public static string password;
        public static string NomeAmbiente = ConfigurationManager.AppSettings["_ambiente"];
        #endregion

        static Ambiente()
        {
            switch (NomeAmbiente.ToUpper())
            {
                case "QA":
                  BaseUri = "http://ogs-qa-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
                    BaseUriAuth = "http://apigtmdev.amil.com.br:8080/qa/portais/auth/token";
                    #region dbQA
                    //dados conexão db
                    host = "sisamilteste6-db.grupoamil.com.br";
                    port = "1521";
                    servicename = "QA6";
                    user = "siteamil_integracao";
                    password = "siteamil_integracao";
                    #endregion
                    break;
                case "DEV":
                    BaseUri = "http://ogs-dev-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
                    BaseUriAuth = "http://apigtmdev.amil.com.br:8080/dev/portais/auth/token";
                    #region dbDEV
                    host = "dsisamil.amil.com.br";
                    port = "1521";
                    servicename = "OGS";
                    user = "TS_ODO";
                    password = "xpto2000";
                    #endregion
                    break;
                case "HOM":
                    BaseUri = "http://ogs-hom-middleware.amil.com.br/CanaisDigitais-PortalEmpresa/api/";
                    BaseUriAuth = "https://api-hom.amil.com.br/portais/auth/token";
                    #region dbHOM
                    host = "hdsisamil-scan.amil.com.br";
                    port = "1521";
                    servicename = "hsisamil";
                    user = "SITEAMIL_INTEGRACAO";
                    password = "64gfurGnnWiz58$nQzOuL#Xebg6dLx";
                    #endregion
                    break;
                default:
                    break;
            }
        }

        public static string UrlMiddleware { get; internal set; }
    }
}
