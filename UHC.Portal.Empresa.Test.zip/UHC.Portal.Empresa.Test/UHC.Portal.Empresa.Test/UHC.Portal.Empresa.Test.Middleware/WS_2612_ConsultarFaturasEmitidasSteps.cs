﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_2612_ConsultarFaturasEmitidasSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;

        #endregion
        [Given(@"QUE eu jaa fiz login no Portal Empresa ""(.*)""")]
        public void DadoQUEEuJaaFizLoginNoPortalEmpresa(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
            
        }
        
        [Given(@"ja acessei o item de menu “Gestão Financeira e Demonstrativos / Consultar Faturas Emitidas")]
        public void DadoJaAcesseiOItemDeMenuGestaoFinanceiraEDemonstrativosConsultarFaturasEmitidas()
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("MM-yyyy");
            Console.WriteLine(todayDateFormat);
        }
        
        [Given(@"ja realizei os passos indicados na US \[(.*)] - Busca Contrato")]
        public void DadoJaRealizeiOsPassosIndicadosNaUS_BuscaContrato(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"preenchi os campos obrigatorios “Competência”")]
        public void DadoPreenchiOsCamposObrigatoriosCompetencia()
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"eu clicar emm “Continuar”")]
        public void QuandoEuClicarEmmContinuar()
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"eu ja cliqueii em_effective Autorizacao ""(.*)""")]
        public void EntaoEuJaCliqueiiEm_EffectiveAutorizacao(string p0)
        {

            resposta = empresa.GetHttpWebRequest("Fatura/Emitida/" + lstEmpresaData.CodigoContrato + "/" + lstEmpresaData.InitialDate + "/"+todayDateFormat, "json", 200, null, null, null);
        }
    }
}
