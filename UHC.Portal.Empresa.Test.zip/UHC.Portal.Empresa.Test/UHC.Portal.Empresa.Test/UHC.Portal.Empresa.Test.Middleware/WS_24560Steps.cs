﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_24560Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa_Buscar Contrato Para Consultar Autorizações Token ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresa_BuscarContratoParaConsultarAutorizacoesToken(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Gestão de Beneficiários / Consultar Autorizações Token”")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosConsultarAutorizacoesToken()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sobre o botão “Buscar” ao lado do campo ""(.*)""")]
        public void QuandoEuClicarSobreOBotaoBuscarAoLadoDoCampo(string p0)
        {
            Console.WriteLine(empresa);

        }
        
        [Then(@"o sistema deverá apresentar uma popup contendo os contratos")]
        public void EntaoOSistemaDeveraApresentarUmaPopupContendoOsContratos()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/"+listEmpresaData.numeroContrato+"/"+listEmpresaData.codTsContrato, "json", 200, null, null, null);
        }
    }
}
