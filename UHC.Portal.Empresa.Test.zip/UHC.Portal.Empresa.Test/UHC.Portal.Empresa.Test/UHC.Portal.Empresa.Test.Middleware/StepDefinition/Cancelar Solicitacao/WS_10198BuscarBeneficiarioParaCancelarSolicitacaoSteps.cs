﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Cancelar_Solicitacao
{
    [Binding]
    public class WS_10198BuscarBeneficiarioParaCancelarSolicitacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;

        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa\[Buscar Beneficiário] ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaBuscarBeneficiario(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menuGestão de Beneficiários / Solicitações / Cancelar Solicitações")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesCancelarSolicitacoes()
        {
            empresa = new WebService(Ambiente.BaseUri); ;
        }
        
        [Given(@"o sistema apresentou a tela para cancelamento de solicitações")]
        public void DadoOSistemaApresentouATelaParaCancelamentoDeSolicitacoes()
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo Selecione o beneficiário")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboSelecioneOBeneficiario(int p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os beneficiários cadastrados de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsBeneficiariosCadastradosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Solicitacao/PesquisarCarteira/"+listEmpresaData.Beneficiario, "json", 200, null, null, null);

        }
    }
}
