﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class ImportarArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        DateTime today;
        string todayDateFormat;

        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresaa ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já cliquei emm ""(.*)""")]
        public void DadoJaCliqueiEmm(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar emm ""(.*)""")]
        public void QuandoEuClicarEmm(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"preencher os campos obrigatórioss")]
        public void QuandoPreencherOsCamposObrigatorioss()
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"clicar em “Buscarr rede credenciada” \[LA(.*)]")]
        public void QuandoClicarEmBuscarrRedeCredenciadaLA(int p0)
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"eu inserir um CPF válidoo")]
        public void QuandoEuInserirUmCPFValidoo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu inserir um CPF inválidoo")]
        public void QuandoEuInserirUmCPFInvalidoo()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir um CPF não cadastradoo")]
        public void QuandoEuInserirUmCPFNaoCadastradoo()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu selecionar a busca de prestador por tipo de serviçoo")]
        public void QuandoEuSelecionarABuscaDePrestadorPorTipoDeServicoo()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu selecionar a busca de prestador por nome de prestadorr")]
        public void QuandoEuSelecionarABuscaDePrestadorPorNomeDePrestadorr()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar no link Rede Credenciadaa")]
        public void QuandoEuClicarNoLinkRedeCredenciadaa()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"não preencher todos os campos obrigatórioss")]
        public void QuandoNaoPreencherTodosOsCamposObrigatorioss()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu alterar qualquer campoo da tela""")]
        public void QuandoEuAlterarQualquerCampooDaTela()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"clicar emm “Buscar” \[LA(.*)]")]
        public void QuandoClicarEmmBuscarLA(int p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema apresentará as informações da rede credenciada DENTRO DO PORTAL EMPRESASS \[LA(.*)]")]
       public void EntaoOSistemaApresentaraAsInformacoesDaRedeCredenciadaDENTRODOPORTALEMPRESASSLA(string p0)
        {
            //resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Contrato/PesquisarDadosContratoFiltro/"+985791000, "json", 200, new string[] { "NOME_ENTIDADE" }, null, null);
           resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContratoFiltro/"+listEmpresaData.Contrato, "json", 200, null, null, null);

            
        }

        [Then(@"o campo ""(.*)"" será preenchido automaticamente com o plano referente ao CPF do beneficiárioo")]
        public void EntaoOCampoSeraPreenchidoAutomaticamenteComOPlanoReferenteAoCPFDoBeneficiarioo(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContratoFiltro/"+listEmpresaData.Contrato, "json", 200, null, null, null);

        }

        [Then(@"na combo ""(.*)"" para selecionar, deverá estar separado as informações de Plano e redee")]
        public void EntaoNaComboParaSelecionarDeveraEstarSeparadoAsInformacoesDePlanoERedee(string p0)
        {
            Console.WriteLine(resposta);
        }
        
    }
}
