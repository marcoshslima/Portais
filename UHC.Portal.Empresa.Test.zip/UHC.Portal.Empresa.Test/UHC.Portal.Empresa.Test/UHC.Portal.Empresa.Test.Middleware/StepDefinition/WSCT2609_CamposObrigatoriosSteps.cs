﻿using System;
using TechTalk.SpecFlow;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT2609_CamposObrigatoriosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresa()
        {
            
        }
        
        [Given(@"acessei o item de menu “Gestão de Beneficiários / Solicitações / Consultar Solicitações”")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesConsultarSolicitacoes()
        {
            
        }
        
        [When(@"eu clicar sobre o botão “Consultar” sem o preenchimento dos campos obrigatórios")]
        public void QuandoEuClicarSobreOBotaoConsultarSemOPreenchimentoDosCamposObrigatorios()
        {
            
        }
        
        [Then(@"o sistema NÃO deverá efetivar o registro de  solicitação")]
        public void EntaoOSistemaNAODeveraEfetivarORegistroDeSolicitacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"destacar os campos obrigatórios com a mensagem ""(.*)"" ao lado de cada campo")]
        public void EntaoDestacarOsCamposObrigatoriosComAMensagemAoLadoDeCadaCampo(string p0)
        {
            resposta = empresa.GetHttpWebRequest("TipoSolicitacao/ListarTipoSolicitacao", "json", 200, null, null, null);
            
        }
    }
}
