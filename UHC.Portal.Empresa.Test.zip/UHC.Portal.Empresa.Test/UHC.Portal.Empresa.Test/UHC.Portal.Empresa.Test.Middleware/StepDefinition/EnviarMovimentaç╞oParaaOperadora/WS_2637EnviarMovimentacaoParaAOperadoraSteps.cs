﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_2637EnviarMovimentacaoParaAOperadoraSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
          DateTime today;
        string todayDateFormat;
        
        #endregion

        [Given(@"QUE eu já fiz login no Portall Empresa ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortallEmpresa(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menuMovimentação Cadastral / Enviar Movimentação Para a Operadora")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralEnviarMovimentacaoParaAOperadora()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"seguir os passos indicadoss na US \[(.*)] - Busca Contrato")]
        public void DadoSeguirOsPassosIndicadossNaUS_BuscaContrato(int p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Given(@"clicar em_enviarMovimentacaoo ""(.*)""")]
        public void DadoClicarEm_EnviarMovimentacaoo(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Given(@"os campos obrigatórios referentess aos Dados Contato estão preenchidos \(""(.*)"", ""(.*)"", ""(.*)"" e ""(.*)""\)")]
        public void DadoOsCamposObrigatoriosReferentessAosDadosContatoEstaoPreenchidosE(string p0, string p1, string p2, string p3)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema será redirecionadoo para a tela “Protocolo de Envio de Movimentação Cadastral”")]
        public void EntaoOSistemaSeraRedirecionadooParaATelaProtocoloDeEnvioDeMovimentacaoCadastral()
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"mostrará a mensagemm “Lote Fechado com Sucesso\. Fechamento do Protocolo Automático nº \[número do protocolo]”")]
        public void EntaoMostraraAMensagemmLoteFechadoComSucesso_FechamentoDoProtocoloAutomaticoNºNumeroDoProtocolo()
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"mostrará umm grid contendo a\(s\) movimentação\(ões\) realizada\(s\)")]
        public void EntaoMostraraUmmGridContendoASMovimentacaoOesRealizadaS()
        {
            resposta = empresa.GetHttpWebRequest("Lote/ConsultarControleLote/"+ lstEmpresaData.Contrato, "json", 200, null, null, null);

          
            Console.WriteLine(resposta);
        }
    }
}
