﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.CancelarSuspensaoDeBeneficiario
{
    [Binding]
    public class WS22029PesquisaBeneficiarioParaCancelamentoDeSuspensaoSteps
    {

        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Suspensao ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaSuspensao(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"Que eu tenha acessado o Menu Movimentação Cadastral e Menu Suspensão de Beneficiário")]
        public void QuandoQueEuTenhaAcessadoOMenuMovimentacaoCadastralEMenuSuspensaoDeBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BeneficiarySuspensionReasons", "json", 200, new string[] {"Cancelamento Suspensão Adm. de Benefícios","Suspensão Administradora de Benefícios"}, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("COD_MOTIVO_SUSPENSAO_ADM"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("motivo suspensao is not multiple");
            }
        }

        [Then(@"e clique em Pesquisar e entao Em seguida, o sistema exibirá uma mensagem O beneficiário não possui")]
        public void EntaoECliqueEmPesquisarEEntaoEmSeguidaOSistemaExibiraUmaMensagemOBeneficiarioNaoPossui()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContrato/"+ listEmpresaData.NumContrato+"/"+ listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("There are multiple num contrato values");
            }
        }
    }
}
