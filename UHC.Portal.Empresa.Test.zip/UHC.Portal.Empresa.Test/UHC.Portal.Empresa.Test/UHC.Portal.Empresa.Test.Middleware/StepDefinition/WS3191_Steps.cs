﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3191_BuscarMunicipioIBGEParaAlterarBeneficiarioSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar Município Para Alterar Cadastro de Beneficiários ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarMunicipioParaAlterarCadastroDeBeneficiarios(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Clique no campo do Código Município do IBGE")]
        public void QuandoCliqueNoCampoDoCodigoMunicipioDoIBGE()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os municípios de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsMunicipiosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/BuscaDadosAlteracaoCadastral?codTs=" + empresaData.codTs + "&numContrato=" + empresaData.NumContrato + "&codigoUsuario=" + empresaData.CodigoUsuario, "json", 200, new string[] { "codigoBairro", "siglaUF", "complemento", "numero", "logradouro", "codigoTipoLogradouro", "cep", "indCobrancaEndereco", "indCorrespondenciaEndereco" }, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/Opcionais/" + empresaData.CodTsContrato, "json", 200, new string[] { "COD_ADITIVO", "NOM_ADITIVO" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContratoTitular/" + empresaData.CodTsContrato, "json", 200, new string[] { "NOME_TITULAR_CONTRATO", "IND_PLANO_DIF", "NUM_CONTRATO", "IND_AUTO_GESTAO", "IND_AUTONOMIA_ISENCAO_CAR", "IND_MATRICULA_DIF", "IND_OBRIGA_DT_ADMISSAO", "COD_TIPO_CONTRATO" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.CodTsContrato, "json", 200, new string[] { "null", "", "0" }, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaContatoDental/" + empresaData.CodigoGrupoEmpresa, "json", 200, new string[] { "[]" }, null, null);
            resposta = empresa.GetHttpWebRequest("EstadoCivil", "json", 200, new string[] { "identificador", "descricao" }, null, null);
            resposta = empresa.GetHttpWebRequest("ConfiguracaoSistema/Contrato/"+ empresaData.CodTsContrato+ "/Valor/BLOQUEIO_ALTERACAO_CADASTRAL", "json", 200, new string[] { "N" }, null, null);
            resposta = empresa.GetHttpWebRequest("Pais?exibirBrasil=true", "json", 200, new string[] { "codPaisEmissor", "nomePais" }, null, null);
            resposta = empresa.GetHttpWebRequest("OrgaoEmissor", "json", 200, new string[] { "COD_ORGAO_EMISSOR", "NOME_ORGAO" }, null, null);
            resposta = empresa.GetHttpWebRequest("Documento/Regra/" + empresaData.CodTsContrato+ "/"+empresaData.codTipoOperacao+ "?dataNascimento="+empresaData.dataNascimento+ "&inclusaoDepSozinha="+empresaData.inclusaoDepSozinha, "json", 200, new string[] { "Carteira de Habilitação OU Carteira de Identidade OU Comprovante de residência atual OU CPF " }, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaPlanos/" + empresaData.CodTsContrato, "json", 200, new string[] { "identificador", "descricao" }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/"+empresaData.Usuario+ "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }

        [Then(@"QUE eu já digitei totalmente ou parcialmente um município \(código/nome\) dentro do campo “Código Município do IBGE”")]
        public void EntaoQUEEuJaDigiteiTotalmenteOuParcialmenteUmMunicipioCodigoNomeDentroDoCampoCodigoMunicipioDoIBGE()
        {
            resposta = empresa.GetHttpWebRequest("Municipio?filter=" + empresaData.filter + "&limit="+empresaData.limit, "json", 200, new string[] { "codigoMunicipio", "codigoSemDv", "codigo", "descricao", "municipio", "siglaUF", "nomeUF" }, null, null);
        }

    }
}
