﻿using System;
using TechTalk.SpecFlow;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultadeLotes
{
    [Binding]
    public class WS4387CT_BuscarContratoParaConsultaDeLotesSteps
    {
        [Given(@"logar em Buscar Contrato Para Consulta de Lotes ""(.*)""")]
        public void DadoLogarEmBuscarContratoParaConsultaDeLotes(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"já acessei o item de menu “Movimentação Cadastral / Consultar Lotes”")]
        public void DadoJaAcesseiOItemDeMenuMovimentacaoCadastralConsultarLotes()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar no combobox no campo “Grupo Contrato/Contrato”")]
        public void QuandoEuClicarNoComboboxNoCampoGrupoContratoContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"osistema irá exibir todos os contratos/grupo contrato existentes para a empresa")]
        public void EntaoOsistemaIraExibirTodosOsContratosGrupoContratoExistentesParaAEmpresa()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
