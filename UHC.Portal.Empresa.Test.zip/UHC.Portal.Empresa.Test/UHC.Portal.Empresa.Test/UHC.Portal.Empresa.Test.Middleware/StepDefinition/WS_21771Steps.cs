﻿using System;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS21771RecuperarORelatorioUsandoAFilaDeExecucaoProcessamentoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Ativos Relatorio ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaAtivosRelatorio(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão Financeira e Demonstrativos/Menu Relatório Suspensão de Beneficiários")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoFinanceiraEDemonstrativosMenuRelatorioSuspensaoDeBeneficiarios()
        {
            resposta = empresa.GetHttpWebRequest("SuspensaoBeneficiaryReport/DiffDates/"+listEmpresaData.DateDiff, "json", 200, new string[] { "data_inicial", "data_final" }, null, null);            
        }
        
        [When(@"selecionam uma data usando o calendário ou manualmente")]
        public void QuandoSelecionamUmaDataUsandoOCalendarioOuManualmente()
        {
            resposta = empresa.GetHttpWebRequest("GrupoContrato?codGrupoEmpresa="+listEmpresaData.CodGrupoEmpresa, "json", 200, null, null, null);            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codTsContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem >1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"Ao clicar no ícone de expansão")]
        public void QuandoAoClicarNoIconeDeExpansao()
        {
            resposta = empresa.GetHttpWebRequest("Job/Parametros/"+listEmpresaData.CodigoJob+"/"+listEmpresaData.CodigoJobExecutado, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("idJob"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        

        [Then(@"Em seguida, o sistema recuperará os resultados considerando o período")]
        public void EntaoEmSeguidaOSistemaRecuperaraOsResultadosConsiderandoOPeriodo()
        {
            resposta = empresa.GetHttpWebRequest("Job/RelatorioExecutaJob?IdJob=" + listEmpresaData.IdJob + "&CodUser=" + listEmpresaData.CodigoUsuario + "&NumContratoIn=" + listEmpresaData.NumContratoIn + "&CodGrupoEmpresaIn =" + listEmpresaData.CodGrupoEmpresaIn + "&DataInicioSuspIni=" + listEmpresaData.DataInicioSuspIni + "&DataInicioSuspFim=" + listEmpresaData.DataInicioSuspFim + "&IndTipoRelatorio=" + listEmpresaData.IndTipoRelatorio + "&AuxTipoUsuario=" + listEmpresaData.AuxTipoUsuario, "json", 200, new string[] { "codigoRetorno", "mensagemRetorno" }, null, null);
        }
        [Then(@"todos os detalhes da consulta aparecerão")]
        public void EntaoTodosOsDetalhesDaConsultaAparecerao()
        {
            
        }
    }
}
