﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DemonstrativoDeCustoOperacional
{
    [Binding]
    public class UI2616DemonstrativoDeCustoOperacionalSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta, resposta1;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion

        [Given(@"QUE eu já fiz login Custo no Portal Empresa  ""(.*)""")]
        public void DadoQUEEuJaFizLoginCustoNoPortalEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"já acessei o item de menu Gestão Financeira e Demonstrativos / Demonstrativo de Custo Operacional")]
        public void DadoJaAcesseiOItemDeMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeCustoOperacional()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        [When(@"eu inserir o nome da empresa no campo Contratos")]
        public void QuandoEuInserirONomeDaEmpresaNoCampoContratos()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/"+listEmpresaData.CodigoUsuario+ "?apenasContratosAtivos=" + listEmpresaData.ApenasContratosAtivos, "json", 200, null, null, null);
            //resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + listEmpresaData.CodigoUsuario, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

            resposta1 = empresa.GetHttpWebRequest("Contrato/BuscarReferenciaMesAno/" + listEmpresaData.CodTipoCiclo , "json", 200, new string[] { "NUM_CICLO_TS", "MES_ANO_REF", "MES_ANO_ORDER" },null, null);            
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr = respostacorda1.Split(divididochar1);
            for (numContrato1 = 0; numContrato1 <= strArr1.Length - 1; numContrato1++)
            {
                if (strArr[numContrato1].Contains("NUM_CICLO_TS"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"eu insiro o nome da empresa no campo Contratos")]
        public void QuandoEuInsiroONomeDaEmpresaNoCampoContratos()
        {
            resposta = empresa.GetHttpWebRequest("CustoOperacional/" + listEmpresaData.CodTsContratoNao, "json", 200, null, null, null);
        }
        [When(@"eu clicar no código desejado na coluna Fatura")]
        public void QuandoEuClicarNoCodigoDesejadoNaColunaFatura()
        {
            json = "{" +
               "\"numSeqCobranca\":\"" + listEmpresaData.numSeqCobranca + "\"," +
               "\"codOperadora\":\"" + listEmpresaData.CodOperadora + "\"," +
               "\"codSucursal\":\"" + listEmpresaData.CodSucursal + "\"," +
               "\"codInspetoriaTS\":\"" + listEmpresaData.CodInspetoriaTS + "\"," +
               "\"codMarca\":\"" + listEmpresaData.CodMarca + "\"," +
               "\"numCarteira\":\"" + listEmpresaData.NumCarteira + "\"," +
               "\"indTipoProduto\":\"" + listEmpresaData.IndTipoProduto + "\"," +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContrato + "\"," +
               "\"codUsuario\":\"" + listEmpresaData.CodUsuario + "\"," +
               "\"modulo\":\"" + listEmpresaData.Modulo + "\"," +
               "\"ip\":\"" + listEmpresaData.Ip + "\"," +
               "\"senha\":\"" + listEmpresaData.Senha + "\"," +
               "\"sistema\":\"" + listEmpresaData.Sistema + "\"," +
               "\"codTs\":\"" + listEmpresaData.codTs + "\"," +
               "\"nomeDestinatario\": \"" + listEmpresaData.NomeDestinatario + "\"" +
              "}";

            Console.WriteLine(json);           
            
        }

        [Then(@"o sistema gerará um Demonstrativo de Custo Operacional em formato PFD")]
        public void EntaoOSistemaGeraraUmDemonstrativoDeCustoOperacionalEmFormatoPFD()
        {
            resposta = empresa.PostHttpWebRequest("CustoOperacional/PdfDemonstrativo", "json"
                , 200
                , null
                , null
                , json);
        }


        [Then(@"seguida, o sistema mostrará o respectivo contrato E o sistema retornará a mensagem Nenhum registro foi encontrado para a configuração informada\.")]
        public void EntaoSeguidaOSistemaMostraraORespectivoContratoEOSistemaRetornaraAMensagemNenhumRegistroFoiEncontradoParaAConfiguracaoInformada_()
        {
            resposta = empresa.GetHttpWebRequest("CustoOperacional/"+listEmpresaData.CodTsContratoNao, "json", 200, new string[] { "[]" }, null, null);            
        }
        [Then(@"o sistema irá mostrar o respectivo contrato para o nomedigitado")]
        public void EntaoOSistemaIraMostrarORespectivoContratoParaONomedigitado()
        {
            resposta = empresa.GetHttpWebRequest("CustoOperacional/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);
        }
        [Then(@"o sistema mostrará um grid com todas as faturas geradas para a empresa")]
        public void EntaoOSistemaMostraraUmGridComTodasAsFaturasGeradasParaAEmpresa()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numSeqCobranca"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

    }
}
