﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3194_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar Banco Para Alterar Cadastro de Beneficiários ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarBancoParaAlterarCadastroDeBeneficiarios(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Clique no campo do Banco")]
        public void QuandoCliqueNoCampoDoBanco()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá listar/apresentar abaixo da combo as Bancos de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarApresentarAbaixoDaComboAsBancosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Banco?Filter=" + empresaData.filter + "&Limit=" + empresaData.limit, "json", 200, new string[] { "nome", "codigo" }, null, null);
        }
    }
}
