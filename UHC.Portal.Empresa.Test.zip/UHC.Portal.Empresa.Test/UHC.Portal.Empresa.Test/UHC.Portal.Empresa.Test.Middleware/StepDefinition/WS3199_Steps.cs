﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3199_BuscarEmpresaParaAlterarBeneficiarioSituacaoEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma empresa \(código/nome\) dentro do combo “Empresa” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaEmpresaCodigoNomeDentroDoComboEmpresa(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar sobre alguma “empresa” listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaEmpresaListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Empresa” o código e nome da “empresa” correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoEmpresaOCodigoENomeDaEmpresaCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/Empresas?Limit=" + empresaData.limit, "json", 200, new string[] { "codigo", "descricao" }, null, null);
        }
    }
}
