﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_24558BuscarBeneficiarioParaConsultarAutorizacoesTokenSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"eu já fiz login no Portal Empresa_Buscar Beneficiário Para Consultar Autorizações Token""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresa_BuscarBeneficiarioParaConsultarAutorizacoesToken(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menuBuscar Beneficiário Para Consultar Autorizações Token “Gestão de Beneficiários / Consultar Autorizações Token”")]
        public void DadoAcesseiOItemDeMenuBuscarBeneficiarioParaConsultarAutorizacoesTokenGestaoDeBeneficiariosConsultarAutorizacoesToken()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sobre o botão “Buscar” ao lado do campoBuscar Beneficiário Para Consultar Autorizações Token  ""(.*)""")]
        public void QuandoEuClicarSobreOBotaoBuscarAoLadoDoCampoBuscarBeneficiarioParaConsultarAutorizacoesToken(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá apresentar a popup para busca de beneficiários \(titular e dependente\)_ Buscar Beneficiário Para Consultar Autorizações Token")]
        public void EntaoOSistemaDeveraApresentarAPopupParaBuscaDeBeneficiariosTitularEDependente_BuscarBeneficiarioParaConsultarAutorizacoesToken()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+empresaData.NumContrato+"&listarTodos=true&suspenso=true","json", 200, null, null, null);

        }
    }
}
