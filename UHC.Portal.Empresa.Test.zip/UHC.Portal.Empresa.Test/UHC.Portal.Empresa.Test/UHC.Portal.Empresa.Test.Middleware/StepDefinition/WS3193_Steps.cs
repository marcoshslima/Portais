﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3193_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar CBO Para Alterar Cadastro de Beneficiários ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarCBOParaAlterarCadastroDeBeneficiarios(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Clique no campo do CBO")]
        public void QuandoCliqueNoCampoDoCBO()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o sistema deverá listar/apresentar abaixo da combo as CBOs de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarApresentarAbaixoDaComboAsCBOsDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Documento/GetBanners", "json", 200, new string[] { "nome", "descricao", "label", "link", "status", "statusEdicao", "tags", "corpo" }, null, null);
            resposta = empresa.GetHttpWebRequest("Documento/GetComunicados", "json", 200, new string[] { "nome", "descricao", "label", "link", "status", "statusEdicao", "tags", "corpo" }, null, null);
            resposta = empresa.GetHttpWebRequest("Login/"+empresaData.Usuario+"/Linhas?somenteAtivos="+empresaData.SomenteAtivos, "json", 200, new string[] { "AMIL" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/GetContratoMatriz/" + empresaData.CodigoGrupoEmpresa, "json", 200, new string[] { "numeroContratoMae", "nomeContratoMae" }, null, null);
            resposta = empresa.GetHttpWebRequest("PendenciasCadastrais/AlertaBeneficiario/Exibir/" + empresaData.tipoUsuario+ "/"+empresaData.CodIdentificacaoTs, "json", 200, new string[] { "N" }, null, null);
        }

        [Then(@"QUE eu já digitei totalmente ou parcialmente um CBO \(código/nome\) dentro do campo “CBO”")]
        public void EntaoQUEEuJaDigiteiTotalmenteOuParcialmenteUmCBOCodigoNomeDentroDoCampoCBO()
        {
            resposta = empresa.GetHttpWebRequest("ClassificacaoBrasileiraOcupacoes?Filter=" + empresaData.filter + "&limit=" + empresaData.limit, "json", 200, new string[] { "codCbo", "nomeCbo" }, null, null);
        }
    }
}
