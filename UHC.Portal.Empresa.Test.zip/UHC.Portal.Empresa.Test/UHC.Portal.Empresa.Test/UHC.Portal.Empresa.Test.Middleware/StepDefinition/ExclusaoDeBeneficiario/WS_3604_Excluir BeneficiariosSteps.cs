﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ExclusaoDeBeneficiario
{
    [Binding]
    public class WS3604ExcluirBeneficiariosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Excluir ben ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaExcluirBen(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Movimentação Cadastral/ Excluir Beneficiários")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralExcluirBeneficiarios()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        [Given(@"cliquei no botão Salvar depois de preencher os detalhes necessários")]
        public void DadoCliqueiNoBotaoSalvarDepoisDePreencherOsDetalhesNecessarios()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/" + listEmpresaData.NumSeqAssociadoWeb + "/DadosExcluirBeneficiarioEdicao", "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numSeqAssociadoWeb"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"o sistema processar a inclusão da movimentação de exclusão COM SUCESSO")]
        public void QuandoOSistemaProcessarAInclusaoDaMovimentacaoDeExclusaoCOMSUCESSO()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/Ocorrencias/" + listEmpresaData.NumSeqAssociadoWeb, "json", 200, new string[] { "[]" }, null, null);
        }
        [Then(@"deverá apresentar a seguinte mensagem na modal Operação realizada com sucesso\. Após concluir todo os processo de movimentação cadastral, clicar no Menu Lateral e selecionar a opção Enviar Movimentação para a Operadora\.")]
        public void EntaoDeveraApresentarASeguinteMensagemNaModalOperacaoRealizadaComSucesso_AposConcluirTodoOsProcessoDeMovimentacaoCadastralClicarNoMenuLateralESelecionarAOpcaoEnviarMovimentacaoParaAOperadora_()
        {
            json = "{" +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContratoNovo + "\"," +
               "\"nomeContato\":\"" + listEmpresaData.NomeContato + "\"," +
               "\"nomeCargoContrato\":\"" + listEmpresaData.NomeCargoContrato + "\"," +
               "\"numDDD\":\"" + listEmpresaData.NumDDD + "\"," +
               "\"numTelefone\":\"" + listEmpresaData.NumTelefone + "\"," +
               "\"txtEmailContato\":\"" + listEmpresaData.TxtEmailContato + "\"," +
               "\"indEmailMovCadastral\":\"" + listEmpresaData.IndEmailMovCadastral + "\"," +
               "\"dtNascimento\":\"" + listEmpresaData.DtNascimento + "\"," +
               "\"numRamal\":" + "\"\"," +
               "\"dddCelular\":\"" + listEmpresaData.DddCelular + "\"," +
               "\"numCelular\":\"" + listEmpresaData.NumCelular + "\"," +
               "\"indAcao\":\"" + listEmpresaData.IndAcao + "\"," +
               "\"codUsuarioAtu\":\"" + listEmpresaData.CodUsuarioAtu + "\"," +
               "\"numSeqContato\":" + listEmpresaData.NumSeqContato +
            "}"; 
            resposta = empresa.PostHttpWebRequest("Contato/AtualizaContatosContrato", "json", 200, new string[] { "0" }, null, json);
        }

        [Then(@"após eu clicar no OK da modal, não exibir mensagens no topo da tela, e apresentar botões Salvar e Excluir")]
        public void EntaoAposEuClicarNoOKDaModalNaoExibirMensagensNoTopoDaTelaEApresentarBotoesSalvarEExcluir()
        {
            json = "{" +
                "\"nomeArquivo\":" + listEmpresaData.NullValue + "," +
               "\"mesAnoRef\":\"" + listEmpresaData.MesAnoRef + "\"," +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContratoNovo + "\"," +
               "\"codGrupoEmpresa\":" + listEmpresaData.NullValue + "," +
               "\"usuarioCarga\":\"" + listEmpresaData.UsuarioCarga + "\"," +
               "\"dtCargaIni\":" + listEmpresaData.NullValue + "," +
               "\"dtCargaFim\":" + listEmpresaData.NullValue + "," +
               "\"enderecoIp\":\"" + listEmpresaData.EnderecoIp + "\"," +
               "\"numSeqControleLote\":" + listEmpresaData.NullValue + "," +
               "\"numSeqControleLote2\":" + listEmpresaData.NullValue + "," +
               "\"codRetorno\":" + listEmpresaData.NullValue + "," +
               "\"msgRetorno\":" + listEmpresaData.NullValue + "," +
            "}";
            resposta = empresa.PostHttpWebRequest("Lote/FechaLote", "json", 200, null, null, json);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("Lote fechado com sucesso.Fechamento do Protocolo Parcial nº."))  // check for <BR>
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Sucess message displayed more than once");
            }




        }
        [Then(@"clicou no botão salvar depois de preencher os campos obrigatórios")]
        public void EntaoClicouNoBotaoSalvarDepoisDePreencherOsCamposObrigatorios()
        {
            json = "{" +
               "\"autorizacaoExtra\":\"" + listEmpresaData.AutorizacaoExtra + "\"," +
               "\"processaLote\":\"" + listEmpresaData.ProcessaLote + "\"," +
               "\"operacao\":\"" + listEmpresaData.Operacao + "\"," +
               "\"codUsuario\":\"" + listEmpresaData.CodUsuario + "\"," +
               "\"usuarioAutorizacao\":\"" + listEmpresaData.UsuarioAutorizacao + "\"," +
               "\"enderecoIp\":\"" + listEmpresaData.EnderecoIp + "\"," +
               "\"autorizado\":\"" + listEmpresaData.Autorizado + "\"," +
               "\"txtAutorizacao\":\"" + listEmpresaData.TxtAutorizacao + "\"," +
               "\"motivoRecusa\":\"" + listEmpresaData.MotivoRecusa + "\"," +
               "\"codMensagem\":\"" + listEmpresaData.CodMensagem + "\"," +
               "\"txtSolicitaAutorizacao\":\"" + listEmpresaData.TxtSolicitaAutorizacao + "\"," +
               "\"siglaArea\":\"" + listEmpresaData.SiglaArea + "\"," +
               "\"analiseLote\":\"" + listEmpresaData.AnaliseLote + "\"," +
               "\"codSituacaoAssociadoWeb\":\"" + listEmpresaData.CodSituacaoAssociadoWeb + "\"," +
               "\"txtAcao\":\"" + listEmpresaData.TxtAcao + "\"," +
               "\"numSeqAssociadoWeb\":\"" + listEmpresaData.NumSeqAssociadoWeb + "\"," +
               "\"codGrupoCarencia\":\"" + listEmpresaData.CodGrupoCarencia + "\"," +
               "\"tipoCarencia\":\"" + listEmpresaData.TipoCarencia + "\"," +
               "\"indTipoPessoaContrato\":\"" + listEmpresaData.IndTipoPessoaContrato + "\"," +
               "\"numSeqControleLote\":\"" + listEmpresaData.NumSeqControleLote + "\"," +
               "\"beneficiario\":\"" + "{" +
               "\"mesAnoRef\":\"" + listEmpresaData.MesAnoRef + "\"," +
               "\"numAssociado\":\"" + listEmpresaData.NumAssociado + "\"," +
               "\"nomeAssociado\":\"" + listEmpresaData.NomeAssociado + "\"," +
               "\"numAssociadoTitular\":\"" + listEmpresaData.NumAssociadoTitular + "\"," +
               "\"nomeAssociadoTitular\":\"" + listEmpresaData.NomeAssociadoTitular + "\"," +
               "\"codTs\":\"" + listEmpresaData.codTs + "\"," +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContrato + "\"," +
               "\"codEmpresa\":\"" + listEmpresaData.CodEmpresa + "\"," +
               "\"indMovimentoDental\":\"" + listEmpresaData.IndMovimentoDental + "\"," +
               "\"codTsDental\":\"" + listEmpresaData.CodTsDental + "\"," +
               "\"dataExclusao\":\"" + listEmpresaData.DataExclusao + "\"," +
               "\"codMotivoExclusao\":\"" + listEmpresaData.CodMotivoExclusao + "\"," +
               "\"tipoAssociado\":\"" + listEmpresaData.TipoAssociado + "\"," +
               "\"indContributario\":\"" + listEmpresaData.IndContributario + "\"," +
               "\"numSeqControleArq\":\"" + listEmpresaData.NumSeqControleArq + "\"," +
               "\"numContrato\":\"" + listEmpresaData.NumContrato + "\"," +
               "\"email\":\"" + listEmpresaData.Email + "\"," +
               "\"nomSituacaoAssociado\":\"" + listEmpresaData.NomSituacaoAssociado + "\"," +
               "\"anexo\":\"" + "{" +
                   "\"qtdAnexo\":\"" + listEmpresaData.QtdAnexo + "\"," +
                   "\"registro\":\"" + "[" +
                       "{"+
                           "\"dataAnexado\":\"" + listEmpresaData.DataAnexado + "\"," +
                           "\"descricao\":\"" + listEmpresaData.Descricao + "\"," +
                           "\"localArquivamento\":\"" + listEmpresaData.LocalArquivamento + "\"," +
                           "\"codigoUsuarioAtu\":\"" + listEmpresaData.CodigoUsuarioAtu + "\"," +
                           "\"nomeArquivoAnexo\":\"" + listEmpresaData.NomeArquivoAnexo + "\"," +
                           "\"localArquivamento\":\"" + listEmpresaData.LocalArquivamento + "\"," +
                           "\"indExcluir\":\"" + listEmpresaData.IndExcluir + "\"," +
                           "\"numSeqAssociadoAnexo\":\"" + listEmpresaData.NumSeqAssociadoAnexo + "\"," +
                           "\"guid\":\"" + listEmpresaData.Guid + "\"," +
                           "\"nomeDestinatario\": \"" + listEmpresaData.NomeDestinatario + "\"" +
                       "}"+
                       "]"+
               "}"+
            "}"+
         "}";
            resposta = empresa.PostHttpWebRequest("Beneficiario/ExcluirBeneficiario", "json"
                , 200
                , null
                , null
                , json);
        }
        [Then(@"clique no menu lateral e selecione a opção Enviar movimento para o operador")]
        public void EntaoCliqueNoMenuLateralESelecioneAOpcaoEnviarMovimentoParaOOperador()
        {
            resposta = empresa.GetHttpWebRequest("Lote/GetLote/"+listEmpresaData.codTsContrato+"?mesAnoRef="+listEmpresaData.MesAnoRef, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codtipooperacao"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            resposta = empresa.GetHttpWebRequest("Lote/DadosContato/"+listEmpresaData.codTsContrato, "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato1 = 0; numContrato1 <= strArr1.Length - 1; numContrato1++)
            {
                if (strArr[numContrato1].Contains("COD_TS_CONTRATO"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

        }

    }
}
