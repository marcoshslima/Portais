﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;


namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ExclusaoDeBeneficiario
{
    
    [Binding]
    public class WS3603AnexarDocumentacaoParaExclusaoDeBeneficiarioSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Excluir Portal Empresa  ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoExcluirPortalEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"acessei o item de menu Movimentação Cadastral / Excluir Beneficiários")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralExcluirBeneficiarios()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }    
        
        [Given(@"selecionei um beneficiário titular OU beneficiário dependente")]
        public void DadoSelecioneiUmBeneficiarioTitularOUBeneficiarioDependente()
        {

            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.NumContrato +"&listarTodos="+listEmpresaData.listarTodos+"&suspenso="+listEmpresaData.suspenso, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numero_contrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [Given(@"já realizei o preenchimento dos campos obrigatórios")]
        public void DadoJaRealizeiOPreenchimentoDosCamposObrigatorios()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+listEmpresaData.NumAssociado+"&listarTodos="+listEmpresaData.listarTodos+"&suspenso="+listEmpresaData.suspenso, "json", 200, null, null, null);                                                 
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("nome_associado"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [Given(@"já realizei o preenchimento dos campos obrigatórios e  cliquei sobre o botão Adicionar arquivo")]
        public void DadoJaRealizeiOPreenchimentoDosCamposObrigatoriosECliqueiSobreOBotaoAdicionarArquivo()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + listEmpresaData.CodUsuario, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("null"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }           
        }
              

        [When(@"eu clicar sobre o botão Adicionar arquivo")]
        public void QuandoEuClicarSobreOBotaoAdicionarArquivo()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/DadosExcluirBeneficiario/"+listEmpresaData.codTs+"/"+listEmpresaData.codTsContrato+"/"+listEmpresaData.NumAssociado+"/"+listEmpresaData.tipoUsuario, "json", 200, null, null, null);
                                            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("COD_MOTIVO_EXC_ASSOC"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"realizei o preenchimento dos campos Local Arquivamento e Descrição  e selecionei um arquivo no campo Anexo e clico no botão salvar")]
        public void QuandoRealizeiOPreenchimentoDosCamposLocalArquivamentoEDescricaoESelecioneiUmArquivoNoCampoAnexoEClicoNoBotaoSalvar()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/MotivoExclusao/"+listEmpresaData.IndTipoPessoaContrato +"/"+listEmpresaData.AtivaRn, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if ((strArr[numContrato].Contains("COD_MOTIVO_EXC_ASSOC")) && (strArr[numContrato].Contains("NOME_MOTIVO_EXC_ASSOC")))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            /*
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            */
        }

        [When(@"clicar sobre o botão Confirmar da mensagem Registro será enviado para análise da Operadora\. Confirma o envio")]
        public void QuandoClicarSobreOBotaoConfirmarDaMensagemRegistroSeraEnviadoParaAnaliseDaOperadora_ConfirmaOEnvio()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/"+listEmpresaData.CodUsuario, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoUsuario"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }            
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr1 = respostacorda.Split(divididochar1);
            for (numContrato1 = 0; numContrato1 <= strArr.Length - 1; numContrato1++)
            {
                if (strArr[numContrato1].Contains("null"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            resposta = empresa.GetHttpWebRequest("Lote/GetMovPendentes/" + listEmpresaData.codTsContrato+"/"+ listEmpresaData.MesAnoRef +"/"+ listEmpresaData.IndTipoUsuario, "json", 200, null, null, null);
            string[] strArr2 = null;
            string respostacorda2 = resposta.ToString();
            char[] divididochar2 = { ',' };
            int numContrato2 = 0;
            int numContratocontagem2 = 0;
            strArr2 = respostacorda.Split(divididochar2);
            for (numContrato2 = 0; numContrato2 <= strArr2.Length - 1; numContrato2++)
            {
                if (strArr2[numContrato2].Contains("qtdmovimentacaopendente"))
                {
                    numContratocontagem2 = numContratocontagem2 + 1;
                }
            }
            /*
            // valor validation
            if (!(numContratocontagem2 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            */
            
        }
        
        [Then(@"o sistema deverá apresentar os campos Local Arquivamento/Anexo e Descrição")]
        public void EntaoOSistemaDeveraApresentarOsCamposLocalArquivamentoAnexoEDescricao()
        {            
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("0"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [Then(@"o sistema deverá gerar a solicitação de inclusão contendo o\(s\) anexo\(s\) adicionado\(s\)")]
        public void EntaoOSistemaDeveraGerarASolicitacaoDeInclusaoContendoOSAnexoSAdicionadoS()
        {
            resposta = empresa.GetHttpWebRequest("Contato/PesquisarDadosContato/"+listEmpresaData.codTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("nomeContato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            resposta = empresa.GetHttpWebRequest("Lote/GetLote/" + listEmpresaData.codTsContrato+"?mesAnoRef="+listEmpresaData.MesAnoRef, "json", 200, null, null, null);
            
        }

        [Then(@"apresentar a mensagem Operação registrada com sucesso\. Gerado o protocolo \[número do protocolo] para acompanhamento\.")]
        public void EntaoApresentarAMensagemOperacaoRegistradaComSucesso_GeradoOProtocoloNumeroDoProtocoloParaAcompanhamento_()
        {           
            resposta = empresa.GetHttpWebRequest("Lote/ConsultarControleLote/"+listEmpresaData.NumSeqControleLote, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroSequenciaControleLote"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }          

        }
        [Given(@"selecionei um arquivo no campo Anexo")]
        public void DadoSelecioneiUmArquivoNoCampoAnexo()
        {
            //resposta = empresa.PostHttpWebRequest("Contrato/Anexo", "json", 200, null, null, null);
        }

        [Then(@"o sistema apresentou os detalhes para busca do beneficiário")]
        public void EntaoOSistemaApresentouOsDetalhesParaBuscaDoBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/"+listEmpresaData.NumContrato+"/"+listEmpresaData.codTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [Then(@"o sistema deverá apresentar uma seção para adicionar os documentos necessários para a exclusão")]
        public void EntaoOSistemaDeveraApresentarUmaSecaoParaAdicionarOsDocumentosNecessariosParaAExclusao()
        {
            resposta = empresa.PostHttpWebRequest("Contrato/Anexo", "json", 200, null, null, null);
        }


        

    }
}
