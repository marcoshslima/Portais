﻿using System;
using TechTalk.SpecFlow;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.Utils;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT2654_Consulta_RedeCredenciadaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        [Given(@"que eu já entrei no ""(.*)""")]
        public void DadoQueEuJaEntreiNo(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            //listEmpresaData = "MA648064";
        }

        [When(@"realizo a funcionalidade de pesquisa usando a ""(.*)""")]
        public void QuandoRealizoAFuncionalidadeDePesquisaUsandoA(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o sistema apresentará as informações da rede credenciadas nas empresas do portal")]
        public void EntaoOSistemaApresentaraAsInformacoesDaRedeCredenciadasNasEmpresasDoPortal()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Login/" + empresaData.Usuario + "/Planos", "json", 200, null, null, null);
            
        }

    }
}
