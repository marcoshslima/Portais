﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DeclaraçãodeIR
{
    [Binding]
    public class WS_10486BuscarBeneficiarioParaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion
        [Given(@"eu já fiz login no Portal Empresaa  E acessei o item de menu “Gestão de Beneficiários / Demonstrativos e Declarações / Declaração de IR”  ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresaaEAcesseiOItemDeMenuGestaoDeBeneficiariosDemonstrativosEDeclaracoesDeclaracaoDeIR(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"dado os dados exigidos")]
        public void DadoDadoOsDadosExigidos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"seguida, WebService deve obter as informações necessárias Benefeciaro")]
        public void EntaoSeguidaWebServiceDeveObterAsInformacoesNecessariasBenefeciaro()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + empresaData.NumContrato + "&listarTodos=true&suspenso=true", "json", 200, null, null, null);
            Console.WriteLine(resposta);
        }
    }
}
