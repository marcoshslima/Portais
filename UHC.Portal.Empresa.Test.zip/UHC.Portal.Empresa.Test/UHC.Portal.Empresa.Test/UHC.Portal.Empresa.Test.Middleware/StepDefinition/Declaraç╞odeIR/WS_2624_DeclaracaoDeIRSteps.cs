﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DeclaraçãodeIR
{
    [Binding]
    public class WS_2624_DeclaracaoDeIRSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        [Given(@"eu já fiz login no Portal Empresa   E acessei o item de menu “Gestão de Beneficiários / Demonstrativos e Declarações / Declaração de IR”  ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresaEAcesseiOItemDeMenuGestaoDeBeneficiariosDemonstrativosEDeclaracoesDeclaracaoDeIR(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Preencha todos os campos obrigatórios")]
        public void QuandoPreenchaTodosOsCamposObrigatorios()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sobre o botão Gerar Relatório")]
        public void QuandoEuClicarSobreOBotaoGerarRelatorio()
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá gerar e apresentar o demonstrativo de valores pagos à Amil, de acordo com o preenchimento dos campos de filtro\. \[PROTÓTIPO (.*)]")]
        public void EntaoOSistemaDeveraGerarEApresentarODemonstrativoDeValoresPagosAAmilDeAcordoComOPreenchimentoDosCamposDeFiltro_PROTOTIPO(int p0)
        {
            resposta = empresa.GetHttpWebRequest("DeclaracaoIr/" + empresaData.codTs+ "/"+empresaData.AnoCalendario+"/"+empresaData.Usuario+"/"+ empresaData.CodigoTipoArquivo+"/"+empresaData.codigoTipoOperacao+"/PDF", "json", 200, null, null, null);

        }
    }
}
