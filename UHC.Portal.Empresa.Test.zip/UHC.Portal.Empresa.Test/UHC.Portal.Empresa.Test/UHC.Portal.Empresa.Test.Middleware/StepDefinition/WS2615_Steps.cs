﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2615_DemonstrativoDeTrocaDeFaixaEtariaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logado no portal Empresa para Formato da Consulta PDF da Demonstrativo de troca de faixa etária ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaFormatoDaConsultaPDFDaDemonstrativoDeTrocaDeFaixaEtaria(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"selecione o contrato desejado no menu suspenso '(.*)'")]
        public void DadoSelecioneOContratoDesejadoNoMenuSuspenso(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema gerará um Demonstrativo de Troca de Faixa Etária em formato '(.*)'")]
        public void EntaoOSistemaGeraraUmDemonstrativoDeTrocaDeFaixaEtariaEmFormato(string p0)
        {
            if(p0 == "PDF")
            {
                json = "{" +

                "\"tipoRelatorio\": \""+empresaData.TipoRelatorio+"\"," +
                "\"codigoRelatorio\": \"" + empresaData.CodigoRelatorio + "\"," +
                "\"usuario\": \"" + empresaData.Usuario + "\"," +
                "\"senha\": \"" + empresaData.Senha + "\"," +
                "\"ip\": \"" + empresaData.Ip + "\"," +
                "\"sistema\": \"" + empresaData.Sistema + "\"," +
                "\"modulo\": \"" + empresaData.Modulo + "\"," +
                "\"parametros\"" + ": [" +
                    "{" +
                        "\"chave\": \"pCodTsContrato\"," +
                        "\"valor\": \"" + empresaData.TipoRelatorio + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pNumCicloTs\"," +
                        "\"valor\": "+empresaData.PNumCicloTs
                    + "}," +
                    "{" +
                        "\"chave\": \"pMesAnoRef\"," +
                        "\"valor\": \"" + empresaData.PMesAnoRef + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pCodOperadora\"," +
                        "\"valor\": \"" + empresaData.PCodOperadora + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pCodSucursal\"," +
                        "\"valor\": \"" + empresaData.PCodSucursal + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pCodInspetoriaTs\"," +
                        "\"valor\": \"" + empresaData.PCodInspetoriaTs + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pOrdenacao\"," +
                        "\"valor\": \"" + empresaData.POrdenacao + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pIndQuebra\"," +
                        "\"valor\": \"" + empresaData.PIndQuebra + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pIndiceRelat\"," +
                        "\"valor\": \"" + empresaData.PIndiceRelat + "\""
                    + "}," +
                    "{" +
                        "\"chave\": \"pCodTipoCiclo\"," +
                        "\"valor\": \"" + empresaData.PCodTipoCiclo + "\""
                    + "}" 
                              + "]" +
                          "}";
                resposta = empresa.PostHttpWebRequest("Relatorio", "json", 200, new string[] { "mensagem", "codigo" }, null, json);
            }
            else
            {
                json = "{" +
                "\"codInspetoriaTs\": \"" + empresaData.PCodInspetoriaTs + "\"," +
                "\"codOperadora\": \"" + empresaData.PCodOperadora + "\"," +
                "\"codSucursal\": \"" + empresaData.PCodSucursal + "\"," +
                "\"codTsContrato\": \"" + empresaData.PCodTsContrato + "\"," +
                "\"codUsuario\": \"" + empresaData.Usuario + "\"," +
                "\"ip\": \"" + empresaData.Ip + "\"," +
                "\"indQuebra\": \"" + empresaData.PIndQuebra + "\"," +
                "\"numCicloTs\": " + empresaData.PNumCicloTs + "," +
                "\"senha\": \"" + empresaData.Senha + "\"," +
                "\"mesAnoRef\": \"" + empresaData.mesAnoRef + "\"" +
                          "}";
                resposta = empresa.PostHttpWebRequest("DemonstrativoTrocaFaixaEtaria", "json", 200, new string[] { "mensagem", "codigo" }, null, json);
            }
        }
    }
}
