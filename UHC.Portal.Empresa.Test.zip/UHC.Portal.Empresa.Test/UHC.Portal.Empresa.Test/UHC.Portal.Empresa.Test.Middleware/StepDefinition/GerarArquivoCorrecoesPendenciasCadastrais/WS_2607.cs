﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GerarArquivoCorrecoesPendenciasCadastrais
{
    [Binding]
    public class WS2607_GerarArquivoCorrecoesPendenciasCadastraisSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Gerar ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaGerar(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Gestão de Beneficiário / Gerar Arquivo Correções Pendências Cadastrais")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiarioGerarArquivoCorrecoesPendenciasCadastrais()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"o sistema apresentou a tela para gerar o arquivo de correções de pendências cadastrais")]
        public void DadoOSistemaApresentouATelaParaGerarOArquivoDeCorrecoesDePendenciasCadastrais()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.NumContrato + "/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [Given(@"selecionei um contrato")]
        public void DadoSelecioneiUmContrato()
        {
            resposta = empresa.GetHttpWebRequest("PendenciasCadastrais/Correcoes/Executar/"+listEmpresaData.CodigoUsuario +"/"+listEmpresaData.CodTsContrato+"/"+listEmpresaData.Ip, "json", 200, null, null, null);            
        }
        
        [When(@"eu clicar sobre o botão Executar")]
        public void QuandoEuClicarSobreOBotaoExecutar()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("mensagemRetorno"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"eu clicar preencher o campo Data da solicitação com uma data inicial e final, ambas válidas e COM arquivos  de correções de pendências cadastrais para o período informado")]
        public void QuandoEuClicarPreencherOCampoDataDaSolicitacaoComUmaDataInicialEFinalAmbasValidasECOMArquivosDeCorrecoesDePendenciasCadastraisParaOPeriodoInformado()
        {
            resposta = empresa.GetHttpWebRequest("Job/ExecutadosCrypto/" + listEmpresaData.CodigoUsuario + "/" + listEmpresaData.CodigoJob + "/" + DateTime.Now.ToString("dd-MM-yyyy") + "/" + DateTime.Now.ToString("dd-MM-yyyy"), "json", 200, null, null, null);
        }
        [When(@"eu clicar preencher o campo Data da solicitação com uma data inicial e final, ambas válidas e SEM arquivos  de correções de pendências cadastrais para o período informado  mensagem informando que não há arquivos na fila de execução")]
        public void QuandoEuClicarPreencherOCampoDataDaSolicitacaoComUmaDataInicialEFinalAmbasValidasESEMArquivosDeCorrecoesDePendenciasCadastraisParaOPeriodoInformadoMensagemInformandoQueNãoHáArquivosNaFilaDeExecução()
        {
            resposta = empresa.GetHttpWebRequest("Job/ExecutadosCrypto/" + listEmpresaData.CodigoUsuarioAtu + "/" + listEmpresaData.CodigoJob + "/" + DateTime.Now.ToString("dd-MM-yyyy") + "/" + DateTime.Now.ToString("dd-MM-yyyy"), "json", 200, new string[] { "[]" }, null, null);
        }       
        [Then(@"o sistema deverá apresentar uma tela contendo dados e detalhes e o link para acesso e visualização do\(s\) arquivo\(s\) gerados")]
        public void EntaoOSistemaDeveraApresentarUmaTelaContendoDadosEDetalhesEOLinkParaAcessoEVisualizacaoDoSArquivoSGerados()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("idJob"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [Then(@"o sistema deverá apresentar uma listagem contendo os arquivos que estão na fila de execução")]
        public void EntaoOSistemaDeveraApresentarUmaListagemContendoOsArquivosQueEstaoNaFilaDeExecucao()
        {
            resposta = empresa.GetHttpWebRequest("Job/ExecutadosCrypto/" +listEmpresaData.CodigoUsuario + "/"+listEmpresaData.CodigoJob +"/"+ DateTime.Now.ToString("dd-MM-yyyy") + "/"+ DateTime.Now.ToString("dd-MM-yyyy"), "json", 200, null, null, null);
        }
        
        [Then(@"gerar um arquivo contendo as correções referentes às pendências cadastrais do contrato em questão")]
        public void EntaoGerarUmArquivoContendoAsCorrecoesReferentesAsPendenciasCadastraisDoContratoEmQuestao()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("idJob"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
    }
}
