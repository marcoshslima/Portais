﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Demonstrativodecoparticipação
{
    [Binding]
    public class UI10283CT_BuscarCEPTipoDeConsultaCaixaPostalComunitariaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar CEP Para Buscar CEP Para Demonstrativo de Co-Participação – Tipo de Consulta Caixa Postal Comunitária ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarCEPParaBuscarCEPParaDemonstrativoDeCo_ParticipacaoTipoDeConsultaCaixaPostalComunitaria(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUE eu já realizei a busca de endereços por tipo de consulta Cx\. Postal Comunitária")]
        public void DadoQUEEuJaRealizeiABuscaDeEnderecosPorTipoDeConsultaCx_PostalComunitaria()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/Login/" + empresaData.Usuario + "/false", "json", 200, new string[] { "codigo", "cnpj", "razaoSocial", "nomeFantasia", "codigoTsContrato" }, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + empresaData.numeroContrato + "&listarTodos=true&suspenso=true", "json", 200, new string[] { empresaData.codTsContrato, empresaData.numeroContrato, "numero_contrato", "cod_ts_contrato", "nome_associado", "numero_associado" }, null, null);
            resposta = empresa.GetHttpWebRequest("TipoLogradouro", "json", 200, new string[] { "codigo", "descricao", "abreviacao" }, null, null);
            resposta = empresa.GetHttpWebRequest("TituloPatentes", "json", 200, new string[] { "codigo", "descricao" }, null, null);
        }
        [When(@"eu clicar sobre o botão de seleção contido em algum endereço na listagem de resultados de Caixa Postal Comunitária")]
        public void QuandoEuClicarSobreOBotaoDeSelecaoContidoEmAlgumEnderecoNaListagemDeResultadosDeCaixaPostalComunitaria()
        {
            resposta = empresa.GetHttpWebRequest("UF", "json", 200, new string[] { "codigo", "sigla", "descricao" }, null, null);
            resposta = empresa.GetHttpWebRequest("Municipio/Estado/"+empresaData.SiglaUF, "json", 200, new string[] { "chaveLocDne", "nomeOfiLocalidade" }, null, null);
        }

        [Then(@"o sistema irá realizar o preenchimento automático dos campos ”CEP”, “Logradouro”, “Município”, “UF” e “Bairro” contidos na Demonstrativo de co-participação tela para informar endereço")]
        public void EntaoOSistemaIraRealizarOPreenchimentoAutomaticoDosCamposCEPLogradouroMunicipioUFEBairroContidosNaDemonstrativoDeCo_ParticipacaoTelaParaInformarEndereco()
        {
            resposta = empresa.GetHttpWebRequest("Endereco/Cep/CaixaPostalComunitaria/"+empresaData.SiglaUF+"/"+empresaData.CodigoLocalidade, "json", 200, new string[] { "cep", "siglaUF", "codigoMunicipio", "municipio", "codigoBairro", "bairro" }, null, null);
        }

    }
}
