﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Demonstrativodecoparticipação
{
    [Binding]
    public class WS10206CT_BuscarContratoEBeneficiarioParaDemonstrativoDeCo_ParticipacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar Contrato e Beneficiário Para Demonstrativo de Co-Participação ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarContratoEBeneficiarioParaDemonstrativoDeCo_Participacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"eu selecionei um contrato")]
        public void DadoEuSelecioneiUmContrato()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + empresaData.numeroContrato + "/" + empresaData.codTsContrato, "json", 200, new string[] { empresaData.numeroContrato, empresaData.codTsContrato }, null, null);
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente um beneficiário \(marca ótica / nome\) dentro do campo “Selecione o beneficiário”")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmBeneficiarioMarcaOticaNomeDentroDoCampoSelecioneOBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + empresaData.numeroContrato+ "&listarTodos=true&suspenso=true", "json", 200, new string[] { empresaData.codTsContrato,empresaData.numeroContrato, "numero_contrato", "cod_ts_contrato", "nome_associado", "numero_associado" }, null, null);
        }
        
        [When(@"eu clicar sobre algum beneficiário listado abaixo da combo para Buscar Contrato e Beneficiário Para Demonstrativo de Co-Participação")]
        public void QuandoEuClicarSobreAlgumBeneficiarioListadoAbaixoDaComboParaBuscarContratoEBeneficiarioParaDemonstrativoDeCo_Participacao()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/CompetenciaCoParticipacao/" + empresaData.codigoTsContrato, "json", 200, new string[] { "numeroControleCopartSeq", "mesAnoReferencia", "dataVencimento"}, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Selecione o beneficiário” o nome e marca ótica do beneficiário correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoSelecioneOBeneficiarioONomeEMarcaOticaDoBeneficiarioCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/EnderecosNovo/" + empresaData.codTsBeneficiario, "json", 200, new string[] { "indResidencia", "indCorresp", "indCobranca", "indExterior", "codPais" }, null, null);
        }
    }
}
