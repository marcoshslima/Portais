﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Demonstrativodecoparticipação
{
    [Binding]
    public class UI10281CT_BuscarCEPParaDemonstrativoDeCo_ParticipacaoTipoDeConsultaCaixaPostalSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar CEP Para Demonstrativo de Co-Participação – Tipo de Consulta Caixa Postal ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarCEPParaDemonstrativoDeCo_ParticipacaoTipoDeConsultaCaixaPostal(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUE eu já realizei a busca de endereços por tipo de consulta Caixa Postal")]
        public void DadoQUEEuJaRealizeiABuscaDeEnderecosPorTipoDeConsultaCaixaPostal()
        {
            resposta = empresa.GetHttpWebRequest("TipoLogradouro", "json", 200, new string[] { "codigo", "descricao", "abreviacao" }, null, null);
            resposta = empresa.GetHttpWebRequest("TituloPatentes", "json", 200, new string[] { "codigo", "descricao" }, null, null);
        }
        
        [When(@"eu clicar sobre o botão de seleção contido em algum endereço na listagem de resultados")]
        public void QuandoEuClicarSobreOBotaoDeSelecaoContidoEmAlgumEnderecoNaListagemDeResultados()
        {
            resposta = empresa.GetHttpWebRequest("UF", "json", 200, new string[] { "codigo", "sigla", "descricao" }, null, null);
            resposta = empresa.GetHttpWebRequest("Municipio/Estado/" + empresaData.SiglaUF, "json", 200, new string[] { "chaveLocDne", "nomeOfiLocalidade" }, null, null);
        }
        
        [Then(@"o sistema irá realizar o preenchimento automático dos campos ”CEP”, “Logradouro”, “Município”, “UF” e “Bairro” contidos na popup para informar endereço")]
        public void EntaoOSistemaIraRealizarOPreenchimentoAutomaticoDosCamposCEPLogradouroMunicipioUFEBairroContidosNaPopupParaInformarEndereco()
        {
            resposta = empresa.GetHttpWebRequest("Endereco/Cep/CaixaPostal/" + empresaData.SiglaUF + "/" + empresaData.CodigoLocalidade +"/"+ empresaData.CaixaPostal, "json", 200, new string[] { "cep", "siglaUF", "codigoMunicipio", "municipio", "codigoBairro", "bairro" }, null, null);
        }
    }
}
