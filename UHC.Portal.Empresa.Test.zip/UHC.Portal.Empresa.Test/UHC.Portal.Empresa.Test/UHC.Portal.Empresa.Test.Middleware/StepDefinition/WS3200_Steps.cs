﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3200_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma ARH \(código/nome\) dentro da combo “ARH” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaARHCodigoNomeDentroDaComboARH(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [When(@"eu clicar sobre alguma “ARH” listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaARHListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “ARH” o código e nome da “ARH” correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoARHOCodigoENomeDaARHCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/ARH?Limit=" +empresaData.limit, "json", 200, new string[] { "codigo", "descricao" }, null, null);
        }
    }
}
