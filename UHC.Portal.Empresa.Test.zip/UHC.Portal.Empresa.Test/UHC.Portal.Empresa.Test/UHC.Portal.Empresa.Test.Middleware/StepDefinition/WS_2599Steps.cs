﻿using System;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2599ConsultarInformacoesDeReembolsoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa consultar informacoes ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaConsultarInformacoes(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"acessei o item de menu Gestão de Contratos/ Consultar Informações de Reembolso")]
        public void DadoAcesseiOItemDeMenuGestaoDeContratosConsultarInformacoesDeReembolso()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + listEmpresaData.CodTsContrato + "/" + listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            
        }
        
        [Given(@"o sistema apresentou a tela de filtro para informações de reembolso")]
        public void DadoOSistemaApresentouATelaDeFiltroParaInformacoesDeReembolso()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoTSContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("codigoTSContrato has not repeated morethan once");
            }
            
        }
        
        [Given(@"selecionei um contrato no campo Selecione o contrato")]
        public void DadoSelecioneiUmContratoNoCampoSelecioneOContrato()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.NumContrato + "/" + listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("nomeEntidade"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [Given(@"o sistema carregou a combo Negociação com negociações correspondentes ao contrato selecionado")]
        public void DadoOSistemaCarregouAComboNegociacaoComNegociacoesCorrespondentesAoContratoSelecionado()
        {
            Verification.Wait(3);
        }
        
        [Given(@"selecionei uma negociação no campo Negociação")]
        public void DadoSelecioneiUmaNegociacaoNoCampoNegociacao()
        {
            resposta = empresa.GetHttpWebRequest("Plano/GetPlanosReembolso?cod_ts_contrato="+listEmpresaData.CodTsContratoReembolso+"&dt_ini_cobranca="+listEmpresaData.DtIniCobranca, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("COD_PLANO"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >=1))
            {
                Assert.Fail("COD_PLANO has come only once");
            }
           
        }
        
        [When(@"eu selecionar um plano COM dados de reembolso no campo Plano")]
        public void QuandoEuSelecionarUmPlanoCOMDadosDeReembolsoNoCampoPlano()
        {
            
            resposta = empresa.GetHttpWebRequest("Reembolso/GetDadosPagamento/"+listEmpresaData.CodTsContratoReembolso+"/"+listEmpresaData.DtIniVigencia+"/"+listEmpresaData.CodPlanoAgr, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("quantidadeDiasPgamentoRBM"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("quantidadeDiasPgamentoRBM has repeated morethan once");
            }
        }
        [When(@"eu selecionar um plano SEM dados de reembolso no campo Plano")]
        public void QuandoEuSelecionarUmPlanoSEMDadosDeReembolsoNoCampoPlano()
        {
            resposta = empresa.GetHttpWebRequest("Reembolso/GetDadosPagamento/" + listEmpresaData.CodTsContratoReembolso + "/" + listEmpresaData.DtIniVigencia + "/" + listEmpresaData.CodPlanoDep, "json", 200, new string[] { "null","null"}, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("quantidadeDiasPgamentoRBM"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("quantidadeDiasPgamentoRBM has repeated morethan once");
            }
        }

        

        [Then(@"o sistema deverá apresentar os procedimentos contendo dados/valores referente ao reembolso para cada procedimento apresentado")]
        public void EntaoOSistemaDeveraApresentarOsProcedimentosContendoDadosValoresReferenteAoReembolsoParaCadaProcedimentoApresentado()
        {
            resposta = empresa.GetHttpWebRequest("Reembolso/"+listEmpresaData.CodTsContratoReembolso + "/" + listEmpresaData.DtIniCobranca + "/" + listEmpresaData.CodPlanoAgr, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoTSContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("codigoTSContrato is displayed only once");
            }
            
        }
        [Then(@"o sistema NÃO irá apresentar procedimento\(s\) com dados de reembolso E deverá apresentar a mensagem Nenhuma informação foi encontrada com o critério de seleção estabelecido")]
        public void EntaoOSistemaNAOIraApresentarProcedimentoSComDadosDeReembolsoEDeveraApresentarAMensagemNenhumaInformacaoFoiEncontradaComOCriterioDeSelecaoEstabelecido()
        {
            resposta = empresa.GetHttpWebRequest("Reembolso/" + listEmpresaData.CodTsContratoReembolso + "/" + listEmpresaData.DtIniVigencia + "/" + listEmpresaData.CodPlanoDep, "json", 200, new string[] { }, null, null);
            
        }
    }
}
