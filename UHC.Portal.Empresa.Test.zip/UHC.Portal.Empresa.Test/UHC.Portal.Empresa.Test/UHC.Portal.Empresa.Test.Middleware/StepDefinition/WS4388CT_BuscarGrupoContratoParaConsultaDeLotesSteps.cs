﻿using System;
using TechTalk.SpecFlow;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultadeLotes
{
    [Binding]
    public class WS4388CT_BuscarGrupoContratoParaConsultaDeLotesSteps
    {
        [Given(@"Faça login no portal para testar no Consulta de Lotes funcionalidad ""(.*)""")]
        public void DadoFacaLoginNoPortalParaTestarNoConsultaDeLotesFuncionalidad(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Consultar Lotes”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralConsultarLotes()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o número do grupo contrato no campo ""(.*)""")]
        public void QuandoEuInserirONumeroDoGrupoContratoNoCampo(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivo grupo contrato para o número digitado")]
        public void EntaoOSistemaIraMostrarORespectivoGrupoContratoParaONumeroDigitado()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
