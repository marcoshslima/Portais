﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.RegistrarSolicitace
{
    [Binding]
    public class WS_2608_RegistrarSolicitacoes
    {
        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;

        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Registrar solicitação")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaRegistrarSolicitacao()
        {
            listEmpresaData = new WS_Empresa_Data("REGISTRAR SOLICITACOES");
        }

        [Given(@"acessei o item de menu Gestão de Beneficiários / Solicitações / Registrar Solicitações")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesRegistrarSolicitacoes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"selecionei um contrato no campo Selecione o contrato")]
        public void QuandoSelecioneiUmContratoNoCampoSelecioneOContrato()
        {
            resposta = empresa.GetHttpWebRequest("Solicitacao/Regioes", "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroSequenciaRegiao"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("numeroSequenciaRegiao displayed only ones");
            }
            resposta = empresa.GetHttpWebRequest("Solicitacao/Motivos", "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigo"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("codigo displayed only ones");
            }
            resposta = empresa.GetHttpWebRequest("Solicitacao/TiposEndereco", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + listEmpresaData.Usuario + "/" + listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.Contrato + "/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&listarTodos=" + listEmpresaData.apenasContratosAtivos + "&suspenso=" + listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);

        }

        [Then(@"clicar sobre o botão ""(.*)""")]
        public void EntaoClicarSobreOBotao(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "1", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "3", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "4", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "5", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "2", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Solicitacao/EnderecosDoTipo/" + listEmpresaData.codigoTsBeneficiario + "/" + listEmpresaData.codigoTsContrato + "/" + "6", "json", 200, null, null, null);
        }

        [Then(@"o sistema deverá efetivar o registro de  solicitaçã e apresentar uma mensagem de sucesso")]
        public void EntaoOSistemaDeveraEfetivarORegistroDeSolicitacaEApresentarUmaMensagemDeSucesso()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosFamilia/" + listEmpresaData.codigoTsBeneficiario, "json", 200, null, null, null);


            this.json =
                "{" +
  "\"codigoUsuario\":" + "\"MA985791\"," +
  "\"ip\":" + "\"189.20.205.221\"," +
  "\"solicitacoes\":" + "[" +
    "{" +
      "\"codigoMotivoSegunda\": " + "21," +
      "\"numeroSequenciaRegiao\": " + "\"\"," +
      "\"codigoTs\":" + "\"46525939\"," +
      "\"nomeAssociado\": " + "\"AYRA GUEDES ZISCHEGG\"," +
      "\"numeroAssociado\":" + "\"071991146\"," +
      "\"codigoTipoEnderecoCarteira\":" + "\"1\"," +
      "\"indiceCartaoOrientador\": " + "1," +
      "\"indiceTipoOrientador\": " + "\"C\"," +
      "\"indiceEnvioCarteiraInativo\": " + "\"1\"," +
      "\"indiceAposDemissao\": " + "\"0\"," +
      "\"codigoBairro\":" + "\"\"," +
      "\"codigoMunicipio\": " + "\"\"," +
      "\"codigoTipoLogradouro\":" + "\"\"," +
      "\"nomeLogradouro\":" + "\"\"," +
      "\"numeroCep\":" + "\"\"," +
      "\"numeroEndereco\":" + "\"\"," +
      "\"textoComplemento\":" +"\"\"" +
   "}"+
  "]"+
"}";

            resposta = empresa.PostHttpWebRequest("Solicitacao/Registrar", "json", 200, new string[] { "Operação realizada com sucesso" }, null, this.json);
        }
    }
}   

