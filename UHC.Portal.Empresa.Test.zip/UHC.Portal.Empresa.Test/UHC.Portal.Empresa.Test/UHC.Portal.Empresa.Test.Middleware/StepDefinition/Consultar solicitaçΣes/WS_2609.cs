﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Consultar_solicitações
{
    [Binding]
    public class WS_2609
    {
        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion


        [Given(@"QUE eu já fiz login no Portal Empresa Consultar Solicitações")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaConsultarSolicitacoes()
        {
            listEmpresaData = new WS_Empresa_Data("REGISTRAR SOLICITACOES");
        }
        
        [Given(@"acessei o item de menu Gestão de Beneficiários / Solicitações / Consultar Solicitações”")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesConsultarSolicitacoes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"realizei o preenchimento de todos os campos")]
        public void QuandoRealizeiOPreenchimentoDeTodosOsCampos()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + listEmpresaData.Usuario + "/" + listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("TipoSolicitacao/ListarTipoSolicitacao", "json", 200, null, null, null);

        }
        
        [When(@"eu clicar sobre o botão Enviar")]
        public void QuandoEuClicarSobreOBotaoEnviar()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.Contrato + "/" + listEmpresaData.codTsContrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&listarTodos=" + listEmpresaData.apenasContratosAtivo + "&suspenso=" + listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
        }

        [Then(@"o sistema NÃO deverá exibir o histórico de solicitações mensagem ""Não existe histórico de solicitações para o filtro")]
        public void EntaoOSistemaNAODeveraExibirOHistoricoDeSolicitacoesMensagemNaoExisteHistoricoDeSolicitacoesParaOFiltro()
        {
            resposta = empresa.GetHttpWebRequest("Solicitacao / Pesquisar ? CodigoTsContrato=" + listEmpresaData.codTsContrato + "& CodTs = " + listEmpresaData.CodTs + "& DtIni=" + listEmpresaData.DtIni + "& DtFim =" + listEmpresaData.DtFim + "& CodUsuario =" + listEmpresaData.Usuario, "json", 200, null, null, null);
           // Solicitacao / Pesquisar ? CodigoTsContrato = 16747488 & CodTs = 48709920 & DtIni = 2018 - 09 - 04 & DtFim = 2018 - 10 - 02 & CodUsuario = MA985791
        }
    }
}
