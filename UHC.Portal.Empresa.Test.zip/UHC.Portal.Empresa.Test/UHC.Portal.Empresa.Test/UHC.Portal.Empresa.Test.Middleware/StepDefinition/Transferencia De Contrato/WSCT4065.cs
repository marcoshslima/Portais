﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4065_BuscarEmpresaParaTransferenciaDeContratoSituacaoEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        #endregion

        [Given(@"QUE eu já digitei totalmente ou parcialmente uma empresa \(código/nome\) dentro da combo “Empresa” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaEmpresaCodigoNomeDentroDaComboEmpresa(string p0)
        {
            
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo Empresa")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboEmpresa(int p0)
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu clicar sobre alguma empresa listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaEmpresaListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu digitar um código/nome de empresa inexistente dentro do campo Empresa")]
        public void QuandoEuDigitarUmCodigoNomeDeEmpresaInexistenteDentroDoCampoEmpresa()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo as empresas cadastradas de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboAsEmpresasCadastradasDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro da combo “Empresa” o código e nome da empresa correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDaComboEmpresaOCodigoENomeDaEmpresaCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo Empresa")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaComboEmpresa()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas", "json", 200, null, null, null);
        }
    }
}
