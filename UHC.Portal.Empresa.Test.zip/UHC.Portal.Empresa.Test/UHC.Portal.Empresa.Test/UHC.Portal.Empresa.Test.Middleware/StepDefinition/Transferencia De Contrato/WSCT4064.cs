﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4064_BuscarEmpresaParaTransferenciaDeContratoSituacaoEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        #endregion

        [Given(@"eu já digitei totalmente ou parcialmente um status \(código/nome\) dentro do campo “Status” ""(.*)""")]
        public void DadoEuJaDigiteiTotalmenteOuParcialmenteUmStatusCodigoNomeDentroDoCampoStatus(string p0)
        {
            
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo Status")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboStatus(int p0)
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu clicar sobre algum status listado abaixo da combo")]
        public void QuandoEuClicarSobreAlgumStatusListadoAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu digitar um código/nome de empresa inexistente dentro do campo Status")]
        public void QuandoEuDigitarUmCodigoNomeDeEmpresaInexistenteDentroDoCampoStatus()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os status cadastrados de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsStatusCadastradosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Status", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Status” o código e nome do status correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoStatusOCodigoENomeDoStatusCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Status", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo Status")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaComboStatus()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Status", "json", 200, null, null, null);
        }
    }
}
