﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4068_SelecionarPSAParaTransferenciaDeContratoSituacaoEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu ""(.*)""")]
        public void DadoAcesseiOItemDeMenu(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"selecionei um beneficiário titular sem dependente\(s\)")]
        public void DadoSelecioneiUmBeneficiarioTitularSemDependenteS()
        {
            
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma PSA dentro do campo PSA ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaPSADentroDoCampoPSA(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo “PSA”")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboPSA(int p0)
        {
            
        }
        
        [When(@"eu clicar sobre alguma PSA listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaPSAListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu digitar um nome de PSA inexistente dentro do campo “PSA”")]
        public void QuandoEuDigitarUmNomeDePSAInexistenteDentroDoCampoPSA()
        {
            
        }
        
        [Then(@"o sistema deverá listar abaixo da combo as PSA's de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboAsPSASDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+ listEmpresaData .Contrato+ "&TipoAssociado=T&NumAssociado=PSA&listarTodos=false&suspenso=true", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “PSA” o nome da PSA correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoPSAONomeDaPSACorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&NumAssociado=PSA&listarTodos=false&suspenso=true", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo “PSA”")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaComboPSA()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&NumAssociado=PSA&listarTodos=false&suspenso=true", "json", 200, null, null, null);
        }
    }
}
