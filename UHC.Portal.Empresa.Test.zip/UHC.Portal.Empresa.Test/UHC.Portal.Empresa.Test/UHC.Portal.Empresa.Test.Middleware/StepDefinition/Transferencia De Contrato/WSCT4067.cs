﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4067_BuscarUniOrgTransfContSitEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Organizacional Portal Empresa ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoOrganizacionalPortalEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"acessei o item de menu Organizacional ""(.*)""")]
        public void DadoAcesseiOItemDeMenuOrganizacional(string p0)
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }

        [Given(@"selecionei um beneficiário titular sem dependente\(s\) Organizacional")]
        public void DadoSelecioneiUmBeneficiarioTitularSemDependenteSOrganizacional()
        {
            
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma unidade organizacional \(código/nome\) dentro da combo ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaUnidadeOrganizacionalCodigoNomeDentroDaCombo(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo ""(.*)""")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaCombo(int p0, string p1)
        {
            listEmpresaData = new WS_Empresa_Data(p1);
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&NumAssociado="+p1+"&listarTodos=false&suspenso=true", "json", 200, null, null, null);
        }
        
        [When(@"eu clicar sobre alguma lotação listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaLotacaoListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu digitar um código/nome de unidade organizacional inexistente dentro da combo ""(.*)""")]
        public void QuandoEuDigitarUmCodigoNomeDeUnidadeOrganizacionalInexistenteDentroDaCombo(string p0)
        {
            
        }
        
        [Then(@"o sistema deverá listar abaixo da combo as PSA's de acordo com o que está sendo digitado")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboAsPSASDeAcordoComOQueEstaSendoDigitado()
        {
            
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo ""(.*)"" o código e nome da unidade organizacional correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoOCodigoENomeDaUnidadeOrganizacionalCorrespondente(string p0)
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&NumAssociado="+p0+"&listarTodos=false&suspenso=true", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo ""(.*)""")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaCombo(string p0)
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&NumAssociado=" + p0 + "&listarTodos=false&suspenso=true", "json", 200, null, null, null); 
        }
    }
}
