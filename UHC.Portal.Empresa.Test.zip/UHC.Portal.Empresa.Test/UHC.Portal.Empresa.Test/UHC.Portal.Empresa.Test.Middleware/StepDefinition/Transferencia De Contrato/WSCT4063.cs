﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4063_BuscarCentroDeCustoParaTransferenciaDeContratoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Centro de Custo ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalCentroDeCusto(string p0)
        {
            
        }
        
        [Given(@"selecionei um beneficiário titular sem dependente\(s\) Centro de Custo")]
        public void DadoSelecioneiUmBeneficiarioTitularSemDependenteSCentroDeCusto()
        {
            
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente um centro de custo \(código/nome\) dentro do campo “Centro de Custo” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmCentroDeCustoCodigoNomeDentroDoCampoCentroDeCusto(string p0)
        {
            
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo Centro de Custo")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboCentroDeCusto(int p0)
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu clicar sobre algum centro de custo listado abaixo da combo")]
        public void QuandoEuClicarSobreAlgumCentroDeCustoListadoAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os centro de custos de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsCentroDeCustosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Lotacao/VerificaLotacao/9900003885", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Centro de Custo” o código e nome do centro de custo correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoCentroDeCustoOCodigoENomeDoCentroDeCustoCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Lotacao/VerificaLotacao/9900003885", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo Centro de Custo")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaComboCentroDeCusto()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Lotacao/VerificaLotacao/3885", "json", 200, null, null, null);
        }
    }
}
