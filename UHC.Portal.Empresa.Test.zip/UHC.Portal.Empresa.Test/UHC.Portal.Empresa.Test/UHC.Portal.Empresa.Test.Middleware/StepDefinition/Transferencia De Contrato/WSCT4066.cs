﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT4066_BuscarUniOrgTransfContSitEspecialSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"selecionei um beneficiário titular sem dependente\(s\) ARH")]
        public void DadoSelecioneiUmBeneficiarioTitularSemDependenteSARH()
        {
            
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma ARH \(código/nome\) dentro da combo ARH ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaARHCodigoNomeDentroDaComboARH(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo ARH")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboARH(int p0)
        {
            
        }
        
        [When(@"eu clicar sobre alguma ARH listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaARHListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }
        
        [When(@"eu digitar um código/nome de ARH inexistente dentro do campo ARH")]
        public void QuandoEuDigitarUmCodigoNomeDeARHInexistenteDentroDoCampoARH()
        {
            
        }
        
        [Then(@"o sistema deverá listar abaixo da combo as ARH de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboAsARHDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas?Limit=ARH", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “ARH” o código e nome da ARH correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoARHOCodigoENomeDaARHCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas?Limit=ARH", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema não deverá listar/apresentar nada abaixo da combo ARH")]
        public void EntaoOSistemaNaoDeveraListarApresentarNadaAbaixoDaComboARH()
        {
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Nestle/Empresas?Limit=ARH", "json", 200, null, null, null);
        }

        [Given(@"QUE eu já fiz login no ARH Portal Empresa ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoARHPortalEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"acessei o item de menu ARH ""(.*)""")]
        public void DadoAcesseiOItemDeMenuARH(string p0)
        {
            empresa = new WebService(Ambiente.UrlMiddleware);
        }

    }
}
