﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class US4060_BuscarContratoParaTransferenciaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Contrato ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalContrato(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Contrato ""(.*)""")]
        public void DadoAcesseiOItemDeMenuContrato(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"cliquei sobre o botão “Buscar” ao lado do campo Contrato")]
        public void DadoCliqueiSobreOBotaoBuscarAoLadoDoCampoContrato()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+ listEmpresaData.Contrato+ "&TipoAssociado=T&listarTodos=false&suspenso=true", "json", 200, null, null, null);            
        }
        
        [Given(@"o sistema apresentou a popup para busca de Contrato")]
        public void DadoOSistemaApresentouAPopupParaBuscaDeContrato()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numero_contrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [When(@"eu clicar sobre o botão “Buscar” ao lado do campo Beneficiário")]
        public void QuandoEuClicarSobreOBotaoBuscarAoLadoDoCampoBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/"+ listEmpresaData.Beneficiario + "/Usuario/"+ listEmpresaData .Usuario+ "/DadosTransferenciaContrato", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá apresentar uma popup contendo os Beneficiário")]
        public void EntaoOSistemaDeveraApresentarUmaPopupContendoOsBeneficiario()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"eu clicar sobre algum contrato listado abaixo da combo")]
        public void QuandoEuClicarSobreAlgumContratoListadoAbaixoDaCombo()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato + "&TipoAssociado=T&listarTodos=false&suspenso=true", "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numero_contrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [Then(@"o sistema deverá transferir para dentro do campo Selecione o contrato o número do contrato e o nome da empresa")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoSelecioneOContratoONumeroDoContratoEONomeDaEmpresa()
        {
            resposta = empresa.GetHttpWebRequest("/Contrato/Login/"+listEmpresaData.CodigoUsuario + "/" +listEmpresaData.SomenteAtivos , "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigo"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
            resposta = empresa.GetHttpWebRequest("/Nestle/"+ listEmpresaData.CodigoContrato, "json", 200, null, null, null);
        }

    }
}
