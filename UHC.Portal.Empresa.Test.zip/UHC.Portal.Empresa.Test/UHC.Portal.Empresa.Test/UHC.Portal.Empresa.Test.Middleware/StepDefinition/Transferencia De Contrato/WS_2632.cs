﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Transferencia_De_Contrato
{
    [Binding]
    public class WS2632TransferenciaDeContratoCOMMUDANCANºBENEFSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta, resposta1, resposta2, resposta3;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Transferência de Contrato ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaTransferenciaDeContrato(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Movimentação Cadastral / Transferência de Contrato \(COM MUDANÇA N° BENEF\)")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralTransferenciaDeContratoCOMMUDANCANBENEF()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUE eu já realizei o preenchimento dos campos obrigatórios incorretamente")]
        public void DadoQUEEuJaRealizeiOPreenchimentoDosCamposObrigatoriosIncorretamente()
        {
            resposta = empresa.GetHttpWebRequest("Plano/CarregaPlanoMerito/" + listEmpresaData.CodTsContrato + " /" + listEmpresaData.DtTransferencia, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("COD_PLANO"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

            resposta = empresa.GetHttpWebRequest("Contrato/VerificaLocalTs/" + listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr1 = respostacorda1.Split(divididochar1);
            for (numContrato1 = 0; numContrato1 <= strArr1.Length - 1; numContrato1++)
            {
                if (strArr1[numContrato1].Contains("COD_LOCAL_TRABALHO"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

        }

        [When(@"eu clicar em Salvar")]
        public void QuandoEuClicarEmSalvar()
        {
            resposta = empresa.GetHttpWebRequest("Lotacao/VerificaLotacao/" + listEmpresaData.CodTsContrato , "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("COD_LOTACAO_TS"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (numContratocontagem > 1)
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"eu selecionei contrato")]
        public void QuandoEuSelecioneiContrato()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/" + listEmpresaData.CodigoContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("contratoNeste"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [When(@"eu selecionei um beneficiário sem dependentes")]
        public void QuandoEuSelecioneiUmBeneficiarioSemDependentes()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/Status?Limit=" + listEmpresaData.Limit, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigo"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

            resposta1 = empresa.GetHttpWebRequest("Nestle/Empresas?Limit=" + listEmpresaData.Limit, "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta1.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr1 = respostacorda1.Split(divididochar1);
            for (numContrato1 = 0; numContrato1 <= strArr1.Length - 1; numContrato1++)
            {
                if (strArr1[numContrato1].Contains("codigo"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

            resposta2 = empresa.GetHttpWebRequest("Nestle/ARH?Limit=" + listEmpresaData.Limit, "json", 200, null, null, null);
            string[] strArr2 = null;
            string respostacorda2 = resposta2.ToString();
            char[] divididochar2 = { ',' };
            int numContrato2 = 0;
            int numContratocontagem2 = 0;
            strArr2 = respostacorda2.Split(divididochar2);
            for (numContrato2 = 0; numContrato2 <= strArr2.Length - 1; numContrato2++)
            {
                if (strArr2[numContrato2].Contains("codigo"))
                {
                    numContratocontagem2 = numContratocontagem2 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem2 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }

            resposta3 = empresa.GetHttpWebRequest("Nestle/UnidadeOrganizacional?Filter=" + listEmpresaData.Filter + "&Limit=" + listEmpresaData.Limits, "json", 200, null, null, null);
            string[] strArr3 = null;
            string respostacorda3 = resposta3.ToString();
            char[] divididochar3 = { ',' };
            int numContrato3 = 0;
            int numContratocontagem3 = 0;
            strArr3 = respostacorda3.Split(divididochar3);
            for (numContrato3 = 0; numContrato3 <= strArr3.Length - 1; numContrato3++)
            {
                if (strArr3[numContrato3].Contains("codigo"))
                {
                    numContratocontagem3 = numContratocontagem3 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem3 >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");

            }

            resposta = empresa.GetHttpWebRequest("Nestle/PSA/"+ listEmpresaData.CodEmpresaNestle + "/"+ listEmpresaData.CodArhNestle, "json", 200, new string[] { "[]" }, null, null);           
        }       
        [Then(@"clique no botão Salvar")]
        public void EntaoCliqueNoBotaoSalvar()
        {
            json = "{" +
               "\"autorizacaoExtra\":\"" + listEmpresaData.AutorizacaoExtra + "\"," +
               "\"usuarioAutorizacao\":" + listEmpresaData.UsuarioAutorizacao + "," +
               "\"enderecoIp\":" + listEmpresaData.EnderecoIp + "," +
               "\"autorizado\":" + listEmpresaData.Autorizado + "," +
               "\"txtAutorizacao\":" + listEmpresaData.TxtAutorizacao + "," +
               "\"txtAcao\":\"" + listEmpresaData.TxtAcao + "\"," +
               "\"analiseLote\":\"" + listEmpresaData.AnaliseLote + "\"," +
               "\"codUsuario\":\"" + listEmpresaData.CodUsuario + "\"," +
               "\"planoDif\":\"" + listEmpresaData.PlanoDif + "\"," +
               "\"planoDifAgr\":\"" + listEmpresaData.PlanoDifAgr + "\"," +
               "\"numSeqAssociadoWeb\":" + listEmpresaData.NumSeqAssociadoWeb + "," +
               "\"codSituacaoAssociadoWeb\":\"" + listEmpresaData.CodSituacaoAssociadoWeb + "\"," +
               "\"mesAnoRef\":\"" + listEmpresaData.MesAnoRef + "\"," +
               "\"dataLimite\":\"" + listEmpresaData.DataLimite + "\"," +
               "\"numAssociado\":\"" + listEmpresaData.NumAssociado + "\"," +
               "\"nomeAssociado\":\"" + listEmpresaData.NomeAssociado + "\"," +
               "\"codTs\":\"" + listEmpresaData.codTs + "\"," +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContrato + "\"," +
               "\"numContrato\":\"" + listEmpresaData.NumContrato + "\"," +
               "\"codEmpresa\":\"" + listEmpresaData.CodEmpresa + "\"," +
               "\"tipoAssociado\":\"" + listEmpresaData.TipoAssociado + "\"," +
               "\"numSeqControleArq\":" + listEmpresaData.NumSeqControleArq + "," +
               "\"numSeqControleLote\":\"" + listEmpresaData.NumSeqControleLote + "\"," +
               "\"dataTransferencia\":\"" + listEmpresaData.DataTransferencia + "\"," +
               "\"codTsContratoNovo\":\"" + listEmpresaData.CodTsContratoNovo + "\"," +
               "\"codEmpresaNova\":" + listEmpresaData.CodEmpresaNova + "," +
               "\"codLotacaoTs\":" + listEmpresaData.CodLotacaoTs + "," +
               "\"codLocalTs\":" + listEmpresaData.CodLocalTs + "," +
               "\"nomePlano\":\"" + listEmpresaData.NomePlano + "\"," +
               "\"codPlanoNovo\":\"" + listEmpresaData.CodPlanoNovo + "\"," +
               "\"codPlanoDep\":\"" + listEmpresaData.CodPlanoDep + "\"," +
               "\"codPlanoAgr\":\"" + listEmpresaData.CodPlanoAgr + "\"," +
               "\"numMatricEmpresa\":\"" + listEmpresaData.NumMatricEmpresa + "\"," +
               "\"codPsaTs\":" + listEmpresaData.CodPsaTs + "," +
               "\"codStatusNestle\":" + listEmpresaData.CodStatusNestle + "," +
               "\"codUnidOrgNestle\":" + listEmpresaData.CodUnidOrgNestle + "," +
               "\"codEmpresaNestle\":" + listEmpresaData.CodEmpresaNestle + "," +
               "\"codArhNestle\":" + listEmpresaData.CodArhNestle + "," +

            "}";
        }

        [Then(@"o sistema deve gerar o pedido de transferência do contrato E ele exibirá a mensagem Operação registrada com sucesso")]
        public void EntaoOSistemaDeveGerarOPedidoDeTransferenciaDoContratoEEleExibiraAMensagemOperacaoRegistradaComSucesso()
        {
            resposta = empresa.PostHttpWebRequest("Beneficiario/TransferirContratoComMudancaNumero", "json"
                , 200
                , null
                , null
                , json);
        }

        [Then(@"o sistema retornará a mensagem Operação possui erros\. Realize os ajustes para ser concluída\.")]
        public void EntaoOSistemaRetornaraAMensagemOperacaoPossuiErros_RealizeOsAjustesParaSerConcluida_()
        {
            json = "{" +
               "\"autorizacaoExtra\":\"" + listEmpresaData.AutorizacaoExtra + "\"," +
               "\"usuarioAutorizacao\":" + listEmpresaData.UsuarioAutorizacao + "," +
               "\"enderecoIp\":" + listEmpresaData.EnderecoIp + "," +
               "\"autorizado\":" + listEmpresaData.Autorizado + "," +
               "\"txtAutorizacao\":" + listEmpresaData.TxtAutorizacao + "," +
               "\"txtAcao\":\"" + listEmpresaData.TxtAcao + "\"," +
               "\"analiseLote\":\"" + listEmpresaData.AnaliseLote + "\"," +
               "\"codUsuario\":\"" + listEmpresaData.CodUsuario + "\"," +
               "\"planoDif\":\"" + listEmpresaData.PlanoDif + "\"," +
               "\"planoDifAgr\":\"" + listEmpresaData.PlanoDifAgr + "\"," +
               "\"numSeqAssociadoWeb\":" + listEmpresaData.NumSeqAssociadoWeb + "," +
               "\"codSituacaoAssociadoWeb\":\"" + listEmpresaData.CodSituacaoAssociadoWeb + "\"," +
               "\"mesAnoRef\":\"" + listEmpresaData.MesAnoRef + "\"," +
               "\"dataLimite\":\"" + listEmpresaData.DataLimite + "\"," +
               "\"numAssociado\":\"" + listEmpresaData.NumAssociado + "\"," +
               "\"nomeAssociado\":\"" + listEmpresaData.NomeAssociado + "\"," +
               "\"codTs\":\"" + listEmpresaData.codTs + "\"," +
               "\"codTsContrato\":\"" + listEmpresaData.CodTsContrato + "\"," +
               "\"numContrato\":\"" + listEmpresaData.NumContrato + "\"," +
               "\"codEmpresa\":\"" + listEmpresaData.CodEmpresa + "\"," +
               "\"tipoAssociado\":\"" + listEmpresaData.TipoAssociado + "\"," +
               "\"numSeqControleArq\":" + listEmpresaData.NumSeqControleArq + "," +
               "\"numSeqControleLote\":\"" + listEmpresaData.NumSeqControleLote + "\"," +
               "\"dataTransferencia\":\"" + listEmpresaData.DataTransferencia + "\"," +
               "\"codTsContratoNovo\":\"" + listEmpresaData.CodTsContratoNovo + "\"," +
               "\"codEmpresaNova\":" + listEmpresaData.CodEmpresaNova + "," +
               "\"codLotacaoTs\":" + listEmpresaData.CodLotacaoTs + "," +
               "\"codLocalTs\":" + listEmpresaData.CodLocalTs + "," +
               "\"nomePlano\":\"" + listEmpresaData.NomePlano + "\"," +
               "\"codPlanoNovo\":\"" + listEmpresaData.CodPlanoNovo + "\"," +
               "\"codPlanoDep\":\"" + listEmpresaData.CodPlanoDep + "\"," +
               "\"codPlanoAgr\":\"" + listEmpresaData.CodPlanoAgr + "\"," +
               "\"numMatricEmpresa\":\"" + listEmpresaData.NumMatricEmpresa + "\"," +
               "\"codPsaTs\":" + listEmpresaData.CodPsaTs + "," +
               "\"codStatusNestle\":" + listEmpresaData.CodStatusNestle + "," +
               "\"codUnidOrgNestle\":" + listEmpresaData.CodUnidOrgNestle + "," +
               "\"codEmpresaNestle\":" + listEmpresaData.CodEmpresaNestle + "," +
               "\"codArhNestle\":" + listEmpresaData.CodArhNestle + "," +

            "}";
            resposta = empresa.PostHttpWebRequest("Beneficiario/TransferirContratoComMudancaNumero", "json", 200, null, null, json);
        }
    }
}
