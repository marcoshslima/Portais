﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class ImportarArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"u já acessei o item de menu ""(.*)""")]
        public void DadoUJaAcesseiOItemDeMenu(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"já segui os passos indicados na US \[(.*)] - Busca Contrato")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscaContrato(int p0)
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }

        [Given(@"eu já acessei o item de menu ""(.*)""")]
        public void DadoEuJaAcesseiOItemDeMenu(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        //[Given(@"eu já acessei o item de menu “""(.*)""")]
        //public void DadoEuJaAcesseiOItemDeMenu(string p0)
        //{
        //    ScenarioContext.Current.Pending();
        //}

        [When(@"o sistema identificar que o contrato refere-se à um Cliente Empresa")]
        public void QuandoOSistemaIdentificarQueOContratoRefere_SeAUmClienteEmpresa()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"o sistema identificar que o contrato refere-se à Porte I")]
        public void QuandoOSistemaIdentificarQueOContratoRefere_SeAPorteI()
        {
            resposta = empresa.GetHttpWebRequest("Job/Executados/" + empresaData.Usuario + "/" + empresaData.CodigoPlano + "/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);

        }


        [When(@"o sistema identificar que o contrato refere-se à um Cliente Externo")]
        public void QuandoOSistemaIdentificarQueOContratoRefere_SeAUmClienteExterno()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"o sistema identificar que o contrato refere-se à Porte II")]
        public void QuandoOSistemaIdentificarQueOContratoRefere_SeAPorteII()
        {
            resposta = empresa.GetHttpWebRequest("Job/Executados/" + empresaData.Usuario + "/" + empresaData.CodigoPlano + "/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);

        }

        [When(@"o sistema identificar que o contrato refere-se à um Cliente Individual")]
        public void QuandoOSistemaIdentificarQueOContratoRefere_SeAUmClienteIndividual()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o campo ""(.*)"" receberá o sysdate")]
        public void EntaoOCampoReceberaOSysdate(string p0)
        {
            Console.WriteLine(resposta);

        }
    }
}
