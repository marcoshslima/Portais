﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Controledeacessoportal
{
    [Binding]
    public class US6612CadastroDeAcessoPeloAdministrador
    {
        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"Que eu já fiz login no Portal Empresa-Controle acesso")]
        public void DadoQueEuJaFizLoginNoPortalEmpresa_ControleAcesso()
        {
            Usuario = "MA985791";
           
        }
        
        [Given(@"já acessei o item de menu Controle de Acesso ao Portal")]
        public void DadoJaAcesseiOItemDeMenuControleDeAcessoAoPortal()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"eu clicar em Adicionar Novo Administrador")]
        public void QuandoEuClicarEmAdicionarNovoAdministrador()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + Usuario + "/ Filhos", "json", 200, new string[]{"True"}, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + Usuario + "/ Dados", "json", 200, new string[] {"True"}, null, null);
        }
        
        [When(@"preencher todos os campos obrigatórios \(“Nome”, “Telefone”, “E-mail”, “Perfil” e “Contratos”\) E clicar em “Salvar”")]
        public void QuandoPreencherTodosOsCamposObrigatoriosNomeTelefoneE_MailPerfilEContratosEClicarEmSalvar()
        { 
            this.json = "{" +
                "{" +
                "\"loginPai\": \"MA985791\"," +
                "\"nome\": \"luiz mas\"," +
                "\"telefone\": \"(11) 9854-8590\"," +
                "\"email\": \"Alisson@prestadores.amil.com.br\"," +
                "\"perfis" + ": [" +
                 "\"EMPRESA_WEB04\"," +
                    "]" +
                "\"contratos" + ": [" +
                 "\"15828910\"," +
                    "]" +
                     " }" +
                "}";
            resposta = empresa.PostHttpWebRequest("/Usuario/inserir-administrador-filho", "json", 200, new string[] { "True" }, null, this.json);
        }
        
        [When(@"eu clicar no ícone do lápis, na coluna “Ação”")]
        public void QuandoEuClicarNoIconeDoLapisNaColunaAcao()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + Usuario + "/ Filhos", "json", 200, new string[] { "True" }, null, null);
            
            this.json = "{" +
                "{" +
                "\"loginPai\": \"MA985791\"," +
                "\"nome\": \"Marcos Bispo\"," +
                "\"telefone\": \"(51) 4156-6900\"," +
                "\"email\": \"marcbispo@prestadores.amil.com.br\"," +
                "\"perfis" + ": [" +
                 "\"EMPRESA_WEB04\"," +
                "\"EMPRESA_WEB03\"," +
                    "]" +
                "\"contratos" + ": [" +
                 "\"15828910\"," +
                    "]" +
                "\"loginFilho\": \"985791A01\"," +
                     " }" +
                "}";
            resposta = empresa.PutHttpWebRequest("/Usuario/atualizar-administrador-filho", "json", 200, new string[] { "True" }, null, this.json);
        }
        
        [When(@"eu clicar no ícone no “X”, na coluna “Ação”")]
        public void QuandoEuClicarNoIconeNoXNaColunaAcao()
        {
            Login = "985791A02";
        }
        
        [When(@"o sistema retornar a mensagem “Atenção, você deseja excluir esse Administrador\?” E clicar em “SIM”")]
        public void QuandoOSistemaRetornarAMensagemAtencaoVoceDesejaExcluirEsseAdministradorEClicarEmSIM()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + Usuario + "/ Filhos", "json", 200, new string[] { "True" }, null, null);
        }
        
        [Then(@"o sistema retornará para a tela “Controle de Acesso ao Portal”")]
        public void EntaoOSistemaRetornaraParaATelaControleDeAcessoAoPortal()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + Usuario + "/ Filhos", "json", 200, new string[] { "True" }, null, null);
        }
        
        [Then(@"o sistema retornará para a tela “Controle de Acesso ao Portal” E a coluna “Data de Exclusão” será preenchida com a data atual")]
        public void EntaoOSistemaRetornaraParaATelaControleDeAcessoAoPortalEAColunaDataDeExclusaoSeraPreenchidaComADataAtual()
        {
            resposta = empresa.PostHttpWebRequest("/Usuario/inativar-administrador-filho/" + Login, "json", 200, new string[] { "True" }, null, null);
        }
    }
}
