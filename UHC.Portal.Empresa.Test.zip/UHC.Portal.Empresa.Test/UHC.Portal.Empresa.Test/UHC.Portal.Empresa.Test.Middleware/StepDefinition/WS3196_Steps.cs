﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3196_BuscarLotacaoParaAlterarBeneficiarioSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma Lotação \(código/nome\) dentro da combo “Lotação” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaLotacaoCodigoNomeDentroDaComboLotacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar sobre alguma “Lotação” listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaLotacaoListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Lotação” o código e nome da “Lotação” correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoLotacaoOCodigoENomeDaLotacaoCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("Lotacao/" + empresaData.CodTsContrato+"?Filter=" + empresaData.filter + " & Limit = " + empresaData.limit, "json", 200, new string[] { "identificador", "descricao", "codigoLotacaoTS", "codigoTsContrato" }, null, null);
        }
    }
}
