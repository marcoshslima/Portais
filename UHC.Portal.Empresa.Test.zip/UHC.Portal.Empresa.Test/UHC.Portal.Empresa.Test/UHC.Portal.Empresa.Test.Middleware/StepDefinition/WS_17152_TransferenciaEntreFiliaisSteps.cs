﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_17152_TransferenciaEntreFiliaisSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"Forneça os dados necessários para a API de botão buscar ""(.*)""")]
        public void DadoFornecaOsDadosNecessariosParaAAPIDeBotaoBuscar(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Forneça a solicitação de base para a API de botão buscar")]
        public void QuandoFornecaASolicitacaoDeBaseParaAAPIDeBotaoBuscar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"Aperte a solicitação de API para o botão buscar para")]
        public void EntaoAperteASolicitacaoDeAPIParaOBotaoBuscarPara()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/DadosTransferenciaFilialSemMudancaNumero/"+empresaData.NumAssociado+"/"+ empresaData.tipoUsuario, "json", 200,null, null, null);

        }
    }
}
