﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Trocar_Planos_dos_Beneficiarios
{
    [Binding]
    public class WS_4042_BuscaBeneficiarioParaTrocaDePlanosSteps
    {

        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUEE eu já fiz login no Portal Empresa_unico ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresa_Unico(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresaa_varios_Vários ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresaa_Varios_Varios(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"já acessei o item de menu_Vários “Movimentação Cadastral / Troca Plano dos Beneficiários”")]
        public void DadoJaAcesseiOItemDeMenu_VariosMovimentacaoCadastralTrocaPlanoDosBeneficiarios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresaa_numero_Número ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresaa_Numero_Numero(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresaa_parte_Número   ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresaa_Parte_Numero(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"acessei o item de menu_Número  “Movimentação Cadastral / Troca Plano dos Beneficiários")]
        public void DadoAcesseiOItemDeMenu_NumeroMovimentacaoCadastralTrocaPlanoDosBeneficiarios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresaa_Nome ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresaa_Nome(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"acessei o item de menu_Nome “Movimentação Cadastral / Troca Plano dos Beneficiários”")]
        public void DadoAcesseiOItemDeMenu_NomeMovimentacaoCadastralTrocaPlanoDosBeneficiarios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresa_Nome ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresa_Nome(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresaa ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresaa(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Troca Plano dos Beneficiários”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralTrocaPlanoDosBeneficiarios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"u já acesseii o item de menu ""(.*)""")]
        public void DadoUJaAcesseiiOItemDeMenu(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"eu já fiz as buscas iniciais de contrato ""(.*)""")]
        public void DadoEuJaFizAsBuscasIniciaisDeContrato(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"u já acessei o itemm de menu ""(.*)""")]
        public void DadoUJaAcesseiOItemmDeMenu(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE eu já fiz as buscas iniciais de contrato ""(.*)""")]
        public void DadoQUEEuJaFizAsBuscasIniciaisDeContrato(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"u já acessei o item de menuu ""(.*)""")]
        public void DadoUJaAcesseiOItemDeMenuu(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu acessar o item de menu “Movimentação Cadastral_unico / Troca Plano dos Beneficiários”")]
        public void QuandoEuAcessarOItemDeMenuMovimentacaoCadastral_UnicoTrocaPlanoDosBeneficiarios()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no combobox no campo_Vários “Contrato”")]
        public void QuandoEuClicarNoComboboxNoCampo_VariosContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"acessei o item de menu_Número  “Movimentação Cadastral / Troca Plano dos Beneficiários”")]
        public void QuandoAcesseiOItemDeMenu_NumeroMovimentacaoCadastralTrocaPlanoDosBeneficiarios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o número do contrato no campo_Número  “Contrato”")]
        public void QuandoEuInserirONumeroDoContratoNoCampo_NumeroContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir parte do número do contrato no campo_Número  “Contrato”")]
        public void QuandoEuInserirParteDoNumeroDoContratoNoCampo_NumeroContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o nome da empresa no campo_Nome “Contrato”")]
        public void QuandoEuInserirONomeDaEmpresaNoCampo_NomeContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o nome da empresa no campo “Contrato”")]
        public void QuandoEuInserirONomeDaEmpresaNoCampoContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir parte do nome da empresa no campo “Contrato”")]
        public void QuandoEuInserirParteDoNomeDaEmpresaNoCampoContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar na linha do contrato ativo desejado")]
        public void QuandoEuClicarNaLinhaDoContratoAtivoDesejado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar sob o campo “Beneficiário”")]
        public void QuandoEuClicarSobOCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o número do beneficiário no campo “Beneficiário”")]
        public void QuandoEuInserirONumeroDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o número inválido do beneficiário no campo “Beneficiário")]
        public void QuandoEuInserirONumeroInvalidoDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir parte do número do beneficiário no campo “Beneficiário”")]
        public void QuandoEuInserirParteDoNumeroDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o nome do beneficiário no campo “Beneficiário”")]
        public void QuandoEuInserirONomeDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        //[When(@"eu inserir o nome do beneficiário  no campo “Beneficiário”")]
        //public void QuandoEuInserirONomeDoBeneficiarioNoCampoBeneficiario()
        //{
        //    ScenarioContext.Current.Pending();
        //}
        
        [When(@"eu inserir parte do nome  do beneficiário no campo “Beneficiário”")]
        public void QuandoEuInserirParteDoNomeDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar em um dos beneficiários disponíveis")]
        public void QuandoEuClicarEmUmDosBeneficiariosDisponiveis()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá exibir o número do contrato e nome da empresa no campo “Contrato” no formato somente leitura_unico")]
        public void EntaoOSistemaIraExibirONumeroDoContratoENomeDaEmpresaNoCampoContratoNoFormatoSomenteLeitura_Unico()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.Contrato+"&listarTodos=true&suspenso=false", "json", 200, new string[] { "NOME_ENTIDADE" }, null, null);
            Console.WriteLine(resposta); 
        }

        [Then(@"o sistema irá exibir todos os contratos existentes para a empresa_Vários")]
        public void EntaoOSistemaIraExibirTodosOsContratosExistentesParaAEmpresa_Varios()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivoo grupo contrato para o número digitado_Número  ""(.*)""")]
        public void EntaoOSistemaIraMostrarORespectivooGrupoContratoParaONumeroDigitado_Numero(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivo contrato para o nome digitado_Nome")]
        public void EntaoOSistemaIraMostrarORespectivoContratoParaONomeDigitado_Nome()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema apresentará a mensagem “Contrato não encontrado”")]
        public void EntaoOSistemaApresentaraAMensagemContratoNaoEncontrado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar uma lista com o respectivo nome digitado")]
        public void EntaoOSistemaIraMostrarUmaListaComORespectivoNomeDigitado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema transferirá os dados de número de contrato e nome da empresa para o campo “Contrato”")]
        public void EntaoOSistemaTransferiraOsDadosDeNumeroDeContratoENomeDaEmpresaParaOCampoContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá exibir todos os beneficiário existentes para o contrato indicado e seus respectivos número")]
        public void EntaoOSistemaIraExibirTodosOsBeneficiarioExistentesParaOContratoIndicadoESeusRespectivosNumero()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivo beneficiário para o número digitado")]
        public void EntaoOSistemaIraMostrarORespectivoBeneficiarioParaONumeroDigitado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá retornar a mensagem ""(.*)""")]
        public void EntaoOSistemaIraRetornarAMensagem(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar uma lista com o respectivo número digitado")]
        public void EntaoOSistemaIraMostrarUmaListaComORespectivoNumeroDigitado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivo Beneficiário para o nome digitado")]
        public void EntaoOSistemaIraMostrarORespectivoBeneficiarioParaONomeDigitado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema apresentará a mensagem “Beneficiário não encontrado”")]
        public void EntaoOSistemaApresentaraAMensagemBeneficiarioNaoEncontrado()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"eu inserir parte do nome  do beneficiário no campo “Beneficiário”")]
        public void EntaoEuInserirParteDoNomeDoBeneficiarioNoCampoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema permitirá a conclusão do processo")]
        public void EntaoOSistemaPermitiraAConclusaoDoProcesso()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
