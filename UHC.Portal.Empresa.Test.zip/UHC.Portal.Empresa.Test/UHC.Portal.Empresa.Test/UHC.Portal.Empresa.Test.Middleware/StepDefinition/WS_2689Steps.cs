﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2689GerarPDFConsultarPrecosDosPlanosContratadosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Cancelar Consultar ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaCancelarConsultar(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão de Contratos / Menu Consultar Preços dos Planos Contratados")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoDeContratosMenuConsultarPrecosDosPlanosContratados()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/"+ listEmpresaData.CodTsContrato+"/"+listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoTSContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("codigoTSContrato has not repeated morethan once");
            }

        }
        
        [When(@"selecionei a opção Relatorio PDF  E clicar sobre o botão Download do arquivo")]
        public void QuandoSelecioneiAOpcaoRelatorioPDFEClicarSobreOBotaoDownloadDoArquivo()
        {
            json = "{" + "\"tipoRelatorio\":" + "\"PDF\"," +
                         "\"codigoRelatorio\":" + "7004," +
                         "\"nome\":" + "\"TsAss1071JR\"," +
                         "\"grupo\":" + "\"ASS\"," +
                         "\"usuario\":" + "\"MA648064\"," +
                         "\"senha\":" + "\"6B9EA1AB867E868E9623\"," +
                         "\"ip\":" + "\"189.20.205.221\"," +
                         "\"sistema\":" + "\"dsisamil\"," +
                         "\"modulo\":" + "\"91\"," +
                         "\"parametros\":" +
                         "[" +
                             "{" +
                                 "\"chave\":" + "\"pDtIniVigencia\"," +
                                 "\"valor\":" + "\"01/01/2018\"" +
                             "}," +
                             "{" +
                                 "\"chave\":" + "\"pCodTsContrato\"," +
                                 "\"valor\":" + "\"9900003885\"" +
                             "}," +
                            "{" + "\"chave\":" + "\"pTitulo\"," +
                                 "\"valor\":" + "\"Valores Cadastrados\"" +
                            "}" +
                         "]" +
                        "}";
        }
        [When(@"selecionei a opção Arquivo Texto Delimitador \(\#\) no campo Formato de Saída E clicar sobre o botão Download do arquivo")]
        public void QuandoSelecioneiAOpcaoArquivoTextoDelimitadorNoCampoFormatoDeSaidaEClicarSobreOBotaoDownloadDoArquivo()
        {
            resposta = empresa.GetHttpWebRequest("Plano/PrecosPlanosContratadosTxt?CodTsContrato=" + listEmpresaData.CodTsContrato + "/" + listEmpresaData.DtIniCobranca +"/"+listEmpresaData.CodigoUsuario, "json", 200, new string[] { "Codigo","Mensagem" }, null, null);

        }


        [Then(@"o sistema deverá gerar e apresentar um arquivo no formato PDF contendo os valores dos planos contratados ,abrangidos no contrato")]
        public void EntaoOSistemaDeveraGerarEApresentarUmArquivoNoFormatoPDFContendoOsValoresDosPlanosContratadosAbrangidosNoContrato()
        {
            resposta = empresa.PostHttpWebRequest("Relatorio", "json", 200, new string[]{ "mensagem","codigo"}, null, json);
        }

        [Then(@"o sistema deverá gerar e apresentar um arquivo no formato TXT contendo os valores dos planos contratados , abrangidos no contrato")]
        public void EntaoOSistemaDeveraGerarEApresentarUmArquivoNoFormatoTXTContendoOsValoresDosPlanosContratadosAbrangidosNoContrato()
        {
            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("Mensagem"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Mensagem has  repeated morethan once");
            }
        }
    }
}
