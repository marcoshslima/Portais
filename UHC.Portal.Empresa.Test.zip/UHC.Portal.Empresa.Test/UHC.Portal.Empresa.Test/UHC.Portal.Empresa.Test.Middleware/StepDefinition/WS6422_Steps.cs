﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS6422_BuscarBeneficiarioParaConsultaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"Que eu já fiz login no Portal Empresa para Buscar Beneficiário Para Consultar ""(.*)""")]
        public void DadoQueEuJaFizLoginNoPortalEmpresaParaBuscarBeneficiarioParaConsultar(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Eu inserir o nome do Beneficiário no campo “Selecione o Beneficiário” para Buscar Beneficiário Para Consultar")]
        public void QuandoEuInserirONomeDoBeneficiarioNoCampoSelecioneOBeneficiarioParaBuscarBeneficiarioParaConsultar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"os respectivos Beneficiários sugerirão automaticamente o nome inserido no campo “Beneficiário”")]
        public void EntaoOsRespectivosBeneficiariosSugeriraoAutomaticamenteONomeInseridoNoCampoBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/" + empresaData.codTsBeneficiario, "json", 200, new string[] { "codTs", "codTsTit", "numAssociado", "nomeAssociado", "diaVencimento", "numAssociadoTitular" }, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/Complementar/" + empresaData.codTsBeneficiario, "json", 200, new string[] { "numMatricEmpresa", "nomeMae", "nomLotacao", "codBancoReemb", "codAgenciaReemb", "numDvAgenciaReemb" }, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/Enderecos/" + empresaData.codTsBeneficiario, "json", 200, new string[] { "codEntidadeTs", "indResidencia", "indCorresp", "indCobranca", "nomLogradouro", "numEndereco" }, null, null);
        }
        
        [Then(@"Clico no beneficiário Requerido")]
        public void EntaoClicoNoBeneficiarioRequerido()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosFamilia/" + empresaData.codTsBeneficiario, "json", 200, new string[] { "codTs", "nomeAssociado", "numAssociado", "dataNascimento", "indSexo", "nomSituacao" }, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/Contatos/" + empresaData.CodigoTsBeneficiario + "/Consulta", "json", 200, new string[] { "indClassContato", "indTipoContato", "numDdd", "numTelefone", "numRamal", "indEnviaSms" }, null, null);
        }
    }
}
