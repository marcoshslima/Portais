﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS4075_BuscarCEPParaAlterarBeneficiarioTipoDeConsultaGrandesUsuariosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já realizei a busca de endereços por tipo de consulta “Grandes Usuários” ""(.*)""")]
        public void DadoQUEEuJaRealizeiABuscaDeEnderecosPorTipoDeConsultaGrandesUsuarios(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu preencher os campos obrigatórios E clicar sobre o botão “Buscar CEP”")]
        public void QuandoEuPreencherOsCamposObrigatoriosEClicarSobreOBotaoBuscarCEP()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o  sistema irá exibir todos os endereços cadastrados de acordo com o critério da pesquisa")]
        public void EntaoOSistemaIraExibirTodosOsEnderecosCadastradosDeAcordoComOCriterioDaPesquisa()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/UnidadeOrganizacional?Filter=" + empresaData.Filter+ "&Limit="+empresaData.limit, "json", 200, new string[] { "codigo", "descricao" }, null, null);
            resposta = empresa.GetHttpWebRequest("Nestle/PSA/" + empresaData.CodEmpresaNestle + "/" + empresaData.CodArhNestle, "json", 200, new string[] { "codigo", "descricao", "codigoARH", "codigoEmpresa" }, null, null);
            resposta = empresa.GetHttpWebRequest("Endereco/Cep/GrandesUsuarios/" + empresaData.SiglaUF + "/" + empresaData.CodigoMunicipio+ "/" + empresaData.Usuario, "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
