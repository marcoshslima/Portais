﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT862_ConsultarResolucoesNormativasVinculadasSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        // WSCT862.1 - Acesso com apenas uma empresa vinculada
        [Given(@"que estou logado como Gestor do Contrato ""(.*)""")]
        public void DadoQueEstouLogadoComoGestorDoContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"clicar no link Resolução Normativa")]
        public void QuandoClicarNoLinkResolucaoNormativa()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"deverá ser apresentada a tela com a\(s\) resolução\(ões\) vinculada\(s\) ao contrato")]
        public void EntaoDeveraSerApresentadaATelaComASResolucaoOesVinculadaSAoContrato()
        {
            resposta = empresa.GetHttpWebRequest("api/Empresa/"+ empresaData.Contrato + "/ResolucaoNormativaDescricao", "json", 200, null, null, null);
        }

        // WSCT862.2 - Acesso com múltiplas empresas vinculadas 
        [Then(@"deverá ser apresentada a tela onde devo selecionar a ""(.*)"" no combo-box e apresentar a\(s\) resolução\(ões\) vinculada\(s\) ao contrato")]
        public void EntaoDeveraSerApresentadaATelaOndeDevoSelecionarANoCombo_BoxEApresentarASResolucaoOesVinculadaSAoContrato(string p0)
        {
            ScenarioContext.Current.Pending();
        }

    }
}
