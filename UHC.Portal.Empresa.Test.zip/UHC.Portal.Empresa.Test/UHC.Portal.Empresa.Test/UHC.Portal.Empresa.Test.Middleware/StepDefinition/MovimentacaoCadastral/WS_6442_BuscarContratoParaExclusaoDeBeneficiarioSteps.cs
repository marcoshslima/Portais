﻿using TechTalk.SpecFlow;
using OGS.Framework.Utility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.MovimentacaoCadastral
{
    [Binding]
    public class US6442AnexarDocumentacaoParaExclusaoDeBeneficiarioSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion


        [Given(@"QUE eu já fiz login no Excluir Portal Contrato/Beneficario Empresa  ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoExcluirPortalContratoBeneficarioEmpresa(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            //empresa = new WebService(Ambiente.BaseUri);
        }
        
    }
}
