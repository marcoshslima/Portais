﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ManutençãodeAposentadoDemitidos
{
    [Binding]
    public class WS_17150ManutencaodeAposentadoDemitidosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"eu já fiz login no Portal Empresa ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresa(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Consultar Situação Movimentação”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralConsultarSituacaoMovimentacao()
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }
        
        [Given(@"selecionei um beneficiário")]
        public void DadoSelecioneiUmBeneficiario()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"realizei o preenchimento dos campos com erro/alerta")]
        public void DadoRealizeiOPreenchimentoDosCamposComErroAlerta()
        {
            Console.WriteLine(empresa);
        }

        [Given(@"QUE euu já fiz login no Portal Empresaa ""(.*)""")]
        public void DadoQUEEuuJaFizLoginNoPortalEmpresaa(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNov/" + empresaData.Usuario + "/true", "json", 200, null, null, null);
            Console.WriteLine(empresa);

        }


        [Then(@"o sistema deverá gravar as alterações realizadas")]
        public void EntaoOSistemaDeveraGravarAsAlteracoesRealizadas()
        {
            Console.WriteLine(empresa);
        }
        
       
    }
}
