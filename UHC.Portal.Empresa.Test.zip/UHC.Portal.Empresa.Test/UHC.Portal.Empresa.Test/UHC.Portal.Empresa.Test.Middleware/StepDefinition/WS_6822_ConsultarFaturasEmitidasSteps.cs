﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_6822_ConsultarFaturasEmitidasSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
       
        #endregion
        [Given(@"QUE o sistema mostrou pelo menos um contrato ""(.*)""")]
        public void DadoQUEOSistemaMostrouPeloMenosUmContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"inserir datas válidas no campo ""(.*)""")]
        public void QuandoInserirDatasValidasNoCampo(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"clicar em ""(.*)""")]
        public void EntaoClicarEm(string p0)
        {
            Console.Write(empresa);
        }
        
        [Then(@"o sistema mostrará uma grid com as faturas disponíveis")]
        public void EntaoOSistemaMostraraUmaGridComAsFaturasDisponiveis()
        {
            resposta = empresa.GetHttpWebRequest("Fatura/Emitida/"+empresaData.codTsContrato+"/"+empresaData.InitialDate+"/"+empresaData.FinalDate, "json", 200, null, null, null);
            Console.WriteLine(resposta);
        }
    }
}
