﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultaAutorizaçõesToken
{
    [Binding]
    public class WS_24559_BuscarTokenParaConsultarAutorizacoesTokenSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa\[Token] ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaToken(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"o sistema apresentou a tela para consulta de autorizações")]
        public void DadoOSistemaApresentouATelaParaConsultaDeAutorizacoes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu digitar um número de token")]
        public void QuandoEuDigitarUmNumeroDeToken()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá listar as autorizações de acordo com o número de token digitado\.")]
        public void EntaoOSistemaDeveraListarAsAutorizacoesDeAcordoComONumeroDeTokenDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Autorizacao/Token/"+listEmpresaData.Token, "json", 200, null, null, null);

        }
    }
}
