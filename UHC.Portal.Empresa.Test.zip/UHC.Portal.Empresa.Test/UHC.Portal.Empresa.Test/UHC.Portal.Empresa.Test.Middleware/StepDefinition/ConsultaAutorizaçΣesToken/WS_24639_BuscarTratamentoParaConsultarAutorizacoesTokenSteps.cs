﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultaAutorizaçõesToken
{
    [Binding]
    public class WS_24639_BuscarTratamentoParaConsultarAutorizacoesTokenSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
     

        #endregion
        [Given(@"eu já fiz login no Portal Empresa E acessei o item de menu Gestão de Beneficiários / Consultar Autorizações Token ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresaEAcesseiOItemDeMenuGestaoDeBeneficiariosConsultarAutorizacoesToken(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"o sistema apresentou a tela para consulta de autorizações\[ConsultarAutorizaçõesToken]")]
        public void DadoOSistemaApresentouATelaParaConsultaDeAutorizacoesConsultarAutorizacoesToken()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo “Tratamento”\[ConsultarAutorizaçõesToken]")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboTratamentoConsultarAutorizacoesToken(int p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os tratamentos de acordo com o que está sendo digitado\[ConsultarAutorizaçõesToken]")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsTratamentosDeAcordoComOQueEstaSendoDigitadoConsultarAutorizacoesToken()
        {
            resposta = empresa.GetHttpWebRequest("TipoTratamento/ListarTipoTratamento","json", 200, null, null, null);

        }
    }
}
