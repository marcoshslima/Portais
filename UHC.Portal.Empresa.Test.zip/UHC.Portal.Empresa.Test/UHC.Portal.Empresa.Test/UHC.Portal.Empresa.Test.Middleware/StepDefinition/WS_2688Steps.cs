﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2688ConsultarInformacoesContratuaisSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Consultar Informacoes ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaConsultarInformacoes(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Given(@"Que eu tenha acessado o Menu Gestão de Contratos / Menu Consultar Informações Contratuais")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoDeContratosMenuConsultarInformacoesContratuais()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarPropostaPME/"+listEmpresaData.NumSeqPropostaPjTs+"/"+listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroProposta"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("numeroProposta are more in number");
            }

            resposta = empresa.GetHttpWebRequest("Endereco/GetEndereco/"+listEmpresaData.CodEntidadeTs, "json", 200, null, null, null);
            string[] strArr1 = null;
            string respostacorda1 = resposta.ToString();
            char[] divididochar1 = { ',' };
            int numContrato1 = 0;
            int numContratocontagem1 = 0;
            strArr1 = respostacorda1.Split(divididochar1);
            for (numContrato1 = 0; numContrato1 <= strArr1.Length - 1; numContrato1++)
            {
                if (strArr1[numContrato1].Contains("codigoEntidadeTS"))
                {
                    numContratocontagem1 = numContratocontagem1 + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem1 >= 1))
            {
                Assert.Fail("numeroProposta are more in number");
            }

            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGerente/"+listEmpresaData.CodEquipeVendas+"/"+listEmpresaData.CodCorretorTs, "json", 200, null, null, null);
            string[] strArr2 = null;
            string respostacorda2 = resposta.ToString();
            char[] divididochar2 = { ',' };
            int numContrato2 = 0;
            int numContratocontagem2 = 0;
            strArr2 = respostacorda2.Split(divididochar2);
            for (numContrato2 = 0; numContrato2 <= strArr2.Length - 1; numContrato2++)
            {
                if (strArr2[numContrato2].Contains("analista"))
                {
                    numContratocontagem2 = numContratocontagem2 + 1;
                }
            }
            // valor validation
            if ((numContratocontagem2 > 1))
            {
                Assert.Fail("analista are more in number");
            }
        }
    }
}

