﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.RegistrodeSolicitações
{
    [Binding]
    public class WS_8160_BuscarCEPParaAlterarEnderecoAoRegistrarSolicitacoesSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"acessei o item de menu Gestão de Beneficiários / Solicitações / Registrar Solicitações ""(.*)""")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesRegistrarSolicitacoes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Preencha todos os campos")]
        public void QuandoPreenchaTodosOsCampos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"obrigatórios clique no botão incluir")]
        public void EntaoObrigatoriosCliqueNoBotaoIncluir()
        {
            json = "{" +

               "\"nomeAssociado\": \"" + empresaData.NomeAssociado + "\"," +
               "\"numeroAssociado\": \"" + empresaData.Contrato + "\"," +
               "\"codigoTs\": \"" + empresaData.Usuario + "\"," +
               "\"indiceCartaoOrientador\": \"" + empresaData.Senha + "\"," +
               "\"indiceTipoOrientador\": \"" + empresaData.Ip + "\"," +
               "\"numeroSequenciaRegiao\": \"" + empresaData.Sistema + "\"," +
               "\"codigoTipoEnderecoCarteira\": \"" + empresaData.Modulo + "\"," +
                "\"indiceEnvioCarteiraInativo\": \"" + empresaData.Modulo + "\"," +
                "\"indiceAposDemissao\": \"" + empresaData.Usuario + "\"," +
               "\"codigoBairro\": \"" + empresaData.Senha + "\"," +
               "\"codigoMunicipio\": \"" + empresaData.Ip + "\"," +
               "\"numeroEndereco\": \"" + empresaData.Sistema + "\"," +
               "\"numeroCep\": \"" + empresaData.Modulo + "\"," +
                "\"textoComplemento\": \"" + empresaData.Modulo + "\"," +
                   "\"nomeLogradouro\": \"" + empresaData.Modulo + "\"," +
                      "\"codigoTipoLogradouro\": \"" + empresaData.Modulo + "\"," +
                         "\"codigoMotivoSegunda\": \"" + empresaData.Modulo + "\"," +


                         "}";
            resposta = empresa.PostHttpWebRequest("Relatorio", "json", 200, new string[] { "mensagem", "codigo" }, null, json);
        }
    }
}
