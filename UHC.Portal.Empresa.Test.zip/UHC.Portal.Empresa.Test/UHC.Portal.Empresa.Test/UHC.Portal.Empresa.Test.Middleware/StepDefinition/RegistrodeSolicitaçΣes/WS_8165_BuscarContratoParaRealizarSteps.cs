﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.RegistrodeSolicitações
{
    [Binding]
    public class WS_8165_BuscarContratoParaRealizarSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        [Given(@"eu já fiz login no Portal Empresa E  acessei o item de menu “Gestão de Beneficiários / Solicitações / Registrar Solicitações” ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresaEAcesseiOItemDeMenuGestaoDeBeneficiariosSolicitacoesRegistrarSolicitacoes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo “Selecione o contrato”")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboSelecioneOContrato(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá listar abaixo da combo os contratos de acordo com o que está sendo digitado\.")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsContratosDeAcordoComOQueEstaSendoDigitado_()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/"+empresaData.Contrato+"/"+empresaData.CodigoTSContrato, "json", 200, null, null, null);
            Console.WriteLine(resposta);
        }

    }
}
