﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WSCT1000_ConsultarATabelaCompletaDePrecosTabelaCompletaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        [Given(@"que o gestor do contrato deseja selecionar a empresa para consultar dos preços dos planos ""(.*)""")]
        public void DadoQueOGestorDoContratoDesejaSelecionarAEmpresaParaConsultarDosPrecosDosPlanos(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"clicar no link TABELA COMPLETA")]
        public void QuandoClicarNoLinkTABELACOMPLETA()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"deverá ser apresenta a lista de planos ativos na ""(.*)""")]
        public void EntaoDeveraSerApresentaAListaDePlanosAtivosNa(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Empresa/" + empresaData.Contrato + "/Plano/" + empresaData.CodigoPlano + "/Precos/" + empresaData.DataNegociacao, "json", 200, null, null, null);
        }
        
        [Then(@"os valores referentes a cada plano e tipo de dependência ""(.*)"", ""(.*)"", e/ou Agregado""(.*)""Inativo""")]
        public void EntaoOsValoresReferentesACadaPlanoETipoDeDependenciaEOuAgregadoInativo(string p0, string p1, string p2)
        {
            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int valor = 0;
            int valorcontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (valor = 0; valor <= strArr.Length - 1; valor++)
            {
                if (strArr[valor].Contains("valor"))
                {
                    valorcontagem = valorcontagem + 1;
                }
            }
            // valor validation
            if (!(valorcontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
    }
}
