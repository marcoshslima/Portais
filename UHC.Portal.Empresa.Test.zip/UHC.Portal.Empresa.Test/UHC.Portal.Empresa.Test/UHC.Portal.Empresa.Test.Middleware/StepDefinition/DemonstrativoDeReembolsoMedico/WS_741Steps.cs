﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;


namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DemonstrativoDeReembolsoMedico
{
    [Binding]
    public class UI741DemonstrativoDeReembolsoMedicoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta, resposta1;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Reembolso medico ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaReembolsoMedico(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0); 
        }
        
        [Given(@"acessei o item de menu Gestão de Beneficiários / Demonstrativos e Declarações / Demonstrativo de Reembolso Médico")]
        public void DadoAcesseiOItemDeMenuGestaoDeBeneficiariosDemonstrativosEDeclaracoesDemonstrativoDeReembolsoMedico()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"selecionei um beneficiário no campo Beneficiário E eu clicar sobre o botão Executar")]
        public void QuandoSelecioneiUmBeneficiarioNoCampoBeneficiarioEEuClicarSobreOBotaoExecutar()
        {
            resposta = empresa.GetHttpWebRequest("Reembolso/Demonstrativo/"+listEmpresaData.NumAssociado+"/"+listEmpresaData.Usuario+"/"+listEmpresaData.Senha+"/"+listEmpresaData.Ip, "json", 200, null, null, null);                        
        }
        [When(@"selecionei um beneficiário no campo Beneficiário, sem dados para reembolso e eu clicar sobre o botão Executar")]
        public void QuandoSelecioneiUmBeneficiarioNoCampoBeneficiarioSemDadosParaReembolsoEEuClicarSobreOBotaoExecutar()
        {
            resposta = empresa.GetHttpWebRequest("Reembolso/Demonstrativo/"+listEmpresaData.NumAssociadoTitular+"/"+listEmpresaData.Usuario+"/"+listEmpresaData.Senha+"/"+listEmpresaData.Ip, "json", 200, new string[] { listEmpresaData.Message, listEmpresaData.Codigo }, null, null);
        }

        [Then(@"o sistema deverá gerar e apresentar o relatório contendo o demonstrativo de reembolso médico de acordo com o preenchimento dos campos de filtro\.")]
        public void EntaoOSistemaDeveraGerarEApresentarORelatorioContendoODemonstrativoDeReembolsoMedicoDeAcordoComOPreenchimentoDosCamposDeFiltro_()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("mensagem"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("PDF not generated");
            }
        }


        [Then(@"o sistema NÃO irá gerar o relatório contendo o demonstrativo de reembolso  E deverá apresentar a mensagem Nenhuma informação foi encontrada com o critério de seleção estabelecido\.")]
        public void EntaoOSistemaNAOIraGerarORelatorioContendoODemonstrativoDeReembolsoEDeveraApresentarAMensagemNenhumaInformacaoFoiEncontradaComOCriterioDeSelecaoEstabelecido_()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("mensagem"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("PDF not generated");
            }
        }
    }
}
