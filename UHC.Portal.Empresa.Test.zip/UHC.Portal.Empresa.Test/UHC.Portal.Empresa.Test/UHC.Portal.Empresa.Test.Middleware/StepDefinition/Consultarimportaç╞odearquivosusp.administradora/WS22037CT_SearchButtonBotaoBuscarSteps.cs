﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Consultarimportaçãodearquivosusp.administradora
{
    [Binding]
    public class WS22037CT_SearchButtonBotaoBuscarSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para pesquisar um arquivo de Consultar importação de arquivo susp\. administradora ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaPesquisarUmArquivoDeConsultarImportacaoDeArquivoSusp_Administradora(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            
        }
        
        [Given(@"que selecionou Contrato / Grupo Contrato")]
        public void DadoQueSelecionouContratoGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Relatorio/GetTipoRelatorio/"+ empresaData.NomeRelatorio, "json", 200, new string[] { empresaData.NomeRelatorio }, null, null);
        }
        
        [When(@"eu já coloquei o período de envio")]
        public void QuandoEuJaColoqueiOPeriodoDeEnvio()
        {
            resposta = empresa.GetHttpWebRequest("Relatorio/GetTipoRelatorio/"+ empresaData.NomeRelatorio1, "json", 200, new string[] { empresaData.NomeRelatorio1 }, null, null);
        }
        
        [Then(@"mostre os tópicos abaixo (.*) - Rótulo: ""(.*)"" \(Título\)")]
        public void EntaoMostreOsTopicosAbaixo_RotuloTitulo(int p0, string p1)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"no botão de busca \(botão busca\)")]
        public void EntaoNoBotaoDeBuscaBotaoBusca()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario, "codigoUsuario", "nomeUsuario", "codigoTipoUsuario", "codigoGrupoEmpresa" }, null, null);
        }
        
        [Then(@"mostre os arquivos importados na grade OU mostre a mensagem que não possui arquivos")]
        public void EntaoMostreOsArquivosImportadosNaGradeOUMostreAMensagemQueNaoPossuiArquivos()
        {
            resposta = empresa.GetHttpWebRequest("SuspensaoAdministrator/SuspensaoAdm?Cod_ts_contrato=" + empresaData.CodTsContrato+ "&Data_importacao_ini="+empresaData.Data_importacao_ini+ "&Data_importacao_fim="+empresaData.Data_importacao_fim+ "&Ace_identificacao_ts="+empresaData.Aceidentificacaots+ "&Ace_tipo_usuario="+empresaData.Acetipousuario, "json", 200, new string[] { empresaData.Usuario, ".txt" }, null, null);
        }
    }
}
