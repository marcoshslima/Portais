﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Boletos
{
    [Binding]
    public class WS16175CT_BuscaContratoDeBoletosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Busca Contrato de Boletos ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaBuscaContratoDeBoletos(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já acessei o item ""(.*)""")]
        public void DadoJaAcesseiOItem(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu acessar o item ""(.*)""")]
        public void QuandoEuAcessarOItem(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sob o campo “Contrato”")]
        public void QuandoEuClicarSobOCampoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Login/" + empresaData.Usuario + "/Empresa/Simples?somenteAtivos=false", "json", 200, new string[] { empresaData.Codigo, empresaData.ContratoName }, null, null);
        }
        
        [Then(@"o sistema irá exibir o número do contrato e nome da empresa no campo “Contrato” no formato somente leitura")]
        public void EntaoOSistemaIraExibirONumeroDoContratoENomeDaEmpresaNoCampoContratoNoFormatoSomenteLeitura()
        {
            resposta = empresa.GetHttpWebRequest("Login/" + empresaData.Usuario + "/Empresa/Simples?somenteAtivos=false", "json", 200, new string[] { empresaData.Codigo,empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Fatura/CobrancasPendentes/" + empresaData.codigoTsContrato, "json", 200, new string[] { "[]" }, null, null);
        }
        
        [Then(@"o sistema irá exibir todos os contratos existentes para a empresa e seus respectivos números")]
        public void EntaoOSistemaIraExibirTodosOsContratosExistentesParaAEmpresaESeusRespectivosNumeros()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario, empresaData.ContratoName }, null, null);
        }
    }
}
