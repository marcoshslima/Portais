﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Boletos
{
    [Binding]
    public class WS12592CT_VerificarBoletosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logado no portal Empresa Verificar Contrato de Boletos ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaVerificarContratoDeBoletos(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu acessar o item de menu ""(.*)""")]
        public void QuandoEuAcessarOItemDeMenu(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu seguir os passos da US \[(.*)] - Busca Contrato")]
        public void QuandoEuSeguirOsPassosDaUS_BuscaContrato(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Login/" + empresaData.Usuario + "/Empresa/Simples?somenteAtivos=false", "json", 200, new string[] { empresaData.Codigo, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario, empresaData.ContratoName }, null, null);
        }
        
        [When(@"eu acessar ""(.*)""")]
        public void QuandoEuAcessar(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
        
        [When(@"pesquisar o ""(.*)""")]
        public void QuandoPesquisarO(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Cobranca/GetFaturaVencida?DataFiltro=" + DateTime.Now.ToString("dd/MM/yyyy") + "&CodTsContrato="+empresaData.CodTsContrato, "json", 200, new string[] { "numSequencia", "competencia", "vencimento", "valorMensal", "multa", "jurosDia", "total", "valorAcrescimo" }, null, null);
        }
        
        [When(@"clicar em ""(.*)""")]
        public void QuandoClicarEm(string p0)
        {
            Console.WriteLine(DateTime.Now.ToString("MM/dd/yyyy"));
            this.json = "{"+
                            "\"numSeqCobranca\": " + empresaData.numSeqCobranca + "," +
                            "\"dtVencimentoNova\": \"" + DateTime.Now.ToString("MM/dd/yyyy") + "\"," +
                            "\"acrescimo\": \"1.170,25\"," +
                            "\"codUsuario\": \"" + empresaData.Usuario + "\"" + 
                       "}";
            Console.WriteLine(json);
            resposta = empresa.PutHttpWebRequest("Cobranca/PutAlterarVencimento", "json"
                , 200
                , new string[] { "codigo", "0", "mensagem"}
                , null
                , this.json);
        }
        
        [When(@"ao acessar ""(.*)"", os valores de ""(.*)"" , ""(.*)"", ""(.*)"" e ""(.*)"" devem estar atualizados conforme a tela ""(.*)""")]
        public void QuandoAoAcessarOsValoresDeEDevemEstarAtualizadosConformeATela(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            resposta = empresa.GetHttpWebRequest("Fatura/CobrancasPendentes/" + empresaData.codigoTsContrato, "json", 200, new string[] { "identificacao" }, null, null);
        }
        
        [Then(@"o sistema deverá apresentar o\(s\) boleto\(s\) em aberto/atraso para o contrato em questão")]
        public void EntaoOSistemaDeveraApresentarOSBoletoSEmAbertoAtrasoParaOContratoEmQuestao()
        {
            //Pass new test data new string as "ATRASADO"
            resposta = empresa.GetHttpWebRequest("Fatura/CobrancasPendentes/" + empresaData.codigoTsContrato, "json", 200, new string[] { "identificacao" }, null, null);
        }
        
        [Then(@"o sistema NÃO deverá apresentar boleto para pagamento")]
        public void EntaoOSistemaNAODeveraApresentarBoletoParaPagamento()
        {
            resposta = empresa.GetHttpWebRequest("Login/" + empresaData.Usuario + "/Empresa/Simples?somenteAtivos=false", "json", 200, new string[] { empresaData.Codigo, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario, empresaData.ContratoName }, null, null);
        }
        
        [Then(@"exibirá a mensagem ""(.*)""")]
        public void EntaoExibiraAMensagem(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Fatura/CobrancasPendentes/" + empresaData.codigoTsContrato, "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
