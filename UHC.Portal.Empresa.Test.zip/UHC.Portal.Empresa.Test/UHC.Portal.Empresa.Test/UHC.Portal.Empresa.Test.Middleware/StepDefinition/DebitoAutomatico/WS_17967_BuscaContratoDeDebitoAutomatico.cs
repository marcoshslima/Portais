﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS17967BuscaContratoDeDebitoAutomaticoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        //DateTime today;
        //string todayDateFormat;

        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresaa debito""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaaDebito(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [When(@"eu clicar emm DEBITO AUTOMATICO")]
        public void QuandoEuClicarEmmDEBITOAUTOMATICO()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o sistema irá exibir o número do contrato e nome da empresa no campo Contrato no formato somente leitura")]
        public void EntaoOSistemaIraExibirONumeroDoContratoENomeDaEmpresaNoCampoContratoNoFormatoSomenteLeitura()
        {
            //listEmpresaData = new WS_Empresa_Data();
            resposta = empresa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/DebitoAutomatico/"+listEmpresaData.Contrato, "json", 200, null, null, null);
        }
    }
}
