﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Débito_Automático
{
    [Binding]
    public class WS_5408_CancelarOuReautorizarDebitoAutomaticoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empres_Cancelar ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpres_Cancelar(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"acessei o item de menu “Pagamentos / Débito Automático”_Webservicecancelar")]
        public void DadoAcesseiOItemDeMenuPagamentosDebitoAutomatico_Webservicecancelar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Given(@"anteriormente eu já tenha autorizado o débito automático__Webservicecancelar")]
        public void DadoAnteriormenteEuJaTenhaAutorizadoODebitoAutomatico__Webservicecancelar()
        {
            Console.WriteLine(empresa);
        }

        [Given(@"QUE eu já fiz login no Portal Empres ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpres(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"eu já segui os passos da  - Busca Contrato_Webservicecancelar")]
        public void DadoEuJaSeguiOsPassosDa_BuscaContrato_Webservicecancelar()
        {
            Console.WriteLine(empresa);
        }

        [Given(@"QUE passei pelo cenário (.*) ""(.*)""")]
        public void DadoQUEPasseiPeloCenario(int p0, string p1)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"todos os dados estão preenchidos corretamente”_webservicecancelar")]
        public void DadoTodosOsDadosEstaoPreenchidosCorretamente_Webservicecancelar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Given(@"clico no botão Autorizar_webservicecancelar")]
        public void DadoClicoNoBotaoAutorizar_Webservicecancelar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"eu clicar em “Cancelar débito automático”_WebserviceCancelar")]
        public void QuandoEuClicarEmCancelarDebitoAutomatico_WebserviceCancelar()
        {
            Console.WriteLine(empresa);
        }

        [When(@"clicar em “Cancelar débito automático”_webservicecancelar")]
        public void QuandoClicarEmCancelarDebitoAutomatico_Webservicecancelar()
        {
            Console.WriteLine(empresa);
        }

        [When(@"a tela carregar, deve mostrar a Sessão ""(.*)""_webservicecancelar")]
        public void QuandoATelaCarregarDeveMostrarASessao_Webservicecancelar(string p0)
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano , "json", 200, new string[] { "status", "data" }, null, null);

        }

        [When(@"o sistema informará a mensagem de término do processo_webservicecancelar")]
        public void QuandoOSistemaInformaraAMensagemDeTerminoDoProcesso_Webservicecancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano + "/codUsuario/", "json", 200, new string[] { "status", "data" }, null, null);

        }

        [Then(@"o sistema atualizará a tela e mostrará a mensagem “O débito automático foi: Cancelado em \[Data de Hoje]”")]
        public void EntaoOSistemaAtualizaraATelaEMostraraAMensagemODebitoAutomaticoFoiCanceladoEmDataDeHoje()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/"+empresaData.CodigoPlano, "json", 200,null, null, null);

        }

        [Then(@"o sistema emitirá uma mensagem de confirmação_WebServiceCancelar")]
        public void EntaoOSistemaEmitiraUmaMensagemDeConfirmacao_WebServiceCancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"clicar no botão ""(.*)""_webservicancelar")]
        public void EntaoClicarNoBotao_Webservicancelar(string p0)
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"o processo de cancelamento será abortado_Webservicecancelar")]
        public void EntaoOProcessoDeCancelamentoSeraAbortado_Webservicecancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"o sistema emitirá uma mensagem de confirmação_WebserviceCancelar")]
        public void EntaoOSistemaEmitiraUmaMensagemDeConfirmacao_WebserviceCancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"clicar no botão ""(.*)""_webservicecancelar")]
        public void EntaoClicarNoBotao_Webservicecancelar(string p0)
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"atualizará a tela e mostrará a mensagem na Sessão Situação_webservicecancelar")]
        public void EntaoAtualizaraATelaEMostraraAMensagemNaSessaoSituacao_Webservicecancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/"+empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"o sistema será redirecionado para a tela de autorização de débito automático_webservicecancelar")]
        public void EntaoOSistemaSeraRedirecionadoParaATelaDeAutorizacaoDeDebitoAutomatico_Webservicecancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano, "json", 200, null, null, null);

        }

        [Then(@"o sistema será redirecionado para a tela de autorização de débito automático_reautorizar_webservicecancelar")]
        public void EntaoOSistemaSeraRedirecionadoParaATelaDeAutorizacaoDeDebitoAutomatico_Reautorizar_Webservicecancelar()
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/" + empresaData.CodigoPlano , "json", 200, null, null, null);

        }
    }
}
