﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DebitoAutomatico
{
    [Binding]
    public class WS_2594AutorizarDebitoAutomaticoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
#endregion


        [Given(@"QUE eu já segui os passos -- Busca Contrato​ ""(.*)""")]
        public void DadoQUEEuJaSeguiOsPassos_BuscaContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"eu já cliquei em ""(.*)""")]
        public void DadoEuJaCliqueiEm(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu preencher os campos obrigatórios_Effective Autorizcao \(""(.*)"", ""(.*)"", ""(.*)"", ""(.*)"", ""(.*)"" e ""(.*)""\)")]
        public void QuandoEuPreencherOsCamposObrigatorios_EffectiveAutorizcaoE(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"eu já cliquei em_effective Autorizacao ""(.*)""")]
        public void EntaoEuJaCliqueiEm_EffectiveAutorizacao(string p0)
        {
            resposta = empresa.GetHttpWebRequest("DebitoAutomatico/"+empresaData.CodigoContrato, "json", 200, null, null, null);
            Console.WriteLine(resposta);
        }
    }
}
