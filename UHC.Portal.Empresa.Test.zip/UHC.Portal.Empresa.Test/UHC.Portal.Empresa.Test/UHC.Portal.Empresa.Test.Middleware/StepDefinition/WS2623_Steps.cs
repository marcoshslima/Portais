﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2623_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logado no portal Empresa para gerar o relatório de coparticipação ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaGerarORelatorioDeCoparticipacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"o sistema apresentou a tela de filtro para gerar o demonstrativo de coparticipação e eu clicar sobre o botão '(.*)'")]
        public void QuandoOSistemaApresentouATelaDeFiltroParaGerarODemonstrativoDeCoparticipacaoEEuClicarSobreOBotao(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"selecionei um contrato no campo ""(.*)""")]
        public void QuandoSelecioneiUmContratoNoCampo(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá gerar e apresentar o relatório de coparticipação  de acordo com o preenchimento dos campos de filtro\.")]
        public void EntaoOSistemaDeveraGerarEApresentarORelatorioDeCoparticipacaoDeAcordoComOPreenchimentoDosCamposDeFiltro_()
        {
            resposta = empresa.GetHttpWebRequest("DemonstrativoCoParticipacao/Validar/" + empresaData.CodigoTsBeneficiario + "/" + empresaData.IndParticipacaoIsenta+ "?numeroControleCoParticipacao="+empresaData.numeroControleCoParticipacao, "json", 200, new string[] { "codigo", "mensagem" }, null, null);
            resposta = empresa.GetHttpWebRequest("DemonstrativoCoParticipacao/" + empresaData.CodigoTsBeneficiario + "/" + empresaData.IndParticipacaoIsenta + "/PDF?numeroControleCoParticipacao=" + empresaData.numeroControleCoParticipacao +"&mesAnoRef=" +empresaData.MesAnoRef, "json", 200, new string[] { "codigo", "mensagem" }, null, null);
        }
        
        [Then(@"o sistema deverá gerar o relatório de coparticipação de acordo com o preenchimento dos campos de filtro e encaminhar o mesmo ao e-mail informado")]
        public void EntaoOSistemaDeveraGerarORelatorioDeCoparticipacaoDeAcordoComOPreenchimentoDosCamposDeFiltroEEncaminharOMesmoAoE_MailInformado()
        {
            this.json = "{" +
               "\"codTsBeneficiario\": \"" + empresaData.codTsBeneficiario +"\"," +
                "\"email\":\"bhaskar.k @prestadores.amil.com.br\"," +
                 "\"nome\":\"Bhaskar\"," +
                 "\"mesAnoRef\":\"" + empresaData.MesAnoRef + "\"," +
                 "\"numControleCopartSeq\":\"" + empresaData.numControleCopartSeq + "\"" +
               "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("DemonstrativoCoparticipacao/EnviarEmail", "json"
                , 200
                , new string[] { "codigoRetorno", "mensagemRetorno", "numeroSequenciaFila" }
                , null
                , this.json);
        }

        [Then(@"o sistema deverá gerar o relatório de coparticipação de acordo com o preenchimento dos campos de filtro e encaminhar o mesmo ao endereço informado")]
        public void EntaoOSistemaDeveraGerarORelatorioDeCoparticipacaoDeAcordoComOPreenchimentoDosCamposDeFiltroEEncaminharOMesmoAoEnderecoInformado()
        {
            this.json = "{" +
               "\"codTsBeneficiario\": \"" + empresaData.codTsBeneficiario + "\"," +
                "\"numControleCopartSeq\":"+ empresaData.numControleCopartSeq + "," +
                 "\"codUsuario\":\""+ empresaData.Usuario + "\"," +
                 "\"numCep\":\"" + empresaData.NumCep + "\"," +
                 "\"sglUf\":\"" + empresaData.SiglaUF + "\"," +
                 "\"codMunicipio\":" + empresaData.CodigoMunicipio + "," +
                 "\"nomeBairro\":\"" + empresaData.CodigoBairro + "\"," +
                 "\"nomLogradouro\":\"" + empresaData.NomeLogradouro + "\"," +
                 "\"numEndereco\":\"" + empresaData.numEndereco + "\"," +
                  "\"txtComplemento\":\"" + empresaData.txtComplemento + "\"," +
                  "\"numCaixaPostal\":"+ null +
               "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("DemonstrativoCoparticipacao/EnviarCarta", "json"
                , 200
                , new string[] { "codigo", "mensagem" }
                , null
                , this.json);
        }

        [Then(@"eu digitar a partir de (.*) caractere dentro da combo '(.*)'")]
        public void EntaoEuDigitarAPartirDeCaractereDentroDaCombo(int p0, string p1)
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?CodTsContrato=" + empresaData.CodTsContrato + "&NomeAssociado=" + empresaData.NomeAssociado + "&listarTodos=" + empresaData.listarTodos + "&suspenso=" + empresaData.suspenso, "json", 200, new string[] { "numero_contrato", "cod_ts_contrato", "nome_associado","numero_associado","cpf", "nome_contratante", "data_inclusao" }, null, null);
        }
    }
}
