﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Inclusaodependente
{

    
    [Binding]
    public class WS_1829_IncluirBeneficiarioDependente
    {
        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string file;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Incluir Dependentes")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaIncluirDependentes()
        {
            listEmpresaData = new WS_Empresa_Data("INCLUSAO DE DEPENDENTES");
        }
        
        [Given(@"acessei o item de menu Movimentação Cadastral / Incluir Dependentes")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralIncluirDependentes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"realizei as ações de selecionar Beneficiário Titular")]
        public void QuandoRealizeiAsAcoesDeSelecionarBeneficiarioTitular()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + listEmpresaData.Usuario+"/"+ listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaDeclaracaoDeSaude", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.Contrato + "/"+ listEmpresaData.codTsContrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+ listEmpresaData.Contrato + "&listarTodos="+ listEmpresaData.apenasContratosAtivos + "&suspenso="+ listEmpresaData.apenasContratosAtivos , "json", 200, null, null, null);
        }

        
        [When(@"eu preencher os campos obrigatórios")]
        public void QuandoEuPreencherOsCamposObrigatorios()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarContrato?NumContrato=" + listEmpresaData.Contrato + "&quantidadeDe=" + listEmpresaData.quantidadeDe + "&quantidadeAte=" + listEmpresaData.quantidadeAte, "json", 200, null, null, null);
            this.json = "{" +
                           "\"codTsContrato\":\"" + listEmpresaData.codTsContrato + "\"," +
                           "\"dataInclusaoUm\":\"" + listEmpresaData.dataInclusaoUm + "\"," +
                           "\"mesAnoRef\":\"" + listEmpresaData.mesAnoRef + "\"," +

                           "\"codUsuario\":\"" + listEmpresaData.Usuario + "\"," +
                           "\"dataNascimento\":\"" + listEmpresaData.DataNegociacao + "\"," +
                           "\"CodigoPlano\":\"" + listEmpresaData.CodigoPlano + "\"," +
                           "\"codDependencia\":\"" + listEmpresaData.codDependencia + "\"," +
                           "\"indCadastroDependente\":\"" + listEmpresaData.indCadastroDependente + "\"," +
                           
                       "}";
            resposta = empresa.PostHttpWebRequest("Calculo/ProRata" , "json", 200, new string[] { "" }, null, this.json);
        }

        [Then(@"o sistema deverá gerar a solicitação de inclusão")]
        public void EntaoOSistemaDeveraGerarASolicitacaoDeInclusao()
        {
            this.json=
                "{" +
  "\"informacoesPessoais\": " + "{" +
                "\"nomeMae\":" + "\"RICARDO YUKIO SUEYASU\"," +
                "\"nomePai\":" + null + "," +
                "\"numCpf\":" + "\"487.115.850-05\"," +
                "\"numPis\":" + null + "," +
                "\"numUnicoSaude\":" + null + "," +
                "\"numIdentidade\":" + null + "," +
                "\"codOrgaoEmissor\":" + null + "," +
                "\"codPaisEmisso\":" + "32,"+
     "\"dataNascimento\":" + "\"05/09/2018\"," +
    "\"indNacionalidade\":" + "\"B\"," +
    "\"codMunicipioNatural\":" + null + "," +
    "\"indSexo\":" + "\"M\"," +
    "\"peso\":" + null + "," +
    "\"altura\":" + null + "," +
    "\"indEstadoCivil\":" + "\"1\"," +
    "\"codTsTitDental\": " + null + "," +
    "\"codTsTit\":" + "\"42167657\"," +
    "\"dataCasamento\":" + null +
"}," +
  "\"dadosEmpresa\":" + "{" +
                    "\"dataAdmissao\":" + null + "," +
                    "\"numMatricEmpresa\":" + "\"1121434\","+
     "\"numSeqMatricEmpresa\":" + null + "," +
    "\"numMatricInstituidor\":" + null + "," +
    "\"numMatricSiape\":" + null + "," +
    "\"codLotacao\":" + null + "," +
    "\"dtLotacao\": " + null + "," +
    "\"dtIniContrib\":" + null + "," +
    "\"nomCartao\": " + "\"ANDRE LIMAVERDE FABIANO\"," +
    "\"codEmpresa\": " + 1007513606 + "," +
    "\"codGrupoEmpresa\": " + 648064 +
"}," +
  "\"indTipoProduto\": " + "\"1\"," +
  "\"codTipoOperacao\": " + "\"2\"," +
  "\"mesAnoRef\":" + null + "," +
  "\"nomeAssociado\": " + "\"ANDRE LIMAVERDE FABIANO\"," +
  "\"codTsContrato\":" + "\"14687904\"," +
  "\"codPlano\": " + "\"96513\"," +
  "\"codTsContratoOdonto\":" + null + "," +
  "\"codPlanoOdonto\":" + null + "," +
  "\"tipoAssociado\":" + "\"D\"," +
  "\"indIsentoCarencia\":" + null + "," +
  "\"dataInclusao\": " + "\"01/10/2018\"," +
  "\"codMunicipioIbge\":" + null + "," +
  "\"codDependencia\":" + "\"3\"," +
  "\"numDn\": " + null + "," +
  "\"registrosMovimentacao\":" + "[]," +
  "\"declaracaoSaude\": " + "{" +
    "\"resposta\":" + "[]," +
"}," +
  "\"anexo\":" + "{" +
    "\"registro\":" + "{" +
     " {" +
        "\"dataAnexado\":" + null + "," +
        "\"codigoUsuarioAtu\":" + null + "," +
        "\"nomeArquivoAnexo\":" + "\"Support center.PNG\"," +
        "\"indExcluir\":" + false + "," +
        "\"numSeqAssociadoAnexo\":" + null + "," +
        "\"guid\":" +"\"7e4553ab-8255-48f2-a2d2-7860c870d175\" "+
        "}" +
    "]," +
    "\"qtdAnexo\":" + 1 +
 "}," +
  "\"numSeqAssociadoWeb\":" + null + "," +
  "\"codSituacaoAssociadoWeb\": " + null + "," +
  "\"codTs\":" + null + "," +
  "\"indSubsidio\":" + null +
 "}";
            resposta = empresa.PostHttpWebRequest("Contrato/14687904/Movimentacao/MA648064/Dependente/42167657/0", "json", 200, null,null, this.json);
        }
        
        [Then(@"clicar sobre o botão Incluir")]
        public void EntaoClicarSobreOBotaoIncluir()
        {
            resposta = empresa.GetHttpWebRequest("/Beneficiario/" + listEmpresaData.codTsBeneficiario, "json", 200, null, null, null);
        }
    }
}
