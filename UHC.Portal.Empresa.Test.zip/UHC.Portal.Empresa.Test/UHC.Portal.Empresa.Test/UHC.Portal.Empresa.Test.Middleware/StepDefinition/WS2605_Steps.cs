﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS2605_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logado no portal Empresa para Consultar Autorizações ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaConsultarAutorizacoes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"o sistema apresentou a tela para consulta de autorizações e eu preencher os campos de filtro")]
        public void QuandoOSistemaApresentouATelaParaConsultaDeAutorizacoesEEuPreencherOsCamposDeFiltro()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"O sistema deverá apresentar uma tela contendo as autorizações de acordo com o preenchimento dos campos de filtro")]
        public void EntaoOSistemaDeveraApresentarUmaTelaContendoAsAutorizacoesDeAcordoComOPreenchimentoDosCamposDeFiltro()
        {
            resposta = empresa.GetHttpWebRequest("Autorizacao/PesquisarAutorizacoes?CodigoContrato=" + empresaData.CodigoContrato + "&Beneficiario=" + empresaData.Beneficiario + "&Tratamento=" + empresaData.Beneficiario+ "&DtIni="+empresaData.Beneficiario+ "&DtFim="+empresaData.Beneficiario+ "&CodGrupoEmpresa="+empresaData.CodGrupoEmpresa+ "&TipoUsuario="+empresaData.tipoUsuario+ "&CodUsuario="+empresaData.Usuario, "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
