﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS7051_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Busca Contrato da Calcular Multas e Juros de Faturas Vencidas ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaBuscaContratoDaCalcularMultasEJurosDeFaturasVencidas(string p0)
        {
            empresaData = new WS_Empresa_Data(p0); 
        }
        
        [When(@"acessei o item de menu “Gestão Financeira e Demonstrativos / Calcular Multas e Juros de Faturas Vencidas ”")]
        public void QuandoAcesseiOItemDeMenuGestaoFinanceiraEDemonstrativosCalcularMultasEJurosDeFaturasVencidas()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"Obter lista de fatura vencidas selecionando os contratos disponíveis")]
        public void EntaoObterListaDeFaturaVencidasSelecionandoOsContratosDisponiveis()
        {
            resposta = empresa.GetHttpWebRequest("Cobranca/GetFaturaVencida?DataFiltro=" + DateTime.Now.ToString("dd/MM/yyyy") + "&CodTsContrato="+empresaData.CodTsContrato, "json", 200, new string[] { "numSequencia", "competencia", "vencimento", "valorMensal", "multa", "jurosDia", "total", "valorAcrescimo" }, null, null);
        }
    }
}
