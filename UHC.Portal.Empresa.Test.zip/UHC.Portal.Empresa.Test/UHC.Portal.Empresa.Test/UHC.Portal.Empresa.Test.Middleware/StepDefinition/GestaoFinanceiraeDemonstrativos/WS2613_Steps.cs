﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS2613_CalcularMultasEJurosDeFaturasVencidasSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        string json;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Calcular Multas e Juros de Faturas Vencidas ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaCalcularMultasEJurosDeFaturasVencidas(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no contrato desejado")]
        public void QuandoEuClicarNoContratoDesejado()
        {
            resposta = empresa.GetHttpWebRequest("Menu", "json", 200, new string[] { "Gestão de Contratos", "Calcular Multa e Juros de Faturas Vencidas" }, null, null);
            resposta = empresa.GetHttpWebRequest("Login/"+empresaData.Usuario+ "/Linhas?somenteAtivos=false", "json", 200, new string[] { "AMIL" }, null, null);
            resposta = empresa.GetHttpWebRequest("PendenciasCadastrais/AlertaBeneficiario/Exibir/" + empresaData.tipoUsuario + "/"+empresaData.CodIdentificacaoTs, "json", 200, new string[] { "S" }, null, null);
        }
        
        [Then(@"o sistema mostrará as faturas vencidas junto com o cálculo de multa e juros")]
        public void EntaoOSistemaMostraraAsFaturasVencidasJuntoComOCalculoDeMultaEJuros()
        {
            resposta = empresa.GetHttpWebRequest("Cobranca/GetFaturaVencida?DataFiltro=" + DateTime.Now.ToString("dd/MM/yyyy") + "&" + empresaData.CodTsContrato, "json", 200, new string[] { "numSequencia", "competencia", "vencimento", "valorMensal", "multa", "jurosDia", "valorAcrescimo" }, null, null);
        }
        
        [Then(@"eu clicar em ""(.*)""  quando o sistema mostrar a mensagem ""(.*)""")]
        public void EntaoEuClicarEmQuandoOSistemaMostrarAMensagem(string p0, string p1)
        {
            resposta = empresa.GetHttpWebRequest("Documento/GetBanners", "json", 200, new string[] { "nome", "descricao", "label", "link", "status", "statusEdicao", "tags", "corpo" }, null, null);
            resposta = empresa.GetHttpWebRequest("Documento/GetComunicados", "json", 200, new string[] { "nome", "descricao", "label", "link", "status", "statusEdicao", "tags", "corpo" }, null, null);
        }
        
        [Then(@"o sistema mostrará a mensagem ""(.*)""")]
        public void EntaoOSistemaMostraraAMensagem(string p0)
        {
            this.json = "{" +
                            "\"numSeqCobranca\": " + empresaData.numSeqCobranca + "," +
                            "\"acrescimo\": \""+empresaData.acrescimo+"\"" +
                        "}";
            resposta = empresa.PutHttpWebRequest("Cobranca/PutAlterarVencimento/"+empresaData.Usuario+ "/"+DateTime.Now.ToString("dd-MM-yyyy"), "json"
                , 200
                , new string[] { "codigo", "0", "mensagem" }
                , null
                , this.json);
        }
    }
}
