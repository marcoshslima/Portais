﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS18743_BuscaContratoDaTrocaDeFaixaEtariaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Busca Contrato da Demonstrativo de troca de faixa etária ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaBuscaContratoDaDemonstrativoDeTrocaDeFaixaEtaria(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu acessar o item de menu “Gestão Financeira e Demonstrativos / Demonstrativo de Troca de Faixa Etária”")]
        public void QuandoEuAcessarOItemDeMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeTrocaDeFaixaEtaria()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + empresaData.Usuario + "/false", "json", 200, new string[] { "codigoOperadora", "nomeOperadora", "codigoSucursal", "codigoInspetoriaTS", "nomeInspetoria", "codigoEquipePosVenda" }, null, null);
            resposta = empresa.GetHttpWebRequest("Job/Detalhes/" + empresaData.CodigoJob, "json", 200, new string[] { "idJob", "nomeObjeto", "assunto", "comentarios" }, null, null);
        }
        
        [Then(@"o sistema irá exibir todos os contratos existentes para a empresa e seus respectivos números Buscar Vários Contratos")]
        public void EntaoOSistemaIraExibirTodosOsContratosExistentesParaAEmpresaESeusRespectivosNumerosBuscarVariosContratos()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/BuscarReferenciaMesAno/" + empresaData.CodTipoCiclo, "json", 200, new string[] { "NUM_CICLO_TS", "MES_ANO_REF", "MES_ANO_ORDER" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/GetPlanos?CodTsContrato=" + empresaData.CodTsContrato, "json", 200, new string[] { "codPlano", "nomePlano" }, null, null);
        }
    }
}
