﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS10081_BuscaContratoDoDownloadDeArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"o sistema mostrou pelo menos um ""(.*)"" ""(.*)""")]
        public void DadoOSistemaMostrouPeloMenosUm(string p0, string p1)
        {
            empresaData = new WS_Empresa_Data(p1);
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"eu clicar em um dos ""(.*)"" disponíveis")]
        public void QuandoEuClicarEmUmDosDisponiveis(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/"+empresaData.Usuario+"?apenasContratosAtivos=false", "json", 200, new string[] { "numeroContrato", "codigoTSContrato", "nomeGrupoEmpresa", "codigoGrupoEmpresa" }, null, null);
        }

        [Then(@"o sistema mostrará os demais campos para a visualização da consulta")]
        public void EntaoOSistemaMostraraOsDemaisCamposParaAVisualizacaoDaConsulta()
        {
            resposta = empresa.GetHttpWebRequest("ControleArquivo/PesquisarDownload?codigoGrupoEmpresa=" + empresaData.CodGrupoEmpresa, "json", 200, new string[] { "dataSolicitacao", "tamanhoArquivo", "dataProcessamento", "descricaoTipoArquivo", "nomeDiretorio", "nomeArquivo", "indSituacao", "textoErroProcessamento", "numeroControleArquivo", "mostrarIconeDownload" }, null, null);
            resposta = empresa.GetHttpWebRequest("ControleArquivo/PesquisarDownload?CodigoTsContrato=" + empresaData.CodigoTSContrato, "json", 200, new string[] { "dataSolicitacao", "tamanhoArquivo", "dataProcessamento", "descricaoTipoArquivo", "nomeDiretorio", "nomeArquivo", "indSituacao", "textoErroProcessamento", "numeroControleArquivo", "mostrarIconeDownload" }, null, null);
        }

    }
}
