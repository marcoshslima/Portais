﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS7641_BuscaContratoDaDemonstrativoDeCo_ParticipacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Busca Contrato da Demonstrativo de Co-Participação ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaBuscaContratoDaDemonstrativoDeCo_Participacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"QUE o sistema mostrou pelo menos um contrato")]
        public void DadoQUEOSistemaMostrouPeloMenosUmContrato()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu acessar o item de menu  “Gestão Financeira e Demonstrativos / Demonstrativo de Co-Participação”")]
        public void QuandoEuAcessarOItemDeMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeCo_Participacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar em um dos contratos disponíveis na lista")]
        public void QuandoEuClicarEmUmDosContratosDisponiveisNaLista()
        {
            
        }
        
        [Then(@"o sistema irá exibir o número do contrato e nome da empresa no campo Contrato no formato somente leitura para Buscar Contrato Único")]
        public void EntaoOSistemaIraExibirONumeroDoContratoENomeDaEmpresaNoCampoContratoNoFormatoSomenteLeituraParaBuscarContratoUnico()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "?apenasContratosAtivos=false", "json", 200, new string[] { "numeroContrato", "codigoTSContrato", "nomeGrupoEmpresa", "codigoGrupoEmpresa" }, null, null);
        }
        
        [Then(@"o sistema irá carregar o contrato na combobox text campo")]
        public void EntaoOSistemaIraCarregarOContratoNaComboboxTextCampo()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
