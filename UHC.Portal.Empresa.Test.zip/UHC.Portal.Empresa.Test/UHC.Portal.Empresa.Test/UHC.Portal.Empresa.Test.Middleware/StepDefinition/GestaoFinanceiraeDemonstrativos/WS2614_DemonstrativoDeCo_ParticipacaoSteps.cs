﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS2614_DemonstrativoDeCo_ParticipacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        string json;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logado no portal Empresa para Demonstrativo de Co-Participação ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaDemonstrativoDeCo_Participacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já acessei o item de menu “Gestão Financeira e Demonstrativos / Demonstrativo de Co-Participação")]
        public void DadoJaAcesseiOItemDeMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeCo_Participacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema mostrará um grid com todas as faturas geradas para a selecionado empresa")]
        public void EntaoOSistemaMostraraUmGridComTodasAsFaturasGeradasParaASelecionadoEmpresa()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario+ "?apenasContratosAtivos=false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("ControleCoparticipacao/GetDemonstrativo/" + empresaData.codigoTsContrato, "json", 200, new string[] { "Demonstrativo", "mesAnoReferencia", "numControleCopartSeq", "dataIniPeriodo", "dataFimPeriodo", "dataVencimento", "valFatura" }, null, null);
        }
        
        [Then(@"o sistema gerará um Demonstrativo de Co-Participação em formato PDF com as informações dos beneficiários daquele contrato")]
        public void EntaoOSistemaGeraraUmDemonstrativoDeCo_ParticipacaoEmFormatoPDFComAsInformacoesDosBeneficiariosDaqueleContrato()
        {
            json =
                "{" +
                        "\"numCicloTS\":\"\","+
                        "\"mesAnoRef\":\"05 /2018\","+
                        "\"codEntidadeTS\":2000060,"+
                        "\"numFatura\":\"\"," +
                        "\"codOperadora\":3," +
                        "\"codSucursal\":2,"+
                        "\"codInspetoriaTS\":7,"+
                        "\"codIndTipoPessoa\":\"J\","+
                        "\"numSeqCobranca\":\"\"," +
                        "\"numControleCopartSeq\":1102557,"+
                        "\"codTsContrato\":9900003885," +
                        "\"codTipoFat\":1,"+
                        "\"codUsuario\":\"MA648064\","+
                        "\"ip\":\"189.20.205.222\"," +
                        "\"modulo\":\"91\","+
                        "\"nomeDestinatario\":\"\"," +
                        "\"emailRel\":\"\"," +
                        "\"sistema\":\"dsisamil\","+
                        "\"senha\":\"66989AA37E757C838A1F\","+
                "}";
            resposta = empresa.PostHttpWebRequest("ControleCoparticipacao/PdfDemonstrativo", "json", 200, new string[] { "mensagem", "codigo" }, null, json);
        }
    }
}
