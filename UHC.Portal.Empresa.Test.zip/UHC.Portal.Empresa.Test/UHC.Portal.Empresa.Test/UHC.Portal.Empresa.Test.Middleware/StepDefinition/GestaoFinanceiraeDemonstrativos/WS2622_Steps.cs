﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.GestaoFinanceiraeDemonstrativos
{
    [Binding]
    public class WS2622_DownloadDeArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [When(@"o sistema será redirecionado para a tela de download de arquivos ""(.*)""")]
        public void QuandoOSistemaSeraRedirecionadoParaATelaDeDownloadDeArquivos(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"QUE o sistema mostrou pelo menos um arquivo para download ""(.*)""")]
        public void DadoQUEOSistemaMostrouPeloMenosUmArquivoParaDownload(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [When(@"mostrará uma grid com todos os arquivos disponíveis para download")]
        public void QuandoMostraraUmaGridComTodosOsArquivosDisponiveisParaDownload()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no ícone “clip” da coluna “Download”")]
        public void QuandoEuClicarNoIconeClipDaColunaDownload()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"um grid contendo os arquivos pendentes de processamento de selecionado contrato")]
        public void EntaoUmGridContendoOsArquivosPendentesDeProcessamentoDeSelecionadoContrato()
        {
            resposta = empresa.GetHttpWebRequest("ControleArquivo/PesquisarDownload?codigoTsContrato=" + empresaData.CodigoTSContrato, "json", 200, new string[] { "dataSolicitacao", "tamanhoArquivo", "dataProcessamento", "descricaoTipoArquivo", "textoErroProcessamento", "numeroControleArquivo", "mostrarIconeDownload" }, null, null);
        }
        
        [Then(@"um grid contendo os arquivos pendentes de processamento de selecionado grupo contrato")]
        public void EntaoUmGridContendoOsArquivosPendentesDeProcessamentoDeSelecionadoGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("ControleArquivo/PesquisarDownload?codigoGrupoEmpresa=" + empresaData.GrupoContrato, "json", 200, new string[] { "dataSolicitacao", "tamanhoArquivo", "dataProcessamento", "descricaoTipoArquivo", "textoErroProcessamento", "numeroControleArquivo", "mostrarIconeDownload" }, null, null);
        }
        
        [Then(@"o sistema iniciará automaticamente o download do arquivo")]
        public void EntaoOSistemaIniciaraAutomaticamenteODownloadDoArquivo()
        {
            resposta = empresa.GetHttpWebRequest("Relatorio/GetCaminhoArquivo?NumControleArq=" + empresaData.NumControleArq+ "&CodUsuario="+empresaData.Usuario, "json", 200, new string[] { "nomDiretorio", "nomArquivo", "codTipoArq", "codigo", "message" }, null, null);
        }
    }
}
