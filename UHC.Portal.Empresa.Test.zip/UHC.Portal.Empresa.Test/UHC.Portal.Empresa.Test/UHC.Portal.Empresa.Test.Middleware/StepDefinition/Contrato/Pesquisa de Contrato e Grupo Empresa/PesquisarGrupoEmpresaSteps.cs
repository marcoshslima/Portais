﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using OGS.Framework.Setup;
using OGS.Framework.Utility;
using System;
using System.Configuration;
using TechTalk.SpecFlow;
using Test.Middleware.Helper;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Contrato
{
    [Binding]
    public class PesquisarGrupoEmpresaSteps
    {
        #region sql
        WebService ws = new WebService(Ambiente.BaseUri);

        DataBase db = new DataBase(Ambiente.host, Ambiente.port, Ambiente.servicename, Ambiente.user, Ambiente.password);

        SqlHelper select = new SqlHelper();
        #endregion

        #region Membros da Classe
        string resposta;
        string codUsuario;
        string idUsuario;
        string grupoEmpresa;
        string contratoAtivo;
        string baseUri = (Ambiente.BaseUri);
        WebService obterPesquisa;
        #endregion

        [Given(@"Que eu tenha dados válidos para receber as informações da pesquisa")]
        public void DadoQueEuTenhaDadosValidosParaReceberAsInformacoesDaPesquisa()
        {
            db.ConnectDataBase();
            string[] dados = db.SelectCommand(select.PesquisarGrupoContratoAtivo, null).Split(';');
            codUsuario = dados[0];
            grupoEmpresa = dados[1];
            contratoAtivo = "true";
        }

        [Given(@"Que eu tenha dados válidos para receber as informações da pesquisa com contratos inativos")]
        public void DadoQueEuTenhaDadosValidosParaReceberAsInformacoesDaPesquisaComContratosInativos()
        {
            db.ConnectDataBase();
            string[] dados = db.SelectCommand(select.PesquisarGrupoContratoAtivo, null).Split(';');
            codUsuario = dados[0];
            grupoEmpresa = dados[1];
            contratoAtivo = "false";
        }

        [Given(@"Que eu tenha dados inválidos para enviar ao serviço")]
        public void DadoQueEuTenhaDadosInvalidosParaEnviarAoServico()
        {
            codUsuario = "";
            contratoAtivo = "true";
        }

        [When(@"Eu consumir o servico \[Pesquisa Grupo Empresa]")]
        public void QuandoEuConsumirOServicoPesquisaGrupoEmpresa()
        {
            this.obterPesquisa = new WebService(baseUri);
        }
        
        [Then(@"Eu devo receber os dados da \[Pesquisa Grupo Empresa]")]
        public void EntaoEuDevoReceberOsDadosDaPesquisaGrupoEmpresa()
        {
            resposta = obterPesquisa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + codUsuario + "/" + contratoAtivo, "json", 200, new string[] { "result", "grupoEmpresa", "numeroContrato", "codigoTSContrato", "nomeGrupoEmpresa", "codigoGrupoEmpresa"}, null, null);
            var jObject = JObject.Parse(resposta);
            idUsuario = jObject.SelectToken("result.grupoEmpresa[0].[0].codigoGrupoEmpresa").ToString();
            if (idUsuario == grupoEmpresa)
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.IsTrue(false);
            }
        }

        [Then(@"Eu devo receber retorno de não encontrado")]
        public void EntaoEuDevoReceberRetornoDeNaoEncontrado()
        {
            resposta = obterPesquisa.GetHttpWebRequest("CanaisDigitais-PortalEmpresa/api/Contrato/PesquisarGrupoEmpresa/" + codUsuario + "/" + contratoAtivo, "json", 404, null, null, null);
        }

    }
}
