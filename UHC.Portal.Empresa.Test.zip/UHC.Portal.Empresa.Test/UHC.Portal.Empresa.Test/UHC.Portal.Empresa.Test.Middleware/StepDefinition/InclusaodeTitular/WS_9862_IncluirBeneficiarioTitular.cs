﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.InclusaodeTitular
{
    [Binding]
    public class WS_9862_IncluirBeneficiarioTitular
    {

        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Incluir Titular ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaIncluirTitular(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Movimentação Cadastral / Incluir Titulares")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralIncluirTitulares()
        {
            empresa = new WebService(Ambiente.BaseUri); 
        }
        
        [When(@"realizei as ações de selecionar Contrato")]
        public void QuandoRealizeiAsAcoesDeSelecionarContrato()
        {
            //resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/MA648064/true", "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/"+ listEmpresaData.Usuario +"/"+listEmpresaData.apenasContratosAtivos, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaDeclaracaoDeSaude", "json", 200, null, null, null);

        }
        
        [When(@"realizar o preenchimento de todos os campos obrigatórios")]
        public void QuandoRealizarOPreenchimentoDeTodosOsCamposObrigatorios()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/" + listEmpresaData.Contrato + "/" + listEmpresaData.codTsContrato, "json", 200, new string[] { listEmpresaData.Contrato }, null, null);

        }
        
        [When(@"clicar sobre o botão Salvar")]
        public void QuandoClicarSobreOBotaoSalvar()
        {
            this.json = "{" +
               "\"contatos\":" + "["+
                " {" +
                   "\"contato\":" + "{"+
                     "\"telefone\":" + "{" +
                       "\"ramal\":" + "\"\"," +
                       "\"ddd\":" + "\"\"," +
                       "\"numero\":" + "\"\"," +
                    " }," +
                     "\"celular\":" + "{" +
                       "\"ramal\":" + "\"\"," +
                       "\"ddd\":" + "\"\"," +
                       "\"numero\":" + "\"\"," +
                    " }," +
                     "\"email\":" + "\"\"," +
                     "\"codigoPais\":" + "\"\"," +
                     "\"exterior\":" + "false," +
                 " }," +
                   "\"codigoMunicipioNatural\":" + "\"\"," +
                 "}" +
               "]," +
               "\"enderecos\":" + "[" +
               " {" +
                   "\"codigoBairro\":" + "\"\"," +
                   "\"siglaUF\":" + "\"SP\","+
                   "\"complemento\":" + "\"\"," +
                   "\"numero\":" + "\"671\","+
                   "\"logradouro\":" + "\"R CORONEL CARLOS DOMINGUES GUIMARAES AMBROGI\"," +
                   "\"codigoTipoLogradouro\":" + "\"81\"," +
                   "\"CEP\":" + "\"12081-290\"," +
                   "\"indCobrancaEndereco\":" + "\"S\"," +
                   "\"indCorrespondenciaEndereco\":" + "\"S\"," +
                   "\"indResidenciaEndereco\":" + "\"" +
                   "\"indExcluirEndereco\":" + "\"\"," +
                   "\"indExterior\":" + "\"N\","+
                   "\"bairro\":" + "\"JARDIM SONIA MARIA\"," +
                   "\"municipio\":" + "\"TAUBATE\"," +
                   "\"codigoMunicipio\":" +"\"88978\"" +
                 "}" +
               "]," +
               "\"informacoesPessoais\":" + "{"+
                                "\"nomeMae\":" + "\"MARINA RAYSSA \"," +
                                "\"nomePai\":" + "\"\"," +
                                "\"numCpf\":" + "\"697.394.888-03\"," +
                                "\"numPis\":" + "\"\"," +
                                "\"numUnicoSaude\":" + "\"\"," +
                                "\"numIdentidade\":" + "\"\"," +
                                "\"codOrgaoEmissor\":" + "\"\"," +
                                "\"codPaisEmissor\":" + "32," +
                  "\"dataNascimento\":" + "\"14071996\"," + "}"+
                  "\"indNacionalidade\":" + "\"B\"," +
                 "\"codMunicipioNatural\":" + "\"\"," +
                 "\"indSexo\":" + "\"M\"," +
                 "\"peso\":" + "\"\"," +
                 "\"altura\":" + "\"\"," +
                 "\"numDn\":" + "\"\"," +
                 "\"indEstadoCivil\":" + "1,"+
                 "\"codTsTitDental\":" + "\"\"," +
                 "\"codTsTit\":" + "\"\"" +
                "}," +
               "\"dadosReembolso\":" + "\"\"," +
                 "\"codBancoReemb\":" + "\"\"," +
                 "\"codAgenciaReemb\":" + "\"\"," +
                 "\"numDvAgenciaReemb\":" + "\"\"," +
                 "\"numContaCorrenteReemb\":" + "\"\"," +
                 "\"numDvCcReemb\":" + "\"\"," +
                 "\"indTipoContaReemb\":" +"\"C\""+
                "}," +
            "}," +
                 "\"dadosEmpresa\":" + "{" +
                 "\"dataAdmissao\":" + "\"20092018\"," +
                 "\"numMatricEmpresa\":" + "\"2457856\"," +
                 "\"numMatricEmpresa2\":" + "\"\"," +
                 "\"numSeqMatricEmpresa\":" + "\"\"," +
                 "\"numMatricInstituidor\":" + "\"\"," +
                 "\"numMatricSiape\":" + "\"\"," +
                 "\"indSubsidio\":" + "\"\"," +
                 "\"numSeqMatricEmpresa2\":" + "\"\"," +
                 "\"numNip\":" + "\"\"," +
                 "\"numSeqNip\":" + "\"\"," +
                 "\"indSituacaoEmpresa\":" + "\"\"," +
                 "\"codLotacaoTs\":" + "\"\"," +
                 "\"codLotacao\":" + "\"\"," +
                 "\"dtLotacao\":" + "\"\"," +
                 "\"dtIniContrib\":" + "\"01102018\"," +
                 "\"codCbo\":" + "\"\"," +
                 "\"nomCartao\":" + "\"MURILO RAFAEL FARIAS\"," +
                 "\"codLocalTs\":" + "\"\"," +
                 "\"codCargo\":" + "\"\"," +
                 "\"codEmpresa\":" + "\"\"," +
                 "\"codGrupoEmpresa\":" + "\"\"," +
               "}," +
               "\"indTipoProduto\":" + "\"\"," +
               "\"codTipoOperacao\":" + "\"\"," +
               "\"mesAnoRef\":" + "\"10/2018\"," +
               "\"nomeAssociado\":" + "\"MURILO RAFAEL FARIAS\"," +
               "\"codts\": " + "\"\"," +
               "\"numAssociado\":" + "\"\"," +
               "\"codTsContrato\":" +  "\"9900003877\"," +
               "\"codPlano\":" +"\"96510\"," +
               "\"codTsContratoOdonto\":" + "\"\"," +
               "\"codPlanoOdonto\": " + "\"\"," +
               "\"tipoAssociado\":" + "\"T\"," +
               "\"indIsentoCarencia\":" + "\"\"," +
               "\"dataInclusao\":" + "\"01102018\"," +
               "\"codMunicipioResid\":" + "\"\"," +
               "\"codMunicipioIbge\":" + "\"\"," +
               "\"codUnidadeTs\":" + "\"\"," +
               "\"diaVencimento\":" + "\"\"," +
               "\"codTipoCobranca\":" + "\"6\"," +
                "\"numSeqControleArq\":" + "\"\"," +
                "\"codDependencia\":" + "\"\"," +
                "\"numDn\":" + "\"\"," +
                "\"codPsaTs\": " + "\"\"," +
                "\"indContratoNestle\":" + "\"S\"," +
                "\"codStatusNestle\":" + "\"AT\"," +
                "\"codUnidOrgNestle\":" + "\"10\"," +
                "\"codEmpresaNestle\":" + "\"BR10\"," +
                "\"codArhNestle\":" + "\"BRAA\"," +
                "\"registrosMovimentacao\":" + "[]," +
                "\"declaracaoSaude\":" + "{" +
                  "\"resposta\":" + "[" +
                    "{" +
                      "\"anoEvento\":" + "\"\"," +
                      "\"descricao\": " + "\"\"," +
                      "\"indResposta\":" + "false," +
                      "\"codigoQuestionario\":" + "\"1\"," +
                      "\"codigoCondicaoSaude\":" + "\"1\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"2\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" + "\"3\""+
                    "}," +
                   "{" +
                     "anoEvento\":" + "\"\"," +
                     "descricao\":" + "\"\"," +
                     "indResposta\":" + "false," +
                     "codigoQuestionario\":" + "\"1\"," +
                     "codigoCondicaoSaude\":" +"\"4\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"5\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"6\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"7\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"8\""+
                    "}," +
                   "{" +
                     "\"anoEvento\":" + "\"\"," +
                     "\"descricao\":" + "\"\"," +
                     "\"indResposta\":" + "false," +
                     "\"codigoQuestionario\":" + "\"1\"," +
                     "\"codigoCondicaoSaude\":" +"\"9\""+
                    "}" +
                 "]" +
               "},"+
                "\"anexo\":" + "{" +
                 "\"registro\":" + "[" +
                   "{"+
                      "\"dataAnexado\":" + "\"\"," +
                     "\'codigoUsuarioAtu\":" + "\"MA648064\"," +
                     "\"localArquivamento\":" + "\"teste\"," +
                     "\"nomeArquivoAnexo\":" + "\"EqpTHWK9acGBfo79PzPTV4eCDyYZcxnRwjbLsIwkfAw=\"," +
                     "\"indExcluir\":" +"false," +
                     "\"descricao\":" + "\"\"," +
                     "\"numSeqAssociadoAnexo\":" + "\"11126583\"," +
                     "\"guid\":" + "\"\"," +
                   "}" +
                 "]," +
                 "\"qtdAnexo\":" +  "\"1\""+
                "}," +
               "\"indAutorizacaoExtra\":" + "\"\"," +
               "\"indProcessaLote\":" + "\"\"," +
               "\"numSeqAssociadoWeb\":" + "\"0\"," +
               "\"usuarioAutorizacao\":" + "\"\"," +
               "\"enderecoIP\":" + "\"\"," +
               "\"indAutorizado\":" + "\"\"," +
               "\"txtAutorizacao\":" + "\"\"," +
               "\"indOperacao\":" + "\"\"," +
               "\"txtAcao\":" + "\"I\"," +
               "\"motivoRecusa\":" + "\"\"," +
               "\"codMensagem\":" + "\"\"," +
               "\"textoSolicitaAutorizacao\":" + "\"\"," +
               "\"siglaArea\":" + "\"\"," +
             "}";






                }


        [Then(@"o sistema deverá gerar a solicitação de inclusão Titular")]
        public void EntaoOSistemaDeveraGerarASolicitacaoDeInclusaoTitular()
        {
            //resposta = empresa.PostHttpWebRequest("Contrato/"+ listEmpresaData.CodigoContrato + "/Movimentacao/"+ listEmpresaData.Usuario, "json", 200, new string[] { "Realizado com sucesso." }, null, this.json);
            resposta = empresa.PostHttpWebRequest("Contrato/" + listEmpresaData.CodigoContrato + "/Movimentacao/" + listEmpresaData.Usuario, "json", 200, null, null, this.json);
            resposta = empresa.GetHttpWebRequest("Beneficiario/SituacaoWeb/" + listEmpresaData.numSeqAssociadoWeb, "json", 200, new string[] { "Validado e Pendente de Envio" }, null, null);
        }
    }
}
