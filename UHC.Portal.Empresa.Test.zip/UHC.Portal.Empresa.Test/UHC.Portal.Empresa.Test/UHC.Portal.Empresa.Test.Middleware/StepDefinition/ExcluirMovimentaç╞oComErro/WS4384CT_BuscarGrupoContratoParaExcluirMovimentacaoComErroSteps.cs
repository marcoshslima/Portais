﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    public class WS4384CT_BuscarGrupoContratoParaExcluirMovimentacaoComErroSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal empresa para Excluir Movimentação Com Erro para Grupo Contrato ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaExcluirMovimentacaoComErroParaGrupoContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"acessei o item de menu “Movimentação Cadastral / Excluir Movimentação Com Erro”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralExcluirMovimentacaoComErro()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [When(@"eu inserir o número do grupo contrato no campo Selecione o Grupo Contrato/Contrato")]
        public void QuandoEuInserirONumeroDoGrupoContratoNoCampoSelecioneOGrupoContratoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }

        [Then(@"o sistema irá mostrar o respectivo grupo contrato para o número digitado ""(.*)""")]
        public void EntaoOSistemaIraMostrarORespectivoGrupoContratoParaONumeroDigitado(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "?apenasContratosAtivos=false", "json", 200, new string[] { empresaData.GrupoContrato, empresaData.GrupoContratoName }, null, null);
        }

    }
}
