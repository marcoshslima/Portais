﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS4383CT_BuscarContratoParaExcluirMovimentacaoComErroSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal empresa para Excluir Movimentação Com Erro ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaExcluirMovimentacaoComErro(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"já acessei o item de menu “Movimentação Cadastral / Excluir Movimentação Com Erro”")]
        public void DadoJaAcesseiOItemDeMenuMovimentacaoCadastralExcluirMovimentacaoComErro()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no combobox no campo Selecione o Contrato")]
        public void QuandoEuClicarNoComboboxNoCampoSelecioneOContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Then(@"o sistema irá exibir todos os contratos/grupo contrato existentes para a empresa “Select the Contract Group”")]
        public void EntaoOSistemaIraExibirTodosOsContratosGrupoContratoExistentesParaAEmpresaSelectTheContractGroup()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "?apenasContratosAtivos=false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
    }
}
