﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ExcluirMovimentaçãoComErro
{
    [Binding]
    public class WS2638CT_ExcluirMovimentacaoComErroSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logado no portal Empresa para Excluir Movimentação com Erro ""(.*)""")]
        public void DadoLogadoNoPortalEmpresaParaExcluirMovimentacaoComErro(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Excluir Movimentação Com Erro”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralExcluirMovimentacaoComErro()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Contrato")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarContrato(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
        
        [Given(@"cliquei em “Continuar”")]
        public void DadoCliqueiEmContinuar()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Given(@"o sistema mostrou pelo menos uma linha de movimentação com erro na tabela “Movimentações Pendentes”")]
        public void DadoOSistemaMostrouPeloMenosUmaLinhaDeMovimentacaoComErroNaTabelaMovimentacoesPendentes()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Grupo Contrato")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarGrupoContrato(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesErro?codGrupoEmpresa=" + empresaData.GrupoContrato + "&indTipoUsuario=E", "json", 200, new string[] { "referencia", "quantidade" }, null, null);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Contrato “Não existe Movimentação Pendente para este contrato\.”")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarContratoNaoExisteMovimentacaoPendenteParaEsteContrato_(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Grupo Contrato “Não existe Movimentação Pendente para este contrato ou grupo contrato\.”")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarGrupoContratoNaoExisteMovimentacaoPendenteParaEsteContratoOuGrupoContrato_(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Given(@"deverá apresentar um link para a tela ""(.*)""")]
        public void DadoDeveraApresentarUmLinkParaATela(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/MotivosOperacao", "json", 200, new string[] { "Alteração de Cadastro", "Aposentados e Demitidos", "Cancela Exclusão", "Cancelar Transferência entre Filiais", "Exclusão", "Inclusão de Dependente", "Inclusão de Titular", "Reativação", "Transferência de Contrato", "Transferência entre filiais", "Troca de Plano" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "/false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario,empresaData.GrupoContrato }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/SituacaoMovimentacao/6", "json", 200, new string[] { "6", "7", "2", "Aguardando Autorização", "Autorizado", "Com Erro de Validação","Em análise", "Em análise na Operadora" }, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?CodTsContrato="+empresaData.codTsContrato+"&listarTodos=true&suspenso=true", "json", 200, new string[] { "648064001", "9900003878", "ALCIR MARTINS MORAES", "620705639", "NESTLE BRASIL LTDA BR10 NF", "ALTAIR CASTRO DURAES", "NESTLE BRASIL LTDA BR10 NF", "ANA AMELIA DE SOUSA" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/SituacaoMovimentacao/undefined", "json", 200, new string[] { "6", "7", "2", "Aguardando Autorização", "Autorizado", "Com Erro de Validação", "Em análise", "Em análise na Operadora" }, null, null);
            this.json = "{" +
                            "\"codIdentificacaoTs\":"+ "\"\"," +
                            "\"indTipoMsgE\": \"E\"," +
                            "\"codTsCont\":" + "\"\"," +
                            "\"indOrdenacao\": \"NOM\"," +
                            "\"codTsContrato\": \"" + empresaData.codTsContrato + "\"" +
                            "\"txtUsuario\": \"" + empresaData.Usuario + "\"" +
               "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Contrato/MovimentacaoPendente", "json"
                , 200
                , new string[] { "NUM_ASSOCIADO", "COD_EMPRESA", "TXT_SITUACAO_ASSOCIADO_WEB", }
                , null
                , this.json);
        }
        
        [When(@"eu selecionar a\(s\) linha\(s\) que desejo excluir")]
        public void QuandoEuSelecionarASLinhaSQueDesejoExcluir()
        {
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesErro?codTsContrato=" + empresaData.codTsContrato + "&indTipoUsuario=E", "json", 200, new string[] { "referencia", "quantidade" }, null, null);
        }

        [Then(@"o sistema retornará a mensagem “Exclusão de movimentações pendentes executada com sucesso\.” para contrato")]
        public void EntaoOSistemaRetornaraAMensagemExclusaoDeMovimentacoesPendentesExecutadaComSucesso_ParaContrato()
        {
            json = "{" +
               "\"mesAnoRef" + ": [" + "\"01/09/2018\"" + "]," +
                "\"codTsContrato\":\"" + empresaData.codTsContrato + "\"," +
                 "\"txtUsuario\":\"" + empresaData.Usuario + "\"," +
                 "\"codGrupoEmpresa\":" + "\"\"" +
               "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Contrato/ExcluiMovimentacaoErro", "json"
                , 200
                , new string[] { "[true]" }
                , null
                ,json);
        }

        [Then(@"o sistema retornará a mensagem “Exclusão de movimentações pendentes executada com sucesso\.” para grupo contrato")]
        public void EntaoOSistemaRetornaraAMensagemExclusaoDeMovimentacoesPendentesExecutadaComSucesso_ParaGrupoContrato()
        {
            this.json = "{" +
               "\"mesAnoRef" + ": [" + "\"01/06/2018\"" + "]," +
                "\"codTsContrato\":" + "\"\"," +
                 "\"txtUsuario\":\"" + empresaData.Usuario + "\"," +
                 "\"codGrupoEmpresa\":\"" + empresaData.GrupoContrato + "\"," +
               "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Contrato/ExcluiMovimentacaoErro", "json"
                , 200
                , new string[] { "[true]" }
                , null
                , this.json);
        }


        [Then(@"o sistema retornará a mensagem “Não existe Movimentação Pendente para este contrato\.”")]
        public void EntaoOSistemaRetornaraAMensagemNaoExisteMovimentacaoPendenteParaEsteContrato_()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesErro?codTsContrato=" + empresaData.codTsContrato + "&indTipoUsuario=E", "json", 200, new string[] { "[]" }, null, null);
        }
        
        [Then(@"o sistema retornará a mensagem “Não existe Movimentação Pendente para este contrato ou grupo contrato\.”")]
        public void EntaoOSistemaRetornaraAMensagemNaoExisteMovimentacaoPendenteParaEsteContratoOuGrupoContrato_()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesErro?codGrupoEmpresa=" + empresaData.GrupoContrato + "&indTipoUsuario=E", "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
