﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_4374_BuscarGrupoContratoParaConsultarASituacaoDaMovimentacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"Que  eu já fiz login no Portal Empresa_Grupo Contrato ""(.*)""")]
        public void DadoQueEuJaFizLoginNoPortalEmpresa_GrupoContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menuGrupo Contrato “Movimentação Cadastral / Consultar Situação de Movimentação”")]
        public void DadoAcesseiOItemDeMenuGrupoContratoMovimentacaoCadastralConsultarSituacaoDeMovimentacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUEE eu já fiz login no Portal Empresa_partenumero  ""(.*)""")]
        public void DadoQUEEEuJaFizLoginNoPortalEmpresa_Partenumero(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Consultar Situação de Movimentação”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralConsultarSituacaoDeMovimentacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUEEE eu já fiz login no Portal Empresa_Nome ""(.*)""")]
        public void DadoQUEEEEuJaFizLoginNoPortalEmpresa_Nome(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"QUE eu já fiz login no Portall Empresa_parte name ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortallEmpresa_ParteName(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"QUE o sistema mostrou pelo menos um grupo contratoselecionar ""(.*)""")]
        public void DadoQUEOSistemaMostrouPeloMenosUmGrupoContratoselecionar(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu inserir o número do grupo contrato no campGrupo Contratoo “Grupo Contrato/Contrato”")]
        public void QuandoEuInserirONumeroDoGrupoContratoNoCampGrupoContratooGrupoContratoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new[]{"nomeGrupoEmpresa","codigoGrupoEmpresa"}, null, null);

        }

        [When(@"eu clicar em um dos grupos contratos disponíveis_selecionar")]
        public void QuandoEuClicarEmUmDosGruposContratosDisponiveis_Selecionar()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema irá mostrar uma lista com o respectivo número digitadoo")]
        public void EntaoOSistemaIraMostrarUmaListaComORespectivoNumeroDigitadoo()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new[] { "nomeGrupoEmpresa", "codigoGrupoEmpresa" }, null, null);
        }
        
             
        [Then(@"o sistema transferirá os dados para o campo_selecionar “Grupo Contrato/Contrato”")]
        public void EntaoOSistemaTransferiraOsDadosParaOCampo_SelecionarGrupoContratoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new[] { "nomeGrupoEmpresa", "codigoGrupoEmpresa" }, null, null);
        }
    }
}
