﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_4375_BuscarBeneficiarioParaConsultarASituacaoDaMovimentacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"eu já acessei o item de menu_BuscarBenefeciarioo  “Movimentação Cadastral / Consultar Situação da Movimentação”   ""(.*)""")]
        public void DadoEuJaAcesseiOItemDeMenu_BuscarBenefeciariooMovimentacaoCadastralConsultarSituacaoDaMovimentacao(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"eu já acessei o item de menu_GrupoContrato  “Movimentação Cadastral / Consultar Situação da Movimentação”   ""(.*)""")]
        public void DadoEuJaAcesseiOItemDeMenu_GrupoContratoMovimentacaoCadastralConsultarSituacaoDaMovimentacao(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE eu já fiz as buscas iniciais de contrato_NumeroBeneficiario ""(.*)""")]
        public void DadoQUEEuJaFizAsBuscasIniciaisDeContrato_NumeroBeneficiario(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE eu já fiz as buscas iniciais de contrato_Parte ""(.*)""")]
        public void DadoQUEEuJaFizAsBuscasIniciaisDeContrato_Parte(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE eu já fiz as buscas iniciais de contrato_NomeBeneficiario ""(.*)""")]
        public void DadoQUEEuJaFizAsBuscasIniciaisDeContrato_NomeBeneficiario(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE eu já fiz as buscas iniciais de contrato_ParteNome  ""(.*)""")]
        public void DadoQUEEuJaFizAsBuscasIniciaisDeContrato_ParteNome(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given(@"QUE o sistema mostrou pelo menos um beneficiárioSelectionar ""(.*)""")]
        public void DadoQUEOSistemaMostrouPeloMenosUmBeneficiarioSelectionar(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar sob o campo_BuscarBenefeciario “Beneficiário”")]
        public void QuandoEuClicarSobOCampo_BuscarBenefeciarioBeneficiario()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sob o campo_GrupoContrato “Beneficiário”")]
        public void QuandoEuClicarSobOCampo_GrupoContratoBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o número do beneficiário no campo_NumeroBeneficiario “Beneficiário”")]
        public void QuandoEuInserirONumeroDoBeneficiarioNoCampo_NumeroBeneficiarioBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir parte do número do beneficiário no campo_Parte “Beneficiário”")]
        public void QuandoEuInserirParteDoNumeroDoBeneficiarioNoCampo_ParteBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir o nome do beneficiário no campo_NomeBenficiario “Beneficiário”")]
        public void QuandoEuInserirONomeDoBeneficiarioNoCampo_NomeBenficiarioBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu inserir parte do nome  do beneficiário no campo_ParteNome “Beneficiário”")]
        public void QuandoEuInserirParteDoNomeDoBeneficiarioNoCampo_ParteNomeBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"eu clicar em um dos beneficiários disponíveis_selecionar")]
        public void QuandoEuClicarEmUmDosBeneficiariosDisponiveis_Selecionar()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá exibir todos os beneficiário existentes para o contrato indicado e seus respectivos números_BuscarBeneficiario")]
        public void EntaoOSistemaIraExibirTodosOsBeneficiarioExistentesParaOContratoIndicadoESeusRespectivosNumeros_BuscarBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=9900003877&listarTodos=true&suspenso=true", "json", 200, new string[] { "nome_associado" }, null, null);

        }

        [Then(@"o sistema irá exibir todos os beneficiário existentes para o contrato indicado e seus respectivos números_GrupoContrato")]
        public void EntaoOSistemaIraExibirTodosOsBeneficiarioExistentesParaOContratoIndicadoESeusRespectivosNumeros_GrupoContrato()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar o respectivo beneficiário para o número digitado_NumeroBeneficiario")]
        public void EntaoOSistemaIraMostrarORespectivoBeneficiarioParaONumeroDigitado_NumeroBeneficiario()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar uma lista com o respectivo número digitado_Parte")]
        public void EntaoOSistemaIraMostrarUmaListaComORespectivoNumeroDigitado_Parte()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema irá mostrar uma lista com o respectivo nome digitado_ParteNome")]
        public void EntaoOSistemaIraMostrarUmaListaComORespectivoNomeDigitado_ParteNome()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"o sistema permitirá a conclusão do processo_selecionar")]
        public void EntaoOSistemaPermitiraAConclusaoDoProcesso_Selecionar()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
