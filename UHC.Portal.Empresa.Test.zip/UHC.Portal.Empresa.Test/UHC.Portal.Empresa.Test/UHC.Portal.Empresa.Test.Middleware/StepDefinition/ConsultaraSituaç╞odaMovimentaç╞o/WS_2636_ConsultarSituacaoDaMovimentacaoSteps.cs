﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultaraSituaçãodaMovimentação
{
    [Binding]
    public class WS_2636_ConsultarSituacaoDaMovimentacaoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;
        #endregion

        [Given(@"Que  eu já fiz login no Portal Empresa_Consulta de Situação ""(.*)""")]
        public void DadoQueEuJaFizLoginNoPortalEmpresa_ConsultaDeSituacao(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
            today = DateTime.Today;
            todayDateFormat = today.ToString("dd-MM-yyyy");
            Console.WriteLine(todayDateFormat);
            Console.WriteLine(lstEmpresaData);
        }
        
        [Given(@"acessei o item de menuGrupo ContratoConsulta de Situação “Movimentação Cadastral / Consultar Situação de Movimentação”")]
        public void DadoAcesseiOItemDeMenuGrupoContratoConsultaDeSituacaoMovimentacaoCadastralConsultarSituacaoDeMovimentacao()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"no campo\[Consulta_tela] ""(.*)"" selecionei a opção “Tela”")]
        public void DadoNoCampoConsulta_TelaSelecioneiAOpcaoTela(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"eu clicar em\[Consulta_tela] ""(.*)""")]
        public void QuandoEuClicarEmConsulta_Tela(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá apresentar um grid contentendo a situação das movimentações\[Consulta_tela]")]
        public void EntaoOSistemaDeveraApresentarUmGridContentendoASituacaoDasMovimentacoesConsulta_Tela()
        {
            resposta = empresa.GetHttpWebRequest("Job/ExecutadosCrypto/"+ lstEmpresaData.Usuario+"/"+lstEmpresaData.CodigoJob+"/"+todayDateFormat+"/"+todayDateFormat, "json", 200, null, null, null);   

        }
    }
}
