﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultadeLotes
{
    [Binding]
    public class WS4388CT_BuscarGrupoContratoParaConsultaDeLotesSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"Faça login no portal para testar no Consulta de Lotes funcionalidad ""(.*)""")]
        public void DadoFacaLoginNoPortalParaTestarNoConsultaDeLotesFuncionalidad(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu “Movimentação Cadastral / Consultar Lotes”")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralConsultarLotes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu inserir o número do grupo contrato no campo ""(.*)""")]
        public void QuandoEuInserirONumeroDoGrupoContratoNoCampo(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Then(@"o sistema irá mostrar o respectivo grupo contrato para o número digitado")]
        public void EntaoOSistemaIraMostrarORespectivoGrupoContratoParaONumeroDigitado()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "?apenasContratosAtivos=false", "json", 200, new string[] { empresaData.GrupoContrato, empresaData.GrupoContratoName }, null, null);
        }
    }
}
