﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultadeLotes
{
    [Binding]
    public class WS4395CT_RelatorioAnaliticoDaConsultaDeLotesSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"logar em Buscar Contrato Para Relatório Analítico da Consulta de Lotes ""(.*)""")]
        public void DadoLogarEmBuscarContratoParaRelatorioAnaliticoDaConsultaDeLotes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Contrato Para Consulta de Lotes")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarContratoParaConsultaDeLotes(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"o sistema apresentou a tela com as movimentações contidas no lote em questão")]
        public void DadoOSistemaApresentouATelaComAsMovimentacoesContidasNoLoteEmQuestao()
        {
            resposta = empresa.GetHttpWebRequest("Lote/PesquisarLoteMovimento/" + empresaData.codTsContrato + "/0", "json", 200, new string[] { "dataEnvio", "mesAnoRef", "numeroSeqControleLote" }, null, null);
        }
        
        [Given(@"já segui os passos indicados na US \[(.*)] - Buscar Grupo Contrato Para Consulta de Lotes")]
        public void DadoJaSeguiOsPassosIndicadosNaUS_BuscarGrupoContratoParaConsultaDeLotes(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar sobre o botão ""(.*)""")]
        public void QuandoEuClicarSobreOBotao(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Lote/ConsultarControleLote/" + empresaData.NumSeqControleLote, "json", 200, new string[] { "numeroSequenciaControleLote", empresaData.NumSeqControleLote }, null, null);
        }
        
        [Then(@"o sistema deverá apresentar o relatório analítico das movimentações")]
        public void EntaoOSistemaDeveraApresentarORelatorioAnaliticoDasMovimentacoes()
        {
            json = "{" +

                "\"tipoRelatorio\": \"PDF\","+
                "\"codigoRelatorio\": \"711\"," +
                "\"usuario\": \"G124138\"," +
                "\"senha\": \"74A9ADB9968F99A2AC2B\"," +
                "\"ip\": \"189.20.205.222\"," +
                "\"sistema\": \"dsisamil\"," +
                "\"modulo\": \"91\"," +
                "\"parametros\"" + ": ["+
                    "{"+
                        "\"chave\": \"pNumSeqControleLote\"," +
                        "\"valor\": 615166"
                    + "},"+
                    "{" +
                        "\"chave\": \"pCodTipoUsuario\"," +
                        "\"valor\": \"4\""
                    + "},"+
                    "{" +
                        "\"chave\": \"pCodGrupoEmpresa\"," +
                        "\"valor\": 124138"
                    + "}"
                              + "]"+
                          "}";
            resposta = empresa.PostHttpWebRequest("Relatorio", "json", 200, new string[] { "mensagem", "codigo" }, null, json);
        }
    }
}
