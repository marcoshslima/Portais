﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS4396CT_ProtocoloDaConsultaDeLotesSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logar em Buscar Contrato Para Protocolo da Consulta de Lotes ""(.*)""")]
        public void DadoLogarEmBuscarContratoParaProtocoloDaConsultaDeLotes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"segui os passos indicados na US \[(.*)] - Buscar Contrato Para Consulta de Lotes")]
        public void DadoSeguiOsPassosIndicadosNaUS_BuscarContratoParaConsultaDeLotes(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"osistema apresentou a tela com as movimentações contidas no lote em questão")]
        public void DadoOsistemaApresentouATelaComAsMovimentacoesContidasNoLoteEmQuestao()
        {
            resposta = empresa.GetHttpWebRequest("Lote/PesquisarLoteMovimento/0/" + empresaData.CodGrupoEmpresa, "json", 200, new string[] { "dataEnvio", "mesAnoRef", "numeroSeqControleLote" }, null, null);
        }
        
        [Given(@"segui os passos indicados na US \[(.*)] - Buscar Grupo Contrato Para Consulta de Lotes")]
        public void DadoSeguiOsPassosIndicadosNaUS_BuscarGrupoContratoParaConsultaDeLotes(int p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá apresentar a tela contendo os tipos de movimentações a quantidade de movimentações para o lote em questão")]
        public void EntaoOSistemaDeveraApresentarATelaContendoOsTiposDeMovimentacoesAQuantidadeDeMovimentacoesParaOLoteEmQuestao()
        {
            resposta = empresa.GetHttpWebRequest("Lote/ConsultarControleLote/" + empresaData.NumSeqControleLote, "json", 200, new string[] { "numeroSequenciaControleLote", empresaData.NumSeqControleLote }, null, null);
        }
    }
}
