﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ConsultadeLotes
{
    [Binding]
    public class WS4387CT_BuscarContratoParaConsultaDeLotesSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"logar em Buscar Contrato Para Consulta de Lotes ""(.*)""")]
        public void DadoLogarEmBuscarContratoParaConsultaDeLotes(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já acessei o item de menu “Movimentação Cadastral / Consultar Lotes”")]
        public void DadoJaAcesseiOItemDeMenuMovimentacaoCadastralConsultarLotes()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no combobox no campo “Grupo Contrato/Contrato”")]
        public void QuandoEuClicarNoComboboxNoCampoGrupoContratoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [Then(@"osistema irá exibir todos os contratos/grupo contrato existentes para a empresa")]
        public void EntaoOsistemaIraExibirTodosOsContratosGrupoContratoExistentesParaAEmpresa()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario + "?apenasContratosAtivos=false", "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
    }
}
