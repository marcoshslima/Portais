﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.SolicitacaoDeArquivos
{
    [Binding]
    public class WS2621SolicitacaoDeArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Arquivos ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaArquivos(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [Given(@"Que eu tenha acessado o Menu Gestão Financeira e Demonstrativos/ Solicitação de Arquivos")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoFinanceiraEDemonstrativosSolicitacaoDeArquivos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"já preenchi os campos Contrato e Tipo de solicitação")]
        public void DadoJaPreenchiOsCamposContratoETipoDeSolicitacao()
        {
            resposta = empresa.GetHttpWebRequest("TipoArquivo", "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoTipoArquivo"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [Given(@"preenchi os campos obrigatórios")]
        public void DadoPreenchiOsCamposObrigatorios()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarContratos?NumContrato="+listEmpresaData.NumContrato+ "&quantidadeDe=" + listEmpresaData.QuantidadeDe+ "&quantidadeDe=" + listEmpresaData.QuantidadeAte, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("nomeOperadora"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [When(@"clico em Enviar")]
        public void QuandoClicoEmEnviar()
        {
            json = "{" +
            "\"codigoGrupoEmpresa\":\"\"," +
            "\"codigoTSContrato\":\"" + listEmpresaData.CodigoTSContrato + "\"," +
            "\"mesAnoReferencia\":\"" + listEmpresaData.MesAnoReferencia + "\"," +
            "\"numeroSequenciaFaturaTS\":\"\"," +
            "\"numeroControleCopartSeq\":\"\"," +
            "\"indTipoContrato\":\"" + listEmpresaData.IndTipoContrato + "\"," +
            "\"indFaturado\":\"" + listEmpresaData.IndFaturado + "\"," +
            "\"indFaturado\":\"" + listEmpresaData.IndFaturado + "\"," +
            "\"codigoTipoArquivo\":\"" + listEmpresaData.CodigoTipoArquivo + "\"," +
            "\"codigoUsuario\":\"" + listEmpresaData.CodigoUsuario + "\"," +
            "\"email\":\"" + listEmpresaData.Email + "\"," +         
            "}";
        }
        [When(@"seleciono no campo Tipo de Solicitação Arquivo Beneficiário Com ou Sem Preço ou Arquivo de Custo Operacional ou Coparticipação de Arquivo de Uso")]
        public void QuandoSelecionoNoCampoTipoDeSolicitacaoArquivoBeneficiarioComOuSemPrecoOuArquivoDeCustoOperacionalOuCoparticipacaoDeArquivoDeUso()
        {
            resposta = empresa.GetHttpWebRequest("CicloFaturamento/GetCompetencia/"+listEmpresaData.CodTsContrato+"/"+listEmpresaData.CodTipoCiclo+"/"+listEmpresaData.CodGrupoEmpresa, "json", 200, null, null, null);
        }

        [Then(@"o campo Dados de Competência mudará para um combo com o mês de referência e vencimento")]
        public void EntaoOCampoDadosDeCompetenciaMudaraParaUmComboComOMesDeReferenciaEVencimento()
        {            
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroSequenciaFaturaTS"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        [Then(@"o sistema retornará a mensagem Operação executada com sucesso")]
        public void EntaoOSistemaRetornaraAMensagemOperacaoExecutadaComSucesso()
        {
            resposta = empresa.PostHttpWebRequest("ControleArquivo", "json", 200, null, null, json);
        }
    }
}
