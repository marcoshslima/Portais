﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS4074_BuscarCEPParaAlterarBeneficiarioTipoDeConsultaCEPSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já realizei a busca de endereços por tipo de consulta “CEP” ""(.*)""")]
        public void DadoQUEEuJaRealizeiABuscaDeEnderecosPorTipoDeConsultaCEP(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [When(@"eu clicar sobre o botão de seleção contido em algum endereço na listagem de resultados depois de Buscar CEP")]
        public void QuandoEuClicarSobreOBotaoDeSelecaoContidoEmAlgumEnderecoNaListagemDeResultadosDepoisDeBuscarCEP()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema irá realizar o preenchimento automático dos campos ”CEP”, “Logradouro”, “Município”, “UF” e “Bairro” contidos na tela de inclusão de titular")]
        public void EntaoOSistemaIraRealizarOPreenchimentoAutomaticoDosCamposCEPLogradouroMunicipioUFEBairroContidosNaTelaDeInclusaoDeTitular()
        {
            resposta = empresa.GetHttpWebRequest("Endereco/Cep/" + empresaData.Numerocaixapostal, "json", 200, new string[] { "cep", "siglaUF", "codigoMunicipio", "municipio", "codigoBairro", "bairro", "logradouro", "logradouroCompleto", "codigoTipoLogradouro", "complementoTipo", "complemento" }, null, null);
        }
    }
}
