﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3197_BuscarCentroDeCustoParaAlterarBeneficiarioSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma Centro de Custo \(código/nome\) dentro do combo “Centro de Custo” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaCentroDeCustoCodigoNomeDentroDoComboCentroDeCusto(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar sobre alguma “Centro de Custo” listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaCentroDeCustoListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Centro de Custo” o código e nome da “Centro de Custo” correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoCentroDeCustoOCodigoENomeDaCentroDeCustoCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("CentroCusto/Contrato/" + empresaData.CodTsContrato + "?Filter=" + empresaData.filter + " & Limit = " + empresaData.limit, "json", 200, new string[] { "codLocalTrabalho", "nomLocalTrabalho", "codTsContrato", "codLocalTs" }, null, null);
        }
    }
}
