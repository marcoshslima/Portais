﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.AlterarCadastrodeBeneficiários
{
    [Binding]
    public class WS3189CT_BuscarBeneficiarioParaAlteracaoDeCadastroSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Buscar Beneficiário Para Alteração de Cadastro ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscarBeneficiarioParaAlteracaoDeCadastro(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"Selecionar contrato na lista ""(.*)""")]
        public void QuandoSelecionarContratoNaLista(string p0)
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaDeclaracaoDeSaude", "json", 200, new string[] { "coD_QUESTIONARIO", "coD_CONDICAO_SAUDE", "txT_OBS", "txT_CONDICAO", "inD_SEXO" }, null, null);
        }
        
        [When(@"eu digitar a partir de (.*) caractere dentro da combo “Selecione o beneficiário”")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboSelecioneOBeneficiario(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/BuscarDadosContrato/"+empresaData.numeroContrato+"/"+empresaData.codTsContrato, "json", 200, new string[] { empresaData.numeroContrato,empresaData.codTsContrato,empresaData.ContratoName }, null, null);
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + empresaData.numeroContrato + "&listarTodos=true&suspenso=true", "json", 200, new string[] { empresaData.numeroContrato, empresaData.codTsContrato, empresaData.ContratoName,empresaData.BeneficiarioNome,empresaData.BeneficiarioCPF,empresaData.BeneficiarioMarcaOtica }, null, null);

        }
        
        [Then(@"o sistema deve listar abaixo o combo dos beneficiários cadastrados de acordo com o que está sendo digitado no campo de entrada beneficiário")]
        public void EntaoOSistemaDeveListarAbaixoOComboDosBeneficiariosCadastradosDeAcordoComOQueEstaSendoDigitadoNoCampoDeEntradaBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/"+ empresaData.codTsContrato, "json", 200, new string[] { "contratoNeste", "true" }, null, null);
        }
    }
}
