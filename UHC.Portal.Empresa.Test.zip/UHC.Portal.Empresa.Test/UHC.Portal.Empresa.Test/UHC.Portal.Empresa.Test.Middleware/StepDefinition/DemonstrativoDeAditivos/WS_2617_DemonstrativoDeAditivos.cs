﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DemonstrativoDeAditivos
{
    [Binding]
    public class WS2617DemonstracaoDeAditivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion
        [Given(@"que eu já fiz o login no Portal da Empresa Aditivos ""(.*)""")]
        public void DadoQueEuJaFizOLoginNoPortalDaEmpresaAditivos(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu Gerenciamento Financeiro e Demonstrações / Demonstrações de Aditivos")]
        public void DadoAcesseiOItemDeMenuGerenciamentoFinanceiroEDemonstracoesDemonstracoesDeAditivos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"procure o contrato e selecione contrato na combobox")]
        public void QuandoProcureOContratoESelecioneContratoNaCombobox()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/"+listEmpresaData.CodigoUsuario+ "?apenasContratosAtivos=" + listEmpresaData.ApenasContratosAtivos, "json", 200, null, null, null);                                       
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroContrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [When(@"clico no código desejado da Fatura")]
        public void QuandoClicoNoCodigoDesejadoDaFatura()
        {
            resposta = empresa.GetHttpWebRequest("Aditivo/Demonstrativo/"+listEmpresaData.CodTsContrato+"/"+listEmpresaData.NumCicloTs+"/"+listEmpresaData.CodigoUsuario+"/"+listEmpresaData.Ip, "json", 200, null, null, null);
            
        }        
        [Then(@"o sistema mostrará uma grade contendo as faturas relacionadas ao contrato selecionado")]
        public void EntaoOSistemaMostraraUmaGradeContendoAsFaturasRelacionadasAoContratoSelecionado()
        {
            resposta = empresa.GetHttpWebRequest("Fatura/PesquisarExtratoCliente/"+listEmpresaData.CodTsContrato+"/"+listEmpresaData.CodTipoCiclo, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numeroFatura"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [Then(@"o sistema retornará a mensagem Nenhum registro foi encontrado para os parâmetros relatados")]
        public void EntaoOSistemaRetornaraAMensagemNenhumRegistroFoiEncontradoParaOsParametrosRelatados()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("Mensagem"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
    }
}
