﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DeclaracaoDePagament
{
    [Binding]
    public class WS10485BuscarContratoEBeneficiarioParaDeclaracaoDePagamentoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Declaracao Pagamento ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaDeclaracaoPagamento(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão de Beneficiários/ Demonstrativos e Declarações/ Demonstrativo de Pagamento")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoDeBeneficiariosDemonstrativosEDeclaracoesDemonstrativoDePagamento()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Given(@"QUE eu já digitei totalmente ou parcialmente um beneficiário \(marca ótica / nome\) dentro do campo Selecione o beneficiário")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmBeneficiarioMarcaOticaNomeDentroDoCampoSelecioneOBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/" + listEmpresaData.CodigoUsuario +"/"+ listEmpresaData.ApenasContratosAtivos, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codigoOperadora"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [When(@"eu clicar sobre algum beneficiário listado abaixo da combo")]
        public void QuandoEuClicarSobreAlgumBeneficiarioListadoAbaixoDaCombo()
        {             
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+listEmpresaData.NumContrato +"/"+listEmpresaData.NumAssociado+ "&listarTodos="+listEmpresaData.listarTodos+ "&suspenso="+listEmpresaData.suspenso, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numero_contrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo Selecione o beneficiário o número do contrato, nome e marca ótica do beneficiário correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoSelecioneOBeneficiarioONumeroDoContratoNomeEMarcaOticaDoBeneficiarioCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("DeclaracaoPagamento/ValidaDisponibilidade/"+listEmpresaData.CodTsContrato +"/"+listEmpresaData.codTs, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("mensagem"))
                //if (strArr[numContrato].Contains("Sucesso."))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if ((numContratocontagem > 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
    }
}
