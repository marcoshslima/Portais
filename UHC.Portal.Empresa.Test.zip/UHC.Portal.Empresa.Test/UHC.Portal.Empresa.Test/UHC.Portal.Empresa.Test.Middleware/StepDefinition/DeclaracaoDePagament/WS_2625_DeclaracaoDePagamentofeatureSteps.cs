﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DeclaracaoDePagament
{
    [Binding]
    public class WS2625DeclaracaoDePagamentoSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa  Pagamento ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaPagamento(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão de Beneficiários/Demonstrativos e Declarações/Demonstrativo de Pagamento")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoDeBeneficiariosDemonstrativosEDeclaracoesDemonstrativoDePagamento()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"selecionei um contrato no campo Selecione um contrato e Beneficiário")]
        public void QuandoSelecioneiUmContratoNoCampoSelecioneUmContratoEBeneficiario()
        {
            System.Threading.Thread.Sleep(400);
        }
        [When(@"eu digitar a partir de (.*) caractere dentro da combo Selecione o beneficiário\.")]
        public void QuandoEuDigitarAPartirDeCaractereDentroDaComboSelecioneOBeneficiario_(int p0)
        {                    
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato="+listEmpresaData.NumContrato+"&NomeAssociado="+listEmpresaData.NumAssociado+ "&listarTodos="+listEmpresaData.listarTodos+ "&suspenso="+listEmpresaData.suspenso, "json", 200, null, null, null);
        }
        [When(@"eu digitar um cpf/nome/marca ótica de beneficiário inexistente na combo Selecione o beneficiário")]
        public void QuandoEuDigitarUmCpfNomeMarcaOticaDeBeneficiarioInexistenteNaComboSelecioneOBeneficiario()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaBeneficiariosDependente?NumContrato=" + listEmpresaData.NumContrato + "&NomeAssociado=" + listEmpresaData.InvalidNumAssociado + "&listarTodos=" + listEmpresaData.listarTodos + "&suspenso=" + listEmpresaData.suspenso, "json", 200, null, null, null);
        }


        [Then(@"eu clicar sobre botão Executar")]
        public void EntaoEuClicarSobreBotaoExecutar()
        {
            resposta = empresa.GetHttpWebRequest("DeclaracaoPagamento/" +listEmpresaData.codTsBeneficiario + "/"+DateTime.Now.ToString("MM-yyyy") + "/" + DateTime.Now.ToString("MM-yyyy")+"/PDF", "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("mensagem"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        [Then(@"o sistema deverá listar abaixo da combo os beneficiários cadastrados de acordo com o que está sendo digitado")]
        public void EntaoOSistemaDeveraListarAbaixoDaComboOsBeneficiariosCadastradosDeAcordoComOQueEstaSendoDigitado()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("numero_contrato"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }       

    }
}
