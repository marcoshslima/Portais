﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_17147_ExclusaoDoBeneficiario_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;
        #endregion
        [Given(@"eu já fiz login no Portal Empresa_Exclusão do Beneficiário ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresa_ExclusaoDoBeneficiario(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"realizei pesquisa de movimentações relacionadas à exclusão de beneficiário")]
        public void QuandoRealizeiPesquisaDeMovimentacoesRelacionadasAExclusaoDeBeneficiario()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu realizar alterações nos dados contidos na tela")]
        public void QuandoEuRealizarAlteracoesNosDadosContidosNaTela()
        {
            Console.WriteLine(empresa);

        }
        
        [Then(@"clicar sobre o botão “Salvar”")]
        public void EntaoClicarSobreOBotaoSalvar()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresaNovo/"+lstEmpresaData.Usuario+"/false","json", 200, null, null, null);

        }
    }
}
