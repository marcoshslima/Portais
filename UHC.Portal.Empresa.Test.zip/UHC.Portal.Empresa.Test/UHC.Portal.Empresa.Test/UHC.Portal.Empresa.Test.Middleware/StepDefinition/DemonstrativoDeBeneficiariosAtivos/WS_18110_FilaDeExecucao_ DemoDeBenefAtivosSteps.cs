﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DemonstrativoDeBeneficiariosAtivos
{
    [Binding]
    public class WS18110FilaDeExecucao_DemonstrativoDeBeneficiariosAtivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa Demonstrativo ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaDemonstrativo(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão Financeira e Demonstrativos/Demonstrativo de Beneficiários Ativos")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeBeneficiariosAtivos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"selecione Contrato")]
        public void QuandoSelecioneContrato()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/GetPlanos?CodTsContrato=" + listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codPlano"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
        
        [When(@"clico em Buscar")]
        public void QuandoClicoEmBuscar()
        {
            json = "{" +
                             "\"numSeqFila\":\"" + listEmpresaData.NumSeqFila + "\"," +
                             "\"codUsuario\":\"\"," +
                             "\"codigoTipoRelatorio\":\"\"," +
                             "\"dataInicio\":\"\"," +
                             "\"dataFim\":\"\" "+
                    "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Relatorio/PesquisarFilaRelatorio", "json"
                , 200
                , new string[] { "codigoRetorno", "codUsuario", "dataFimExecucao", "dataInicioExecucao", "dataSolicitacao", "mensagemRetorno","nomeArquivoGerado", "nomeTipoRelatorio", "numSeqFila", "xmlParametros" }
                , null
                , json);
        }
        [When(@"QUE o sistema já foi redirecionado para a Fila de Execução")]
        public void QuandoQUEOSistemaJaFoiRedirecionadoParaAFilaDeExecucao()
        {
            json = "{" +
                        "\"configuracaoRelatorioViewModel\":" +
                        "{" +
                             "\"usuario\":\"" + listEmpresaData.Usuario + "\"," +
                             "\"senha\":\"" + listEmpresaData.Senha + "\"," +
                             "\"ip\":\"" + listEmpresaData.Ip + "\"," +
                             "\"email\":\"" + listEmpresaData.Email + "\"," +
                             "\"modulo\":\"" + listEmpresaData.Modulo + "\"," +
                             "\"sistema\":\"" + listEmpresaData.Sistema + "\"" +                             
                        "}," +
                        "\"consultaRelatorioViewModel\":" +
                        "{" +
                             "\"tipoEnvio\":\"" + listEmpresaData.TipoEnvio + "\"," +
                             "\"codigoFuncao\":\"\"," +
                             "\"codigoTS\":\"\"," +
                             "\"codigoTSContrato\":\"\"," +
                             "\"indTipoAtd\":\"\"" +
                        "}," +
                        "\"codigoRelatorio\":\"" + listEmpresaData.CodigoRelatorio + "\"," +
                        "\"parametros\":" +
                        "[" +
                            
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key1 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value1 + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key2 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value2 + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key3 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value3 + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key4 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value4 + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key5 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value5 + "\"" +
                            "}," +
                            "{" +
                                 "\"key\":\"" + listEmpresaData.Key6 + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value6 + "\"" +
                            "}" +
                        "]" +

                 "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Relatorio/InserirFilaRelatorio", "json"
                , 200
                , new string[] { "codigoRetorno", "mensagemRetorno", "numeroSequenciaFila" }
                , null
                , json);

        }


        [Then(@"o sistema mostrará uma fila de execução")]
        public void EntaoOSistemaMostraraUmaFilaDeExecucao()
        {
            json = "{" +
                        "\"configuracaoRelatorioViewModel\":" +
                        "{" +
                             "\"usuario\":\""+listEmpresaData.Usuario +"\"," +
                             "\"senha\":\"" + listEmpresaData.Senha + "\"," +
                             "\"ip\":\"" + listEmpresaData.Ip + "\"," +
                             "\"email\":\"" + listEmpresaData.Email + "\"," +
                             "\"modulo\":\"" + listEmpresaData.Modulo + "\"," +
                             "\"sistema\":\"" + listEmpresaData.Sistema + "\"," +
                             "\"destinatario\":\"" + listEmpresaData.Destinatario + "\"," +
                             "\"nomeRelatorio\":\"" + listEmpresaData.NomeRelatorio + "\"" +
                        "},"+
                        "\"consultaRelatorioViewModel\":" +
                        "{" +
                             "\"tipoEnvio\":\"" + listEmpresaData.TipoEnvio + "\"," +
                             "\"codigoFuncao\":\"\"," +
                             "\"codigoTS\":\"\"," +
                             "\"codigoTSContrato\":\"\"," +
                             "\"indTipoAtd\":\"\"" +
                        "},"+
                        "\"codigoRelatorio\":\"" + listEmpresaData.CodigoRelatorio + "\"," +
                        "\"parametros\":" +
                        "["+
                            "{"+
                                 "\"key\":\"" + listEmpresaData.Key + "\"," +
                                 "\"value\":\"" + listEmpresaData.Value + "\"" +
                            "}"+
                        "]"+

                 "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Relatorio/InserirFilaRelatorio", "json"
                , 200
                , new string[] { "codigoRetorno", "mensagemRetorno", "numeroSequenciaFila" }
                , null
                , json);

        }
        [Then(@"o sistema retornará a mensagem Nenhuma informação foi encontrada com os critérios de seleção selecionados")]
        public void EntaoOSistemaRetornaraAMensagemNenhumaInformacaoFoiEncontradaComOsCriteriosDeSelecaoSelecionados()
        {
            json = "{" +
                         "\"codUsuario\":\"\"," + 
                         "\"enderecoIp\":\"\"," +
                         "\"indRel\":\"" + listEmpresaData.IndRel + "\"," +
                         "\"codTsContrato\":\"" + listEmpresaData.CodTsContratoNaoInf + "\"," +
                         "\"codPlano\":" + listEmpresaData.CodPlanoAgr + "," +
                         "\"codEntidadeTs\":\"\"," +
                         "\"indOrdenacao\":\"" + listEmpresaData.IndOrdenacao + "\"," +
                         "\"indTipoBeneficiario\":\"" + listEmpresaData.IndTipoBeneficiario + "\"," +
                         "\"codGrupoContrato\":\"\"," +
                         "\"codLotacaoTs\":\"\"," +
                         "\"numContrato\":\"" + listEmpresaData.NumContrato + "\"," +
                         "\"indTipoRelatorio\":\"\"," +
                         "\"codOperadora\":\"\"," +
                         "\"codSucursal\":\"\"," +
                         "\"codInspetoriaTs\":\"\"" +
             "}"; 
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Beneficiario/PostRelatorioBeneficiarioAtivo", "json"
                , 200
                , new string[] { "codRetorno", "msgRetorno", "nomeArquivo", "caminhoWebFile" }
                , null
                , json);

        }

        [Then(@"já retornou a mensagem Solicitação gravada com No\. \[Número] na Fila de Relatórios : \[Código]")]
        public void EntaoJaRetornouAMensagemSolicitacaoGravadaComNo_NumeroNaFilaDeRelatoriosCodigo()
        {
            json = "{" +
                            "\"numSeqFila\":\"" + listEmpresaData.NumSeqFila + "\"," +
                            "\"codUsuario\":\"\"," +
                            "\"codigoTipoRelatorio\":\"\"," +
                            "\"dataInicio\":\"\"," +
                            "\"dataFim\":\"\" " +
                   "}";
            Console.WriteLine(json);
            resposta = empresa.PostHttpWebRequest("Relatorio/PesquisarFilaRelatorio", "json"
                , 200
                , new string[] { "codigoRetorno", "codUsuario", "dataFimExecucao", "dataInicioExecucao", "dataSolicitacao", "mensagemRetorno", "nomeArquivoGerado", "nomeTipoRelatorio", "numSeqFila", "xmlParametros" }
                , null
                , json);
        }

    }
}
