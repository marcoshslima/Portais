﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.DemonstrativoDeBeneficiariosAtivos
{
    [Binding]
    public class WS15503BuscaContratoDeBeneficiariosAtivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        #endregion

        [Given(@"QUE eu já fiz login no Portal Empresa Ativos ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaAtivos(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"Que eu tenha acessado o Menu Gestão Financeira e Demonstrativos /Demonstrativo de Beneficiários Ativos")]
        public void DadoQueEuTenhaAcessadoOMenuGestaoFinanceiraEDemonstrativosDemonstrativoDeBeneficiariosAtivos()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar em um dos contratos disponíveis")]
        public void QuandoEuClicarEmUmDosContratosDisponiveis()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/GetPlanos?CodTsContrato=" + listEmpresaData.CodTsContrato, "json", 200, null, null, null);            
        }

        [Then(@"o sistema transferirá as informações para a combo")]
        public void EntaoOSistemaTransferiraAsInformacoesParaACombo()
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int numContrato = 0;
            int numContratocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (numContrato = 0; numContrato <= strArr.Length - 1; numContrato++)
            {
                if (strArr[numContrato].Contains("codPlano"))
                {
                    numContratocontagem = numContratocontagem + 1;
                }
            }
            // valor validation
            if (!(numContratocontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }
    }
}
