﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS4078_BuscarCEPParaAlterarBeneficiarioTipoDeConsultaLogradouroLocalidadeSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já realizei a busca de endereços por tipo de consulta “Logradouro/Localidade” ""(.*)""")]
        public void DadoQUEEuJaRealizeiABuscaDeEnderecosPorTipoDeConsultaLogradouroLocalidade(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu preencher os campos obrigatórios e clicar sobre o botão “Buscar CEP”")]
        public void QuandoEuPreencherOsCamposObrigatoriosEClicarSobreOBotaoBuscarCEP()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema irá exibir todos os endereços cadastrados de acordo com o critério da pesquisa")]
        public void EntaoOSistemaIraExibirTodosOsEnderecosCadastradosDeAcordoComOCriterioDaPesquisa()
        {
            resposta = empresa.GetHttpWebRequest("Municipio/Bairros/" + empresaData.CodigoMunicipio, "json", 200, new string[] { "chaveBaiDne", "chaveLocDne", "siglaUf", "nomeOfiBai", "nomeOfiBaiPsq", "abreBaiRecEct", "codRegionalOld", "codUsuarioAtu", "dtAtu", "codLocalidadeOld", "codBairroOld" }, null, null);
            resposta = empresa.GetHttpWebRequest("Endereco/" + empresaData.SiglaUF+"/"+empresaData.CodigoLocalidade + "?codigoBairro="+ empresaData.CodigoBairro + "&codigoTipoLogradouro="+ empresaData.CodigoTipoLogradouro + "&codigoTitulo="+ empresaData.CodigoTitulo + "&nomeLogradouro="+empresaData.NomeLogradouro, "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
