﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;
namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_17146_AlterarCadastroDoBeneficiarioTitularSteps

    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion
        [Given(@"eu já fiz login no Portal Empresa_Alterar Cadastro do Beneficiário Titular ""(.*)""")]
        public void DadoEuJaFizLoginNoPortalEmpresa_AlterarCadastroDoBeneficiarioTitular(string p0)
        {

            empresaData = new WS_Empresa_Data(p0);

        }

        [Given(@"acessei o item de menu “Movimentação Cadastral / Consultar Situação Movimentação”_-Alteração da Solicitação")]
        public void DadoAcesseiOItemDeMenuMovimentacaoCadastralConsultarSituacaoMovimentacao__AlteracaoDaSolicitacao()
        {
            empresa = new WebService(Ambiente.BaseUri); ;
        }
        
        [Given(@"realizei pesquisa de movimentações relacionadas à alteração de cadastro de beneficiário titular")]
        public void DadoRealizeiPesquisaDeMovimentacoesRelacionadasAAlteracaoDeCadastroDeBeneficiarioTitular()
        {
            resposta = empresa.GetHttpWebRequest("BeneficiarioDependente/ListaDeclaracaoDeSaude", "json", 200, null, null, null);
           
        }
        
        [Given(@"o sistema apresentou uma grid contendo movimentações correspondentes à pesquisa")]
        public void DadoOSistemaApresentouUmaGridContendoMovimentacoesCorrespondentesAPesquisa()
        {
            resposta = empresa.GetHttpWebRequest("Beneficiario/"+empresaData.NumAssociado+ "/DadosAlteracao", "json", 200, null, null, null);
            
        }
        
        [Given(@"cliquei sobre o link contido sobre o  nome do beneficiário ou marca ótica")]
        public void DadoCliqueiSobreOLinkContidoSobreONomeDoBeneficiarioOuMarcaOtica()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/Ocorrencias/"+empresaData.NomSituacaoAssociado, "json", 200, null, null, null);
        }
        
        [When(@"eu realizar alterações nos dados contidos na tela \(preenchimento/alteração dos campos\)")]
        public void QuandoEuRealizarAlteracoesNosDadosContidosNaTelaPreenchimentoAlteracaoDosCampos()
        {
            resposta = empresa.GetHttpWebRequest("EstadoCivil", "json", 200, null, null, null);
        }
        
        [When(@"clicar sobre o botão “Salvar”")]
        public void QuandoClicarSobreOBotaoSalvar()
        {
           resposta = empresa.GetHttpWebRequest("ConfiguracaoSistema/Contrato/"+empresaData.CodTsContrato+"/Valor/BLOQUEIO_ALTERACAO_CADASTRAL", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema deverá gravar as alterações realizadas_-Alteração da Solicitação")]
        public void EntaoOSistemaDeveraGravarAsAlteracoesRealizadas__AlteracaoDaSolicitacao()
        {
            resposta = empresa.GetHttpWebRequest("OrgaoEmissor", "json", 200, null, null, null);
        }
    }
}
