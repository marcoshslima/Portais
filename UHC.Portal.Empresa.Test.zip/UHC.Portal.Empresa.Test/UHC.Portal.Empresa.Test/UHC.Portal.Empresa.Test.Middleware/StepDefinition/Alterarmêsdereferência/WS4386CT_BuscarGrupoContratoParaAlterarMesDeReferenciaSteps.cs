﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS4386CT_BuscarGrupoContratoParaAlterarMesDeReferenciaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal empresa para alterar mes de referencia para Grupo Contrato ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaAlterarMesDeReferenciaParaGrupoContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu inserir o número do grupo contrato no campo “Grupo Contrato/Contrato” Grupo Contrato – Número Grupo Contrato")]
        public void QuandoEuInserirONumeroDoGrupoContratoNoCampoGrupoContratoContratoGrupoContratoNumeroGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/"+empresaData.Usuario, "json", 200, new string[] { empresaData.GrupoContrato, empresaData.GrupoContratoName }, null, null);
        }
        
        [Then(@"o sistema irá mostrar o respectivo grupo contrato para o número digitado Grupo Contrato – Número Grupo Contrato")]
        public void EntaoOSistemaIraMostrarORespectivoGrupoContratoParaONumeroDigitadoGrupoContratoNumeroGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/"+empresaData.Usuario+"/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
    }
}
