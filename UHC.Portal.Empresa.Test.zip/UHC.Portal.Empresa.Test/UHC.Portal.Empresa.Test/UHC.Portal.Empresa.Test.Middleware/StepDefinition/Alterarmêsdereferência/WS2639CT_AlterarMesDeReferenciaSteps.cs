﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Alterarmêsdereferência
{
    [Binding]
    public class WS2639CT_AlterarMesDeReferenciaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal empresa para Movimentação Pendente de Meses Anteriores ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaMovimentacaoPendenteDeMesesAnteriores(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"já segui os passos indicados na US \[(.*)] - Buscar Contrato para Movimentação Pendente de Meses Anteriores")]
        public void QuandoJaSeguiOsPassosIndicadosNaUS_BuscarContratoParaMovimentacaoPendenteDeMesesAnteriores(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
        
        [When(@"cliquei em “Buscar”")]
        public void QuandoCliqueiEmBuscar()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario + "/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
        
        [When(@"o sistema mostrou pelo menos uma linha de movimentação na tabela “Resumo da Movimentação Pendente de Meses Anteriores”")]
        public void QuandoOSistemaMostrouPeloMenosUmaLinhaDeMovimentacaoNaTabelaResumoDaMovimentacaoPendenteDeMesesAnteriores()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
        }

        [When(@"eu clicar em “Executar” para Contrato")]
        public void QuandoEuClicarEmExecutarParaContrato()
        {
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesReferencia?codTsContrato=" + empresaData.codTsContrato + "&indTipoUsuario=E&mesAnoRef=01/09/2018", "json", 200, new string[] { "[]" }, null, null);
        }

        [When(@"eu clicar em “Executar” para Grupo Contrato")]
        public void QuandoEuClicarEmExecutarParaGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesReferencia?codGrupoEmpresa=" + empresaData.GrupoContrato + "&indTipoUsuario=E&mesAnoRef=01/09/2018", "json", 200, new string[] { "[]" }, null, null);
        }


        [When(@"já segui os passos indicados na US \[(.*)] - Buscar Grupo Contrato para Movimentação Pendente de Meses Anteriores")]
        public void QuandoJaSeguiOsPassosIndicadosNaUS_BuscarGrupoContratoParaMovimentacaoPendenteDeMesesAnteriores(int p0)
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }

        [Then(@"o sistema retornará a mensagem “Troca de Referência executada com sucesso\.” para Contrato")]
        public void EntaoOSistemaRetornaraAMensagemTrocaDeReferenciaExecutadaComSucesso_ParaContrato()
        {
            resposta = empresa.GetHttpWebRequest("MesReferencia/TrocaReferencia?mesAnoRef=01/09/2018&codUsuario="+ empresaData.Usuario+ "&enderecoIP="+empresaData.ContratoenderecoIP+ "&codTsContrato=" + empresaData.codTsContrato, "json", 200, new string[] { "Troca de Referência executada com sucesso." }, null, null);
        }

        [Then(@"o sistema retornará a mensagem “Troca de Referência executada com sucesso\.” para Grupo Contrato")]
        public void EntaoOSistemaRetornaraAMensagemTrocaDeReferenciaExecutadaComSucesso_ParaGrupoContrato()
        {
            resposta = empresa.GetHttpWebRequest("MesReferencia/TrocaReferencia?mesAnoRef=01/09/2018&codUsuario=" + empresaData.Usuario + "&enderecoIP=" + empresaData.GrupoenderecoIP + "&codGrupoEmpresa=" + empresaData.GrupoContrato, "json", 200, new string[] { "Troca de Referência executada com sucesso." }, null, null);
        }


        [Then(@"o sistema retornará a mensagem “Não existe Movimentação Pendente de Meses Anteriores para este contrato\.”")]
        public void EntaoOSistemaRetornaraAMensagemNaoExisteMovimentacaoPendenteDeMesesAnterioresParaEsteContrato_()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/" + empresaData.codTsContrato, "json", 200, new string[] { "2018" }, null, null);
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesReferencia?codTsContrato=" + empresaData.codTsContrato+ "&indTipoUsuario=E&mesAnoRef=01/09/2018", "json", 200, new string[] { "[]" }, null, null);
            resposta = empresa.GetHttpWebRequest("Lote/MovimentacoesPendentesReferencia?codGrupoEmpresa=" + empresaData.GrupoContrato + "&indTipoUsuario=E&mesAnoRef=01/09/2018", "json", 200, new string[] { "[]" }, null, null);
        }
    }
}
