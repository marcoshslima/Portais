﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Alterarmêsdereferência
{
    [Binding]
    public class WS4385CT_BuscarContratoParaAlterarMesDeReferenciaSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal empresa para alterar mes de referencia para contrato ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaAlterarMesDeReferenciaParaContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar no combobox no campo “Grupo Contrato/Contrato” Buscar Contrato")]
        public void QuandoEuClicarNoComboboxNoCampoGrupoContratoContratoBuscarContrato()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarGrupoEmpresa/"+ empresaData.Usuario, "json", 200, new string[] { empresaData.Contrato, empresaData.ContratoName }, null, null);
        }
        
        [Then(@"o sistema irá exibir todos os contratos/grupo contrato existentes para a empresa Buscar Contrato")]
        public void EntaoOSistemaIraExibirTodosOsContratosGrupoContratoExistentesParaAEmpresaBuscarContrato()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/"+empresaData.Usuario+"/Tipo", "json", 200, new string[] { "E" }, null, null);
        }
    }
}
