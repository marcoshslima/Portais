﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT861_ExportarAListaDeFaturasSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"que o gestor do contrato deseja exportar a lista de faturas emitidas para o contrato, no período informado ""(.*)""")]
        public void DadoQueOGestorDoContratoDesejaExportarAListaDeFaturasEmitidasParaOContratoNoPeriodoInformado(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"clicar no link Gerar PDF")]
        public void QuandoClicarNoLinkGerarPDF()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"deverão ser apresentadas as opções de ""(.*)"", ""(.*)"" ou ""(.*)"" a geração do PDF")]
        public void EntaoDeveraoSerApresentadasAsOpcoesDeOuAGeracaoDoPDF(string p0, string p1, string p2)
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
            previousDate = DateTime.Now.AddMonths(-2);
            previousDateDateFormat = previousDate.ToString("yyyy-MM-dd");
            resposta = empresa.GetHttpWebRequest("Empresa/"+ empresaData.Contrato+ "/Fatura/"+ previousDateDateFormat +"/ "+ todayDateFormat + "/AMIL/Pdf", "json", 200, null, null, null);
        }
    }
}
