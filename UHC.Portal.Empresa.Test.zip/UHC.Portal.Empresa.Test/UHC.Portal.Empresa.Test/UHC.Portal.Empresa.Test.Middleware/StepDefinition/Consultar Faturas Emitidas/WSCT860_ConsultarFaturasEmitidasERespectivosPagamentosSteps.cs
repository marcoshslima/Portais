﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.Consultar_Faturas_Emitidas
{
    [Binding]
    public class WSCT860_ConsultarAsFaturasEmitidasESeusRespectivosPagamentosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"que o gestor do contrato deseja selecionar um período para consultar as faturas emitidas para o contrato ""(.*)""")]
        public void DadoQueOGestorDoContratoDesejaSelecionarUmPeriodoParaConsultarAsFaturasEmitidasParaOContrato(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }

        [When(@"clicar no link DEMONSTRATIVOS DE PAGAMENTO")]
        public void QuandoClicarNoLinkDEMONSTRATIVOSDEPAGAMENTO()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"selecionar a ""(.*)""")]
        public void QuandoSelecionarA(string p0)
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }
        
        [When(@"selecionar o ""(.*)""")]
        public void QuandoSelecionarO(string p0)
        {
            previousDate = DateTime.Now.AddMonths(-6);
            previousDateDateFormat = previousDate.ToString("yyyy-MM-dd");
        }
        
        [Then(@"deverá ser apresenta a lista de faturas emitidas dentro desse período")]
        public void EntaoDeveraSerApresentaAListaDeFaturasEmitidasDentroDessePeriodo()
        {
            resposta = empresa.GetHttpWebRequest("Empresa/" + empresaData.Contrato + "/Fatura/" + previousDateDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int valor = 0;
            int valorcontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (valor = 0; valor <= strArr.Length - 1; valor++)
            {
                if (strArr[valor].Contains("valor"))
                {
                    valorcontagem = valorcontagem + 1;
                }
            }
            // valor validation
            if (!(valorcontagem >= 1))
            {
                Assert.Fail("Não constam demonstrativos de pagamento neste período.");
            }
        }

        // WSCT860.2 - Não tem faturas emitidas
        [When(@"selecionar a Empresa selecionar o Período")]
        public void QuandoSelecionarAEmpresaSelecionarOPeriodo()
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }

        [Then(@"apresentar a mensagem ""(.*)""")]
        public void EntaoApresentarAMensagem(string p0)
        {
            resposta = empresa.GetHttpWebRequest("Empresa/" + empresaData.Contrato + "/Fatura/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);
        }

        [Then(@"não habilitar o botão ""(.*)""")]
        public void EntaoNaoHabilitarOBotao(string p0)
        {
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int valor = 0;
            int valorcontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (valor = 0; valor <= strArr.Length - 1; valor++)
            {
                if (strArr[valor].Contains("valor"))
                {
                    valorcontagem = valorcontagem + 1;
                }
            }
            // valor validation
            if (valorcontagem >= 1)
            {
                Assert.Fail("constam demonstrativos de pagamento neste período.");
            }
        }

    }
}
