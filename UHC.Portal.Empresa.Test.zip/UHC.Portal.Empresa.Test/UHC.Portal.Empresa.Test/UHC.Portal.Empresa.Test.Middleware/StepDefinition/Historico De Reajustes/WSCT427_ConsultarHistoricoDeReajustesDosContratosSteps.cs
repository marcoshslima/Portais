﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;


namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WSCT427_ConsultarHistoricoDeReajustesDosContratosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        DateTime today;
        string todayDateFormat;
        #endregion

        // WSCT427.1 - Abrir a tela para selecionar a Empresa
        [Given(@"que o gestor do contrato deseja selecionar a empresa para consultar os históricos de reajustes de preços dos planos ""(.*)""")]
        public void DadoQueOGestorDoContratoDesejaSelecionarAEmpresaParaConsultarOsHistoricosDeReajustesDePrecosDosPlanos(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }


        [When(@"clicar no link ""(.*)""")]
        public void QuandoClicarNoLink(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        
        [When(@"selecionar a Empresa e Período")]
        public void QuandoSelecionarAEmpresaEPeriodo()
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }

        [Then(@"deverá ser apresenta a lista de planos e seus respectivos reajustes")]
        public void EntaoDeveraSerApresentaAListaDePlanosESeusRespectivosReajustes()
        {
            resposta = empresa.GetHttpWebRequest("Empresa/"+ listEmpresaData.Contrato + "/Plano/Reajuste/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int codigo = 0;
            int codigocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (codigo = 0; codigo <= strArr.Length - 1; codigo++)
            {
                if (strArr[codigo].Contains("codigo"))
                {
                    codigocontagem = codigocontagem + 1;
                }
            }
            // Reajustevalidation
            if (!(codigocontagem >= 1))
            {
                Assert.Fail("Não existem reajustes para a empresa dentro do período informado.");
            }
        }

        // WSCT427.2 - Consultar histórico de reajuste para uma empresa que não tem histórico de reajuste
        [Given(@"que o gestor do contrato deseje selecionar a empresa para consultar os reajuste dos planos ""(.*)""")]
        public void DadoQueOGestorDoContratoDesejeSelecionarAEmpresaParaConsultarOsReajusteDosPlanos(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }

        [When(@"clicar no link do menu lateral ""(.*)""")]
        public void QuandoClicarNoLinkDoMenuLateral(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }

        [Then(@"será apresentada a tela Histórico de Reajuste com a mensagem O contrato não possui reajustes\.")]
        public void EntaoSeraApresentadaATelaHistoricoDeReajusteComAMensagemOContratoNaoPossuiReajustes_()
        {
            resposta = empresa.GetHttpWebRequest("Empresa/" + listEmpresaData.Contrato + "/Plano/Reajuste/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);
            string[] strArr = null;
            string respostacorda = resposta.ToString();
            char[] divididochar = { ',' };
            int codigo = 0;
            int codigocontagem = 0;
            strArr = respostacorda.Split(divididochar);
            for (codigo = 0; codigo <= strArr.Length - 1; codigo++)
            {
                if (strArr[codigo].Contains("codigo"))
                {
                    codigocontagem = codigocontagem + 1;
                }
            }
            // Reajustevalidation
            if ((codigocontagem > 1))
            {
                Assert.Fail("Existem reajustes para a empresa dentro do período informado.");
            }
        }

    }
}
