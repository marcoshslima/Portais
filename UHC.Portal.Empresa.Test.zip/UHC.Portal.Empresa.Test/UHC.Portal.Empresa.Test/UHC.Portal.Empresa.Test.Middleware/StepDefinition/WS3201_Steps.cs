﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS3201_Steps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já digitei totalmente ou parcialmente uma unidade organizacional \(código/nome\) dentro da combo “Unidade Organizacional” ""(.*)""")]
        public void DadoQUEEuJaDigiteiTotalmenteOuParcialmenteUmaUnidadeOrganizacionalCodigoNomeDentroDaComboUnidadeOrganizacional(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"eu clicar sobre alguma Unidade Organizacional listada abaixo da combo")]
        public void QuandoEuClicarSobreAlgumaUnidadeOrganizacionalListadaAbaixoDaCombo()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"o sistema deverá transferir para dentro do campo “Unidade Organizacional” o código e nome da unidade organizacional correspondente")]
        public void EntaoOSistemaDeveraTransferirParaDentroDoCampoUnidadeOrganizacionalOCodigoENomeDaUnidadeOrganizacionalCorrespondente()
        {
            resposta = empresa.GetHttpWebRequest("Nestle/UnidadeOrganizacional?Filter=" + empresaData.Filter + "&Limit=" + empresaData.limit, "json", 200, new string[] { "codigo", "descricao" }, null, null);
        }
    }
}
