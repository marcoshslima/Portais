﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ImportarArquiv
{
    [Binding]
    public class WS22914CT_BuscaContratoDaImportacaoDeArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa para Busca Contrato da Importação de Arquivos ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresaParaBuscaContratoDaImportacaoDeArquivos(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar em um dos contratos disponíveis para Busca Contrato da Importação de Arquivos")]
        public void QuandoEuClicarEmUmDosContratosDisponiveisParaBuscaContratoDaImportacaoDeArquivos()
        {
            resposta = empresa.GetHttpWebRequest("Usuario/" + empresaData.Usuario, "json", 200, new string[] { empresaData.Usuario }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PesquisarDadosContratoFiltro/" + empresaData.numeroContrato, "json", 200, new string[] { empresaData.numeroContrato, empresaData.CodTsContrato, empresaData.ContratoName, "NOME_ENTIDADE" }, null, null);
            resposta = empresa.GetHttpWebRequest("Job/Executados/" + empresaData.Usuario + "/"+ empresaData.CodigoJob + "/"+ empresaData.dataInicioExecucao + "/" + empresaData.dataFimExecucao, "json", 200, new string[] { "[]" }, null, null);
        }
        
        [Then(@"o sistema mostrará os demais campos para realização da importação de arquivo para Busca Contrato da Importação de Arquivos")]
        public void EntaoOSistemaMostraraOsDemaisCamposParaRealizacaoDaImportacaoDeArquivoParaBuscaContratoDaImportacaoDeArquivos()
        {
            resposta = empresa.GetHttpWebRequest("Contrato/" + empresaData.CodTsContrato + "/PermiteMovimentacaoViaArquivo", "json", 200, new string[] { "IND_MOVIMENTO_CADASTRAL","A" }, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/VerificaBloqueio/" + empresaData.numeroContrato + "/" + empresaData.CodGrupoEmpresa + "/" + empresaData.codigoTipoOperacao, "json", 200, new string[] { "result", "id", "isCompleted" }, null, null);
        }
        [When(@"eu inserir o nome da empresa no campo ""(.*)""")]
        public void QuandoEuInserirONomeDaEmpresaNoCampo(string p0)
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o sistema irá mostrar o respectivo contrato para o nome digitado")]
        public void EntaoOSistemaIraMostrarORespectivoContratoParaONomeDigitado()
        {
            
        }

        [When(@"eu clicar em um dos grupos contratos disponíveis")]
        public void QuandoEuClicarEmUmDosGruposContratosDisponiveis()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }

        [Then(@"o sistema mostrará os demais campos para realização da importação de arquivo nestlé")]
        public void EntaoOSistemaMostraraOsDemaisCamposParaRealizacaoDaImportacaoDeArquivoNestle()
        {
            
        }

    }
}
