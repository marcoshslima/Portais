﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ImportarArquiv
{
    [Binding]
    public class ImportarArquivosSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        DateTime today;
        string todayDateFormat;
        DateTime previousDate;
        string previousDateDateFormat;
        #endregion

        [Given(@"u já acessei o item dee menu ""(.*)""")]
        public void DadoUJaAcesseiOItemDeeMenu(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já segui os passos indicadoss na US \[(.*)] - Busca Contrato")]
        public void DadoJaSeguiOsPassosIndicadossNaUS_BuscaContrato(int p0)
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }
        
        [Given(@"eu já acessei o item de menuu ""(.*)""")]
        public void DadoEuJaAcesseiOItemDeMenuu(string p0)
        {
            listEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"já segui os passos indicados naa US \[(.*)] - Busca Contrato")]
        public void DadoJaSeguiOsPassosIndicadosNaaUS_BuscaContrato(int p0)
        {
            today = DateTime.Today;
            todayDateFormat = today.ToString("yyyy-MM-dd");
        }
        
        [When(@"o sistema identificarr que o contrato refere-se à um Cliente Empresa")]
        public void QuandoOSistemaIdentificarrQueOContratoRefere_SeAUmClienteEmpresa()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"o sistema identificar quee o contrato refere-se à Porte I")]
        public void QuandoOSistemaIdentificarQueeOContratoRefere_SeAPorteI()
        {
            Console.WriteLine(listEmpresaData);
        }
        
        [When(@"o sistema identificar que eo contrato refere-se à um Cliente Externo")]
        public void QuandoOSistemaIdentificarQueEoContratoRefere_SeAUmClienteExterno()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"o sistema identificar quee o contrato refere-se à Porte II")]
        public void QuandoOSistemaIdentificarQueeOContratoRefere_SeAPorteII()
        {
            Console.WriteLine(listEmpresaData);
        }
        
        [When(@"o sistema identificar que o contratoo refere-se à um Cliente Individual")]
        public void QuandoOSistemaIdentificarQueOContratooRefere_SeAUmClienteIndividual()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"o sistema identificar que o contratoo refere-se à Porte I")]
        public void QuandoOSistemaIdentificarQueOContratooRefere_SeAPorteI()
        {
            Console.WriteLine(listEmpresaData);
        }
        
        [When(@"o sistema identificar que o contratoo refere-se à Porte II")]
        public void QuandoOSistemaIdentificarQueOContratooRefere_SeAPorteII()
        {
            Console.WriteLine(listEmpresaData);
        }
    
        [Then(@"o campo ""(.*)"" receberá o sysdatee")]
        public void EntaoOCampoReceberaOSysdatee(string p0)
        {
            string resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/"+listEmpresaData.Contrato, "json", 200,null, null, null);
            Console.WriteLine(resposta);

        }
    }
}
