﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware
{
    [Binding]
    public class WS_21713_RunButtonBotaoExecutarSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;

        #endregion

        [Given(@"ue a tela carregada ""(.*)""")]
        public void DadoUeATelaCarregada(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
        }
        
        [When(@"Quando clicado no botão executarr")]
        public void QuandoQuandoClicadoNoBotaoExecutarr()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"Em seguida, o sistema vai dar uma mensagemm")]
        public void EntaoEmSeguidaOSistemaVaiDarUmaMensagemm()
        {
          resposta = empresa.GetHttpWebRequest("Job/ExecutaJob?IdJob="+lstEmpresaData.Contrato+"&CodUser="+lstEmpresaData.Usuario+"&DtSchedule="+lstEmpresaData.DataNegociacao+"&NomeArquivoIn="+lstEmpresaData.NomeArquivoAnexo+"&NumContratoIn="+lstEmpresaData.NumContrato+"&CodTipoLayoutIn=null&MesAnoRefIn=undefined&CommitIn=S&VersaoIn=N&UsuarioIn="+lstEmpresaData.Usuario+"&EnderecoIpIn="+lstEmpresaData.EnderecoIp+"&DataInclusao="+lstEmpresaData.DataInclusao+"&IndRelampago=N" ,"json", 200, null, null, null);
          //resposta = empresa.GetHttpWebRequest("Job/ExecutaJob?IdJob=1003&CodUser=MA648064&DtSchedule=28/08/2018%2008:07:56&NomeArquivoIn=AtendimentosRealizados%20(3).pdf&NumContratoIn=648064&CodTipoLayoutIn=null&MesAnoRefIn=undefined&CommitIn=S&VersaoIn=N&UsuarioIn=MA648064&EnderecoIpIn=189.20.205.223&TxtParametrosMsg=&DataInclusao=01/09/2018&IndRelampago=N", "json", 200, null, null, null);

            Console.WriteLine(resposta);

        }
    }
}
