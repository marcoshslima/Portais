﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ImportarArquiv
{
    [Binding]
    public class WS_4371_2UploadDeArquivo
    {
        #region Variáveis
        private String Usuario;
        private String Login;
        WebService empresa;
        private string json;
        string resposta;
        TestData.WS_Empresa_Data listEmpresaData;
        private string file;
        #endregion

        [Given(@"u já acessei o item dee menu Movimentacao Cadastral Importar Arquivo")]
        public void DadoUJaAcesseiOItemDeeMenuMovimentacaoCadastralImportarArquivo()
        {
            listEmpresaData = new WS_Empresa_Data("Upload De Arquivo");
        }
        
        [Given(@"selecionei o contrato conforme indicado na Busca Contrato")]
        public void DadoSelecioneiOContratoConformeIndicadoNaBuscaContrato()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu clicar em “Escolher Arquivo” no campo “Nome Arquivo”")]
        public void QuandoEuClicarEmEscolherArquivoNoCampoNomeArquivo()
        {
            resposta = empresa.GetHttpWebRequest("Contato/PesquisarDadosContato/"+ listEmpresaData.codtscontrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/PeriodoMovimentacao/"+ listEmpresaData.CodTsContrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Job/Executados/"+ listEmpresaData.Usuario + "/"+ listEmpresaData.CodigoJob + "/"+ listEmpresaData.dataInicioExecucao +"/"+ listEmpresaData.dataFimExecucao, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato /"+ listEmpresaData.CodTsContrato + "/ PermiteMovimentacaoViaArquivo", "json", 200, null, null, null);
        }
        
        [Then(@"o sistema irá realizar o upload do arquivo contendo as atualizações cadastrais dos beneficiários do contrato selecionado")]
        public void EntaoOSistemaIraRealizarOUploadDoArquivoContendoAsAtualizacoesCadastraisDosBeneficiariosDoContratoSelecionado()
        {
            resposta = empresa.GetHttpWebRequest("Contato/PesquisarDadosContato/" + listEmpresaData.codtscontrato, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contrato/VerificaBloqueio/" + listEmpresaData.CodigoContrato + "/"+ listEmpresaData.CodigoGrupoEmpresa + "/" + listEmpresaData.codigoTipoOperacao, "json", 200, null, null, null);
            resposta = empresa.GetHttpWebRequest("Contato/PesquisarDadosContato/" + listEmpresaData.codtscontrato, "json", 200, null, null, null);
            //json ="{"+ "\" name\" = "+file+"\"," +
                //"+"\" filename\" = "+985791000.csv +"\"
       //+ "};

            resposta = empresa.PostHttpWebRequest("Contrato/Anexo/EnvioArquivo", "json", 200, null, null, json);
            resposta = empresa.GetHttpWebRequest("ExecutaJob?CodUser=" + listEmpresaData.Usuario, "json", 200, null, null, null);
        }
    }
}
