﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition.ImportarArquiv
{
    [Binding]
    public class WS_22316_UpdateButtonBotaoAtualizarSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data lstEmpresaData;
        DateTime today;
        string todayDateFormat;

        #endregion
        [Given(@"que eu quero procurar um novo período ""(.*)""")]
        public void DadoQueEuQueroProcurarUmNovoPeriodo(string p0)
        {
            lstEmpresaData = new WS_Empresa_Data(p0);
            today = DateTime.Today;
            todayDateFormat = today.ToString("dd-MM-yyyy");
            Console.WriteLine(todayDateFormat);
        }
        
        [When(@"eu altero os dados")]
        public void QuandoEuAlteroOsDados()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [Then(@"seguida, clicado no botão de atualizaçã")]
        public void EntaoSeguidaClicadoNoBotaoDeAtualizaca()
        {
            resposta = empresa.GetHttpWebRequest("Job/Executados/"+ lstEmpresaData.Usuario+"/"+ lstEmpresaData.Codigo+"/"+ todayDateFormat + "/"+todayDateFormat, "json", 200, null, null, null);
           // resposta = empresa.GetHttpWebRequest("Job/Executados/" + empresaData.Usuario + "/" + empresaData.CodigoPlano + "/" + todayDateFormat + "/" + todayDateFormat, "json", 200, null, null, null);


        }

        [Then(@"e as informações na grade serão alterados")]
        public void EntaoEAsInformacoesNaGradeSeraoAlterados()
        {
            Console.WriteLine(resposta);
        }
    }
}
