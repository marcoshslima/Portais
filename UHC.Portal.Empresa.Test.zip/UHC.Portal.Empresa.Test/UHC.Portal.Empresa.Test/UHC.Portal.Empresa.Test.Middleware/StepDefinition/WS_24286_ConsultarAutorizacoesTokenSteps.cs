﻿using System;
using OGS.Framework.Utility;
using TechTalk.SpecFlow;
using UHC.Portal.Empresa.Test.Middleware.TestData;
using UHC.Portal.Empresa.Test.Middleware.Utils;

namespace UHC.Portal.Empresa.Test.Middleware.StepDefinition
{
    [Binding]
    public class WS_24286_ConsultarAutorizacoesTokenSteps
    {
        #region Variáveis
        WebService empresa;
        string resposta;
        TestData.WS_Empresa_Data empresaData;
        private string json;
        #endregion
        [Given(@"QUE eu já fiz login no Portal Empresa_Consultar Autorizações Token ""(.*)""")]
        public void DadoQUEEuJaFizLoginNoPortalEmpresa_ConsultarAutorizacoesToken(string p0)
        {
            empresaData = new WS_Empresa_Data(p0);
        }
        
        [Given(@"acessei o item de menu_Consultar Autorizações Token “Gestão de Beneficiários / Consultar Autorizações Token”")]
        public void DadoAcesseiOItemDeMenu_ConsultarAutorizacoesTokenGestaoDeBeneficiariosConsultarAutorizacoesToken()
        {
            empresa = new WebService(Ambiente.BaseUri);
        }
        
        [When(@"eu preencher os campos de filtro")]
        public void QuandoEuPreencherOsCamposDeFiltro()
        {
            Console.WriteLine(empresa);
        }
        
        [When(@"clicar sobre o botão ""(.*)""")]
        public void QuandoClicarSobreOBotao(string p0)
        {
            Console.WriteLine(empresa);
        }
        
        [Then(@"o sistema deverá apresentar uma tela contendo as autorizações de acordo com o preenchimento dos campos de filtro")]
        public void EntaoOSistemaDeveraApresentarUmaTelaContendoAsAutorizacoesDeAcordoComOPreenchimentoDosCamposDeFiltro()
        {
            resposta = empresa.GetHttpWebRequest("Autorizacao/PesquisarAutorizacoes?CodigoContrato= "+empresaData.CodigoContrato+"&Beneficiario="+empresaData.Beneficiario+"&Tratamento =2&DtIni="+empresaData.InitialDate+"&DtFim="+empresaData.FinalDate+"&CodGrupoEmpresa="+empresaData.CodEmpresa+"&TipoUsuario="+empresaData.tipoUsuario+"&IndToken=S&CodUsuario="+empresaData.Usuario+"", "json", 200,null, null, null);

        }
    }
}
