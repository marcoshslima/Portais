﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.Middleware.TestData
{
    class WS_Empresa_Data
    {
        public string Usuario { get; set; }
        public string Login { get; private set; }
        public string codtscontrato { get; private set; }
        public string Numerocaixapostal { get; set; }
        private string cod_ts_contrato;
        public string CodigoMunicipio { get; set; }
        public string Contrato { get; set; }
        public string TipoRelatorio { get; set; }
        public string GrupoContrato { get; set; }
        public string ContratoName { get; set; }
         public string AnoCalendario {get; set;}
        public string GrupoContratoName { get; set; }
        public string Tipo { get; set; }
        public string DataNegociacao { get; set; }
        public string inclusaoDepSozinha { get; set; }
        public string CodigoPlano { get; set; }
        public string filter { get; set; }
        public string NumAssociado { get; set; }
        public string limit { get; set; }
        public string quantidadeDe { get; private set; }
        public string quantidadeAte { get; private set; }
        public string CodigoJob { get; set; }
        public string dataInicioExecucao { get; set; }
        public string NumControleArq { get; set; }
        public string dataFimExecucao { get; set; }
        public string numeroContrato { get; set; }
        public string codTsBeneficiario { get; set; }
        public string CodigoTsBeneficiario { get; set; }
        public string IndParticipacaoIsenta { get; set; }
        public string numeroControleCoParticipacao { get; set; }
        public string numControleCopartSeq { get; set; }
        public string NumCep { get; set; }
        public string NomeRelatorio { get; set; }
        public string CaixaPostal { get; set; }

        public string InitialDate { get; set; }
        public  string FinalDate { get; set; }
        public string NomeRelatorio1 { get; set; }
        public string Aceidentificacaots { get; set; }
        public string acrescimo { get; set; }
        public string codigoTipoOperacao { get; set; }
        public string Acetipousuario { get; set; }
        public string Data_importacao_ini { get; set; }
        public string Data_importacao_fim { get; set; }
        public string Codigo { get; set; }
        public string codigoTsContrato { get; set; }
        public string codTsContrato { get; set; }
        public string dataInclusaoUm { get; private set; }
        public string mesAnoRef { get; private set; }
        public string codDependencia { get; private set; }
        public string indCadastroDependente { get; private set; }
        public string BeneficiarioCPF { get; set; }
        public string BeneficiarioNome { get; set; }
        public string BeneficiarioMarcaOtica { get; set; }
        public string GrupoenderecoIP { get; set; }
        public string ContratoenderecoIP { get; set; }
        public string CodigoUsuario { get; set; }
        public string SomenteAtivos { get; set; }
        public string Beneficiario { get; set; }
        public string apenasContratosAtivos { get; private set; }
        public string apenasContratosAtivo { get; private set; }
        public string numSeqAssociadoWeb { get; private set; }
        public string DtFim { get; private set; }
        public string DtIni { get; private set; }
        public string CodTs { get; private set; }
        public string CodigoContrato { get; set; }
        public string codigoTsBeneficiario { get; private set; }
        public string CodigoGrupoEmpresa { get; private set; }
        public string codTipoOperacao { get; private set; }
        public string dataNascimento { get; private set; }
        public string NumContrato { get; set; }
        public string listarTodos { get; set; }
        public string suspenso { get; set; }
    
        public string numSeqCobranca { get; set; }
        public string codTs { get; set; }
        public string CodTsContrato { get; set; }
        public string tipoUsuario { get; set; }
        public string CodIdentificacaoTs { get; set; }
        public string IndTipoPessoaContrato { get; set; }
        public string AtivaRn { get; set; }
        public string CodUsuario { get; set; }
        public string MesAnoRef { get; set; }
        public string IndTipoUsuario { get; set; }
        public string NumSeqControleLote { get; set; }
        public string ApenasContratosAtivos { get; set; }
        public string CodTsContratoNao { get; set; }
        public string CodOperadora { get; set; }
        public string CodSucursal { get; set; }
        public string CodInspetoriaTS { get; set; }
        public string CodMarca { get; set; }
        public string NumCarteira { get; set; }
        public string IndTipoProduto { get; set; }
        public string Modulo { get; set; }
        public string Ip { get; set; }
        public string Senha { get; set; }
        public string Sistema { get; set; }
        public string NomeDestinatario { get; set; }
        public string PCodTsContrato { get; set; }
        public string PNumCicloTs { get; set; }
        public string PMesAnoRef { get; set; }
        public string PCodOperadora { get; set; }
        public string PCodSucursal { get; set; }
        public string PCodInspetoriaTs { get; set; }
        public string POrdenacao { get; set; }
        public string PIndQuebra { get; set; }
        public string PIndiceRelat { get; set; }
        public string PCodTipoCiclo { get; set; }
        public string CodTipoCiclo { get; set; }
        public string NumCicloTs { get; set;}
        public string AutorizacaoExtra { get; set; }
        public string  ProcessaLote { get; set; }
        public string Operacao { get; set; }
        public string UsuarioAutorizacao { get; set; }
        public string EnderecoIp { get; set; }
        public string  Autorizado { get; set; }
        public string TxtAutorizacao { get; set; }
        public string MotivoRecusa { get; set; }
        public string CodMensagem { get; set; }
        public string TxtSolicitaAutorizacao { get; set; }
        public string SiglaArea { get; set; }
        public string CodigoLocalidade { get; set; }
        public string CodigoBairro { get; set; }
        public string CodigoTipoLogradouro { get; set; }
        public string CodigoTitulo { get; set; }
        public string NomeLogradouro { get; set; }
        public string numEndereco { get; set; }
        public string txtComplemento { get; set; }
        public string AnaliseLote { get; set; }
        public string CodSituacaoAssociadoWeb { get; set; }
        public string TxtAcao { get; set; }
        public string NumSeqAssociadoWeb { get; set; }
        public string CodGrupoCarencia { get; set; }
        public string TipoCarencia { get; set; }
        public string NomeAssociado { get; set; }
        public string NumAssociadoTitular { get; set; }
        public string NomeAssociadoTitular { get; set; }       
        public string IndMovimentoDental { get; set; }
        public string CodEmpresa { get; set; }
        public string CodTsDental { get; set; }
        public string DataExclusao { get; set; }
        public string DataInclusao { get; set; }
        public string SiglaUF { get; set; }
        public string CodMotivoExclusao { get; set; }
        public string  TipoAssociado { get; set; }
        public string IndContributario { get; set; }
        public string NumSeqControleArq { get; set; }        
        public string Email { get; set; }
        public string NomSituacaoAssociado { get; set; }
        public string QtdAnexo { get; set; }
        public string DataAnexado { get; set; }
        public string Descricao { get; set; }
        public string LocalArquivamento { get; set; }
        public string CodigoUsuarioAtu { get; set; }
        public string NomeArquivoAnexo { get; set; }
        public string IndExcluir { get; set; }
        public string NumSeqAssociadoAnexo { get; set; }
        public string Guid{ get; set; }
        public string DtTransferencia { get; set; }
        public string Limit { get; set; }
        public string Filter { get; set; }
        public string Limits { get; set; }
        public string CodEmpresaNestle { get; set; }
        public string CodArhNestle { get; set; }
        public string PlanoDif { get; set; }
        public string PlanoDifAgr { get; set; }
        public string DataLimite { get; set; }
        public string DataTransferencia { get; set; }
        public string CodTsContratoNovo { get; set; }
        public string CodEmpresaNova { get; set; }
        public string CodLotacaoTs { get; set; }
        public string CodLocalTs { get; set; }
        public string NomePlano { get; set; }
        public string CodPlanoNovo { get; set; }
        public string CodPlanoDep { get; set; }
        public string CodPlanoAgr { get; set; }
        public string NumMatricEmpresa { get; set; }
        public string CodPsaTs { get; set; }
        public string CodStatusNestle { get; set; }
        public string CodUnidOrgNestle { get; set; }
        public string QuantidadeDe { get; set; }
        public string QuantidadeAte { get; set; }
        public string CodigoTSContrato { get; set; }
        public string MesAnoReferencia { get; set; }
        public string IndTipoContrato { get; set; }
        public string IndFaturado { get; set; }
        public string CodigoTipoArquivo { get; set; }
        public string NumSeqFila { get; set; }
        public string Destinatario { get; set; }
        public string TipoEnvio { get; set; }
        public string CodigoRelatorio { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
        public string Key1 { get; set; }
        public string Value1 { get; set; }
        public string Key2 { get; set; }
        public string Value2 { get; set; }
        public string Key3 { get; set; }
        public string Value3 { get; set; }
        public string Key4 { get; set; }
        public string Value4 { get; set; }
        public string Key5 { get; set; }
        public string Value5 { get; set; }
        public string Key6 { get; set; }
        public string Value6 { get; set; }
        public string Token { get; set;} 
        public string CodGrupoEmpresa { get; set; }
        public string  IndRel { get; set; }
        public string  IndOrdenacao { get; set; }
        public string IndTipoBeneficiario { get; set; }
        public string CodTsContratoNaoInf { get; set; }
        public string InvalidNumAssociado { get; set; }
        public string Message { get; set; }
        public string NumSeqPropostaPjTs { get; set; }
        public string CodEntidadeTs { get; set; }
        public string CodEquipeVendas { get; set; }
        public string CodCorretorTs { get; set; }
        public string DtIniCobranca { get; set; }
        public string CodTsContratoReembolso { get; set; }
        public string DtIniVigencia { get; set; }
        public string DateDiff { get; set; }
        public string IdJob { get; set; }
        public string NumContratoIn { get; set; }
        public string CodGrupoEmpresaIn { get; set; }
        public string DataInicioSuspIni { get; set; }
        public string DataInicioSuspFim { get; set; }
        public string IndTipoRelatorio { get; set; }
        public string AuxTipoUsuario { get; set; }
        public string CodigoJobExecutado { get; set; }
        public string NomeContato { get; set; }
        public string NomeCargoContrato { get; set; }
        public string NumDDD { get; set; }
        public string NumTelefone { get; set; }
        public string TxtEmailContato { get; set; }
        public string IndEmailMovCadastral { get; set; }
        public string DtNascimento { get; set; }
        public string DddCelular { get; set; }
        public string NumCelular { get; set; }
        public string IndAcao { get; set; }
        public string CodUsuarioAtu { get; set; }
        public string NumSeqContato { get; set; }
        public string NullValue { get; set; }
        public string UsuarioCarga { get; set; }
        public List<string> LstEmpresaData = new List<string>();
        private int p0;

        public WS_Empresa_Data(string tipoEmpresa)
        {
            Tipo = tipoEmpresa;
            LstEmpresaData = ObterEmpresaData(Tipo);
        }

        public WS_Empresa_Data(int p0)
        {
            this.p0 = p0;
        }

        List<string> ObterEmpresaData(string tipoEmpresa)
        {
            switch (tipoEmpresa.ToUpper())
            {
                case "HISTORICO DE REAJUSTES DOS CONTRATOS":
                    Usuario = "MA648064";
                    Contrato = "648064017";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    Contrato = "985791000";
                    Beneficiario = "072852128";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                case "TRANSFERENCIA DE CONTRATOS":
                    Usuario = "MA985791";
                    Contrato = "1120870000";                    
                    CodigoUsuario = "MA985791";
                    SomenteAtivos = "false";
                    CodTsContrato = "16747488";
                    codTipoOperacao = "1";
                    CodigoContrato = "16545487";
                    break;
                case "Upload De Arquivo":
                    Usuario = "MA985791";
                    Login = "985791A02";
                    codtscontrato = "114037300";
                    CodTsContrato = "16747488";
                    CodigoJob = "1003";
                    dataInicioExecucao = "20-09-2018";
                    dataFimExecucao = "20-09-2018";
                    CodigoContrato = "1140373000";
                    CodigoGrupoEmpresa = "985791";
                    codigoTipoOperacao = "10";
                    break;
                case "INCLUSAO DE DEPENDENTES":
                    Usuario = "MA648064";
                    Contrato = "648064017";
                    codTsContrato = "14687904";
                    dataInclusaoUm = "01/10/2018";
                    mesAnoRef = "10/2018";
                    codDependencia = "3";
                    indCadastroDependente = "S";
                    DataNegociacao = "05/09/2018";
                    CodigoPlano = "96513";
                    quantidadeDe = "0";
                    quantidadeAte = "100";
                    codTsBeneficiario = "42167657";
                    apenasContratosAtivos = "true";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                case "FATURAS EMITIDAS":
                    Usuario = "MA648064";
                    Contrato = "648064017";
                    CodigoContrato = "12430313";
                    InitialDate = "08-2017";
                    mesAnoRef = "10/2018";
                    codDependencia = "3";
                    indCadastroDependente = "S";
                    DataNegociacao = "05/09/2018";
                    CodigoPlano = "96513";
                    quantidadeDe = "0";
                    quantidadeAte = "100";
                    codTsBeneficiario = "42167657";
                    apenasContratosAtivos = "true";
                    LstEmpresaData.Add(CodigoContrato);
                    LstEmpresaData.Add(InitialDate);
                    break;
                case "DE REEMBOLSO MEDICO":
                    Usuario = "MA648064";
                    NumAssociado = "621005010";
                    Senha = "6091929A746A70767C1A";
                    Ip = "189.20.205.223";
                    NumAssociadoTitular = "621578797";
                    Message = "Nenhuma informação foi encontrada com o critério de seleção estabelecido.";
                    Codigo = "-11";
                    break;

                case "INCLUSAO DE TITULAR":
                    Usuario = "MA648064";
                    Contrato = "1140373000";
                    codTsContrato = "16747488";
                    apenasContratosAtivos = "true";
                    numSeqAssociadoWeb = "26313973";
                    CodigoContrato = "9900003877";
                    break;
                case "REGISTRAR SOLICITACOES":
                    Usuario = "MA985791";
                    Contrato = "1083436000";
                    codTsContrato = "16181388";
                    apenasContratosAtivos = "false";
                    numSeqAssociadoWeb = "26313973";
                    CodigoContrato = "46525939";
                    codigoTsBeneficiario = "16545487";
                    break;

                case "CONSULTAR SOLICITACOES":
                    Usuario = "MA985791";
                    Contrato = "1140373000";
                    codTsContrato = "16747488";
                    apenasContratosAtivos = "false";
                    apenasContratosAtivo = "true";
                    numSeqAssociadoWeb = "26313973";
                    DtFim = "2018-10-02";
                    DtIni = "2018-09-04";
                    CodTs = "48709920";
                    
                    break;

                case "DEMONSTRATIVO DE ADITIVOS":
                    CodigoUsuario = "MA985791";
                    ApenasContratosAtivos = "false";
                    CodTsContrato = "16747488";
                    CodTipoCiclo="1";                    
                    NumCicloTs = "6797";
                    Ip = "189.20.205.223";
                    break;

                case "GERAR ARQUIVO CORRECOES PENDENCIAS":
                    NumContrato = "1140373000";
                    CodTsContrato = "16747488";
                    CodigoJob = "1601";
                    break;

                case "GERAR ARQUIVO CORRECOES PENDENCIAS CADASTRAIS":
                    NumContrato = "1140373000";
                    codTsContrato = "16747488";
                    CodigoUsuario = "MA985791";
                    CodTsContrato = "16747488";
                    Ip = "189.20.205.221";
                    CodigoJob = "1601";
                    CodigoUsuarioAtu = "MA648064";
                    break;
                case "DECLARACAO DE PAGAMENTO":
                    CodigoUsuario = "MA985791";
                    ApenasContratosAtivos = "false";
                    NumContrato = "1058300000";
                    NumAssociado = "068035314";
                    listarTodos = "true";
                    suspenso = "true";
                    tipoUsuario = "6";
                    CodTsContrato = "15844587";
                    LstEmpresaData.Add(NumAssociado);
                    LstEmpresaData.Add(tipoUsuario);
                    codTs = "45190395";
                    break;

                case "TRANSFERENCIA ENTRE  FILIAIS":
                    CodigoUsuario = "MA985791";
                    ApenasContratosAtivos = "false";
                    NumContrato = "1058300000";
                    NumAssociado = "068035314";
                    listarTodos = "true";
                    suspenso = "true";
                    tipoUsuario = "6";
                    CodTsContrato = "15844587";
                    LstEmpresaData.Add(NumAssociado);
                    LstEmpresaData.Add(tipoUsuario);
                    codTs = "45190395";
                    break;
                case "CONTRATO DE BENEFCIARIOS ATIVOS":
                    CodTsContrato = "16747488";
                    break;
                case "RELATORIO SUSPENSAO DE BENEF":
                    DateDiff = "60";
                    IdJob = "1626";
                    CodigoUsuario = "MA648064";
                    NumContratoIn = "9900003880";
                    CodGrupoEmpresaIn = "648064";
                    DataInicioSuspIni = "01-10-2018";
                    DataInicioSuspFim = "01-10-2018";
                    IndTipoRelatorio = "T";
                    AuxTipoUsuario = "6";
                    CodigoJob = "1626";
                    CodigoJobExecutado = "56042669";
                    CodGrupoEmpresa = "648064";
                    break;
                case "DEMONSTRATIVO BENEFCIARIOS ATIVOS FILA":
                    CodTsContrato = "9900003841";
                    NumSeqFila = "214650075";
                    Usuario = "MA985791";
                    Senha = "639597A07A70777E851D";
                    Ip = "189.20.205.221";
                    Email = "ronaldo_carmo@optum.com";
                    Modulo = "91";
                    Sistema = "dsisamil";
                    Destinatario = "string";
                    NomeRelatorio = "string";
                    TipoEnvio = "E";
                    CodigoRelatorio = "650";
                    Key1 = "pCodTsContrato";
                    Value1 = "16747488";
                    Key2 = "pCodPlano";
                    Value2 = "57177";
                    Key3 = "pIndOrdenacao";
                    Value3 = "NU";
                    Key = "pIndTipoBeneficiario";
                    Value = "T";
                    Key4 = "pNumContrato";
                    Value4 = "1140373000";
                    Key5 = "pIndTipoRelatorio";
                    Value5 = "AC";
                    Key6 = "pIndRel";
                    Value6 = "1";
                    IndRel = "1";
                    CodTsContratoNaoInf = "11763968";
                    CodPlanoAgr = "null";
                    IndOrdenacao = "NU";
                    IndTipoBeneficiario = "T";
                    NumContrato = "985791001";
                    break;
                case "DEMONSTRATIVO BENEFCIARIOS ATIVOS":
                    CodTsContrato = "9900003841";
                    NumSeqFila = "214650075";
                    Usuario = "MA648064";
                    Senha = "7DB3B9C6A49FAAB5C032";
                    Ip = "189.20.205.222";
                    Email = "ronaldo_carmo@optum.com";                    
                    Modulo = "91";
                    Sistema = "dsisamil";
                    Destinatario = "string";
                    NomeRelatorio = "string";
                    TipoEnvio = "E";
                    CodigoRelatorio = "650";                    
                    Key = "pIndTipoBeneficiario";
                    Value = "T";                    
                    IndRel = "1";
                    CodTsContratoNaoInf = "11763968";
                    CodPlanoAgr = "null";
                    IndOrdenacao = "NU";
                    IndTipoBeneficiario = "T";
                    NumContrato = "985791001";
                    break;
                        
                case "DEMONSTRATIVO DE CUSTO OPERACIONAL":
                    CodUsuario = "MA648064";
                    ApenasContratosAtivos = "false";
                    codTsContrato = "9900003885";
                    CodTsContratoNao = "16747488";
                    numSeqCobranca = "143998901";
                    CodOperadora = "3";
                    CodSucursal = "2";
                    CodInspetoriaTS = "7";
                    CodMarca = "3";
                    NumCarteira = "206";
                    IndTipoProduto = "1";
                    Modulo = "91";
                    Ip = "";
                    Senha = "659799A27C737A81881E";
                    Sistema = "dsisamil";
                    codTs = "";
                    NomeDestinatario = "";
                    CodTipoCiclo = "1";
                    break;
                case "CONSULTAR PRECOSDOS PLANOS":
                    CodTsContrato = "G85200";
                    apenasContratosAtivos = "false";                    
                    break;
                case "CONSULTAR PRECOSDOS PLANOS CONTRATODOS":
                    CodTsContrato = "9900003885";
                    DtIniCobranca = "01/01/2018";
                    CodigoUsuario = "MA648064";
                    break;
                case "PESQUISA BENF CANCELAMENTO SUSPENSAO":
                    NumContrato = "1140373000";
                    CodTsContrato = "16747488";
                    break;
                case "CONSULTAR INFORMACOES CONTRATUAIS":
                    NumSeqPropostaPjTs = "1296515";
                    CodTsContrato = "12430313";
                    CodEntidadeTs = "1004254480";
                    CodEquipeVendas = "CELULAPE1";
                    CodCorretorTs="408114";
                    break;
                case "CONSULTAR INFORMACOES DE REEMBOLSO":
                    CodTsContrato = "MA648064";
                    apenasContratosAtivos = "false";
                    NumContrato = "648064009";
                    //CodTsContrato = "9900003885";
                    CodTsContratoReembolso = "9900003885";
                    DtIniCobranca = "01-09-2017";
                    DtIniVigencia = "01-01-2018";
                    CodPlanoAgr = "96510";
                    CodPlanoDep = "96513";
                    break;
                case "TRANSFERENCIA CONTRATO COM SEM":
                    CodTsContrato = "16545487";
                    DtTransferencia = "16-08-2018";
                    CodigoContrato = "9900003884";
                    Limit = "100";
                    Filter = "418";
                    Limits = "5";
                    CodEmpresaNestle = "BR27";
                    CodArhNestle = "BRA8";
                    AutorizacaoExtra = "N";
                    UsuarioAutorizacao = "null";
                    EnderecoIp = "null";
                    Autorizado = "null";
                    TxtAutorizacao = "null";
                    TxtAcao = "I";
                    AnaliseLote = "N";
                    CodUsuario = "MA985791";
                    PlanoDif = "N";
                    PlanoDifAgr = "N";
                    NumSeqAssociadoWeb = "null";
                    CodSituacaoAssociadoWeb = "MA985791";
                    MesAnoRef = "01102018";
                    DataLimite = "string";
                    NumAssociado = "071990942";
                    NomeAssociado = "ADILSON DAMASCENO PASSOS";
                    codTs = "46525645";
                    CodTsContrato = "16545487";
                    NumContrato = "string";
                    CodEmpresa = "1009658199";
                    TipoAssociado = "T";
                    NumSeqControleArq = "null";
                    NumSeqControleLote = "string";
                    DataTransferencia = "29082018";
                    CodTsContratoNovo = "16747488";
                    CodEmpresaNova = "null";
                    CodLotacaoTs = "null";
                    CodLocalTs = "null";
                    NomePlano = "string";
                    CodPlanoNovo = "57177";
                    CodPlanoDep = "57177";
                    CodPlanoAgr = "57177";
                    NumMatricEmpresa = "999";
                    CodPsaTs = "null";
                    CodStatusNestle = "null";
                    CodUnidOrgNestle = "null";
                    CodEmpresaNestle = "null";
                    CodArhNestle = "null";
                    break;
                case "SOLICITACAO DE ARQUIVOS":
                    NumContrato = "1140373000";
                    QuantidadeDe = "1";
                    QuantidadeAte = "1";
                    CodigoTSContrato = "16747488";
                    MesAnoReferencia = "08-2018";
                    IndTipoContrato = "U";
                    IndFaturado = "C";
                    CodigoTipoArquivo = "BENEF_BASE";
                    CodigoUsuario = "MA985791";
                    Email = "ronaldo.carmo@prestadores.amil.com.br";
                    CodTsContrato = "16747488";
                    CodTipoCiclo = "0";
                    CodGrupoEmpresa = "985791";
                    break;

                case "BUSCAR CEP":
                    Contrato = "1140373000";
                    CodigoTSContrato = "16747488";
                    LstEmpresaData.Add(Contrato);
                    LstEmpresaData.Add(codigoTsContrato);
                    break;
               
                    case "BUSCAR DECLARDO":
                    Usuario = "MA985791";
                    Contrato = "1140373000";
                    CodigoTSContrato = "16747488";
                    AnoCalendario = "2018";
                    CodigoTipoArquivo = "7BB1B7C4A29CA7B2BD31";
                    codTs = "46525645";
                    NumContrato = "1120870000";
                    codigoTipoOperacao = "200.153.26.126";
                    LstEmpresaData.Add(AnoCalendario);
                    LstEmpresaData.Add(Contrato);
                    LstEmpresaData.Add(codigoTsContrato);
                    LstEmpresaData.Add(codTs);
                    LstEmpresaData.Add(CodigoTipoArquivo);
                    LstEmpresaData.Add(codigoTipoOperacao);

                    break;

                case "IMPORTAR ARQUIVOS":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "1003";
                    DataNegociacao = "28/08/2018%2008:07:56";
                    NomeArquivoAnexo = "AtendimentosRealizados%20(3).pdf";
                    NumContrato = "648064";
                    EnderecoIp = "189.20.205.223";
                    DataInclusao = "01/09/2018";
                    CodTipoCiclo = "";
                    break;
                case "DECLARACAO PAGAMENTO":
                    codTsBeneficiario = "45190395";
                    NumContrato = "1058300000";
                    NumAssociado = "f";
                    listarTodos = "true";
                    suspenso = "true";
                    InvalidNumAssociado = "abc"; 
                    break;

                case "BUSCAR TOKEN":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "1003";
                    Token = "12";
                   LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Senha);
                    LstEmpresaData.Add(Token);
                    break;

                  

                    case "BUSCAR BENEFICIARIO":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Beneficiario = "48709515";
                    Token = "12";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Senha);
                    LstEmpresaData.Add(Beneficiario);
                    break;







                case "UPDATE BUTTON":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Codigo = "1703";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Codigo);
                    CodTipoCiclo = "";
                    break;


                case "EXCLUSAO DE BENIFICIARIO":
                    NumContrato = "1120870000";
                    listarTodos = "false";
                    suspenso = "true";
                    NumAssociado = "071990942";
                    codTs = "46525645";
                    codTsContrato = "16545487";
                    tipoUsuario = "10";
                    IndTipoPessoaContrato = "J";
                    AtivaRn = "N";
                    CodUsuario = "MA985791";
                    MesAnoRef = "01-10-2018";
                    IndTipoUsuario = "E";
                    NumSeqControleLote = "6791958";
                    codTsBeneficiario = "48709920";
                    CodigoTsBeneficiario = "42188924";
                    break;

                case "VARIOS CONTRATOS":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "648064";
                    DataNegociacao = "01/09/2017";
                    CodigoPlano = "96512";
                    Beneficiario = "072852128";
                    LstEmpresaData.Add(CodigoPlano);
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Senha);
                    break;


                case "EXCLUSAO DE BENIFICIARIOS":
                    NumContrato = "1120870000";
                    listarTodos = "false";
                    suspenso = "true";
                    AutorizacaoExtra = "N";
                    ProcessaLote = "N";
                    Operacao = "null";
                    CodUsuario = "MA985791";
                    UsuarioAutorizacao = "null";
                    EnderecoIp = "null";
                    Autorizado = "null";
                    TxtAutorizacao = "null";
                    MotivoRecusa = "null";
                    CodMensagem = "null";
                    TxtSolicitaAutorizacao = "null";
                    SiglaArea = "null";
                    AnaliseLote = "N";
                    CodSituacaoAssociadoWeb = "null";
                    TxtAcao = "I";
                    NumSeqAssociadoWeb = "null";
                    CodGrupoCarencia = "null";
                    TipoCarencia = "0";
                    IndTipoPessoaContrato = "string";
                    NumSeqControleLote = "string";
                    MesAnoRef = "01/10/2018";
                    NumAssociado = "071990948";
                    NomeAssociado = "APARECIDO ORESTES SENE DOS SANTOS";
                    NumAssociadoTitular = "string";
                    NomeAssociadoTitular = "string";
                    codTs = "46525651";
                    CodTsContrato = "16545487";
                    IndMovimentoDental = "null";
                    CodEmpresa = "null";
                    CodTsDental = "null";
                    DataExclusao = "24082018";
                    CodMotivoExclusao = "25";
                    TipoAssociado = "T";
                    IndContributario = "N";
                    NumSeqControleArq = "null";
                    NumContrato = "string";
                    Email = "null";
                    NomSituacaoAssociado = "string";
                    QtdAnexo = "1";
                    DataAnexado = "null";
                    Descricao = "string";
                    LocalArquivamento = "string";
                    CodigoUsuarioAtu = "null";
                    NomeArquivoAnexo = "null";
                    IndExcluir = "true";
                    NumSeqAssociadoAnexo = "null";
                    Guid = "null";
                    codTsContrato = "16181232";
                    MesAnoRef = "01-10-2018";
                    IndTipoUsuario = "E";
                    NumSeqAssociadoWeb = "26314683";
                    CodTsContratoNovo = "16181232";
                    NomeContato = "VITOR THEODORO DE SOUZA NASCIMENTO";
                    NomeCargoContrato = "ASSISTENTE DE BENEFICIOS";                    
                    NumDDD = "11";
                    NumTelefone = "34758161";
                    TxtEmailContato = "VITOR.NASCIMENTO@BR.THBGROUP.COM";
                    IndEmailMovCadastral = "S";
                    DtNascimento = "01/06/1987";
                    DddCelular = "11";
                    NumCelular = "985213935";
                    IndAcao = "A";
                    CodUsuarioAtu = "VINIRODRIGUES";
                    NumSeqContato = "1";
                    NullValue = "null";
                    MesAnoRef = "01/12/2018";
                    UsuarioCarga = "MA985791";
                    EnderecoIp = "189.20.205.221";
                    break;

                case "NUMERO FRUPO CONTRATO":
                    Usuario = "MA648064";
                    Contrato = "648064017";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                case "PARTE NUMERO GRUPO":
                    Usuario = "G85200";
                    Contrato = "648064017";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                case "NUMERO FRUPO  CONTRATO":
                    Usuario = "G85200";
                    Contrato = "648064017";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                case "BUSCA CONTRATO UNICO":
                    Usuario = "G85200";
                   // Contrato = "085200000";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;

                  

                     case "BUSCA CONTRATO":
                    Usuario = "MA985791";
                    Contrato = "6791772";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;


                case "TELA":
                    Usuario = "G778238";
                    CodigoJob = "1600";
                    DataNegociacao = "2017-09-01";
                    CodigoPlano = "96512";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(CodigoJob);
                    break;




                case "REDE CREDENCIADA":
                    Usuario = "MA648064";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    LstEmpresaData.Add(DataNegociacao);
                    LstEmpresaData.Add(CodigoPlano);
                    break;

                case "REAJUSTE DOS PLANOS":
                    Usuario = "G510452";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;
                case "ABRIR A TELA PARA CONSULTAR AS FATURAS":
                    Usuario = "G778238";
                    Contrato = "985791000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;
                case "BENEFIT MANAGER":
                    Usuario = "MA648064";
                    GrupoContrato = "648064";
                    GrupoContratoName= "NESTLE BRASIL LTDA BR10 AT";
                    Contrato = "648064002";
                    ContratoName= "NESTLE BRASIL LTDA BR10 AT";
                    codTsContrato = "9900003882";
                    CodigoTSContrato= "9900003885";
                    NumSeqControleLote = "615166";
                    CodGrupoEmpresa = "124138";
                    NumControleArq = "11983359";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(GrupoContrato);
                    LstEmpresaData.Add(GrupoContratoName);
                    LstEmpresaData.Add(Contrato);
                    LstEmpresaData.Add(ContratoName);
                    break;
                case "BOLETOS ÚNICO CONTRATO":
                    Usuario = "G778238";
                    Codigo = "778238000";
                    ContratoName = "DEBRITO PROPAGANDA LTDA";
                    codigoTsContrato= "1296186";
                    break;
                case "BOLETOS VÁRIOS CONTRATOS":
                    Usuario = "MA648064";
                    Codigo = "648064016";
                    Contrato = "648064002";
                    ContratoName = "NESTLE BRASIL LTDA BR10 AT";
                    codigoTsContrato = "9900003877";
                    CodigoJob = "1602";
                    CodTipoCiclo = "1";
                    CodTsContrato= "9900003885";
                    //codigoTsContrato = "14687639";
                    codigoTsContrato = "14687905";
                    numSeqCobranca = "144968726";
                    break;
                case "VÁRIOS CONTRATOS":
                    Usuario = "MA985791";
                    CodTsContrato = "16747487";
                    tipoUsuario = "6";
                    CodIdentificacaoTs = "985791";
                    numSeqCobranca = "144361953";
                    acrescimo = "15,93";
                    break;
                case "PSA PARA TRANSFERENCIA DE CONTRATO":
                    Usuario = "ALESSANDRAVOLVO";
                    Contrato = "706731000";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(Contrato);
                    break;
                  

                case "MOVIMENTACAO CADASTRAL IMPORTAR ARQUIVO":
                    Usuario = "MA648064";
                    Contrato = "9900003885";
                    CodigoPlano = "1003";
                    LstEmpresaData.Add(Usuario);
                    LstEmpresaData.Add(CodigoPlano);
                    LstEmpresaData.Add(Contrato);

                    break;
                case "DEBITO AUTOMATICO":
                    Contrato = "778238000";
                    break;

                case "NÃO MOVIMENTAÇÕES PENDENTES":
                    Usuario = "MA648064";
                    GrupoContrato = "648064";
                    Contrato = "648064006";
                    ContratoName = "NESTLE BRASIL LTDA BR10 AT";
                    codTsContrato = "9900003882";
                    break;
                case "MOVIMENTAÇÕES PENDENTES":
                    Usuario = "MA648064";
                    GrupoContrato = "648064";
                    Contrato = "648064009";
                    ContratoName = "NESTLE BRASIL LTDA BR10 AT";
                    codTsContrato = "9900003885";
                    break;
                case "MOVIMENTAÇÕES PENDENTES GRUPO":
                    Usuario = "MA985791";
                    GrupoContrato = "985791";
                    Contrato = "1083437000";
                    ContratoName = "SYNERJET BRASIL LTDA";
                    codTsContrato = "11746921";
                    break;
                case "ALTERAR MES DE REFERENCIA":
                    Usuario = "G984748";
                    GrupoContrato = "984748";
                    GrupoContratoName = "SUPERMERCADOS VIANENSE";
                    Contrato = "984748000";
                    ContratoName = "SUPERMERCADOS VIANENSE LTDA";
                    break;
                case "MOVIMENTAÇÃO PENDENTE":
                    Usuario = "G984748";
                    GrupoContrato = "984748";
                    codTsContrato = "15364557";
                    GrupoContratoName = "SUPERMERCADOS VIANENSE";
                    Contrato = "984748000";
                    ContratoName = "SUPERMERCADOS VIANENSE LTDA";
                    GrupoenderecoIP = "189.20.205.223";
                    ContratoenderecoIP = "189.20.203.223";
                    break;
                case "NÃO EXISTE MOVIMENTAÇÃO PENDENTE":
                    Usuario = "G124138";
                    GrupoContrato = "124138";
                    codTsContrato = "15364557";
                    GrupoContratoName = "BK BRASIL (grupo)";
                    Contrato = "124138007";
                    ContratoName = "BK BRASIL OPERACAO E ASSESSORIA A RESTAURANTES S.A.";
                    break;

                case "BUSCAR BENEFICIÁRIO PARA ALTERAÇÃO DE CADASTRO":
                    Usuario = "MA648064";
                    Contrato = "648064010";
                    ContratoName = "NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA";
                    codTsContrato = "9900003841";
                    numeroContrato = "648064010";
                    BeneficiarioCPF = "6469386733";
                    BeneficiarioNome = "AGATHA JACURU DOMINGOS DA SILVA";
                    BeneficiarioMarcaOtica = "072246646";
                    break;
                case "CONSULTA IMPORTAÇÃO DE ARQUIVO DE ARQUIVO SUSP ADMINISTRADORA":
                    Usuario = "MA648064";
                    NomeRelatorio = "TsAss0511JR";
                    NomeRelatorio1= "TsAss0511JRE";
                    BeneficiarioCPF = "18943914890";
                    BeneficiarioNome = "ANTONIA LUCIA REGINALDO NAZARETH BERNARD";
                    CodTsContrato = "9900003841";
                    Aceidentificacaots = "648064";
                    Acetipousuario = "6";
                    Data_importacao_ini = "20/07/2018";
                    Data_importacao_fim = DateTime.Now.ToString("dd/MM/yyyy");
                    break;
                case "BUSCA CONTRATO DA IMPORTAÇÃO DE ARQUIVOS":
                    Usuario = "MA648064";
                    BeneficiarioCPF = "18943914890";
                    BeneficiarioNome = "ANTONIA LUCIA REGINALDO NAZARETH BERNARD";
                    numeroContrato= "648064008";
                    CodTsContrato= "9900003884";
                    ContratoName= "FUNDACAO NESTLE DE PREV PRIVADA BR27 AT";
                    CodigoJob= "1003";
                    dataInicioExecucao= DateTime.Now.ToString("dd-MM-yyyy");
                    dataFimExecucao= DateTime.Now.ToString("dd-MM-yyyy");
                    CodGrupoEmpresa = "648064";
                    codigoTipoOperacao= "10";
                    break;
                case "BUSCAR CONTRATO E BENEFICIÁRIO PARA DEMONSTRATIVO DE CO-PARTICIPAÇÃO":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "648064010";
                    codTsContrato = "9900003885";
                    codigoTsContrato= "9900003885";
                    codTsBeneficiario= "26580";
                    numeroContrato = "648064009";
                    ContratoName = "NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA";
                    BeneficiarioCPF = "064.693.867-33";
                    BeneficiarioNome = "AGATHA JACURU DOMINGOS DA SILVA";
                    BeneficiarioMarcaOtica = "072246646";
                    break;

                case "DEBITO AUTOMATICOS":
                    Usuario = "MA985791";
                    Senha = "Amil@1234";
                    CodigoContrato = "1120870000";
                    LstEmpresaData.Add(CodigoContrato);
                    BeneficiarioMarcaOtica = "072246646";
                    break;


                case "BUSCAR CONTRATO":
                    Usuario = "MA985791";
                    Senha = "Amil@1234";
                    Contrato = "648064010";
                    codTsContrato = "16747488";
                    codigoTsContrato = "9900003885";
                    codTsBeneficiario = "26580";
                    NumAssociado = "16747488";
                    NomSituacaoAssociado = "851268463";
                    numeroContrato = "648064009";
                    InitialDate = "04-2018";
                    CodEmpresa = "985791";
                    tipoUsuario = "6";
                    FinalDate = "08-2018";
                    CodigoContrato = "16747488";
                    BeneficiarioMarcaOtica = "072246646";
                    Beneficiario = "48709920";
                    LstEmpresaData.Add(Usuario);
                    break;

                case "BUSCAR CONTRATO PARA":
                    Usuario = "MA985791";
                    Senha = "Amil@1234";
                    Contrato = "1140373000";
                    codTsContrato = "16747488";
                    codigoTsContrato = "9900003885";
                    codTsBeneficiario = "26580";
                    numeroContrato = "648064009";
                    InitialDate = "04-2018";
                    FinalDate = "08-2018";
                    BeneficiarioMarcaOtica = "072246646";
                    LstEmpresaData.Add(Usuario);
                    break;
                case "TIPO DE CONSULTA CAIXA POSTAL":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "648064010";
                    ContratoName = "NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA";
                    BeneficiarioCPF = "064.693.867-33";
                    BeneficiarioNome = "AGATHA JACURU DOMINGOS DA SILVA";
                    BeneficiarioMarcaOtica = "072246646";
                    numeroContrato = "648064009";
                    codTsContrato = "9900003885";
                    SiglaUF = "SP";
                    CodigoLocalidade = "8853";
                    CaixaPostal = "17800970";
                    break;
                case "TIPO DE CONSULTA CAIXA POSTAL COMUNITARIA":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "648064010";
                    ContratoName = "NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA";
                    BeneficiarioCPF = "064.693.867-33";
                    BeneficiarioNome = "AGATHA JACURU DOMINGOS DA SILVA";
                    BeneficiarioMarcaOtica = "072246646";
                    numeroContrato = "648064009";
                    codTsContrato = "9900003885";
                    SiglaUF = "SP";
                    CodigoLocalidade = "8853";
                    CaixaPostal = "17800970";
                    break;
                case "TROCA DE FAIXA ETARIA":
                    Usuario = "G778238";
                    Senha = "6EA2A5B08C848D959E26";
                    Sistema = "dsisamil";
                    TipoRelatorio = "PDF";
                    CodigoRelatorio = "85";
                    Ip = "189.20.205.221";
                    Modulo = "91";
                    PCodTsContrato = "1296186";
                    PNumCicloTs = "27554";
                    PCodSucursal = "2";
                    PMesAnoRef = "01/06/2016";
                    PCodOperadora = "2";
                    PCodInspetoriaTs = "7";
                    POrdenacao = "1";
                    PIndQuebra = "C";
                    PIndiceRelat = "1";
                    PCodTipoCiclo = "1";
                    mesAnoRef = "06/2016";
                    break;
                case "BUSCAR MUNICÍPIO PARA ALTERAÇÃO DE CADASTRO":
                    Usuario = "G778238";
                    Senha = "Amil@1234";
                    codTs = "6587458";
                    NumContrato = "778238000";
                    CodigoUsuario = "G778238";
                    CodTsContrato = "1296186";
                    CodigoGrupoEmpresa = "778238";
                    codTipoOperacao = "3";
                    dataNascimento = "21/05/1967";
                    inclusaoDepSozinha = "N";
                    filter = "B";
                    limit = "10";
                    tipoUsuario = "6";
                    CodIdentificacaoTs = "778238";
                    Numerocaixapostal = "17800970";
                    CodigoMunicipio = "6015";
                    SiglaUF = "PR";
                    CodigoLocalidade = "6015";
                    CodigoBairro = "8645";
                    CodigoTipoLogradouro = "738";
                    CodigoTitulo = "112";
                    NomeLogradouro = "Rua Emiliano Perneta";
                    Filter = "548";
                    CodEmpresaNestle = "BR10";
                    CodArhNestle = "BRA1";
                    CodUsuario = "Nestle";
                    break;
                case "BUSCAR ARH PARA ALTERAÇÃO DE CADASTRO":
                    Usuario = "MA648064";
                    Senha = "Amil@1234";
                    Contrato = "648064007";
                    ContratoName = "NESTLE WATERS BRASIL BEB ALIM LT BR15 AT";
                    BeneficiarioCPF = "333.054.118-05";
                    BeneficiarioNome = "ALEXANDRE MIGUES RODRIGUES NETO";
                    BeneficiarioMarcaOtica = "621879290";
                    limit = "10";
                    Filter = "548";
                    CodTsContrato = "9900003883";
                    filter = "a";
                    CodEmpresaNestle = "BR10";
                    CodArhNestle = "BRA1";
                    break;
                case "DEMONSTRATIVO DE CO PARTICIPAÇÃO":
                    Usuario = "MA648064";
                    CodTsContrato = "9900003885";
                    NomeAssociado = "tars";
                    listarTodos = "true";
                    suspenso = "true";
                    CodigoTsBeneficiario = "45278704";
                    IndParticipacaoIsenta = "S";
                    numeroControleCoParticipacao = "1052462";
                    MesAnoRef = "10/2018";
                    codTsBeneficiario = "45278671";
                    numControleCopartSeq = "1055054";
                    codTsBeneficiario = "26580";
                    NumCep = "04.145-011";
                    SiglaUF = "SP";
                    CodigoMunicipio = "88412";
                    CodigoBairro = "VILA DA SAUDE";
                    NomeLogradouro = "RUA CATULO DA PAIXAO CEARENSE";
                    numEndereco = "566";
                    txtComplemento = "AP 31";
                    CaixaPostal = "null";
                    break;
            }
            return LstEmpresaData;
        }
    }
}
