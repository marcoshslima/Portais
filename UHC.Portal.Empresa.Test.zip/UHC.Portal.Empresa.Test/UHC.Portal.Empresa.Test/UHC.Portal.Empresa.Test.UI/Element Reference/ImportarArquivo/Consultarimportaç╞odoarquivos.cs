﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.ImportarArquivo
{
    class Consultarimportaçãodoarquivos
    {

        public static class Grupocontratobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o Grupo Contrato/Contrato:')]//following::button[1]";

        }
        public static class Grupocontratobtntxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o Grupo Contrato/Contrato:')]//following::button[1]//following::input[1]";

        }
        public static class ContratoComboBoxLST
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/../div/div/div[2]/div/div/ul/li";
        }
        public static class MesAnoreferencia
        {
            public static string Xpath = "//label[text()='Mês/Ano referência']/..//div//input";
        }
        public static class Períododecarga
        {
            public static string Xpath = "(//div[@class='datepicker__input']/..//div//input)[1]";
        }
        public static class Períododecargaate
        {
            public static string Xpath = "(//div[@class='datepicker__input']/..//div//input)[2]";
        }
        public static class Nomedoarquivo
        {
            public static string Xpath = "//input[@name='fileName']";
        }
        public static class Buscarbtn
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class ErrorMsg
        {
            public static string Xpath = "//section[@class='alert__message ']";
        }
        public static class NaoContractoExist
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";

        }
    }
}
