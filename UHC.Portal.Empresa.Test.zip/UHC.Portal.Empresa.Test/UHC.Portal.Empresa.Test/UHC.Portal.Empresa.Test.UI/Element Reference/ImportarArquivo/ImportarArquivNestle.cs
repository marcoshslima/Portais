﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.ImportarArquivo
{
    class ImportarArquivNestle
    {
        public static class Uploadfeild
        {
            public static string Xpath = "//button[text()='Procurar']/following-sibling::input[1]";
        }
        public static class TipoLayoutMovimentacaooCadastralComboBtn
        {
            public static string Xpath = "//label[text()='Tipo Layout Movimentação Cadastral (pós-implantação)']/../div/div/div/span/button";
        }
        public static class TipoLayoutMovimentacaooCadastralComboTxt
        {
            public static string Xpath = "//label[text()='Tipo Layout Movimentação Cadastral (pós-implantação)']/../div/div/div[2]/div/div/div/input";
        }
        public static class TipoLayoutMovimentacaooCadastralCombo_lst
        {
            public static string Xpath = "//label[text()='Tipo Layout Movimentação Cadastral (pós-implantação)']/../div/div/div[2]/div/div/ul/li";
        }
        public static class TipoLayoutMovimentacaooCadastralCombo
        {
            public static string Xpath = "//label[text()='Tipo Layout Movimentação Cadastral (pós-implantação)']/../div/div/div/div";
        }
        public static class Procurarbtn
        {
            public static string Xpath = "//button[text()='Procurar']";
        }
        public static class Executarbtn
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class ExibirFiladeexecução
        {
            public static string Xpath = "//button[text()='Exibir Fila de Execução']";
        }
        public static class Filadeexecução
        {
            public static string Xpath = "//h2[text()='Fila de execução']";
        }
        public static class Processo
        {
            public static string Xpath = "//p[text()='Processo:']";
        }
        public static class StartDate
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[1]/div/div[1]/input";
        }
        public static class StartDateErrorTag
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[1]/div[@class='datepicker datepicker--hasError']";
        }
        public static class EndDate
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[2]/div/div[1]/input";
        }
        public static class EndDateErrorTag
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[2]/div[@class='datepicker datepicker--hasError']";
        }
        public static class Refresh
        {
            public static string Xpath = "//i[@class='icon icon-spinner11 undefined']";
        }
        public static class DataDesolicitacao
        {
            public static string Xpath = "//th[text()='Data de Solicitação']";
        }
        public static class DataInicialGreater
        {
            public static string Xpath = "//div[text()='Data inicial do Período de Solicitação não pode ser maior que a data final']";
        }
        public static class Usuario
        {
            public static string Xpath = "//th[text()='Usuário']";
        }
        public static class Status
        {
            public static string Xpath = "//th[text()='Status']";
        }
        public static class Mensagem
        {
            public static string Xpath = "//th[text()='Mensagem']";
        }
        public static class Periodo
        {
            public static string Xpath = "//p[text()='Período:']";
        }
        public static class NaoHaDados
        {
            public static string Xpath = "//div[text()='Não há dados.']";
        }
        public static class Atualizarbtn
        {
            public static string Xpath = "//button[text()='Atualizar']";
        }
        public static class NoContractoExist
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }
        public static class InvalidStartDate
        {
            public static string Xpath = "//div[text()='Data inicial inválida']";
        }
        public static class InvalidEndDate
        {
            public static string Xpath = "//div[text()='Data final inválida']";
        }
        public static class Selecioneogrupocontratobtn
        {
            public static string Xpath = "//label[text()='Grupo Contrato/Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']";

        }
        public static class Selecioneogrupocontratobtntxt
        {
            public static string Xpath = "//label[text()='Grupo Contrato/Contrato']/../div/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Grupo Contrato/Contrato']/../div/div/div[2]/div/div/ul/li";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Grupo Contrato/Contrato']/../div/div/div/div";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class Origemdoarquivotab
        {
            public static string Xpath = "//label[text()='Origem do arquivo é tela relâmpago']";
            public static class Origemdoarquivosim
            {
                public static string Xpath = "//label[text()='Sim']";

            }
            public static class Origemdoarquivonao
            {
                public static string Xpath = "//label[text()='Não']";

            }

        }
    }
}
