﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.ImportarArquivo
{
    class ImportarArquiv
    {
        public static class Date
        {
            public static string ID = "rw_4_input";
            public static string Xpath = "//*[@id='" + ID + "']";
        }

        public static class CampoGrupoContratoImportar
        {
            public static string Xpath = "//div[@class='test_select_contract rw-dropdown-list rw-widget']";

        }
        public static class Selecioneogrupocontratobtn
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']";

        }
        public static class Selecioneogrupocontratobtntxt
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[1]//input";

        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/../div/div/div[2]/div/div/ul/li";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class Origemdoarquivotab
        {
            public static string Xpath = "//label[text()='Origem do arquivo é tela relâmpago?']/..";
            public static class Origemdoarquivosim
            {
                public static string Xpath = "//label[text()='Sim']";

            }
            public static class Origemdoarquivonao
            {
                public static string Xpath = "//label[text()='Não']";

            }

        }

        public static class Procurarbtn
        {
            public static string Xpath = "//button[text()='Procurar']";

        }
        public static class Uploadfeild
        {
            public static string Xpath = "//button[text()='Procurar']/following-sibling::input[1]";

        }
        public static class Executarbtn
        {
            public static string Xpath = "//button[text()='Executar']";

        }
        public static class Filadeexecução
        {
            public static string Xpath = "//div[@class='execution-queue']";

        }
        public static class Atualizarbtn
        {
            public static string Xpath = "//button[text()='Atualizar']";

        }
        public static class NoContractoExist
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";

        }
    }
}

