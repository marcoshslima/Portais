﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OGS.Framework.Utility;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Menu
{
	class MenuReference
    { 
        public static class LoginPopup

        {
            public static string Xpath = "//div[@class='reactour__helper walktrough md__hide reactour__helper--is-open sc-ifAKCX cRduaF']";
         }

        public static class Popupclose

        {
           // public static string Xpath = "new Actions(_driver).DoubleClick(_driver.FindElement(By.XPath("//*[@d='M5.9 4.5l2.8-2.8c.4-.4.4-1 0-1.4-.4-.4-1-.4-1.4 0L4.5 3.1 1.7.3C1.3-.1.7-.1.3.3c-.4.4-.4 1 0 1.4l2.8 2.8L.3 7.4c-.4.4-.4 1 0 1.4.2.2.4.3.7.3s.5-.1.7-.3L4.5 6l2.8 2.8c.3.2.5.3.8.3s.5-.1.7-.3c.4-.4.4-1 0-1.4L5.9 4.5z']"))).Perform();"
           
        }


        public static class PopupCloseProximo
        {
            public static string Xpath ="//span[text()='Próximo ']";
        }

        public static class PopupcloseAnterior
        {
            public static string Xpath = "//span[text()=' Anterior']";
        }

       
        public static class GestaoContratos
		{
			public static string XPath = "//div[text()='Gestão de Contratos']";

			public static class ConsultarInformacoesContratuais
			{
				public static string XPath = "//a[text()='Consultar Informações Contratuais']";
			}

			public static class ConsultarPrecoDosPlanosContratados
			{
				public static string XPath = "//a[text()='Consultar Preços dos Planos Contratados']";
			}

			public static class ConsultarInformacoesReembolso
			{
				public static string XPath = "//a[text()='Consultar Informações de Reembolso']";
			}

			public static class NovosAnexosAdministrativosEFinanceiros
			{
				public static string XPath = "//a[text()='Novos Anexos Administrativos e Financeiros']";
			}

			public static class EnviarAnexosParaOperadora
			{
				public static string XPath = "//a[text()='Enviar Anexos para Operadora']";
			}

			public static class ConsultarSituacaoDosAnexos
			{
				public static string XPath = "//a[text()='Consultar Situação dos Anexos']";
			}
		}

		public static class GestaoFinanceiraDemonstrativos
		{
			public static string XPath = "//div[text()='Gestão Financeira e Demonstrativos']";

			public static class ConsultarFaturasEmitidas
			{
				public static string XPath = "Consultar Faturas Emitidas";
			}

			public static class CalcularMultaEJurosDeFaturasVencidas
			{
				public static string XPath = "//a[text()='Calcular Multa e Juros de Faturas Vencidas']";
			}

			public static class DemonstrativoAnaliticoFaturamento
			{
				public static string XPath = "//a[text()='Demonstrativo Analítico do Faturamento']";
			}

			public static class DemonstrativoMovimentacoesBeneficiarios
			{
				public static string XPath = "//a[text()='Demonstrativo de Movimentações dos Beneficiários']";
			}

			public static class DemonstrativoCoParticipacao
			{
				public static string XPath = "//a[text()='Demonstrativo de Co-participação']";
			}

			public static class DemonstrativoDeTrocaDeFaixaEtaria
			{
				public static string XPath = "//a[text()='Demonstrativo de Troca de Faixa Etária']";
			}

			public static class DemonstrativoDeCustoOperacional
			{
				public static string XPath = "//a[text()='Demonstrativo de Custo Operacional']";
			}

			public static class DemonstrativoDeAditivos
			{
				public static string XPath = "//a[text()='Demonstrativo de Aditivos']";
			}

			public static class DemonstrativoDeBeneficiariosAtivos
			{
				public static string XPath = "//a[text()='Demonstrativo de Beneficiários Ativos']";

            }

			public static class DemontrativoDeAditivos
			{
				public static string XPath = "Demonstrativo de Aditivos";
			}

			public static class DemonstrativoDeReajuste
			{
				public static string XPath = "//a[text()='Demonstrativo Reajuste RN389']";
			}

			public static class SolicitacaoDeArquivos
			{
				public static string XPath = "Solicitação de Arquivos";
			}

			public static class DownloadDeArquivos
			{
				public static string XPath = "//a[text()='Download de Arquivos']";
			}

			public static class RelatorioSuspensaoBeneficiarios
			{
				public static string XPath = "Relatório Suspensão de Beneficiários";
			}
		}

		public static class MovimentacaoCadastral
		{
			public static string XPath = "//div[text()='Movimentação Cadastral']";

			public static class IncluirTitulares
			{
				public static string XPath = "//a[text()='Incluir Titulares']";
			}
			public static class IncluirDependentes
			{
				public static string XPath = "//a[text()='Incluir Dependentes']";
			}
			public static class AlterarCadastroDeBeneficiarios
			{
				public static string XPath = "//a[text()='Alterar Cadastro de Beneficiários']";
			}
			public static class ExcluirBeneficiarios
			{
				public static string XPath = "//a[text()='Excluir Beneficiários']";
			}
			public static class TrocarPlanoDosBeneficiarios
			{
				public static string XPath = "//a[text()='Trocar Plano dos Beneficiários']";
			}
			public static class TransferenciaDeContrato
			{
				public static string XPath = "//a[text()='Transferência de Contrato (COM MUDANÇA Nº BENEF)']";
			}
			public static class TransferenciaEntreFiliais
			{
				public static string XPath = "//a[text()='Transferência entre Filiais (SEM MUDANÇA Nº BENEF)']";
			}
			public static class ManutencaoDeAposentadosEDemitidos
			{
				public static string XPath = "//a[text()='Manutenção de Aposentados e Demitidos']";
			}
			public static class ImportarArquivo
			{
				public static string XPath = "//a[text()='Importar Arquivo']";
			}
            public static class ImportarArquivoNestle
            {
                public static string XPath = "//a[text()='Importar ArquivoNestlé']";
            }
            public static class ConsultarSituacaoMovimentacao
			{
				public static string XPath = "//a[text()='Consultar Situação da Movimentação']";
			}
			public static class EnviarMovimentacaoParaOperadora
			{
				public static string XPath = "//a[text()='Enviar Movimentação para a Operadora']";
			}
			public static class ExcluirMovimentacaoComErro
			{
				public static string XPath = "//a[text()='Excluir Movimentação com Erro']";
			}
			public static class AlterarMesReferencia
			{
				public static string XPath = "//a[text()='Alterar Mês Referência']";
			}
			public static class ConsultarImportacaoArquivo
			{
				public static string XPath = "//a[text()='Consultar Importação do Arquivo']";
			}
			public static class ConsultarLotes
			{
				public static string XPath = "//a[text()='Consultar Lotes']";
			}
			public static class ImportacaoDeArquivoSuspensaoDeBeneficiario
			{
				public static string XPath = "//a[text()='Importação de Arquivo Suspensão de Beneficiário']";
			}
			public static class SuspensaoDeBeneficiario
			{
				public static string XPath = "//a[text()='Suspensão de Beneficiário']";
			}
			public static class CancelarExclusaoDeBeneficiario
			{
				public static string XPath = "//a[text()='Cancelar Exclusão de Beneficiário']";
			}
			public static class CancelarSuspensaoBeneficiario
			{
				public static string XPath = "//a[text()='Cancelar Suspensão de Beneficiário']";
			}

			public static class ConsultaImportacaoDeArqSuspAdministradora
			{
				public static string XPath = "//a[text()='Consulta Importação de Arq. Susp. Administradora']";
			}
		}

		public static class GestaoBeneficiarios
		{
			public static string XPath = "//div[text()='Gestão de Beneficiários']";

			public static class ConsultarCadastroDosBeneficiarios
			{
				public static string XPath = "//a[text()='Consultar Cadastro dos Beneficiários']";
			}
            public static class ConulstarToken

            {
                public static string Xpath = "//*[text()='Consultar Autorizações Token']";
            }


            public static class EmitirSegundaViaDeBoletoDoBeneficiario
			{
				public static string XPath = "//a[text()='Emitir Segunda Via de Boleto do Beneficiário']";
			}

			public static class ConsultarAutorizações
			{
				public static string XPath = "//a[text()='Consultar Autorizações']";
			}

			public static class RelatorioDePendenciasCadastrais
			{
				public static string XPath = "//a[text()='Relatório de Pendências Cadastrais']";
			}

			public static class GerarArquivoCorrecoesPendenciasCadastrais
			{
				public static string XPath = "//a[text()='Gerar Arquivo Correçoes Pendências Cadastrais']";
			}

			public static class Solicitacoes
			{
				public static string XPath = "//div[text()='Solicitações']";

				public static class RegistrarSolicitacoes
				{
					public static string XPath = "//a[text()='Registrar Solicitações']";
				}

				public static class ConsultarSolicitacoes
				{
					public static string XPath = "//a[text()='Consultar Solicitações']";
				}

				public static class CancelarSolicitacoes
				{
					public static string XPath = "//a[text()='Cancelar Solicitações']";
				}
			}

			public static class DemonstrativosEDeclaracoes
			{
				public static string XPath = "//div[text()='Demonstrativos e Declarações']";

				public static class DemonstrativoCoparticipacao
				{
					public static string XPath = "//a[text()='Demonstrativo de Co-participação']";
				}

				public static class DemonstrativoDeReembolsoMedico
				{
					public static string XPath = "//a[text()='Demonstrativo de Reembolso Médico']";
				}

				public static class DeclaracaoDePagamento
				{
					public static string XPath = "//a[text()='Declaração de Pagamento']";
				}

				public static class DeclaracaoDeIR
				{
					public static string XPath = "//a[text()='Declaração de IR']";
				}

				public static class DeclaracaoDeIRDeReembolsos
				{
					public static string XPath = "//a[text()='Declaração de IR']";
				}

				public static class DeclaracaoDePermanencia
				{
					public static string XPath = "//a[text()='Declaração de Permanência']";
				}
			}
		}

		public static class Pagamento
		{
			public static string XPath = "//div[text()='Pagamento']";

			public static class Boletos
			{
				public static string XPath = "//a[text()='Boletos']";
			}

			public static class Demonstrativo
			{
				public static string XPath = "//a[text()='Demostrativo']";
			}

			
            public static class Débitoautomático_LNK
            {
                public static string Xpath = "//div/a[@href='#/debito-automatico']";
            }
        }

		public static class PrecosEProdutos
		{
			public static string XPath = "//div[text()='Preços e produtos']";

			public static class TabelaCompleta
			{
				public static string XPath = "//a[text()='Tabela completa']";
			}

			public static class HistoricoDeReajustes
			{
				public static string XPath = "//a[text()='Histórico de reajustes']";
			}
			
		}

		public static class RedeCredenciada
		{
			public static string XPath = "//a[text()='Rede credenciada']";
		}

		public static class AgendamentoOnline
		{
			public static string XPath = "//a[text()='Agendamento online']";
		}

		public static class ResolucoesNormativas
		{
			public static string XPath = "//a[text()='Resoluções normativas']";
		}

		public static class ControleAcessoAoPortal
		{
			public static string XPath = "//a[text()='Controle de Acesso ao Portal']";
		}

		public static class RelatoriosGerenciais
		{
			public static string XPath = "//a[text()='Relatórios gerenciais']";
		}
	}
}
