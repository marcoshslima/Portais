﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ConsultarAutorizacoes
    {
        public static class BeneficiarioCombo
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div[2]//ul/li";
        }
        public static class DateInvalid
        {
            public static string Xpath = "//div[text()='Data final não pode ser menor que data inicial']";
        }
        public static class DateFormat
        {
            public static string Xpath = "//small[text()='dd/mm/aaaa']";
        }
        public static class Datadeautorização
        {
            public static string Xpath = "//label[text()='Data de autorização']/following::input[@title='Selecionar Data'][1]";
        }
        public static class DateAté
        {
            public static string Xpath = "//div[text()='Até']/following::input[@title='Selecionar Data'][1]";
        }
        public static class Consultar_btn
        {
            public static string Xpath = "//button[text()='Consultar']";
        }
        public static class TratamentoComboInput
        {
            public static string Xpath = "//label[text()='Tratamento']/following::div[@class='wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div/input";
        }
        public static class TratamentoComboLst
        {
            public static string Xpath = "//label[text()='Tratamento']/following::div[@class='wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div[2]/div/div/ul/li";
        }
        public static class ConsultarAutorizacoes_Tela
        {
            public static string Xpath = "//h1[text()='Consultar autorizações']";
        }
    }
}

