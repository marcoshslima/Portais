﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class DebitoAutomatico1
    {
        #region Contrato
        public static class ContratoDropDown
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::button[1]";
        }
        public static class ContratoDropdownTextbox
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::input[@class='rw-input-reset']";
        }
        public static class Contrato
        {
            public static string Xpath = "//p[text()='778238000 / DEBRITO PROPAGANDA LTDA']";
        }
        public static class ContratoValue
        {
            public static string Xpath = "//label[text()='Contrato: ']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        #endregion

        #region Cancelar Button
        public static class CancelarDebitoAutomatico
        {
            public static string Xpath = "//button[text()='débito automático']";
        }
        public static class CancelarSIM
        {
            public static string Xpath = "//button[text()='Sim']";
        }

        public static class CancelarNão
        {
            public static string Xpath = "//button[text()='Não']";
        }
        public static class SalvarEsair
        {
            public static string Xpath = "//button[text()='Salvar e sair']";
        }



        public static class Authorizar
        {
            public static string Xpath = "//button[text()='Autorizar']";
        }


        public static class AlterarbancáriosButton

        {
            public static string Xpath = "//button[text()='Alterar'][1]";
        }

        public static class AlterarNotificaçãoButton

        {
            public static string Xpath = "//*[text()='E-mail: ']//following::button[text()='Alterar']";
        }

        //div[@class='rw-input rw-dropdown-list-input']

        public static class AlterarBancoCombobox
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }

        #endregion
        public static class Email
        {
            public static string Name = "email";


        }
        public static class Phone
        {
            public static string Name = "phone";
        }

        public static class ModalPhone
        {
            public static string Name = "modalPhone";
        }

        

             public static class ModalEmail
        {
            public static string Name = "modalEmail";
        }

        #region Cancelar Text
        public static class Cancelartext
        {
            public static string Xpath = "//p[text()='O débito automático foi:']";
        }

        public static class InvalidEmail
        {
            public static string Xpath = "//div[@class='invalid-feedback']";
        }

        public static class Authorizotext
        {
            public static string Xpath = "//h3[text()='Autorizado']";
        }

        public static class DadasdeEmpresa
        {
            public static string Xpath = "//h4[text()='Dados da empresa:']";
        }

        public static class Bancarios
        {
            public static string Xpath = "//h4[text()='Dados bancários:']";
        }

        public static class Atençãotext
        {
            public static string Xpath = "//h5[text()='Atenção']";

        }
        #endregion

       

        #region checkbox

        public static class CondradoCheckbox
        {
            public static string Xpath = "//div[@class='control__indicator']";
        }
        #endregion
        #region List of Contrato items

        public static class ContratoItemsList
        {
            public static string Xpath = "//ul[@id='rw_14_listbox']/li";
        }
        public static class NestleBrasilLtdaBR10AT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[@id='rw_5_listbox_active_option']";
        }
        public static class NestleBrasilLtdaBR10NF_17
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064017 / NESTLE BRASIL LTDA BR10 NF']";
        }
        public static class NestleBrasilLtdaBR10FU_18
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064018 / NESTLE BRASIL LTDA BR10 FU']";
        }
        public static class NestleWatersBrasil_BebidasEAlimentosLtda
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064010 / NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA']";
        }
        public static class NestleBrasilLtdaBR10AT_00
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064000 / NESTLE BRASIL LTDA BR10 AT']";
        }
        public static class NestleBrasilLtdaBR10NF_01
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064001 / NESTLE BRASIL LTDA BR10 NF']";
        }
        public static class DairyPartnersAmericasBrLtdBr24AT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064002 / DAIRY PARTNERS AMERICAS BR LTD BR24 AT']";
        }
        public static class DairyPartnersAmericasBrLtdBr24NF
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064003 / DAIRY PARTNERS AMERICAS BR LTD BR24 NF']";
        }
        public static class NestleBrasilLtdaBR10FU_06
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064006 / NESTLE BRASIL LTDA BR10 FU']";
        }
        public static class NesteleWatersBrasilBebAlimLtBr15AT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064007 / NESTLE WATERS BRASIL BEB ALIM LT BR15 AT']";
        }
        public static class FundacaoNestleDePrevPrivadaBR27AT
        {
            public static string Xpath = " //div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064008 / FUNDACAO NESTLE DE PREV PRIVADA BR27 AT']]";
        }
        public static class CPWBrasilLtdaBR19AT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Contrato: ')]//following::li[text()='648064009 / CPW BRASIL LTDA BR19 AT']";
        }
        public static class PartialContratoList
        {
            public static string Xpath = "//ul[@id='rw_7_listbox']/li";
        }
        #endregion

        #region Messages
        public static class NenhumResultado
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }
        #endregion

    }
}
