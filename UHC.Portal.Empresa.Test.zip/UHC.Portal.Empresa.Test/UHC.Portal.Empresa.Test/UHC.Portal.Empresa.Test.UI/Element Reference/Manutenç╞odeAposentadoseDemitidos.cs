﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ManutencaodeAposentadoseDemitidos
    {

        #region Manutencao
        public static class Selecioneocontrato
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]//following::button[1]//following::input[1]";
        }
        public static class Beneficiário
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]";
        }
        public static class Consultar
        {
            public static string Xpath = "//button[text()='Consultar']";
        }
        public static class AlertaPopup
        {
            public static string Xpath = "//h5[text()='Alerta']";
            public static class OkBtn
            {
                public static string Xpath = "//button[text()='Ok']";
            }
        }
        public static class Dadosdoplano 
        {
            public static string Xpath = "//h2[text()='Dados do plano']";
        }
        public static class Iníciodainatividade
        {
            public static string Xpath = "//input[@name='dataInicio']";
        }
        public static class Situaçãobox
        {
            public static string Xpath = "//label[text()='Situação:']";
            public static class Aposentadobox
            {
                public static string Xpath = "//label[text()='Aposentado']";
            }
            public static class Demitidobox
            {
                public static string Xpath = "//label[text()='Demitido']";
            }
        }
        
        public static class IníciodeContribuição
        {
            public static string Xpath = "//label[text()='Início de Contribuição']";
            public static class IníciodeContribuiçãodate
            {
                public static string Xpath = "//input[@id='dtIniContrib']";
            }
        }
        public static class TempodeContribuição
        {
            public static string Xpath = "//label[text()='Tempo de Contribuição']";
            public static class Anos
            {
                public static string Xpath = "//input[@id='qtdAnosContrib']";
            }
            public static class Meses
            {
                public static string Xpath = "//input[@id='qtdMesesContrib']";
            }
            public static class Dias
            {
                public static string Xpath = "//input[@id='qtdDiasContrib']]";
            }
        }

        public static class PeríododePermanência
        {
            public static string Xpath = "//input[@name='dtIniPeriodo']";
        }
        public static class PeríododePermanênciaate
        {
            public static string Xpath = "//input[@name='dtFimPeriodo']";
        }
        public static class DiadoVencimento
        {
            public static string Xpath = "//input[@id='diaPagamento']";
        }
        public static class Observação
        {
            public static string Xpath = "//label[text()='Observação']//..//textarea";
        }
        #endregion

        #region Anexo

        public static class LocaldeArquivamento
        {
            public static string Xpath = "//label[text()='Local de Arquivamento']";
        }
        public static class LocaldeArquivamentotextbox
        {
            public static string Xpath = "//input[@name='attachFiles[0].localArquivamento']";
        }
        public static class LocaldeArquivamentotextbox1
        {
            public static string Xpath = "//input[@name='attachFiles[1].localArquivamento']";
        }
        public static class Anexo
        {
            public static string Xpath = "//label[text()='Anexo']";
            public static class Procurar
            {
                public static string Xpath = "//button[text()='Procurar']";
            }

            public static class AnexoDeletebtn
            {
                public static string Xpath = "//button[@class='test_btn_delete_attachment_0 btn btn-primary']";
            }
            public static class AnexoDeletebtn1
            {
                public static string Xpath = "//button[@class='test_btn_delete_attachment_1 btn btn-primary']";
            }
        }
        public static class Descrição
        {
            public static string Xpath = "(//label[text()='Descrição']//..//textarea)[1]";
        }
        public static class Descrição1
        {
            public static string Xpath = "(//label[text()='Descrição']//..//textarea)[2]";
        }
        public static class Adicionarbtn
        {
            public static string Xpath = "//button[text()='+ Adicionar']";
        }
        #endregion

        #region  Históricodemovimentação
        public static class Históricodemovimentação
        {
            public static string Xpath = "//h2[text()='Histórico de movimentação']";
        }
        public static class Históricodemovimentaçãogrid
        {
            public static string Xpath = "//div[@class='table-responsive']//..//table";
        }
        #endregion

    }
}
