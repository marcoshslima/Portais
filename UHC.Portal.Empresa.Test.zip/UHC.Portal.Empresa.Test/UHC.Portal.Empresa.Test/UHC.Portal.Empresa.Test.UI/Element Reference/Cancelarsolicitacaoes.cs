﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Cancelarsolicitacaoes
    {
        public static class GestaoDeBeneficiarioslink
        {
            public static string Xpath = "//*[text()='Gestão de Beneficiários']";
        }

        public static class CancelarTela
        {
            public static string Xpath = "//h1[text()='Cancelar solicitações']";
        }

        public static class BeneficiarioErrortext
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
    }
}
