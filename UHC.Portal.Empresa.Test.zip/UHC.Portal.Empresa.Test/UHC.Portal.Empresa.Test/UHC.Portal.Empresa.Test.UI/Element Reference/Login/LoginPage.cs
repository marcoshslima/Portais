﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using UHC.Portal.Empresa.Test.UI.Utils;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class LoginPage
    {
        #region Login

        public static class InputUsername
        {

            public static string Xpath = "//input[@name = 'username']";
        }

        public static class InputPassword
        {
            public static string Xpath = "//input[@name = 'password']";
        }

        public static class BtnAcessar
        {
            public static string Xpath = "//button[text() ='Entrar']";
        }

        public static class LoginPopupclose
        {
            public static string Xpath = "//*[@d='M5.9 4.5l2.8-2.8c.4-.4.4-1 0-1.4-.4-.4-1-.4-1.4 0L4.5 3.1 1.7.3C1.3-.1.7-.1.3.3c-.4.4-.4 1 0 1.4l2.8 2.8L.3 7.4c-.4.4-.4 1 0 1.4.2.2.4.3.7.3s.5-.1.7-.3L4.5 6l2.8 2.8c.3.2.5.3.8.3s.5-.1.7-.3c.4-.4.4-1 0-1.4L5.9 4.5z']";
        }
        public static class UserName_WBEMT
        {
            public static string ClassName = "navbar-default__content__user-name";
        }
        public static class Proximo_Btn
        {
            public static string Xpath = "//span[text()='Próximo ']";
        }

        public static class Proximo_Popup_Close
        {
            public static string Xpath = "//button[@class='sc-bxivhb eTpeTG sc-bdVaJa jRQxUV']";
        }

        #endregion

        #region Login Atualização Cadastral

        public static class AtualizacaoCadastral
		{
			public static class TiutuloAtualizeSeuCadastro
			{
				public static string XPath = "//h3[text()='Atualize o seu cadastro']";
			}

			public static class CampoNomeCompleto
			{
				public static string Name = "registerUpdateName";
			}

			public static class CampoCPF
			{
				public static string Name = "registerUpdateCpf";
			}

			public static class CampoDDD
			{
				public static string Name = "registerUpdateDdd";
			}

			public static class CampoTelefone
			{
				public static string Name = "registerUpdatePhone";
			}

			public static class BotaoAtualizar
			{
				public static string XPath = "//button[text()='Atualizar']";
			}

			public static class IconeLapis
			{
				public static string XPath = "//i[contains(@class, 'icon-pencil')]";
			}

			public static class CampoEmail
			{
				public static string Name = "registerUpdateEmail";
			}

			public static class CampoConfirmeEmail
			{
				public static string Name = "registerUpdateEmailConfirm";
			}
		}

        #endregion

        #region Métodos da Classe
        public bool NecessitaAtualizacaoCadastral(IWebDriver _driver)
        {
            var _wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(5));
            try
            {
                _wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(AtualizacaoCadastral.TiutuloAtualizeSeuCadastro.XPath)));
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public void AtualizarCadastro(IWebDriver _driver)
        {
            if (NecessitaAtualizacaoCadastral(_driver))
            {
                // Preencher CPF


                ElementActions.ClearField(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoCPF.Name, Util.ShortWait);
                ElementActions.SetText(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoCPF.Name, Framework.Utilities.CNPJgenerator.GeradorCPF(), Util.ShortWait);

                // Preencher Campos Email

                ElementActions.ClickOnElement(_driver, "XPATH", LoginPage.AtualizacaoCadastral.IconeLapis.XPath, Util.ShortWait);
                ElementActions.ClearField(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoEmail.Name, Util.ShortWait);
                ElementActions.SetText(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoEmail.Name, "automacao@optum.com", Util.ShortWait);
                ElementActions.ClearField(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoConfirmeEmail.Name, Util.ShortWait);
                ElementActions.SetText(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoConfirmeEmail.Name, "automacao@optum.com", Util.ShortWait);

                // Preencher Telefone

                ElementActions.ClearField(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoDDD.Name, Util.ShortWait);
                ElementActions.SetText(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoDDD.Name, "41", Util.ShortWait);
                ElementActions.ClearField(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoTelefone.Name, Util.ShortWait);
                ElementActions.SetText(_driver, "NAME", LoginPage.AtualizacaoCadastral.CampoTelefone.Name, "999999999", Util.ShortWait);

                // Clicar Botão Atualizar

                ElementActions.ClickOnElement(_driver, "XPATH", LoginPage.AtualizacaoCadastral.BotaoAtualizar.XPath, Util.ShortWait);
                Util.WaitLoaders(_driver);
            }           
        }
        #endregion
    }
}

