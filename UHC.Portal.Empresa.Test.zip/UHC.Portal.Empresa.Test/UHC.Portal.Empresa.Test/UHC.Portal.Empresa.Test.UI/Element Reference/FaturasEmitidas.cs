﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class FaturasEmitidas
    {

        public static class Contratotext
        {
            public static string Xpath = "//label[text()='Contrato *']";
        }

        public static class Calendarclick
        {
            public static string Xpath = "//td[@class='rw-cell']//following::td[text()='mar']";
        
        }

        public static class CompetenciaButton
        {
            public static string Xpath = "//label[text()='Data de competência *']//following::span[@class='rw-i rw-i-calendar']";

        }

        public static class AteButton
        {
            public static string Xpath = "//label[text()='Até *']//following::span[@class='rw-i rw-i-calendar']";

        }

        public static class ConsultarButton
        {
            public static string Xpath = "//button[text()='Consultar']";
        }
        public static class InitialError
        {
            public static string Xpath = "//div[text()='Data Inicial inválida']";
        }

        public static class TabelResponsive
        {
            public static string Xpath = "//div[@class='table-responsive']";
        }
    }
}
