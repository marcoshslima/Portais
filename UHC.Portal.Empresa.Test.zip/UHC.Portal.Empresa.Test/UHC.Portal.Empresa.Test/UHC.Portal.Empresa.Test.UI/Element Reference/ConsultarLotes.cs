﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ConsultarLotes
    {

        public static class MovimentacaoCadastralMenu
        {
            public static string Xpath = "//*[text()='Movimentação Cadastral']";
        }
        public static class ConsultarLotesLink
        {
            public static string Xpath = "//*[text()='Consultar Lotes']";
        }
        public static class ContratoGroupDropdown
        {
            public static string Xpath = "//*[@class='rw-input rw-dropdown-list-input']";
        }
        public static class BatchInformation
        {
            public static string Xpath = "//*[text()='Lote: ']";
        }
        public static class SubmitButton
        {
            public static string Xpath = "//*[text()='Buscar']";
        }
        public static class GridCode
        {
            public static string Xpath = "//*[text()='Lote: ']/following-sibling::p";
        }
        public static class EnviadoHeader
        {
            public static string Xpath = "//tr[1]/th[2]";
        }
        public static class AceitoHeader
        {
            public static string Xpath = "//tr[1]/th[3]";
        }
        public static class DevolvidoHeader
        {
            public static string Xpath = "//tr[1]/th[4]";
        }
        public static class RecusadoHeader
        {
            public static string Xpath = "//tr[1]/th[5]";
        }
        public static class PendentesHeader
        {
            public static string Xpath = "//tr[1]/th[6]";
        }

        public static class NoInformation
        {
            public static string Xpath = "//div[@class='test_select_contract--feedback invalid-feedback']";
        }
        public static class LoteDropDown
        {
            public static string Xpath = "(//div[@class='rw-input rw-dropdown-list-input'])[2]";
        }

        public static class LoteErrorMessage
        {
            public static string Xpath = "//*[text()='Lote não informado']";
        }
        

    }
}