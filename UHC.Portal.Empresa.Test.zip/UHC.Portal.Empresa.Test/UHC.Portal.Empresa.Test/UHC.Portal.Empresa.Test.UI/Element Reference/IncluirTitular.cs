﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
   
    class IncluirTitular
    {
        public static class Selectbtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]//following::button[1]";
        }
        public static class Selectcontratotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]//following::button[1]//following::input[1]";
        }
        public static class Selectcontratolist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]/../div/div/div[2]//ul/li";
        }
        public static class Selectcontratoerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }
        #region Dados do titular beneficiário
        public static class Cpf
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.cpf']";
        }
        public static class Nome
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.nome']";
        }
        public static class Nomecartão
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.nomeCartao']";
        }
        public static class Datadeinclusão
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.dataInclusao']";
        }
        public static class Dataderegistro
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.dataRegistro']";
        }
        public static class Datadenascimento
        {
            public static string Xpath = "(//label[text()='Data de nascimento *']/..//following::input[1])[1]";
        }
        public static class SexoMasculino
        {
            public static string Xpath = "//label[text()='Masculino']";
        }
        public static class SexoFeminino
        {
            public static string Xpath = "//label[text()='Feminino']";
        }
        public static class Nacionalidade
        {
            public static string Xpath = "//label[text()='Brasileiro']";
        }
        public static class NacionalidadeEstrangeiro
        {
            public static string Xpath = "//label[text()='Estrangeiro']";
        }
        public static class Nomedamãe
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.nomeMae']";
        }
        public static class Nomedopai
        {
            public static string Xpath = "//input[@name='beneficiaryOwner.nomePai']";
        }
        // Combo Box
        public static class Estadocivil 
        {
            public static string Xpath = "//select[@name='beneficiaryOwner.estadoCivil']";
        }
        public static class Planobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Plano *')]//following::button[1]";
        }
        public static class Planotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Plano *')]//following::button[1]//following::input[1]";
        }
        public static class IBGEbutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]//following::button[1]";
        }
        public static class IBGEtext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]//following::button[1]//following::input[1]";
        }
        public static class IBGElist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]/../div/div/div[2]//ul/li";
        }
        public static class IBGEerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }


        #endregion

        #region Endereço

        public static class País
        {
            public static string Xpath = "//label[text()='Brasil']";
        }
        public static class PaísExterior
        {
            public static string Xpath = "//label[text()='Exterior']";
        }
        public static class CEP
        {
            public static string Xpath = "//input[@name='address.cep']";
        }
        public static class Logradouro
        {
            public static string Xpath = "//input[@name='address.logradouro']";
        }
        public static class Número
        {
            public static string Xpath = "//input[@name='address.numero']";
        }
        public static class Complemento
        {
            public static string Xpath = "//input[@name='address.complemento']";
        }
        public static class Bairro
        {
            public static string Xpath = "//input[@name='address.bairro']";
        }
        public static class Município
        {
            public static string Xpath = "//input[@name='address.codigoMunicipio']";
        }
        public static class UF
        {
            public static string Xpath = "//input[@name='address.uf']";
        }
        #endregion

        #region Contato
        public static class Telefone
        {
            public static string Xpath = "//input[@name='contact.telefone']";
        }
        public static class Ramal
        {
            public static string Xpath = "//input[@name='contact.ramal']";
        }
        public static class Celular
        {
            public static string Xpath = "//input[@name='contact.celular']";
        }
        public static class Email
        {
            public static string Xpath = "//input[@name='contact.email']";
        }
        #endregion

        #region Documentos
        public static class Identidade
        {
            public static string Xpath = "//input[@name='documents.identidade']";
        }
        public static class ÓrgãoEmissor
        {
            public static string Xpath = "//input[@name='documents.orgaoEmissor']";
        }
        public static class Paísemissor
        {
            public static string Xpath = "//input[@name='documents.paisEmissor']";
        }
        public static class PIS
        {
            public static string Xpath = "//input[@name='documents.pis']";
        }
        public static class Cartãonacionaldesaúde
        {
            public static string Xpath = "//input[@name='documents.cartaoNacionalSaude']";
        }
        public static class CBObutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'CBO')]//following::button[1]";
        }
        public static class CBOtext
        {
            public static string Xpath = "//div//.//label[contains(text(),'CBO')]//following::button[1]//following::input[1]";
        }
        public static class CBOlist
        {
            public static string Xpath = "//div//.//label[contains(text(),'CBO')]/../div/div/div[2]//ul/li";
        }
        public static class CBOerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'CBO')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }
        public static class Declaraçãodenascidovivo
        {
            public static string Xpath = "//input[@name='documents.declaracaoNascidoVivo']";
        }
        #endregion

        #region Dados de reembolso
        public static class Bancobutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Banco')]//following::button[1]";
        }
        public static class Bancotext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Banco')]//following::button[1]//following::input[1]";
        }
        public static class Bancolist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Banco')]/../div/div/div[2]//ul/li";
        }
        public static class Bancoerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Banco')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }
        public static class Agência
        {
            public static string Xpath = "//input[@name='refundData.agencia']";
        }
        public static class DV
        {
            public static string Xpath = "//input[@name='refundData.agenciaDv']";
        }
        public static class Tipodeconta
        {
            public static string Xpath = "//input[@name='refundData.conta']";
        }
        public static class TipodecontaContapoupança
        {
            public static string Xpath = "//input[@name='refundData.contaDv']";
        }
        #endregion

        #region Dados na empresa
        public static class Matrículafuncional
        {
            public static string Xpath = "//input[@name='companyData.matriculaFuncional']";
        }
        public static class Sequencial
        {
            public static string Xpath = "//input[@name='companyData.sequencial']";
        }
        public static class Cargo
        {
            public static string Xpath = "//input[@name='companyData.codCargo']";
        }
        public static class Lotaçãobutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Lotação')]//following::button[1]";
        }
        public static class Lotaçãotext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Lotação')]//following::button[1]//following::input[1]";
        }
        public static class Lotaçãolist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Lotação')]/../div/div/div[2]//ul/li";
        }
        public static class Lotaçãoerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Lotação')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }
        public static class Centrodecustobutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Centro de custo')]//following::button[1]";
        }
        public static class Centrodecustotext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Centro de custo')]//following::button[1]//following::input[1]";
        }
        public static class Centrodecustolist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Centro de custo')]/../div/div/div[2]//ul/li";
        }
        public static class Centrodecustoerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Centro de custo')]/../div/div/div[2]//ul/li[contains(text(),'Nenhum resultado encontrado')]";
        }
        public static class Datadeadmissão
        {
            public static string Xpath = "(//label[text()='Data de admissão *']/..//following::input[1])[1]";
        }
        public static class Datainíciocontribuição
        {
            public static string Xpath = "//input[@id='rw_14_input']";
        }
        public static class Iníciolotação
        {
            public static string Xpath = "//input[@id='rw_15_input']";
        }
        public static class Statusbutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Status ')]//following::button[1]";
        }
        public static class Statustext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Status ')]//following::button[1]//following::input[1]";
        }
        public static class Statuslist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Status ')]/../div/div/div[2]//ul/li";
        }
        public static class Statuserror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Status ')]/../div/div/div[2]//ul/li[text()='Nenhum resultado encontrado']";
        }

        public static class Empresabutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Empresa *')]//following::button[1]";
        }
        public static class Empresatext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Empresa *')]//following::button[1]//following::input[1]";
        }
        public static class Empresalist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Empresa *')]/../div/div/div[2]//ul/li";
        }
        public static class Empresaerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Empresa *')]/../div/div/div[2]//ul/li[text()='Nenhum resultado encontrado']";
        }

        public static class ARHbutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'ARH *')]//following::button[1]";
        }
        public static class ARHtext
        {
            public static string Xpath = "//div//.//label[contains(text(),'ARH *')]//following::button[1]//following::input[1]";
        }
        public static class ARHlist
        {
            public static string Xpath = "//div//.//label[contains(text(),'ARH *')]/../div/div/div[2]//ul/li";
        }
        public static class ARHerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'ARH *')]/../div/div/div[2]//ul/li[text()='Nenhum resultado encontrado']";
        }

        public static class PSAbutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]";
        }
        public static class PSAtext
        {
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]//following::input[1]";
        }
        public static class PSAlist
        {
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]/../div/div/div[2]//ul/li";
        }
        public static class PSAerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]/../div/div/div[2]//ul/li[text()='Nenhum resultado encontrado']";
        }
        public static class Unidadebutton
        {
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional *')]//following::button[1]";
        }
        public static class Unidadetext
        {
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional *')]//following::button[1]//following::input[1]";
        }
        public static class Unidadelist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional *')]/../div/div/div[2]//ul/li";
        }
        public static class Unidadeerror
        {
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional *')]/../div/div/div[2]//ul/li[text()='Nenhum resultado encontrado']";
        }

        #endregion

        #region Anexo

        public static class LocaldeArquivamento
        {
            public static string Xpath = "//input[@name='attachFiles[0].localArquivamento']";
        }

        public static class Procurarbtn
        {
            public static string Xpath = "//button[text()='Procurar']";
        }
        public static class Anexodescricao
        {
            public static string Xpath = "//textarea[@name='attachFiles[0].descricao']";
        }

        #endregion
        public static class Incluirbtn
        {
            public static string Xpath = "//button[text()='Incluir']";
        }
        public static class Popups
        {
            public static string Xpath = "//h5[text()='Inclusão de Titular']";
            public static class Sucessomsg
            {
                public static string Xpath = "(//span[text()='Operação realizada com sucesso.'])[2]";
            }
            public static class Okbtns
            {
                public static string Xpath = "//button[text()='Ok']";
            }
            public static class Fecharbtn
            {
                public static string Xpath = "//button[text()='Fechar']";
            }
            public static class Errormsg
            {
                public static string Xpath = "//span[text()='Existem campos de preenchimento obrigatório que não foram preenchidos.']";
            }
        }
        public static class Sucessomsg
        {
            public static string Xpath = "//span[text()='Operação realizada com sucesso.']";
        }
        public static class Alterarbtn
        {
            public static string Xpath = "//button[text()='Alterar']";
        }
        public static class Excluirbtn
        {
            public static string Xpath = "//button[text()='Excluir']";
        }
        public static class Dependentebtn
        {
            public static string Xpath = "//button[text()='Incluir Dependente']";
        }
        public static class NovoTitularbtn
        {
            public static string Xpath = "//button[text()='Incluir Novo Titular']";
        }
        #region CEP Pop
        public static class CEPbutton
        {
            public static string Xpath = "//button[text()='Não sei o CEP']";
            public static class CEPPop
            {
                public static string Xpath = "//h5[text()='Busca CEP']";
            }
            public static class Tipodeconsulta
            {
                public static string Xpath = "//label[text()='Tipo de consulta']/..//select";
            }
            public static class Estadobutton
            {
                public static string Xpath = "//div//.//label[contains(text(),'Estado *')]//following::button[1]";
            }
            public static class Estadotext
            {
                public static string Xpath = "//div//.//label[contains(text(),'Estado *')]//following::button[1]//following::input[1]";
            }
            public static class Municipiobutton
            {
                public static string Xpath = "//div//.//label[contains(text(),'Municipio *')]//following::button[1]";
            }
            public static class Municipiotext
            {
                public static string Xpath = "//div//.//label[contains(text(),'Municipio *')]//following::button[1]//following::input[1]";
            }
            public static class Bairrobutton
            {
                public static string Xpath = "//div//.//label[contains(text(),'Bairro')]//following::button[1]";
            }
            public static class Bairrotext
            {
                public static string Xpath = "//div//.//label[contains(text(),'Bairro')]//following::button[1]//following::input[1]";
            }
            public static class Logradourotext
            {
                public static string Xpath = "//input[@name='localityPubAreaSearch']";
            }
            public static class CEPtext
            {
                public static string Xpath = "//input[@name='zipCode']";
            }

            public static class Usuariotext
            {
                public static string Xpath = "//input[@name='user']";
            }
            public static class Númerocaixapostaltext
            {
                public static string Xpath = "//input[@name='mailboxNumber']";
            }
            public static class Buscarbutton
            {
                public static string Xpath = "//button[text()='Buscar CEP']";
            }
            public static class Municípiomsg
            {
                public static string Xpath = "//span[contains(text(),'* Município')]";
            }
            public static class Buscaceppopup
            {
                public static string Xpath = "//h5[text()='Busca CEP']/../..";
                public static class Checkbtn
                {
                    public static string Xpath = "//div[text()='Ações']/..//ul//li//span";
                }
                //change button
                public static class Voltarbtn
                {
                    public static string Xpath = "//button[text()='Voltar']";
                }
                public static class Errormsg
                {
                    public static string Xpath = "//td[text()='CEP não encontrado.']";
                }
            }
            


        }
        #endregion

        #region Relatórios gerenciais 
        public static class Relatóriosgerenciais
        {
            public static string Xpath = "(//a[text()='Relatórios gerenciais'])[1]";
            public static class GestãoSaúdeMenu
            {
                public static string Xpath = "//a[text()='Gestão Saúde']";
            }
            public static class Booksgerenciaislink
            {
                public static string LinkText = "BI - BOOKS GERENCIAIS";
            }
        }

        #endregion
    }




}
