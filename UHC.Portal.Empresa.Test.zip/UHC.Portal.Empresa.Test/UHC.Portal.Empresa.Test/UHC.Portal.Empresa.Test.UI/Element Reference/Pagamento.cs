﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Pagamento
    {
        #region Pagamento page details

        public static class Boletos_LNK
        {
            public static string LinkText = "Boletos";
        }

        public static class Pagamento_LNK
        {
            public static string Xpath = "//div[contains(text(),'Pagamento')]";
        }
        public static class Débitoautomático_LNK
        {
            public static string Xpath = "//div/a[@href='#/debito-automatico']";
        }

        public static class Demostrativo_LNK
        {
            public static string Xpath = "//a[text()='Demostrativo']";
        }

        public static class DatePeriod_CMBBOX
        {
            public static string Name = "datePeriod";
        }

        public static class Test_table_demonstratives_WBTBL
        {
            public static string Xpath = "//table[@class='text-center test_table_demonstratives component-table--undefined table table-hover']";
        }

        public static class Nãoconstamdemonstrativos_WBEMT
        {
            public static string Xpath = "//td[text()='Não constam demonstrativos de pagamento neste período.']";
        }

        public static class Boltes_Empresa
        {
            public static string Xpath = "//label[text()='Empresa: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
        }

        public static class Boltes_Contrato
        {
            public static string Xpath = "//label[text()='Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']";
        }

        public static class Boltes_Empresa_Input
        {
            public static string Xpath = "//label[text()='Empresa: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class Boltes_Contrato_Input
        {
            public static string Xpath = "//label[text()='Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div[2]/div/div/div/input";
        }
        public static class GerarPDF_BTN
        {
            public static string Xpath = "//button[text()='Gerar PDF']";
        }
        public static class GerarPDFEnable_BTN
        {
            public static string Xpath = "//button[@class='btn btn-primary disabled']";
        }
        public static class Boltes_Único_Contrato
        {
            public static string Xpath = "//label[text()='Empresa: ']/following-sibling::p";
        }
        public static class EmpresaComBox_BTN
        {
            public static string Xpath = "//div//.//label[contains(text(),'EMPRESA:')]//following::button[1]";
        }
        public static class Buscar_BTN
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class Sim_BTN
        {
            public static string Xpath = "//button[text()='Sim']";
        }
        public static class Executar_BTN
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class Copiarcódigo_BTN
        {
            public static string Xpath = "//button[text()='Copiar código']";
        }
        public static class Copiado_BTN
        {
            public static string Xpath = "//button[text()='Copiado!']";
        }
        public static class Acessar_BTN
        {
            public static string Xpath = "//button[text()='Acessar']";
        }
        public static class Atualizar_BTN
        {
            public static string Xpath = "//button[text()='Atualizar']";
        }
        public static class Boltes_Selected_Contrato
        {
            public static string Xpath = "//label[text()='Empresa: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div[1]/div";
        }
        public static class Boltes_Table
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr";
        }
        public static class Boltes_Observação
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr[1]/td[4]";
        }
        public static class Boltes_Valortotal 
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr[1]/td[3]";
        }
        public static class Nao_Boltes
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr[1]/td";
        }
        public static class Prorrogar_fatura
        {
            public static string Xpath = "//p[text()='Tem certeza que deseja prorrogar todas as faturas para o novo vencimento?']";
        }
        public static class InvoiceAlert_DateExtend
        {
            public static string Xpath = "//p[text()='Faturas prorrogadas com sucesso']";
        }
        public static class Print_Action
        {
            public static string Xpath = "//span[@class='icon icon-printer']";
        }
        public static class Vencimento
        {
            public static string Xpath = "//div[@class='summary-bankslip-line']/div[2]/div";
        }
        public static class Valor
        {
            public static string Xpath = "//div[text()='Valor']/following-sibling::div[contains(text(),'R$')]";
        }
        public static class Juros
        {
            public static string Xpath = "//div[text()='Juros']/following-sibling::div[contains(text(),'R$')]";
        }
        public static class Multa
        {
            public static string Xpath = "//div[text()='Multa']/following-sibling::div[contains(text(),'R$')]";
        }
        public static class Faturas_Valor
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr[1]/td[6]";
        }
        public static class vencimento_table
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr[1]/td[2]";
        }
        public static class DemonstrativodePagamentos_title
        {
            public static string Xpath = "//h1[text()='Demonstrativo de pagamentos']";
        }
        public static class BOLETOSCOM60DIASDEATRASO
        {
            public static string Xpath = "//div[text()='Vencido há 60 dias']";
        }
        public static class vencimentoatual
        {
            public static string Xpath = "//div[text()='Vencimento']/following-sibling::div[@class='summary-bankslip-line-right']/div/div/button";
        }
        public static class vencimento_Expiredmessage
        {
            public static string Xpath = "//div[text()='Data de vencimento do boleto está fora do período permitido para recálculo.']";
        }
        public static class Bacode_number
        {
            public static string Xpath = "//div[@class='bankslip-barcode-numbers']";
        }
        public static class dataatual
        {
            public static string Xpath = "//div[text()='Vencimento']/following-sibling::div[@class='summary-bankslip-line-right']/div/span/button[1]";
        }
        public static class Futurebusinessdate
        {
            public static string Xpath = "//div[text()='Vencimento']/following-sibling::div[@class='summary-bankslip-line-right']/div/span/button[2]";
        }
        #endregion

        #region TextandSeText

        public static class DebitoAutomaticoScreen

        {
            public static string Xpath = "//h1[text()='Débito automático']";
        }

        public static class InvaldEmail
        {
            public static string Xpath = "Email inválido";
                }
        public static class CampoErrortext

        {
            public static string Xpath = "//div[text()='Campo obrigatório']";
        }

        public static class Authorizado
        {
            public static string Xpath = "//h3[text()='Autorizado']";
        }

        public static class Agencia
        {
            public  static string Xpath = "//label[text()='Agencia']//following::div[@class='input-container'][1]";
        }

        public static class AlterarNotificaçãoButton

        {
            public static string Xpath = "//*[text()='E-mail: ']//following::button[text()='Alterar']";
        }

        public static class Digito1

        {
            public static string Xpath = "//label[text()='Agencia']//following::div[@class='input-container'][2]";
        }


        public static class Digito2
        {
            public static string Xpath = "//label[text()='Agencia']//following::div[@class='input-container'][4]";
        }
        public static class Conta

        {
            public static string Xpath = "//label[text()='Agencia']//following::div[@class='input-container'][3]";
        }

        public static class PopupmodalAgencia

        {
            public static  string Name = "modalBranch";
        }

        public static class Bancodabrasil

        {
            public static string Xpath = "//label[text()='Banco']//following::div[@class='rw-input rw-dropdown-list-input']//following::li[@class='rw-list-option'][1]";
        }


        public static class BancodaBRADESCO

        {
            public static string Xpath = "//li[@class='rw-list-option rw-state-focus']";
        }


        public static class Email
        {
            public static string Name = "email";

        }

        public static class ModalEmail
        {
            public static string Name = "modalEmail";
        }
        public static class Phone
        {
            public static string Name = "phone";
        }
        public static class ModalPhone
        {
            public static string Name = "modalPhone";
        }

        public static class PopupModal

        {
            public static string Xpath = "//*[@class='modal-title']";
        }

        public static class Popupemailphone
        {
            public static string Xpath = "//div[@class='col-lg-10']";
        }

        public static class ManinCelluar

        {
            public static string Xpath = "//b[text()='Celular: ']";
        }

        public static class MainEmail
        {
            public static string Xpath = "//b[text()='E-mail: ']";
        }


       

        public static class DadasdeEmpresa
        {
            public static string Xpath = "//h4[text()='Dados da empresa:']";
        }

        public static class Bancarios
        {
            public static string Xpath = "//h4[text()='Dados bancários:']";
        }
        public static class Authorizotext
        {
            public static string Xpath = "//h3[text()='Autorizado']";
        }

        public static class CellularInvalido

        {
            public static string Xpath = "//div[text()='Celular inválido']";
        }

        public static class Atençãotext
        {
            public static string Xpath = "//h5[text()='Atenção']";

        }
        public static class Cancelartext
        {
            public static string Xpath = "//p[text()='O débito automático foi:']";
        }


        public static class Situcao
        {
            public static string Xpath = "h2[text()='Situação:']";
        }

        public static class AuthorizoGrid

        {
            public static string Xpath = "//h2[text()='Autorizar débito automático']";

        }
        public static class Cancelado

        {

            public static string Xpath = "//h3[text()='Cancelado']";

        }
        public static class CanceladoBody

        {
            public static string Xpath = "//h2[text()='Situação:']//following::div[@class='card-body']";
        }
        #endregion

        #region Dropdown
        public static class ContratoDropdown

        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }

        public static class DadosDropdown
        {
            public static string Xpath = "//*[text()='Banco']//following::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']//following::*[@class ='rw-input-reset']";
        }

        public static class ContratoInput

        {
            public static string Xpath = "//input[@class='rw-input-reset']";
        }


        public  static class Errortext
        {
            public static string Xpath = "//p[text()='Você não precisa mais se preocupar com os horários bancários ou com o recebimento de seu boleto via correio']";
        }

        public  static class Bancotext
        {
            public static  string Xpath = "//*[text()='Após a adesão ao Débito Automático, é necessário que o cliente titular da conta conclua a operação autorizando o serviço com o Banco do Brasil S.A.']";
        }
        #endregion

        #region Button

        public static class AuthorizarDebitoButton
        {
            public static string Xpath = "//button[text()='Autorizar débito automático']";
        }
        public static class Authorizar
        {
            public static string Xpath = "//button[text()='Autorizar']";
        }

        public static class CancelarDebitoAutomatico
        {
            public static string Xpath = "//button[text()='débito automático']";
        }

        public static class AlterarbancáriosButton

        {
            public static string Xpath = "//button[text()='Alterar'][1]";
        }

        public static class SalvarEsair
        {
            public static string Xpath = "//button[text()='Salvar e sair']";
        }

        public static class CancelarNão
        {
            public static string Xpath = "//button[text()='Não']";
        }

        public static class CancelarSIM
        {
            public static string Xpath = "//button[text()='Sim']";
        }
        #endregion
    }
}
