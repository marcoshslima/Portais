﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ConsultarAutorizacoesToken
    {
        #region Text
        public static class GestaoDeBeneficiarioslink
        {
            public static string Xpath = "//*[text()='Gestão de Beneficiários']";

        }

        public static class ConsultarButton
        {
            public static string Xpath = "//button[text()='Consultar']";
        }
        public static class AutorizoBeneficiario

        {
            public static string  Xpath = "//label[text()='Beneficiário']";
        }
        public static class Conulstarlink

        {
            public static string Xpath = "//*[text()='Consultar Autorizações Token']";
        }

        public static class Contratobutton
        {
            public static string Xpath = "//label[text()='Selecione o contrato']//following::div[@class='rw-input rw-dropdown-list-input']";
        }

        public static class ConsultarautorizaçõesTela

        {
            public static string Xpath = "//h1[text()='Consultar autorizações']";
        }
        public static class SelecioneoCóontrato_CMBLST
        {
            public static string Xpath = "//label[text()='Selecione o contrato']/../div//ul/li";
        }

        public static class ContratoTXt
        {
            public static string Xpath = "//input[@class='rw-input-reset']";
        }
        public static class Conulstarautorizaçõeslink

        {
            public static string Xpath = "//*[text()='Consultar Autorizações']";

        }
        public static class ConsultarautorizaçõesScreen
        {
            public static string Xpath = "//h1[text()='Consultar autorizações']";

        }


        public static class Tratamentoerror
        {
            public static string Xpath = " //*[text()='Dados não encontrados']";
        }
        public static class ConsultarTokenScreen
        {
            public static string Xpath = "//h1[text()='Consultar autorizações token']";
        }

        public static class TokenText
        {
            public static string Xpath = "//input[@class='undefined  form-control']";
        }

        public static class TokenError
        {
            public static string Xpath = "//p[strong='Houve um erro ao buscar o beneficiário. Tente novamente.']";
        }

        public static class Tratamento
        {
            public static string Xpath = "//input[@class ='rw-widget-input rw-input'][1]";
        }
        #endregion

        #region Dropdownlist

        public static class TratemntoDropdown
        {
            public static string Xpath = "//*[@class ='rw-list-option rw-state-focus']";
        }

        #endregion

    }
    }

