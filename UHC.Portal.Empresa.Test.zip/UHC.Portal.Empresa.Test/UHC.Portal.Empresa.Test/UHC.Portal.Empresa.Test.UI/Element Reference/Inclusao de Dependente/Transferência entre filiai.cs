﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Inclusao_de_Dependente
{
    class Transferência_entre_filiai
    {

        public static class Selecioneocontratobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]//following::button[1]";

        }
        public static class Selecioneocontratobtntxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]//following::button[1]//following::input[1]";

        }
        public static class ContratoComboLST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o')]/../div/div/div[2]/div/div/ul/li";
        }
        public static class Beneficiáriobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]";

        }
        public static class Beneficiáriobtntxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]";

        }
        public static class BeneficiárioComboLST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]/../div/div/div[2]/div/div/ul/li";
        }
        public static class NoContractoExists
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";

        }
        public static class Buscarbtn
        {
            public static string Xpath = "//button[text()='Buscar']";

        }
        public static class Datadetransferência
        {
            public static string Xpath = "//input[@name='transferDate']";

        }
        public static class Novocontrato
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo contrato *')]//following::button[1]";

        }
        public static class Novocontratotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo contrato *')]//following::button[1]//following::input[1]";

        }
        public static class Novalotação
        {
            public static string Xpath = "//div//.//label[contains(text(),'Nova lotação')]//following::button[1]";

        }
        public static class Novalotaçãotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Nova lotação')]//following::button[1]//following::input[1]";

        }
        
        public static class Novoplanotitular
        {
            public static string Xpath = "//select[@name='holderPlan']";

        }
        public static class Novoplanodependente
        {
            public static string Xpath = "//select[@name='dependentPlan']";

        }
        public static class Novoplanoagregado
        {
            public static string Xpath = "//select[@name='aggregatePlan']";

        }
        public static class Novamatrícula
        {
            public static string Xpath = "//input[@name='registerCode']";

        }
    }
}

