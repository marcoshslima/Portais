﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Inclusao_de_Dependente
{
    class InclusaodeDependente
    {

        public static class NúmerodoBeneficiário
        {
            public static string Xpath = "//label[text()='Número do Beneficiário titular']/div";

        }

        public static class BeneficiárioTitularcadastro
        {
            public static string Xpath = "//label[text()='Beneficiário titular em processo de cadastro']/div";

        }
        public static class Selecioneocontrato
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]//following::button[1]";

        }
        public static class Selecioneocontratotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]//following::button[1]//following::input[1]";

        }
        public static class SelecioneocontratoCMBLST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]/../div/div/div[2]//ul/li";
        }
        public static class SelecioneoBeneficiário
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]";

        }
        public static class SelecioneoBeneficiáriotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]";

        }
        public static class SelecioneoBeneficiárioCMBLST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]/../div/div/div[2]//ul/li";

        }
        public static class Beneficiáriotitular
        {
            public static string Xpath = "//label[text()='Beneficiário titular em processo de cadastro']/div";
            public static class NomedoTitular
            {
                public static string Xpath = "//input[@name='nomeTitular']";

            }
            public static class Titulargrid
            {
                public static string Xpath = "//div[@class='table-responsive']";

            }

        }
        

        public static class Dadosdodependentegrid
        {
            public static string Xpath = "//h2[text()='Dados do dependente']/../..";
            public static class Cpfbox
            {
                public static string Xpath = "//input[@name='personalData.cpf']";

            }
            public static class Nomebox
            {
                public static string Xpath = "//input[@name='personalData.nome']";

            }
            public static class Datadeinclusao
            {
                public static string Xpath = "//label[text()='Data de inclusão *']/..//div//input";

            }
            public static class Dataderegistro
            {
                public static string Xpath = "//label[text()='Data de registro']/..//div//input";

            }
            public static class Datadenascimentobox
            {
                public static string Xpath = "//label[text()='Data de nascimento *']/..//div[1]//div[1]//input";

            }
            public static class Masculinosexo
            {
                public static string Xpath = "//label[text()='Masculino']";

            }
            public static class Femininosexo
            {
                public static string Xpath = "//label[text()='Feminino']";

            }
            public static class Nomedamãe
            {
                public static string Xpath = "//input[@name='personalData.nomeMae']";

            }
            public static class EstadoCivil
            {
                public static string Xpath = "//select[@name='personalData.estadoCivil']";

            }
            public static class Plano
            {
                public static string Xpath = "//select[@name='personalData.plano']";

            }
            public static class NCódigoMunicípiodoIBGE
            {
                public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]//following::button[1]//following::input[1]";

            }
            public static class ContratoDental
            {
                public static string Xpath = "//select[@name='personalData.contratoDental']";

            }
            public static class PlanoDental
            {
                public static string Xpath = "//select[@name='personalData.planoDental']";

            }
            public static class Dependência
            {
                public static string Xpath = "//select[@name='personalData.dependencia']";

            }
            public static class Datadocasamento
            {
                public static string Xpath = "//label[text()='Data do casamento']/..//div[1]//div[1]//input";

            }
            public static class Matrículafuncional
            {
                public static string Xpath = "//input[@name='personalData.functionalRegister']";

            }
            public static class Sequencial
            {
                public static string Xpath = "//input[@name='personalData.sequencial']";

            }

        }
        public static class Anexo
        {
            public static string Xpath = "//div[@class='alert alert-warning fade show']//section";
            public static class localdebtn
            {
                public static string Xpath = "//input[@name='attachFiles[0].localArquivamento']";

            }
            public static class Procurarbtn
            {
                public static string Xpath = "//button[text()='Procurar']";

            }
            public static class Adicionarbtn
            {
                public static string Xpath = "//button[text()='+ Adicionar']";

            }
            public static class Excluirbtn
            {
                public static string Xpath = "//label[text()='Excluir']/..//div";

            }
            public static class Deletebtn
            {
                public static string Xpath = "//button[text()='-']";

            }

        }
        public static class Campoobrigatorio
        {
            public static string Xpath = "//div[@class='personalData.dataNascimento--feedback invalid-feedback']";

        }
        public static class Alertcfpinvalido
        {
            public static string Xpath = "//p[contains(text(),'CPF inválido')]";

        }
        public static class Salvarbtn
        {
            public static string Xpath = "//button[text()='Salvar']";

        }
        public static class Salvarbtndisabled
        {
            public static string Xpath = "//button[@class='mb-2 btn btn-primary disabled']";

        }
        public static class Limparbtn
        {
            public static string Xpath = "//button[text()='Limpar']";

        }
        public static class Inclusaobtn
        {
            public static string Xpath = "//button[text()='Incluir Dependente']";

        }

        public static class Inclusaopopup
        {
            public static string Xpath = "//h5[text()='Inclusão de Dependente']";
            public static class Popupmsg
            {
                public static string Xpath = "//div[@class='modal-body']//div//i";

            }
            public static class PopupOkbtn
            {
                public static string Xpath = "//button[text()='Ok']";

            }
            public static class Popupclosebtn
            {
                public static string Xpath = "//span[@class='close-modal']";

            }

        }
        public static class CPFinvalid
        {
            public static string Xpath = "//div[@class='alert alert-danger fade show']//section/p";

        }

    }
}
