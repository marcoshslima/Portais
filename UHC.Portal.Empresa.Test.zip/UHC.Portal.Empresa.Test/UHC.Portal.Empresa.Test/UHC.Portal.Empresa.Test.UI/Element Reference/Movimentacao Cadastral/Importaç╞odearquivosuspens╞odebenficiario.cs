﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Importaçãodearquivosuspensãodebenficiario
    {

        #region Text

        public static class ImportarSuspensaoTitle
        {
            public static string Xpath = "//h2[text()='Importação de arquivo suspensão de beneficiário']"; 
        }

        public static class Escolherarquivotext

        {
            public static string Xpath = " //label[text()='Escolher arquivo']";
        }

        public static class ProgramaçãodeprocessamentoText

        {
            public static string Xpath = "//label[text()='Programação de processamento']";
        }

        public static class Fila_de_execução
        {
            public static string Xpath = "//h2[text()='Fila de execução']";
        }

        public static class Filaheader

        {
            public static string Xpath = "//div[@class='card-header']";
        }

        public static class AgedementoText
        {
            public static string XPath = "//div[text()='Agendamento'][1]";
        }


        public static class ProgramacacoError
        {
            public static string Xpath = "//div[text()='Campo obrigatório']";
        }
        public static class Filagrid
        {
            public static string Xpath = "//div[@class='card-header']//following::div[@class='card-body']";
        }

        public static class UploadErrortext
        {
            public static string Xpath = "//span[text()='O tipo de arquivo deve ser .csv ou .txt']";
        }
        #endregion

        #region Button

        public static class  ProcurarButton

        {
            public static string Xpath = "//button[text()='Procurar']";
        }

        public static class ExecutorButton

        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class CalendarButton
        {
            public static string Xpath = "//div[@class='datepicker__input']";
        }
        public static class CalnederDays
        {
            public static string Xpath = "//button[@class='react-calendar__tile react-calendar__month-view__days__day']";
        }

        public static class ChevronCollapse

        {
            public static string Xpath = "//span[@class='details-desktop icon icon-chevron-down']";
        }
        #endregion



        #region Textbox

        public static class Time

        {
            public static String Name = "time";
        }

        public static class DateTextbox

        {
            public static string Xpath = "//label[text()='Programação de processamento']//following::input[@id='date']";
        }

        public static class TimeTextbox
        {
            public static string Xpath = "//label[text()='Programação de processamento']//following::input[@id='time']";
        }
        public static class CalendarTextbox

        {
            public static string Xpath = "//input[@title='Selecionar Data']";
        }
        #endregion

    }
}
