﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Movimentacao_Cadastral
{
    class CancelarExclusaoDeBeneficiario
    {
        public static class CancelarExclusaoDeBenf
        {
            public static string Xpath = "//h1[text()='Cancelar exclusão de beneficiário']";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioComboBox
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[1]/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//ul/li";
        }
        public static class BenefNaoEncontrado
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class SituacaoExcluido
        {
            public static string Xpath = "//label[text()='Situação']/../strong/p[text()='EXCLUIDO']";
        }
        public static class BenefNaoEstaExcludoMsg
        {
            public static string Xpath = "//section[@class='alert__message ']/p[text()='Beneficiário não está excluído e não possui data de exclusão futura. Cancelamento de exclusão não permitido.']";
        }
        public static class Operadora
        {
            public static string Xpath = "//label[text()='Operadora']";
        }
        public static class BeneficiarioTitular
        {
            public static string Xpath = "//label[text()='Beneficiário titular']";
        }
        public static class LinhaDeProduto
        {
            public static string Xpath = "//label[text()='Linha de Produto']";
        }
        public static class Filial
        {
            public static string Xpath = "//label[text()='Filial']";
        }
        public static class Tipo
        {
            public static string Xpath = "//label[text()='Tipo']";
        }
        public static class Contrato
        {
            public static string Xpath = "//label[text()='Contrato']";
        }
        public static class Unidade
        {
            public static string Xpath = "//label[text()='Unidade']";
        }
	    public static class TipoDeProduto
        {
            public static string Xpath = "//label[text()='Tipo de Produto']";
        }
        public static class Plano
        {
            public static string Xpath = "//label[text()='Plano']";
        }
        public static class Situacao
        {
            public static string Xpath = "//label[text()='Situação']";
        }
        public static class DataDeInclusao
        {
            public static string Xpath = "//label[text()='Data de inclusão']";
        }
        public static class MotivoDaExclusao
        {
            public static string Xpath = "//label[text()='Motivo da exclusão']";
        }
	    public static class Observacoes
        {
            public static string Xpath = "//label[text()='Observações']";
        }
        public static class RegistradaEm
        {
            public static string Xpath = "//label[text()='Registrada em']";
        }
        public static class Por
        {
            public static string Xpath = "//label[text()='Por']";
        }
    }
}
