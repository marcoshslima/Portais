﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Movimentacao_Cadastral
{
    class SuspensaoDeBeneficiarios
    {
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioComboBox
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[1]/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//input";
        }
         public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//ul/li";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }        
        public static class DataDeInicioDaSuspensaoHeading
        {
            public static string Xpath = "//label[text()='Data de Início da Suspensão *']";
        }
        public static class DataDeInicioDaSuspensao
        {
            public static string Xpath = "//label[text()='Data de Início da Suspensão *']/../div//input";
        }
        public static class ContratoTextValue
        {
            public static string Xpath = "//label[text()='Contrato']/../strong/p";
        }        
        public static class MotivoDeSuspensaoCombo
        {
            public static string Xpath = "//label[text()='Motivo da Suspensão *']/../div/div/div/div/div";
        }
        public static class MotivoDeSuspensaoComboBtn
        {
            public static string Xpath = "//label[text()='Motivo da Suspensão *']/../div/div/div/div/span/button";
        }
        public static class MotivoDeSuspensaoComboTxt
        {
            public static string Xpath = "//label[text()='Motivo da Suspensão *']/../div/div/div/div[2]//input";
        }
        public static class MotivoDeSuspensaoComboLst
        {
            public static string Xpath = "//label[text()='Motivo da Suspensão *']/../div/div/div/div[2]//ul/li";
        }
        public static class Observacao
        {
            public static string Xpath = "//label[text()='Observação *']/../div/div/textarea";
        }
        public static class BenefNaoEncontrado
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
        public static class ContractNenhumResultado
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }
        public static class BenefNaoTitular
        {
            public static string Xpath = "//p[text()='Beneficiário não é titular.']";
        }
        
    }
}
