﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Movimentacao_Cadastral
{
    class ConsultarSituaçãoda
    {

        #region text
        public static class TexTela
        {
            public static string Xpath = "//*[text()='Tela']";
        }

        public static class NaoHistaricaoText

        {
            public static string Xpath = "//td[text()='Não há histórico.']";
        }

        public static class TipodeOperacao
        {
            public static string Xpath = "//label[text()='Tipo de operação']//following::div[@class='rw-input rw-dropdown-list-input']";
        }

        public static class TipodeOperacaoText
        {
            public static string Xpath = "//input[@class='rw-input-reset']";
        }

        public static class AlteracaoDropDown

        {
            public static string Xpath = "//li[text()='Alteração de Cadastro']";
        }

        public static class Exclusao
        {

            public static string Xpath = "//li[text()='Exclusão']";
        }


        public static class ExcluirScreen
            {
            public static string Xpath = "//h1[text()='Excluir beneficiário']";
            }
        public static class Inclusodetitulartext
        {
            public static string Xpath = "//h1[text()='Inclusão de titular']";
        }


        public static class ConsultarSceeentext

        {
            public static string Xpath = "//h1[text()='Consultar situação da movimentação']";
        }
        public static class Movimentacao
        {
            public static string Xpath = "//*[text()='Movimentação']";
        }

        public static class Fila_de_execução
        {
            public static string Xpath = "//h2[text()='Fila de execução']";
        }


        public static class Relatorio
        {
            public static string Xpath = "//*[text()= 'Relatório 56040717']";
        }



        public static class InculsaodeText
        {
            public static string Xpath = "//h1[text()='Inclusão de titular']";
        }


        public static class HistoricaoText
        {
            public static string Xpath = "//h2[text()='Histórico de movimentação']";
        }

        public static class Nometext

        {
            public static string Xpath = "//div[text()='Nome']";
        }


        public static class Nomegridtext
        {
            public static string Xpath = "//th[text()='Nome']";
        }

        public static class Numerogridtext
        {
            public static string Xpath = "//th[text()='Número']";
        }
        public static class DataFinalText

        {
            public static string Xpath = "//*[text()='Data final inválida']";
        }


        public static class Lotetextbox
        {

            public static string Xpath = "[name =numLote]";
        }

        public static class Errormessage

        {
            public static string Xpath = "//p[text() ='Nenhuma informação encontrada com os parâmetros informados.']";
        }

        public static class Invalidcontrato

        {
            public static string Xpath = "//*[text()='Nenhum resultado encontrado']";
        }

        public static class Processo
        {
            public static string Xpath = "//p[text()='Processo:']";
        }
        public static class Dataincialerror
        {
            public static string Xpath = "//div[text()='Data inicial inválida']";
        }

       

        public static class DeclarcaoTextScreen
        {
            public static string Xpath = "//h1[text()='Declaração de permanência']";
        }
        #endregion
        #region Button

        public static class Continuar
        {
            public static string Xpath = "//button[text()='Continuar']";
        }


        public static class CollapseButton
        {
            public static string Xpath = "//span[@class='details-desktop icon icon-chevron-down']";
        }

        public static class TransferênciaText

        {
            public static string Xpath = "//h1[text()='Transferência de contrato (COM MUDANÇA Nº BENEF)']";
        }
        public static class SalvarButton
        {
            public static string Xpath = "//button[text()='Salvar']";
        }

        public static class AlterarButton
        {
            public static string Xpath = "//button[text()='Salvar']";
        }

        public static class EXcluirButton
        {
            public static string Xpath = "//button[text()='Excluir']";
        }
        public static class NomeOrdernacao
        {
            public static string Xpath = "//label[text() ='Nome']";
        }
        public static class Filatable
        {
            public static string Xpath = "//div[@class='expansive-table']";
        }

        public static class Consultarfiladeexecução
        {
            public static string Xpath = "//button[@class='mb-2 btn btn-secondary']";
        }

        public static class FiladeExecuacobutton

        {
            public static string Xpath = "//button[text()='Consultar fila de execução']";

        }

        public static class ExhbirFilabutton
        {
            public static string Xpath = "//button[text()='Exibir Fila de Execução']";

        }


        public static class FilaRefresh
        {
            public static string Xpath = "//*[text()='Período:']//following::input[@title='Selecionar Data']//following::button[@class='mb-2 btn btn-primary']";
        }
        public static class Delimitador

        {
            public static string Xpath = "//button[text() ='Arquivo texto com Delimitador (#)']";
        }
        #endregion
        #region Dropdown

        public static class TipoOperacaodropdown
        {
            public static string Xpath = "//div//.//*[text()='Tipo de operação']//following::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox '][1]";
        }

        public static class Situaçãodropdown
        {
            public static string Xpath = "//div//.//*[text()='Situação']//following::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox '][1]";
        }

        public static class Dateinicial
        {
            public static string Xpath = "//div[@class='datepicker__input'][1]";
        }


        public static class ContratoTextbox           
         {
            public static string Xpath = "//input[@class='rw-input-reset']";
           }

        public static class GrupoContrato_Contrato
        {
            public static string Xpath = "//div[@class='rw-widget-input rw-widget-picker rw-widget-container']";

        }
        public static class GrupoContratoRowlist

        {
            public static string Xpath = "//*[@class='rw-list-option']";
        }

        public  static class ExclurirChangeDate

        {
            public static string Xpath = "//label[text()='Motivo da exclusão *']";
        }


        public static class Benefeciario
         {
            public static string Xpath = "//div[text()='Selecione o beneficiário']//div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
         }

        public static class BenefeciarioTextbox
        {
            public static string Xpath = "//div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox dropdownList--error']//following::input[@class='rw-input-reset']";
        }
        public static class DataInicial
        {
            public static string Xpath = "//*[text()='Período:']//following::input[@title='Selecionar Data']";
        }

        public static class DataFinal
        {
            public static string Xpath = "//span[text()='a']/following-sibling::div//input[@title='Selecionar Data']";
        }
        #endregion

        #region Radiobutton
        public static class Errorsradio

        {
            public static string Xpath = "//*[text() ='Tipo Inconsistência']//following::*[text()='Erros']";
        }

        public static class Alertsradio
        {
            public static string Xpath = "//*[text() ='Tipo Inconsistência']//following::*[text()='Alertas']";
        }

        public static class SemInconsistências
        {
            public static string Xpath = " //*[text() ='Tipo Inconsistência']//following::*[text()='Sem Inconsistências']";
        }

        public static class Pendenteenvioparaoperadora
        {
            public static string Xpath = "//*[text() ='Situação Movimentação']//following::*[text()='Pendente envio para operadora']";
        }
        public static class Enviadoparaoperadora
        {
            public static string Xpath = "//*[text() ='Situação Movimentação']//following::*[text()='Enviado para operadora']";
        }
       

        #endregion

        #region GridLink
        public static class DependenteLink
        {
            public static string Xpath = "//td[text()='Inclusão de Dependente'][1] //following::td[text()='Validado e Pendente de Envio'] //following::span[@class='icon icon-pencil']";
        }

        public static class AlteraçãodeCadastroLink
        {
            public static string Xpath = "//td[text()='Alteração de Cadastro'][1]//following::span[@class='icon icon-pencil']";
        }

        public static class ExclusaoLink
        {
            public static string Xpath = "//td[text()='Exclusão'][1]//following::span[@class='icon icon-pencil']";
        }

        public static class MovementacaoGrid

        {
            public static string Xpath = "//div[@class='result card']";
        }

        public static class AlteracaoScreen
        {
            public static string Xpath = "//h1[text()='Alteração cadastral']";
        }

        public static class InclusaoDeTitularLink

        {
            public static string Xpath = "//td[text()='Inclusão de Titular'][1] //following::td[text()='Pendente de Validação'] //following::span[@class='icon icon-pencil']";
        }
        #endregion
    }
}
