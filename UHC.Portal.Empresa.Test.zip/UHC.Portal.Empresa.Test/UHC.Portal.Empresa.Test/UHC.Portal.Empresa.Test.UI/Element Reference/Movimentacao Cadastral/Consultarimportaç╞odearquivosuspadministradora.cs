﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Consultarimportaçãodearquivosuspadministradora
    {
        public static class PageTitle
        {
            public static string Xpath = "//h1[text()='Consultar importação de arquivo susp. administradora']";
        }
        public static class ContratoLabel
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']";
        }
        public static class AteLabel
        {
            public static string Xpath = "//label[text()='Até *']";
        }
        public static class PeríododeenvioLabel
        {
            public static string Xpath = "//label[text()='Período de envio *']";
        }
        public static class SelecioneoGrupoContratoORContrato
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
        }
        public static class Selectcontract
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class EnterGrupoContratoORContrato
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class SelectedContract
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneocontratoComBox_TXT
        {
            //public static string Xpath = "//input[@class='rw-input-reset']";
            public static string Xpath = "//div//.//label[contains(text(),'Contrato / Grupo Contrato *')]//following::button[1]//following::input[1]";
        }
        public static class PeríododeenvioData
        {
            public static string Xpath = "//label[text()='Período de envio *']//following::button[1]";
        }
        public static class AteData
        {
            public static string Xpath = "//label[text()='Até *']//following::button[1]";
        }
        public static class PeríododeenvioInput
        {
            public static string Xpath = "//label[text()='Período de envio *']//following::input[1]";
        }
        public static class AteInput
        {
            public static string Xpath = "//label[text()='Até *']//following::input[1]";
        }
        public static class BuscarButton
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class Período1Data
        {
            public static string Xpath = "//div[text()='Período1:']//following::button[1]";
        }
        public static class AData
        {
            public static string Xpath = "//span[text()='a']//following::button[1]";
        }
        public static class Período1Input
        {
            public static string Xpath = "//div[text()='Período1:']//following::input[1]";
        }
        public static class AInput
        {
            public static string Xpath = "//span[text()='a']//following::input[1]";
        }
        public static class AtualizarButton
        {
            public static string Xpath = "//button[text()='Atualizar']";
        }
        public static class Collapse
        {
            public static string Xpath = "//b[text()='V']";
        }
        public static class NomedoArquivo
        {
            public static string Xpath = "//span[contains(text(),'.txt')]";
        }
        public static class QtdSuspensão
        {
            public static string Xpath = "//div[text()='Qtd. Suspensão']";
        }
        public static class Enviados
        {
            public static string Xpath = "//b[text()='Enviados:']";
        }
        public static class Aceitos
        {
            public static string Xpath = "//b[text()='Aceitos:']";
        }
        public static class Recusados
        {
            public static string Xpath = "//b[text()=' Recusados:']";
        }
        public static class QtdCancelamento
        {
            public static string Xpath = "//div[text()='Qtd. Cancelamento']";
        }
        public static class TipodeRelatório
        {
            public static string Xpath = "//div[text()='Tipo de Relatório']";
        }
        public static class Processados
        {
            public static string Xpath = "//div[text()='Processados:']";
        }
        public static class Erros
        {
            public static string Xpath = "//div[text()='Erros:']";
        }
        public static class PDF
        {
            public static string Xpath = "//span[text()='PDF']";
        }
        public static class Texto
        {
            public static string Xpath = "//span[text()='Texto']";
        }
        public static class CalendarofPeríododeenvio
        {
            public static string Xpath = "//label[text()='Período de envio *']//following-sibling::div[@class='date-time-picker test_ipt_suspendedbeneficiarieslist_from_date  rw-datetime-picker rw-widget rw-state-focus rw-open']/div[2]/div/div";
        }
        public static class CalendarofAté
        {
            public static string Xpath = "//label[text()='Até *']//following-sibling::div[@class='date-time-picker test_ipt_suspendedbeneficiarieslist_to_date  rw-datetime-picker rw-widget rw-state-focus rw-open']/div[2]/div/div";
        }
        public static class ProcessoLabel
        {
            public static string Xpath = "//p[text()='Processo:']";
        }
        public static class ProcessoDescription
        {
            public static string Xpath = "//p[text()='Importação de Arquivos de Beneficiários Suspensos pela Administradora']";
        }
        public static class PageTitle_Buscar
        {
            public static string Xpath = "//h2[text()='Importação de arquivo suspensão de beneficiário']";
        }
        public static class Período1Label
        {
            public static string Xpath = "//div[text()='Período1:']";
        }
        public static class A
        {
            public static string Xpath = "//span[text()='a']";
        }
        public static class Accordionheader
        {
            public static string Xpath = "//div[@class='accordion-header']";
        }
    }
}
