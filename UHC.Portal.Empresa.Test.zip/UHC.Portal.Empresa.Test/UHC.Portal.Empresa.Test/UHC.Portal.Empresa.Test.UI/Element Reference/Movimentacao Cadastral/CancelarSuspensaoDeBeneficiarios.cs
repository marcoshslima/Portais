﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Movimentacao_Cadastral
{
    class CancelarSuspensaoDeBeneficiarios
    {
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioComboBox
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[1]/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/../div/div/div/div[2]//ul/li";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class BenefNaoMsg
        {
            public static string Xpath = "//p[text()='Beneficiário não possui suspensão ativa para cancelamento']";
        }
    }
}
