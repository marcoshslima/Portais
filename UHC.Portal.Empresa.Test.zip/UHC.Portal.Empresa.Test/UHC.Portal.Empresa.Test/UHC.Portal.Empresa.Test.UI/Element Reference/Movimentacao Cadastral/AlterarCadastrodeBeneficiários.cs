﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class AlterarCadastrodeBeneficiários
    {
        public static class Selecioneocontrato_CMBBOX
        {
            public static string Xpath = "//label[text()='contrato *']/parent::div/div";
        }
        public static class Selecioneocontrato_CMBLST
        {
            public static string Xpath = "//label[text()='contrato *']/../div//following::ul/li";
        }
        public static class Selecioneocontrato_Value
        {
            public static string Xpath = "//label[text()='contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneocontratoComBox_TXT
        {
            //public static string Xpath = "//input[@class='rw-input-reset']";
            public static string Xpath = "//div//.//label[text()='contrato *']//following::button[1]//following::input[1]";
        }
        public static class BeneficiarioComBox_BTN
        {
            // public static string Xpath = "//input[@name='beneficiary']//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]";
        }
        public static class BeneficiarioComBox_TXT
        {
            //public static string Xpath = "//input[@placeholder='Digite o CPF (com pontuação), nome ou marca ótica.']";
            public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]";
        }

        public static class BenefeciarioErrorText

        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }

        public static class CPF

        {
            public static string Name = "personalData.cpf";
        }

        public static class IncluriButton
        {
            public static string Xpath = "//button[text()='Incluir']";
        }

        public static class Popupok

        {
            public static string Xpath = "//*[text()='Operação realizada com sucesso. Após concluir todo o processo de movimentação cadastral, clicar no Menu Lateral e selecionar a opção Enviar Movimentação para a Operadora.']";
        }


        public static class Alterartext

        {
            public static string Xpath = "//h5[text()='Alteração Cadastral']";
        }

        public static class AlterarAlertError
        {
            public static string Xpath = "//*[text()='Beneficiário informado já está em processo de Alteração Cadastral. Utilize a função Consulta Situação da Movimentação para alterar este beneficiário.']";
        }

        public static class CPFError

        {
            public static string Xpath = "//div[text()='Informe um CPF válido']";

        }

        public static class DadosText
        {

            public static string Xpath = "//div[text()='Dados do titular']";
        }
        public static class AlterarPopuptext

        {
            public static string Xpath = "//div[text()='Existem campos de preenchimento obrigatório que não foram preenchidos']";
        }

        public static class Datadenascimento
        {
            public static string Xpath = "//label[text()='Data de Nascimento']";
        }

        public static class Bairrotextbox
        {
            public static string Xpath = "//input[@class='test_input_nhood  form-control']";
        }
        public static class SelecioneoBeneficario_Value
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']/div";
        }
        public static class SelecioneoBeneficario_CMBLST
        {
            public static string Xpath = "//label[text()='Beneficiário *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }

        public static class SelecioneoCódigoMunicípiodoIBGE_CMBBOX
        {
            public static string Xpath = "//label[text()='Código Município do IBGE']/parent::div/div";
        }
        public static class SelecioneoCódigoMunicípiodoIBGE_CMBLST
        {
            public static string Xpath = "//label[text()='Código Município do IBGE']/../div//ul/li";
        }
        public static class SelecioneoCódigoMunicípiodoIBGE_Value
        {
            public static string Xpath = "//label[text()='Código Município do IBGE']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoCódigoMunicípiodoIBGEComBox_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Código Município do IBGE')]//following::button[1]//following::input[1]";
        }

        public static class SelecioneoCBO_CMBBOX
        {
            public static string Xpath = "//label[text()='CBO']/parent::div/div";
        }
        public static class SelecioneoCBO_CMBLST
        {
            public static string Xpath = "//label[text()='CBO']/../div//ul/li";
        }
        public static class SelecioneoCBO_Value
        {
            public static string Xpath = "//label[text()='CBO']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoCBO_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'CBO')]//following::button[1]//following::input[1]";
        }

        public static class SelecioneoBanco_CMBBOX
        {
            public static string Xpath = "//label[text()='Banco']/parent::div/div";
        }
        public static class SelecioneoBanco_CMBLST
        {
            public static string Xpath = "//label[text()='Banco']/../div//ul/li";
        }
        public static class SelecioneoBanco_Value
        {
            public static string Xpath = "//label[text()='Banco']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoBanco_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Banco')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoUnidadeOrganizacional_CMBBOX
        {
            public static string Xpath = "//label[text()='Unidade Organizacional *']/parent::div/div";
        }
        public static class SelecioneoUnidadeOrganizacional_CMBLST
        {
            public static string Xpath = "//label[text()='Unidade Organizacional *']/../div//ul/li";
        }
        public static class SelecioneoUnidadeOrganizacional_Value
        {
            public static string Xpath = "//label[text()='Unidade Organizacional *']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoUnidadeOrganizacional_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional *')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoARH_CMBBOX
        {
            public static string Xpath = "//label[text()='ARH *']/parent::div/div";
        }
        public static class SelecioneoARH_CMBLST
        {
            public static string Xpath = "//label[text()='ARH *']/../div//ul/li";
        }
        public static class SelecioneoARH_Value
        {
            public static string Xpath = "//label[text()='ARH *']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoARH_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'ARH *')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoLotação_CMBBOX
        {
            public static string Xpath = "//label[text()='Lotação']/parent::div/div";
        }
        public static class SelecioneoLotação_CMBLST
        {
            public static string Xpath = "//label[text()='Lotação']/../div//ul/li";
        }
        public static class SelecioneoLotação_Value
        {
            public static string Xpath = "//label[text()='Lotação']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoLotação_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Lotação')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoCentrodecusto_CMBBOX
        {
            public static string Xpath = "//label[text()='Centro de custo']/parent::div/div";
        }
        public static class SelecioneoCentrodecusto_CMBLST
        {
            public static string Xpath = "//label[text()='Centro de custo']/../div//ul/li";
        }
        public static class SelecioneoCentrodecusto_Value
        {
            public static string Xpath = "//label[text()='Centro de custo']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoCentrodecusto_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Centro de custo')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoStatus_CMBBOX
        {
            public static string Xpath = "//label[text()='Status *']/parent::div/div";
        }
        public static class SelecioneoStatus_CMBLST
        {
            public static string Xpath = "//label[text()='Status *']/../div//ul/li";
        }
        public static class SelecioneoStatus_Value
        {
            public static string Xpath = "//label[text()='Status *']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoStatus_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Status *')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoEmpresa_CMBBOX
        {
            public static string Xpath = "//label[text()='Empresa *']/parent::div/div";
        }
        public static class SelecioneoEmpresa_CMBLST
        {
            public static string Xpath = "//label[text()='Empresa *']/../div//ul/li";
        }
        public static class SelecioneoEmpresa_Value
        {
            public static string Xpath = "//label[text()='Empresa *']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoEmpresa_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Empresa *')]//following::button[1]//following::input[1]";
        }
        public static class SelecioneoPSA_CMBBOX
        {
            public static string Xpath = "//label[text()='PSA']/parent::div/div";
        }
        public static class SelecioneoPSA_CMBLST
        {
            public static string Xpath = "//label[text()='PSA']/../div//ul/li";
        }
        public static class SelecioneoPSA_Value
        {
            public static string Xpath = "//label[text()='PSA']/..//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class SelecioneoPSA_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]//following::input[1]";
        }
    }
}
