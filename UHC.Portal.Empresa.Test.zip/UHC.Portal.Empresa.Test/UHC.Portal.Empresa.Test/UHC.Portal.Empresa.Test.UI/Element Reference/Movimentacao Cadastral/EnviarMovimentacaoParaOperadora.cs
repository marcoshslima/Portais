﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class EnviarMovimentacaoParaOperadora
    {
        #region Titulo
        public static class TltEmpresa
        {
            public static string Xpath = "//div[@class='col-lg-10']//span[text()='Página inicial']";
        }

        public static class TltEnviarMovOperadora
        {
            public static string Xpath = "//h1[@class='page-title'][text()='Enviar movimentação para operadora']";
        }

        #endregion

        #region Textbox
        public static class EmailText
        {
            public static string Xpath = "//input[@class='test_input_email  form-control']";
        }


        public static class Dadostext
        {

            public static string Xpath = "//h3[text()='Dados Contato:']";
        }

        public static class Errortext
        {
            public static string Xpath = "//p[text()='Não existe movimentação para fechar um lote.']";


        }

        public static class ResumoErrortext1

        {
            public static string Xpath = "//p[text()='Existe(m) 3 registro(s) referente(s) a Movimentações Anteriores que não foram enviados em nenhum lote.']";
        }
        public static class ResumoErrortext2

        {
            public static string Xpath = "//p[text()='Para que sua movimentação seja enviada para operadora, é necessário que esse(s) 3 registro(s) seja(m) corrigido(s), após correção, alterar o campo mês de referência e enviar para operadora.']";
        }

        public static class ResumoErrortext3

        {
            public static string Xpath = "//p[text()='Verificar em consulta situação da movimentação.']";
        }
       

        public static class ProtocoloScreen
        {
            public static string Xpath = "//h2[text()='Protocolo de envio de movimentação cadastral']";
        }


        public static class LoteFechadotext
        {
            public static string Xpath = "//p[text() = 'Lote fechado com sucesso']";
        }
        public static class Invalidemailtext

        {
            public static string Xpath = "//div[text()='Informe um e-mail válido']";
        }
        #endregion

        #region Campos
        public static class CampoGrupoContrato
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
            //Campo input habilitado após abrir a lista
            public static string Xpath1 = "//input[@class='rw-input-reset']";
        }
        #endregion

        #region ListBox
        public static class ListGrupoContrato
        {
            public static string Xpath = "//ul[@id='rw_8_listbox'][@class='rw-list']";

            public static string Option(string option)
            {
                return Xpath = "//li[text()='" + option + "']";
            }
        }
        #endregion

        #region Button
        public static class ContinuarButton
        {
            public static string Xpath = "//button[text()='Continuar']";
        }

        public  static class ExecutarButton
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        #endregion

        #region Grid

        public static class Movemovimentaçãogrid
        {
            public static string Xpath = "//div[@class='table-responsive']";
        }

        #endregion
        #region Mensagem
        public static class MsgNenhumResultadoEncontrado
        {
            public static string Xpath = "//li[@class='rw-list-empty'][text()='Nenhum resultado encontrado']";
        }
        #endregion
    }
}
