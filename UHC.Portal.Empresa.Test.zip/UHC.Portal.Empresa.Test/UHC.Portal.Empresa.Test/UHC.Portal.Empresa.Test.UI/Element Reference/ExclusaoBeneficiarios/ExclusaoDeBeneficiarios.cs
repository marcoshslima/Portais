﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.ExclusaoBeneficiarios
{
    class ExclusaoDeBeneficiarios
    {
        public static class ExcluirBeneficario
        {
            public static string Xpath = "//h1[text()='Excluir beneficiário']";
        }
        public static class Information
        {
            public static string Xpath = "//h2[text()='Informações']";
        }
        #region Combobox
        public static class ContratoComboBox
        {
            //public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class ContratoComboBox_BTN
        {
            //public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//following::span[1]/button";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboBox_TextBox
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]/div/div/ul/li";
        }
        public static class BeneficiarioComboBox
        {
            //public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div/div";
        }
        public static class BeneficiarioComboBox_BTN
        {
            //public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//following::span[@class='rw-select']/button";
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div/span/button";

        }
        public static class BeneficiarioComboBox_TextBox
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/div/input";
        }
        public static class BeneficiarioComboBox_LST
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/ul/li";
        }
        public static class ExclusaoProgramada
        {
            public static string Xpath = "//label[text()='Exclusão imediata']/..//following::label[text()='Exclusão programada']";
        }
        public static class ExclusaoRN412
        {
            public static string Xpath = "//label[text()='Exclusão imediata']/..//following::label[text()='Exclusão RN412']";
        }
        public static class MotivoDaExclusao
        {
            public static string Xpath = "//label[text()='Motivo da exclusão *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class MotivoDaExclusao_BTN
        {
            public static string Xpath = "//label[text()='Motivo da exclusão *']/..//following::button[@class='rw-btn rw-btn-select']";
        }
        public static class MotivoDaExclusao_TextBox
        {
            public static string Xpath = "//label[text()='Motivo da exclusão *']/..//following::div[@role='combobox']/div[2]//input";
        }
        public static class MotivoDaExclusao_LST
        {
            public static string Xpath = "//label[text()='Motivo da exclusão *']/..//following::div[@role='combobox']/div[2]//ul/li";
        }
        public static class ExcluirPopup
        {
            public static string Xpath = "//h5[text()='Excluir Beneficiários']";
        }
        public static class ExcluirOkButton
        {
            public static string Xpath = "//button[text()='Ok']";
        }
        public static class GroupoContrato_ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class GroupoContrato_ContratoCombo_BTN
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']/span/button";
        }
        public static class GroupoContrato_ContratoCombo_LST
        {
            public static string Xpath = "//label[text()='Selecione o Grupo Contrato/Contrato:']/..//following::div[@id='rw_9_input']/div[2]//ul/li";
        }
        public static class GroupoContrato_ContinueBTN
        {
            public static string Xpath = "//button[text()='Continuar']";
        }
        public static class TipoOperacao
        {
            public static string Xpath = "//th[text()='Tipo Operação']";
        }
        public static class Quantidade
        {
            public static string Xpath = "//th[text()='Quantidade']";
        }
        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class ExcluirSucessMessage
        {
            public static string Xpath = " //p[text()='Lote fechado com sucesso']";
        }
        public static class ExcluirProtocolo
        {
            public static string Xpath = "//p[contains(text(),'Fechamento de protocolo Automático nº')]";
        }
        #endregion


        public static class Informacao_BeneficarioHolder
        {
            public static string Xpath = "//label[text()='Beneficiário Titular']/../strong/span";
        }
        public static class Informacao_Contrato
        {
            public static string Xpath = "//label[text()='Contrato']/../strong/span";
        }

        public static class RemoveAdicionar
        {
            public static string Xpath = "//button[text()='-']";
        }
        public static class Adicionar
        {
            public static string Xpath = "//button[text()='+ Adicionar']";
        }
        public static class ProcurarFirst
        {
            public static string Xpath = "//label[@for='attachFiles[0].nomeArquivoAnexo']/..//button[1]";
        }
        public static class ProcurarSecond
        {
            public static string Xpath = "//label[@for='attachFiles[1].nomeArquivoAnexo']/..//button[1]";
        }

        public static class DescricaoFirst
        {
            public static string Xpath = "//label[text()='Descrição']/..//textarea[@name='attachFiles[0].descricao']";
        }
        public static class DescricaoSecond
        {
            public static string Xpath = "//label[text()='Descrição']/..//textarea[@name='attachFiles[1].descricao']";
        }
        public static class LocalDeArquivamento_TxtBox_First
        {
            public static string Xpath = "//label[@for='attachFiles[0].localArquivamento']/..//input";
        }
        public static class LocalDeArquivamento_TxtBox_Second
        {
            public static string Xpath = "//label[@for='attachFiles[1].localArquivamento']/..//input";
        }
        public static class DataDeExclusao
        {
            public static string Xpath = "//label[text()='Data de exclusão *']/..//following::div[@class='datepicker__input']/input";
        }        
        public static class Salvar
        {
            public static string Xpath = "//button[text()='Salvar']";
        }
        public static class Contributario
        {
            public static string Xpath = "//label[text()='Contributário']";
        }
        public static class ContributarioNao
        {
            public static string Xpath = "//label[text()='Não']";
        }
        public static class ContributarioSim
        {
            public static string Xpath = "//label[text()='Sim']";
        }
        public static class Contatos
        {
            public static string Xpath = "//h2[text()='Contatos']";
        }
        public static class EmailTextBox
        {
            public static string Xpath = "//label[text()='E-mail *']/..//input";
        }
        public static class EnviarDeEmailSim
        {
            public static string Xpath = "//label[text()='Envio de E-mail *']/..//label[text()='Sim']";
        }
        public static class EnviarDeEmailNao
        {
            public static string Xpath = "//label[text()='Envio de E-mail *']/..//label[text()='Não']";
        }
        public static class DeleteEmailButton
        {
            public static string Xpath = "//div[@class='delete-beneficiary-email--margin row']/div[3]//button[text()='-']";
        }
        public static class AdicionrEmailButton
        {
            public static string Xpath = "//h1[text()='Excluir beneficiário']/..//form[1]/div[4]//button[text()='+ Adicionar']";
        }
        #region Message
        public static class SucessMessageExclusionTitular
        {
            public static string Xpath = "//h5[text()='Excluir Beneficiários']/../../div[2]";
        }
        public static class InvalidEmailMessage
        {
            public static string Xpath = "//div[text()='Informe um e-mail válido']";
        }
        public static class BeneficiarioExcludedMessage
        {
            public static string Xpath = "//p[text()='Beneficiário não está ativo. Exclusão não permitida.']";
        }
        public static class BeneficiarioCampoObrigatorio
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class ContratoCampoObrigatorio
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class DataDeTransferênciaCampoObrigatorio
        {
            public static string Xpath = "//label[text()='Data de Transferência *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class NovoContratoCampoObrigatorio
        {
            public static string Xpath = "//label[text()='Novo contrato *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class NovoPlanoDoTitularCampoObrigatorio
        {
            public static string Xpath = "//label[text()='Novo Plano do Titular *']/..//following::div[text()='Campo obrigatório']";
        }
        #endregion

        }
}

