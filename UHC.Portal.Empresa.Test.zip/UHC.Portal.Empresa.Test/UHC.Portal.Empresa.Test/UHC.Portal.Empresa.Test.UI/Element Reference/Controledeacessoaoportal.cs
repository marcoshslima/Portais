﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Controledeacessoaoportal
    {


        #region Controle de acesso ao portal
        public static class Acessolink
        {
            //public static string LinkText = "#/controle-acesso-ao-portal";
            public static string Xpath = "//a[text()='Controle de Acesso ao Portal']";
           
        }
        public static class Controletablevalues
        {

            public static string Xpath = "//table[@class='custom-table table undefined table']/tbody/tr";
        }
        public static class Acaoicone
        {

            public static string Xpath = "(//span[@class='details-desktop icon icon-pencil'])[1]";
        }
        public static class Dadostable
        {

            public static string Xpath = "(//div[@class='custom-expansive-table-details'])[1]";
            public static class Nomeedit
            {

                public static string Xpath = "(//div[@class='col-lg-8 col-xl-6']/div[2]/div[1]/div[1]/input[1])[1]";
            }
        }
        public static class Xicone
        {

            public static string Xpath = "(//span[@class='details-desktop icon icon-cross'])[1]";

        }
        public static class XPopup
        {
            public static string Xpath = "//div[@class='modal-content']";
            public static class Popupmsg
            {

                public static string Xpath = "//div[text()='Você deseja excluir este Administrador?']";
            }
            public static class Simbtn
            {

                public static string Xpath = "//button[text()='Sim']";
                public static class Simpopup
                {

                    public static string Xpath = "//div[text()='Operação realizada com sucesso.']";
                }
                public static class Simokbtn
                {

                    public static string Xpath = "//button[text()='Ok']";
                }
                
            }
            public static class Naobtn
            {

                public static string Xpath = "//button[text()='Não']";
            }
            public static class Fechar
            {

                public static string Xpath = "//span[@class='close-modal']";
            }
        }
        public static class Dateofexclusao
        {

            public static string Xpath = "//th[text()='Data de exclusão']";
        }
        public static class Adicionarlink
        {

            public static string LinkText = " Adicionar novo Administrador";
        }
        public static class Dadoslink
        {

            public static string Xpath = "//label[text()='Código/Senha Primeiro Acesso:']";
        }
        public static class Dadosstatus
        {

            public static string Xpath = "//span[text()=' Automático']";
        }
        public static class Nome
        {

            public static string Xpath = "//input[@name='name']";
        }
        public static class Email
        {

            public static string Xpath = "//input[@name='email']";
        }
        public static class Telefone
        {

            public static string Xpath = "//input[@name='phone']";
        }
        //check box
        public static class PerfilTable
        {

            public static string Xpath = "//h4[text()='Perfil']";
        }
        public static class Perfil0
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[1]/label[1]/div[1])[1]";
        }
        public static class Perfil1
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[2]/label[1]/div[1])[1]";
        }
        public static class Perfil2
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[3]/label[1]/div[1])[1]";
        }
        public static class Perfil3
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[4]/label[1]/div[1])[1]";
        }
        public static class ContratosTable
        {

            public static string Xpath = "//h4[text()='Contratos']";
        }
        public static class Contratos0
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[1]/label[1]/div[1])[2]";
        }
        public static class Contratos1
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[2]/label[1]/div[1])[2]";
        }
        public static class Contratos2
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[3]/label[1]/div[1])[2]";
        }
        public static class Contratos3
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[4]/label[1]/div[1])[2]";
        }
        public static class Contratos4
        {

            public static string Xpath = "(//div[@class='col-xl-12']/div[1]/div[5]/label[1]/div[1])[2]";
        }
        public static class Errormsg
        {

            public static string Xpath = "//div[text()='Campo obrigatório']";
        }
        public static class Salvarbtn
        {

            public static string Xpath = "//button[text()='Salvar']";
        }
        public static class Cancelarbtn
        {

            public static string Xpath = "//button[text()='Cancelar']";
        }
        public static class  Salvarpopup
        {

            public static string Xpath = "//h5[text()='Atenção']";
            public static class Popupmsg
            {

                public static string Xpath = "//div[text()='Operação realizada com sucesso.']";
            }
            public static class Popupokmsg
            {

                public static string Xpath = "//button[text()='Ok']";
            }
        }
        public static class Controlescreen
        {

            public static string Xpath = "//h1[text()='Controle de acesso ao portal']";
        }
        public static class Controlegrid
        {

            public static string Xpath = "//table[@class='custom-table table undefined table']/tbody";
        }


        #endregion
    }    
}
