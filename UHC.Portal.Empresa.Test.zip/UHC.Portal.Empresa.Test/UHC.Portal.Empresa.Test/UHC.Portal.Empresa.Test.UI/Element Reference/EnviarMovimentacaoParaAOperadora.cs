﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class EnviarMovimentacaoParaAOperadora
    {
        public static class MovimentacaoCadastralMenu
        {
            public static string Xpath = "//*[text()='Movimentação Cadastral']";
        }

        public static class EnviarMovimentaçãoParaAOperadora
        {
            public static string Xpath = "//*[text()='Enviar Movimentação para a Operadora']";
        }
        public static class GroupContratoDropDown
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }

        public static class GroupContratInput
        {
            public static string Xpath = "//input[@class='rw-input-reset']";
        }

        public static class DropDownFirstElement
        {
            public static string Xpath = "//*[text()='648064 - NESTLE BRASIL LTDA BR10 AT (grupo)']";
        }
        public static class DropDownSecondElement
        {
            public static string Xpath = "//*[text()='648064010 - NESTLE WATERS BRASIL - BEBIDAS E ALIMENTOS LTDA']";
        }

        public static class ErrorMessage
        {
            public static string Xpath = "//li[@class = 'rw-list-empty']";
        }

        public static class ContinueButton
        {
            public static string Xpath = "(//button[@type='button'])[4]";
        }
        public static class EmailOption
        {
            public static string Xpath = "//*[text()='Email *']";
        }
        public static class FixoOption
        {
            public static string Xpath = "//*[text()='Fixo *']";
        }
        public static class CelluarOption
        {
            public static string Xpath = "//*[text()='Celular *']";
        }

    }
}
