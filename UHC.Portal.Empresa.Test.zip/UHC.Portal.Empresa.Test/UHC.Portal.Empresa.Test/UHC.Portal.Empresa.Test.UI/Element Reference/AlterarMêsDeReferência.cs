﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class AlterarMêsDeReferência
    {
        #region AlterarMêsDeReferência page details
        public static class MovimentaçãoCadastra_LNK
        {
            public static string Xpath = "//div[text()='Movimentação Cadastral']";
        }

        public static class AlterarMêsReferência_LNK
        {
            public static string Xpath = "//a[text()='Alterar Mês Referência']";
        }

        public static class AlterarMêsDeReferência_Header
        {
            public static string Xpath = "//h1[contains(text(),'Alterar')]";
        }

        public static class EMPRESA_CMBBOX_BTN
        {
            public static string Xpath = "//button[@role='presentational']";
        }

        public static class EMPRESA_CMBBOX_LIST
        {
            public static string Xpath = "//*[text()='510452 - METSO PAPER SULAMERICANA LTDA (grupo)']";
        }

        public static class Buscar_LNK
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        

        public static class Resumo_Da_Movimentação_Header
        {
            public static string Xpath = "//h2[text()='Resumo da movimentação pendente de meses anteriores']";
        }

        public static class NumeroDoContrato
        {
            public static string Xpath = "//label[text()='Número do contrato']";
        }

        public static class Executar_LNK
        {
            public static string Xpath = "//button[text()='Executar']";
        }

        public static class Troca_Header
        {
            public static string Xpath = "//p[text()='Troca de Referência executada com sucesso']";
        }

        public static class EMPRESA_CMBBOX_LIST1
        {
            public static string Xpath = "//li[text()='648064 - NESTLE BRASIL LTDA BR10 AT (grupo)']";
        }

        public static class NãoExisteMovimentação_Header
        {
            public static string Xpath = "//p[text()='Não existe Movimentação Pendente de Meses Anteriores para este contrato.']";
        }

        public static class SelecioneoGrupoContratoORContrato
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
        }
        public static class Selectcontract
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class EnterGrupoContratoORContrato
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class SelectedContract
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class Referência
        {
            public static string Xpath = "//th[text()='Referência']";
        }
        public static class TipoOperação
        {
            public static string Xpath = "//th[text()='Tipo Operação']";
        }
        public static class Quantidade
        {
            public static string Xpath = "//th[text()='Quantidade']";
        }
        public static class Movimentaçãopendente
        {
            public static string Xpath = "//table[@class='text-center pending-movement-table component-table--undefined table table-hover']/tbody/tr";
        }
        #endregion
    }
}
