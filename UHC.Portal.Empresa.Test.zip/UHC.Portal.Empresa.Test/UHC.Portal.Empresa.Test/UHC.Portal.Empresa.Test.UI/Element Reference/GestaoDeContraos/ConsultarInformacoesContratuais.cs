﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoDeContraos
{
    class ConsultarInformacoesContratuais
    {
        public static class ContratoHeading
        {
            public static string Xpath = "//label[text()='Selecione o ']";
        }
        public static class InformacoesContratuais
        {
            public static string Xpath = "//h1[text()='Informações contratuais']";
        }
        public static class CNPJTxt
        {
            public static string Xpath = "//h3[text()='C.N.P.J.']/../p";
        }
        public static class Legislacao
        {
            public static string Xpath = "//h2[text()='Legislação']";
        }
        public static class Arquivo
        {
            public static string Xpath = "//th[text()='Arquivo']";
        }
        public static class Assunto
        {
            public static string Xpath = "//th[text()='Assunto']";
        }
        public static class Acao
        {
            public static string Xpath = "//th[text()='Ação']";
        }
        public static class AcoesDownloadIcon
        {
            public static string Xpath = "//div[text()='Ações']/../ul/li/span";
        }
        
    }
}
