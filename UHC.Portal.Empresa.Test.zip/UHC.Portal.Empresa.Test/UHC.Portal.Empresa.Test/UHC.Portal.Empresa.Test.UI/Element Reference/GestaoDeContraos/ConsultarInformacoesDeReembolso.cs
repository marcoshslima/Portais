﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoDeContraos
{
    class ConsultarInformacoesDeReembolso
    {
        public static class InformacoesDeReembolso
        {
            public static string Xpath = "//h1[text()='Informações de reembolso']";
        }
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class NegocicacaoComb
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div/div";
        }
        public static class NegocicacaoCombBtn
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div[1]/span/button";
        }        
        public static class NegocicacaoCombLSt
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div[2]//ul/li";
        }

        public static class PlanoComb
        {
            public static string Xpath = "//label[text()='Plano']/../div/div/div/div";
        }
        public static class PlanoCombBtn
        {
            public static string Xpath = "//label[text()='Plano']/../div/div/div[1]/span/button";
        }
        public static class PlanoCombLSt
        {
            public static string Xpath = "//label[text()='Plano']/../div/div/div[2]//ul/li";
        }
        public static class PraoPagamentoField
        {
            public static string Xpath = "//label[text()='Prazo pagamento']";
        }
        public static class InformacaoDetailsList
        {
            public static string Xpath = "//ul[@class='accordion__list']";
        }
        public static class NenhumaInfor
        {
            public static string Xpath = "//section[text()='Nenhuma informação foi encontrada com o critério de seleção estabelecido']";
        }
    }
}
