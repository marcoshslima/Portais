﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoDeContraos
{
    class ConsultarPrecosDosPlanosContratados
    {
        public static class ConsultarPrecosHeading
        {
            public static string Xpath = "//h1[text()='Consultar preços dos planos contratados']";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class NegociacaoCombo
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div[1]/div";
        }
        public static class NegociacaoComboBtn
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div[1]/span/button";
        }
        public static class NegociacaoComboLst
        {
            public static string Xpath = "//label[text()='Negociação']/../div/div/div[2]//ul/li";
        }
        public static class FormaoDeSaida
        {
            public static string Xpath = "//label[text()='Formato de saída']";
        }
        public static class RelatorioPDF
        {
            public static string Xpath = "//label[text()='Relatório PDF']";
        }
        public static class ArquivoText
        {
            public static string Xpath = "//label[text()='Arquivo Texto com Delimitador (#)']";
        }
        public static class DownloadDoArquivoBtn
        {
            public static string Xpath = "//button[text()='Download do arquivo']";
        }
    }
}
