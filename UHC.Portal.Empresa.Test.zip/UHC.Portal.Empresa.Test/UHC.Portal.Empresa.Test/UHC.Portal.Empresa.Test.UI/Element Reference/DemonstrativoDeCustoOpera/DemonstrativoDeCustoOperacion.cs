﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.DemonstrativoDeCustoOpera
{
    class DemonstrativoDeCustoOperacion
    {
        public static class SingleContratoComboBox
        {
            public static string Xpath = "//label[text()='Contrato']/../strong";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            // public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
            public static string Xpath = "//label[text()='Contrato']/../div/div/div[2]//input";
        }
        public static class ContratoComboBox_LST
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//ul/li";
            public static string Xpath = "//label[text()='Contrato']/../div/div/div[2]//ul/li";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class Fatura
        {
            public static string Xpath = "//th[text()='Fatura']";
        }
        public static class Referencia
        {
            public static string Xpath = "//th[text()='Referência']";
        }
        public static class Início
        {
            public static string Xpath = "//th[text()='Início']";
        }
        public static class Termino
        {
            public static string Xpath = "//th[text()='Término']";
        }
        public static class Vencimento
        {
            public static string Xpath = "//th[text()='Vencimento']";
        }
        public static class Valor
        {
            public static string Xpath = "//th[text()='Valor']";
        }
        public static class FaturaValue
        {
            public static string Xpath = "//tbody/tr[1]/td[1]/a";
        }
        public static class GerandoDemonstrativo
        {
            public static string Xpath = "//span[text()=' Gerando demonstrativo...']";
        }

        #  region Messages
        public static class NenhumRegistro
        {
            public static string Xpath = "//section[@class='alert__message ']/p[text()='Nenhum registro encontrado para o contrato informado.']";
        }
        public static class InformacaoConfidencial
        {
            public static string Xpath = "//label[text()='Informação confidencial']";
        }
        public static class NenhumMsgContrato
        {
            public static string Xpath = "//li[text()='Contrato não encontrado']";
        }        
        #endregion
        #region Buttons
        public static class NaoButton
        {
            public static string Xpath = " //button[text()='Não']";
        }
        #endregion


        }
}
