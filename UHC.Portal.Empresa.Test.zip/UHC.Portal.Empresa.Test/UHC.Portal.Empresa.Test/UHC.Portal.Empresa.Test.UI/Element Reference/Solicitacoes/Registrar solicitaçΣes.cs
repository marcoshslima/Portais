﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.Solicitacoes
{
    class Registrar_solicitações
    {

        public static class Motivobtn
        {
            public static string Xpath = "//input[@name='motivo']";
        }
        public static class Selectobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o ')]//following::button[1]";
        }
        public static class Selectocontratotxt
        {
            public static string Xpath = "(//div//.//label[contains(text(),'Selecione o ')]//following::button[1]//following::input[1])[1]";
        }
        public static class Beneficiáriobtn
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o beneficiário')]//following::button[1]";
        }
        public static class Beneficiáriotxt
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o beneficiário')]//following::button[1]//following::input[1]";
        }
        public static class Beneficiáriolist
        {
            public static string Xpath = "//div//.//label[contains(text(),'Selecione o beneficiário')]/../div/div/div[2]//ul/li";
        }
        public static class NaoBeneficiárioExist
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";

        }
        public static class Regiaolabel
        {
            public static string Xpath = "//label[text()='Selecione a região: ']";
        }
        public static class Regiaotxt
        {
            public static string Xpath = "//input[@name='request[0].regiao']";
        }
        public static class Enderecoicon
        {
            public static string Xpath = "//span[@class='icon-location2']";
            //a[text()=' Endereço']
            public static class Popup
            {
                public static string Xpath = "//h5[text()='Endereço']";
            }
            public static class Tipoendereco
            {
                public static string Xpath = "//label[text()='Tipo endereço']/..//select";
            }
            public static class Ceptxt
            {
                public static string Xpath = "//input[@name='address.cep']";

            }
            
            public static class Ceplink
            {
                public static string Xpath = "//button[text()='Não sei o CEP']";
                public static class Ceppopup
                {
                    public static string Xpath = "//h5[text()='Busca CEP']";
                }
                public static class Tipodeconsulta
                {
                    public static string Xpath = "//label[text()='Tipo de consulta']/..//select";
                }
                public static class Estadobtn
                {
                    public static string Xpath = "//div//.//label[contains(text(),'Estado *')]//following::button[1]";
                }
                public static class Estadotxt
                {
                    public static string Xpath = "//div//.//label[contains(text(),'Estado *')]//following::button[1]//following::input[1]";
                }
                public static class Municipiobtn
                {
                    public static string Xpath = "//div//.//label[contains(text(),'Municipio *')]//following::button[1]";
                }
                public static class Municipiotxt
                {
                    public static string Xpath = "//div//.//label[contains(text(),'Municipio *')]//following::button[1]//following::input[1]";
                }
                public static class Campotxt
                {
                    public static string Xpath = "//div[text()='Campo obrigatório']";
                }
                public static class Logradourobtn
                {
                    public static string Xpath = "//input[@name='localityPubAreaSearch']";
                }
                public static class Buscarbtn
                {
                    public static string Xpath = "//button[text()='Buscar CEP']";
                }
                public static class Buscaceppopup
                {
                    public static string Xpath = "//h5[text()='Busca CEP']/../..";
                }
                public static class Checkbtn
                {
                    public static string Xpath = "//div[text()='Ações']/..//ul//li//span";
                }
                public static class Voltarbtn
                {
                    public static string Xpath = "//button[text()='Voltar']";
                }
            }
            public static class Numerotxt
            {
                public static string Xpath = "//input[@name='address.numero']";
            }
            public static class Selecionarbtn
            {
                public static string Xpath = "//button[text()='Selecionar']";
            }

        }

        public static class Cartaobtn
        {
            public static string Xpath = "//label[text()='Cartão']//div";
        }
        public static class Orientadorbtn
        {
            public static string Xpath = "//label[text()='Orientador']//div";
        }
        public static class Incluirbtn
        {
            public static string Xpath = "//button[text()='Incluir']";
        }
        public static class Sucessomsg
        {
            public static string Xpath = "//h4[contains(text(),'Operação realizada com sucesso.')]";
        }
        public static class Existmsg
        {
            public static string Xpath = "//div[contains(text(),'Solicitação ')]";
            //div[contains(text(),'Existe um solicitação que foi aberta ')]
        }

    }
}
