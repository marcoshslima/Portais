﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Rede_Credenciada

    {
        #region Rede Credenciada page details
        public static class Rede_Credenciada_LNK
        {
            public static string Xpath = "//a[text()='Rede credenciada']";
        }

        public static class Rede_Credenciada_Title
        {
            public static string Xpath = "//h1[text()='Rede credenciada']";
        }
        public static class Planoourede_BTN
        {
            public static string Xpath = "//input[@name='network']//ancestor::div[1]//following::span[1]";
        }
       
        public static class PlanOurRede_CMBBOX_LIST
        {
            public static string Id = "rw_8_input";
            //public static string Xpath = "//*[@id="rw_8_input"]";
        }
        public static class Estado_CMBBOX_LIST
        {
            public static string Id = "rw_9_input";
        }
        public static class Cidado_CMBBOX_LIST
        {
            public static string Id = "rw_10_input";
        }
        public static class Bairraro_CMBBOX_LIST
        {
            public static string Id = "rw_4_input";
        }
        public static class Tipodeservico_CMBBOX_LIST
        {
            public static string Id = "rw_9_input";
        }
        public static class Especialidade_CMBBOX_LIST
        {
            public static string Id = "rw_10_input";
        }
        public static class Buscar_Rede_Credencidada_BTN
        {
            public static string Xpath = "//button[text()='Buscar rede credenciada']";
        }
        public static class Tipodeservico_RadioBTN
        {
            public static string Xpath = "//div[@class='form-check form-check-inline']//label[text()='Tipo de serviço']";
        }
        public static class Nome_do_prestador_RadioBTN
        {
            public static string Xpath = "//div[@class='form-check form-check-inline']//label[text()='Nome do prestador']";
        }
        public static class Planourede_RadioBTN
        {
            public static string Xpath = "//div[@class='form-check form-check-inline']//label[text()='Plano ou rede']";
        }
        public static class Numerodocartao_ou_CPF_RadioBTN
        {
            public static string Xpath = "//div[@class='form-check form-check-inline']//label[text()='Número do cartão ou CPF']";
        }
        public static class Dados_pesquisados_Txt
        {
            public static string Xpath = "//h2[text()='Dados pesquisados']";
        }

        #endregion
    }
}
