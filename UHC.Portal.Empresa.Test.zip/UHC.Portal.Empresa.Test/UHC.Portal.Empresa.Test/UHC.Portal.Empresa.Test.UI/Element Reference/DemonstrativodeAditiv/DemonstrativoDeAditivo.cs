﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.DemonstrativodeAditiv
{
    class DemonstrativoDeAditivo
    {
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
            public static string Xpath = "//div//.//label[contains(text(),'Contrato')]//following::button[1]//following::input[1]";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//li";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class ResultadoDoDemonstrativoText
        {
            public static string Xpath = "//h4[text()='Resultado do demonstrativo']";
        }
        public static class NumeroContratoText
        {
            public static string Xpath = "//label[text()='Número contrato']";
        }

        public static class Fatura
        {
            public static string Xpath = "//th[text()='Fatura']";
        }
        public static class Referencia
        {
            public static string Xpath = "//th[text()='Referência']";
        }
        public static class Início
        {
            public static string Xpath = "//th[text()='Início']";
        }
        public static class Termino
        {
            public static string Xpath = "//th[text()='Término']";
        }
        public static class Vencimento
        {
            public static string Xpath = "//th[text()='Vencimento']";
        }
        public static class Valor
        {
            public static string Xpath = "//th[text()='Valor']";
        }
        public static class FaturaValue
        {
            public static string Xpath = "//tbody/tr[1]/td[1]/a";
        }
        #region Messages
        public static class NaoRegistroEncontrado
        {
            public static string Xpath = "//div[text()='Não foi encontrado nenhum registro para os parâmetros informados.']";
        }
            #endregion
        }
}
