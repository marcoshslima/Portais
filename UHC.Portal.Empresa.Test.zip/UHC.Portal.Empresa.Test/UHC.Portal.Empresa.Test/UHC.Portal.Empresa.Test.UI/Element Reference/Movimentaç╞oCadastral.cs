﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class MovimentaçãoCadastral
    {
        #region MovimentaçãoCadastral page details

        public static class MovimentaçãoCadastral_LNK
        {
            public static string Xpath = "//div[text()='Movimentação Cadastral']";
        }
        public static class IncluirTitulares_LNK
        {
            public static string LinkText = "Incluir Titulares";
        }

        public static class IncluirDependentes_LNK
        {
            public static string LinkText = "Incluir Dependentes";
        }

        public static class AlterarCadastrodeBeneficiários_LNK
        {
            public static string LinkText = "Alterar Cadastro de Beneficiários";
        }

        public static class ExcluirBeneficiários_LNK
        {
            public static string LinkText = "Excluir Beneficiários";
        }

        public static class TrocarPlanodosBeneficiários_LNK
        {
            public static string LinkText = "Trocar Plano dos Beneficiários";
        }

        public static class TransferênciadeContratoCOMMUDANÇANºBENEF_LNK
        {
            public static string Xpath = "//a[text()='Transferência de Contrato (COM MUDANÇA Nº BENEF)']";
        }

        public static class TransferênciaentreFiliaisSEMMUDANÇANºBENEF_LNK
        {
            public static string LinkText = "Transferência entre Filiais (SEM MUDANÇA Nº BENEF)";
        }

        public static class ManutençãodeAposentadoseDemitidos_LNK
        {
            public static string LinkText = "Manutenção de Aposentados e Demitidos";
        }

        public static class ImportarArquivo_LNK
        {
            public static string LinkText = "Importar Arquivo";
        }

        public static class Importalink
        {
            public static string Xpath = "//*[text()='Importar Arquivo']";
        }
        public static class ConsultarSituaçãodaMovimentação_LNK
        {
            public static string LinkText = "Consultar Situação da Movimentação";
        }

        public static class EnviarMovimentaçãoparaaOperadora_LNK
        {
            public static string LinkText = "Enviar Movimentação para a Operadora";
        }

        public static class ExcluirMovimentaçãocomErro_LNK
        {
            public static string LinkText = "Excluir Movimentação com Erro";
        }

        public static class AlterarMêsReferência_LNK
        {
            public static string LinkText = "Alterar Mês Referência";
        }

        public static class ConsultarImportaçãodoArquivo_LNK
        {
            public static string LinkText = "Consultar Importação do Arquivo";
        }

        public static class ConsultarLotes_LNK
        {
            public static string LinkText = "Consultar Lotes";
        }

        public static class SuspensãodeBeneficiário_LNK
        {
            public static string LinkText = "Suspensão de Beneficiário";
        }

        public static class CancelarSuspensãodeBeneficiário_LNK
        {
            public static string LinkText = "Cancelar Suspensão de Beneficiário";
        }

        public static class ImportaçãodeArquivoSuspensãodeBeneficiário_LNK
        {
            public static string LinkText = "Importação de Arquivo Suspensão de Beneficiário";
        }

        public static class ImportaçãodeArquivoSuspensãodeBeneficiário
        {
            public static string Xpath = "//*[text()='Importação de Arquivo Suspensão de Beneficiário']";
            //*[text()
        }

        public static class Fila_de_execução
        {
            public static string Xpath = "//h2[text()='Fila de execução']";
        }

        public static class ProcurarButton
        {
            public static string Xpath = "//button[text()='Procurar']";
        }


        public static class Selecioneocontrato_CMBBOX
        {
            //public static string Xpath = "//label[text()='Selecione o contrato *']/parent::div/div";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class Selecioneocontrato_CMBLST
        {
            //public static string Xpath = "//label[text()='Selecione o contrato *']/../div//following::ul/li";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class Selecioneocontrato_Value
        {
            //public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div/span";
        }
        public static class SelecioneoBeneficario_Value
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']/div";
        }

        public static class StatusComBox_BTN
        {
            //public static string Xpath = "//input[contains(@name,'status')]//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Status')]//following::button[1]";
        }
        public static class SelecioneocontratoComBox_TXT
        {
            //public static string Xpath = "//input[@class='rw-input-reset']";
            //public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]//following::button[1]//following::input[1]";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class EmpresaComBox_BTN
        {
            //public static string Xpath = "//input[contains(@name,'company')]//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Empresa')]//following::button[1]";
        }

        public static class EmpresaComBox_TXT
        {
            //public static string Xpath = "//input[contains(@name,'company')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]";
            public static string Xpath = "//div//.//label[contains(text(),'Empresa')]//following::button[1]//following::input[1]";
        }

        public static class EmpresaComBox_LST
        {
            //public static string Xpath = "//input[contains(@name,'company')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]//following::ul[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Empresa')]//following::button[1]//following::input[1]//following::ul[1]";
        }


        public static class Selecioneocontrato_BTN
        {
            //public static string Xpath = "//input[@name='contractNumber']//ancestor::div[1]//following::span[1]";
            //public static string Xpath = "//div//.//label[contains(text(),'Selecione o contrato *')]//following::button[1]";
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span[1]/button";
        }

        public static class BeneficiarioComBox_BTN
        {
            // public static string Xpath = "//input[@name='beneficiary']//ancestor::div[1]//following::span[1]";
            //public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]";
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div/span[1]/button";
        }

        public static class BeneficiarioComBox_TXT
        {
            //public static string Xpath = "//input[@placeholder='Digite o CPF (com pontuação), nome ou marca ótica.']";
            //public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]";
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]//input";
        }
        /*
        public static class BeneficiarioComBox_LST
        {
            //public static string Xpath = "//input[@placeholder='Digite o CPF (com pontuação), nome ou marca ótica.']";
            public static string Xpath = "//font[text()='Beneficiary *']/../../..//ul/li";
        }*/
        public static class DataDeTransferencia_TXT
        {
            public static string Xpath = "//label[text()='Data de Transferência *']";
        }
        public static class DataDeTransferencia_CalenderDate
        {
            public static string Xpath = "//table[@id='rw_5_date_calendar']";
        }      

        public static class Nenhumresultadoencontrado_WBEMT
        {            
            public static string Xpath = "//li[contains(text(),'Nenhum resultado encontrado')]";
            //public static string Xpath = "//li[text()='Nenhum resultado encontrado' or text()='The filter returned no results']";
        }
        public static class BeneficiarioNaoExist
        {
            public static string Xpath = "//li[text()='Beneficiário não existe']";
        }
        public static class ARHComBox_LST
        {
            //public static string Xpath = "//input[contains(@name,'arh')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]//following::ul[1]";
            public static string Xpath = "//div//.//label[contains(text(),'ARH')]//following::button[1]//following::input[1]//following::ul[1]";
        }

        public static class PSAComBox_BTN
        {
            //public static string Xpath = "//input[contains(@name,'psa')]//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]";
        }

        public static class PSAComBox_TXT
        {
            //public static string Xpath = "//input[contains(@name,'psa')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]";
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]//following::input[1]";
        }

        public static class PSAComBox_LST
        {
            //public static string Xpath = "//input[contains(@name,'psa')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]//following::ul[1]";
            public static string Xpath = "//div//.//label[contains(text(),'PSA')]//following::button[1]//following::input[1]//following::ul[1]";
        }

        public static class OrganizationComBox_BTN
        {
            //public static string Xpath = "//input[contains(@name,'organization')]//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional')]//following::button[1]";
        }

        public static class OrganizationComBox_TXT
        {
            //public static string Xpath = "//input[contains(@name,'organization')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]";
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional')]//following::button[1]//following::input[1]";
        }
        public static class StatusComBox_TXT
        {
            //public static string Xpath = "//input[contains(@name,'status')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]";
            public static string Xpath = "//div//.//label[contains(text(),'Status')]//following::button[1]//following::input[1]";

        }
        public static class ARHComBox_TXT
        {
            //public static string Xpath = "//input[contains(@name,'arh')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]";
            public static string Xpath = "//div//.//label[contains(text(),'ARH')]//following::button[1]//following::input[1]";
        }
        public static class NovoPlanoTitular_TXT
        {
            public static string Xpath = "//label[text()='Novo Plano do Titular *']";
        }
        public static class NovoPlanoTitular_BTN
        {
            public static string Xpath = "//label[text()='Novo Plano do Titular *']/../div/div/div/span/button/span";
        }

        public static class NovoPlanoTitular_TXTBox
        {
            public static string Xpath = "//label[text()='Novo Plano do Titular *']/..//following::input[@class='rw-input-reset']";
        }
        public static class NovoPlanoTitular_LST
        {
            public static string Xpath = " //label[text()='Novo Plano do Titular *']/..//following::ul[1]";
        }
        public static class NovoPlanoDeDEpendente_BTN
        {
            public static string Xpath = "//label[text()='Novo Plano do Dependente *']/..//following::span[2]";
        }
        public static class NovoPlanoDeDEpendente_TXTBox
        {
            //public static string Xpath = "//label[text()='Novo Plano do Dependente *']/../div/div/div[2]//following::input[@class='rw-input-reset']";
            public static string Xpath = "//label[text()='Novo Plano do Dependente *']/../div/div/div[2]//input";
        }
        public static class NovoPlanoDeDEpendente_LST
        {
            public static string Xpath = "//label[text()='Novo Plano do Dependente *']/..//following::ul[1]";
        }
        public static class NovoPlanoDoAgregadoBTN
        {
            public static string Xpath  = "//label[text()='Novo Plano do Agregado *']/..//following::span[2]";
        }
        public static class NovoPlanoDoAgregado_TXTBox
        {
            public static string Xpath = "//label[text()='Novo Plano do Agregado *']/../div/div/div[2]//input[@class='rw-input-reset']";
        }
        public static class NovoPlanoDoAgregadoLST
        {
            public static string Xpath = "//label[text()='Novo Plano do Agregado *']/..//following::ul[1]";
        }
        
        public static class NovocontratoComBox_BTN
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo contrato *')]//following::button[1]";
        }
        public static class NovocontratoTxt
        {
            public static string Xpath = "//label[text()='Novo contrato *']";
        }
        public static class NovocontratoComBox_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo contrato *')]//following::button[1]//following::input[1]";
        }
        public static class ARHComBox_BTN
        {
            //public static string Xpath = "//input[contains(@name,'arh')]//ancestor::div[1]//following::span[1]";
            public static string Xpath = "//div//.//label[contains(text(),'ARH')]//following::button[1]";
        }

        public static class DateInitial
        {
            public static string Name = "dataInicial";
        }

        public static class DataFinal
        {
            public static string Name = "dataFinal";

        }
        public static class ExbhirFilaButton

        {
            public static string Xpath = "//button[text()='Exibir Fila de Execução']";
        }
        public static class NovocentrodecustoComBox_BTN
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo centro de custo')]//following::button[1]";
        }
        public static class NovocentrodecustoComBox_LST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo centro de custo')]//following::button[1]//following::input[1]//following::ul[1]";
        }
        public static class NovocentrodecustoComBox_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Novo centro de custo')]//following::button[1]//following::input[1]";
        }
        public static class OrganizationComBox_LST
        {
            //public static string Xpath = "//input[contains(@name,'organization')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]//following::ul[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Unidade Organizacional')]//following::button[1]//following::input[1]//following::ul[1]";
        }
        public static class NovalotaçãoComBox_BTN
        {
            public static string Xpath = "//div//.//label[contains(text(),'Nova lotação')]//following::button[1]";
        }
        public static class NovalotaçãoComBox_TXT
        {
            public static string Xpath = "//div//.//label[contains(text(),'Nova lotação')]//following::button[1]//following::input[1]";
        }
        public static class BeneficiarioComBox_LST
        {
            //public static string Xpath = "//div//.//label[contains(text(),'Beneficiário *')]//following::button[1]//following::input[1]//following::ul[1]";
            //public static string Xpath = "//input[@placeholder='Digite o CPF (com pontuação), nome ou marca ótica.']";
            public static string Xpath = "//font[text()='Beneficiary *']/../../..//ul/li";
        }
        public static class StatusComBox_LST
        {
            //public static string Xpath = "//input[contains(@name,'status')]//ancestor::div[1]//following::span[1]//following::input[@class='rw-input-reset'][1]//following::ul[1]";
            public static string Xpath = "//div//.//label[contains(text(),'Status')]//following::button[1]//following::input[1]//following::ul[1]";
        }
        public static class NovalotaçãoComBox_LST
        {
            public static string Xpath = "//div//.//label[contains(text(),'Nova lotação')]//following::button[1]//following::input[1]//following::ul[1]";
        }

        #endregion

        #region Combobox
        public static class SelecioneoGrupoContratoORContrato
        {
            public static string Xpath= "//label[text()='Contrato / Grupo Contrato:']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
           

        }

       public static class  GrupoContratoorContrato

        {
            public static string Xpath = "//div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']";
        }



        public static class TextContract

        {
            public static string Xpath = "//input[@class='rw-input-reset']";
        }
        public static class Selectcontract
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato:']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class SelecioneoLote
        {
            public static string Xpath = "//label[text()='Lote: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']";
        }
        public static class SelectLote
        {
            public static string Xpath = "//label[text()='Lote: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div[2]/div/div/ul/li";
        }
        public static class movimentações
        {
            public static string Xpath = "//table[@class='table']/tbody/tr";
        }
        public static class MovimentaçõesPendentes
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr";
        }
        public static class ConsultarsituaçãodamovimentaçãoErros
        {
            public static string Xpath = "//table[@class='text-center undefined component-table--undefined table table-hover']/tbody/tr";
        }
        public static class NãoexisteMovimentaçõesPendentes
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined table table-hover']/tbody/tr/td";
        }
        public static class Lote
        {
            public static string Xpath = "//table[@class='table table-striped']/tbody/tr";
        }
        public static class Ajaxcombobox
        {
            public static string Xpath = "//div[@class='rw-popup']/ul";
        }
        #endregion

        public static class CampoGrupoContratoImportar
        {
            public static string Xpath = "//div[@class='rw-widget-input rw-widget-picker rw-widget-container']";
      
        }

        public static class Datecombobox
        {
            public static string Xpath = "//div[@class='rw-widget-input rw-input]";

        }


   
    

        public static class DateInvalid
        {
            public static string Xpath = "//*[text()='Data inválida']";
        }

        public static class DateInicialInvalid
        {
          public static string Xpath = "//div[text()='Data inicial inválida']";
        }


        public static class NenhumResultado

        {
            public static string Xpath = "//*[text()='Nenhum resultado encontrado']";
        }
        public static class Date
        {
            public static string Xpath = "//div[@id='rw_20_input']";

        }
        public static class DataDeTransferência
        {
            public static string Xpath = "//label[text()='Data de Transferência *']/..//following::div[@class='datepicker__input']/input";
        }
        public static class DataDeTransferênciaText
        {
            public static string Xpath = "//label[text()='Data de Transferência *']";
        }

        #region input
        public static class EnterGrupoContratoORContrato
        {
            public static string Xpath = "//label[text()='Contrato / Grupo Contrato:']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }

        public static class EnterLote
        {
            public static string Xpath = "//label[text()='Lote: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox']/div/div[2]/div/div/div/input";
        }
        public static class SelectedContract
        {
            public static string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }
        #endregion

        #region Messages
        public static class TransferenciaDeContrato
        {
            public static string Xpath = "//h5[text()='Transferência de contrato']";
        }
        public static class TransferenciaDeContratoSucess
        {
            public static string Xpath = "//span[text()='Operação registrada com sucesso.']";
        }
        public static class TransferenciaDeContratoOk
        {
            public static string Xpath = "//button[text()='Ok']";
        }
        public static class TransferenciaDeContratoFechar
        {
            public static string Xpath = "//button[text()='Fechar']";
        }
        public static class ContratoInactiveSuspenso
        {
            public static string Xpath = "//span[text()='Beneficiário para transferência não está ativo ou suspenso.']";
        }
        #endregion

        #region errormessage
        public static class Errormessage
        {
            public static string Xpath = "//p[@class='error-message ']";
        }
        public static class DataDeTransferenciaError
        {
            public static string Xpath = "//label[text()='Data de Transferência *']/../div/div/div[text()='Campo obrigatório']";
        }
        public static class NovoContratoError
        {
            //public static string Xpath = "//label[text()='Novo contrato *']/../div//following-sibling::div[text()='Campo obrigatório']";
            public static string Xpath = "//label[text()='Novo contrato *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class NovoPlanoDOTitularError
        {
            public static string Xpath = "//label[text()='Novo Plano do Titular *']/../div//following-sibling::div[text()='Campo obrigatório']";
        }
        public static class NovoPlanoDoDependenteError
        {
            public static string Xpath = "//label[text()='Novo Plano do Dependente *']/../div//following-sibling::div[text()='Campo obrigatório']";
        }
        public static class NovoPlanoDoAgregadoError
        {
            public static string Xpath = "//label[text()='Novo Plano do Agregado *']/../div//following-sibling::div[text()='Campo obrigatório']";
        }
        public static class OperacoErrors
        {
            public static string Xpath = "//span[text()='Operação possui erros. Realize os ajustes para ser concluída.']";
        }
        public static class Contratovalidation
        {
            public static string Xpath = "//span[text()='646 - Contrato destino não pode ser igual ao contrato de origem']";
        }
        public static class PlanoDependentes
        {
            public static string Xpath = "//h2[text()='Planos / Dependentes']";
        }
            #endregion

            #region Buttons
            public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class RelatórioAnalítico
        {
            public static string Xpath = "//button[text()='Relatório Analítico']";
        }
        public static class Protocolo
        {
            public static string Xpath = "//button[text()='Protocolo']";
        }
        public static class Continuar
        {
            public static string Xpath = "//button[text()='Continuar']";
        }
        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }

        public static class Atulizar

        {
            public static string Xpath = "//button[text()='Atualizar']";
        }

     

        public static class Salvar
        {
            public static string Xpath = "//button[text()='Salvar']";
        }
        public static class Excluir
        {
            public static string Xpath = "//button[text()='Excluir']";
        }


        public static class Sim
        {
            public static string Xpath = "//label[text()='Sim']";
        }
            #endregion

        #region Text
        public static class Tipodemovimentação
        {
            public static string Xpath = "//table[@class='table']/tbody/tr/td[1]";
        }
        public static class Aceito
        {
            public static string Xpath = "//table[@class='table']/tbody/tr/td[3]";
        }

        public static class TexTela
        {
            public static string Xpath = "//*[text()='Tela']]";
        }

        public static class Movimentacao
        {
            public static string Xpath = "//*[text()='Movimentação']";
        }


        public static class Datadesolicitação

        {
            public static string Xpath = "//th[text() ='Data de solicitação']";
        }

        public static class Usuario
        {

            public static string Xpath = "//th[text() ='Usuário']";
        }

        public static class Mensagem
        {
            public static string Xpath = "//th[text()='Mensagem']";
        }

        public static class Status
        {
            public static string Xpath = "//th[text()='status']";
        }


        #endregion

        #region Checkbox
        public static class ExcluirMovimentaçõesPendentes
        {
            public static string Xpath = "//div[@class='control__indicator']";
        }
      
        
        
        public static class ExclusãoMovimentações_Alert
        {
            public static string Xpath = "//span[text()='Exclusão de movimentações pendentes executada com sucesso.']";
        }

        #endregion

        #region combobox 1st value after search
        public static class Firstvalueaftersearch
        {
            public static string Xpath = "//div[@class='rw-popup']/ul/li[1]";
        }
        #endregion
        #region selectedvalue in the combo box
        public static class SelectedvalueinthecomboboxAlterarmesref
        {
            public static string Xpath = "//div[@id='rw_8_input']/div/div";
        }
        #endregion

    }
}