﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ReajusteRN389
    {

        #region Dropdown

        public  static class ContratoDropdown

        {
            public static  string Xpath = "//div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class Contrato_LST
        {
            public static string Xpath = "//li[@class='rw-list-option rw-state-focus']/div[2]//li";
        }
        #endregion

#region text

        public static class Contratotext

        {
            public static string Xpath = "//label[text()='Contrato:']";

        }

        public static class Errortext
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }

        public static class ContratotextBox
        {
            public static string Xpath = "//input[@class='rw-input-reset']";

           // public static string Xpath = "//div//.//label[text()='Contrato:']//following::button[1]//following::input[1]";
        }

        public static class PDFerrortext
        {
            public  static  string Xpath = "//p[text()='Demonstrativo inexistente para o Contrato informado para o ano 2018.']";
        }
        #endregion

        #region button

        public static class ContinuarButton
        {
            public static string Xpath = "//button[text()='Continuar']";

        }

        public static class PDFspinner
        {
            public static string Xpath = "//*[@class='icon icon-spinner2 loading-icon']";
        }

        #endregion


    }
}
