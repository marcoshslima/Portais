﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Resoluçõesnormativas
    {
        public static class Resoluçõesnormativas_LNK
        {
            //public static string Xpath = "//*[text()='Resoluções normativas']";

            public static string Xpath = "//i[@class='icon icon-checkmark undefined']";
        }
      //  Resoluções normativas
        public static class EmpresaTxt_WBEMT
        {
            public static string Xpath = "//label[text()='EMPRESA:']//..//p[1]";
        }

        public static class SelecioneoperíodoEmpresa_CMBBOX
        {
            public static string Xpath = "//select[@placeholder='Selecione o período']";
        }

        public static class BlankAditivo
        {
            public static string Xpath = "//tr[1]/td[5]";
        }
        public static class DownloadAditivo
        {
            public static string Xpath = "//tr[2]/td[5]";
        }

        public static class Legislação_WBTBL
        {
            public static string Xpath = "//table[@class='text-center test_table_normative component-table--undefined table table-hover']";
        }
    }
}
