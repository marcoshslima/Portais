﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class ResolucoesNormativas
    {
        public static class ResolucoesNormativas_Link
        {
            public static string Xpath = "//*[text()='Resoluções normativas']";
        }
        public static class BlankAditivo
        {
            public static string Xpath = "//tr[1]/td[5]";
        }
        public static class DownloadAditivo
        {
            public static string Xpath = "//tr[2]/td[5]";
        }
    }
}
