﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference
{
    class Preçoseprodutos
    {
        #region Preçoseprodutos page details
        public static class Preçoseprodutos_LNK
        {
            public static string Xpath = "//div[text()='Preços e produtos']";
        }

        public static class Tabelacompleta_LNK
        {
            public static string LinkText = "Tabela completa";
        }

        public static class Históricodereajustes_LNK
        {
            public static string LinkText = "Histórico de reajustes";
        }

        public static class EMPRESA_CMBBOX_BTN
        {
            public static string Xpath = "//button[@role='presentational']";
        }

        public static class EMPRESA_CMBBOX_LIST
        {
            public static string Id = "rw_9_listbox";
        }

        public static class PERÍODOtimeInput_CMBBOX
        {
            public static string Name = "timeInput";
        }

        public static class Test_card_readjustment_WBTBL
        {
            public static string Xpath = "//div[@class='test_card_readjustment card']//.//div[@class='card-body']";
        }

        public static class Ocontratonãopossuireajustes_WBEMT
        {
            public static string Xpath = "//td[text()='Não existem reajustes para a empresa dentro do período informado.']";
        }

        public static class ComboDataNegociacao
        {
            public static string Name = "negociacionDate";
        }

		public static class ComboPeriodo
		{
			public static string Name = "timeInput";
		}

        public static class ComboEmpresa
        {
            public static string XPath = "//label[text()='Empresa:']/parent::div/div";
        }

		public static class ComboEmpresaHistorico
		{
			public static string XPath = "//label[text()='EMPRESA: ']/parent::div/div";
		}
        #endregion
    }
}
