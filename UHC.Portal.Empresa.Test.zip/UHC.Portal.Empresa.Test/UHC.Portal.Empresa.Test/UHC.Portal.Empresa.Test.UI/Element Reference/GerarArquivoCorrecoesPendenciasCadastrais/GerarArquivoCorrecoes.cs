﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GerarArquivoCorrecoesPendenciasCadastrais
{
    class GerarArquivoCorrecoes
    {

        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        #region Texts
        public static class Arquivo
        {
            public static string Xpath = "//h1[text()='Arquivo de correções pendências cadastrais']";
        }
        public static class ArquivoComOsBeneficiarios
        {
            public static string Xpath = "//h2[text()='Arquivo com os beneficiários que estao pendentes para serem corrigidos']";
        }

        #endregion

        #region Executar
        public static class ExecutarLink
        {
            public static string Xpath = "//label[text()='Executar']";
        }
        public static class Contrato
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']/span";
        }

        public static class ContratoComboBox_Btn
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//button";
        }
        public static class ContratoComboBox_Txt
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//div/div/div[2]//input";
        }
        public static class ContratoComboBox_Lst
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//div/div/div[2]//ul/li";
        }

        #endregion

        #region PesquisarFilaDeExecucao
        public static class PesquisarFilaDeExecucaoLink
        {
            public static string Xpath = "//label[text()='Pesquisar Fila de Execução']";
        }
        public static class DadaDeSolicitacao
        {
            public static string Xpath = "//label[text()='Data da solicitação']";
        }
        public static class DadaDeSolicitacaoStart
        {
            public static string Xpath = "//label[text()='Data da solicitação']/../div/div/input";
        }
        public static class DadaDeSolicitacaoEnd
        {
            public static string Xpath = "//label[@for='dataAutorizacaoFim']/../div/div/input";
        }
        public static class DadaDeSolicitacaoErrorMsg
        {
            public static string Xpath = "//div[text()='Data de fim é menor que a data de início']";
        }
        

        #endregion

        #region Error messages
        public static class ContratoErrorMsg
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[text()='Campo obrigatório']";
        }
        public static class NaoArquivos
        {
            public static string Xpath = "//td[text()='Não há arquivos na fila de execução']";
        }
            #endregion

        #region Arquivo com os beneficiários
        public static class Periodo
        {
            public static string Xpath = "//label[text()='Período']";
        }
        public static class Atualizar
        {
            public static string Xpath = "//button[text()='Atualizar']";
        }
        public static class DataDaSolicitação
        {
            public static string Xpath = "//tr/th[text()='Data da solicitação']";
        }
        public static class Agendamento
        {
            public static string Xpath = "//tr/th[text()='Agendamento']";
        }
        public static class Usuario
        {
            public static string Xpath = "//tr/th[text()='Usuário']";
        }
        public static class Status
        {
            public static string Xpath = "//tr/th[text()='Status']";
        }
        public static class DadaDaSolicitacaoList
        {
            public static string Xpath = "//tbody/tr[1]/td/div[text()='Data da solicitação']";
        }
        public static class AgendamentoList
        {
            public static string Xpath = "//tbody/tr[1]/td/div[text()='Agendamento']";
        }
        public static class UsuarioList
        {
            public static string Xpath = "//tbody/tr[1]/td/div[text()='Usuário']";
        }
        public static class StatusList
        {
            public static string Xpath = "//tbody/tr[1]/td/div[text()='Status']";
        }
        public static class DropdownList
        {
            public static string Xpath = "//tbody/tr[1]/td[5]/div/i";
        }
        public static class InicioDoProcessamentoList
        {
            public static string Xpath = "//tbody/tr[2]//label[text()='Início do processamento']";
        }
        public static class FimDoProcessamentoList
        {
            public static string Xpath = "//tbody/tr[2]//label[text()='Fim do processamento']";
        }
        public static class MensagemList
        {
            public static string Xpath = "//tbody/tr[2]//label[text()='Mensagem']";
        }
        public static class Parametro
        {
            public static string Xpath = "//tbody/tr[2]//label[text()='Parâmetro']";
        }
        public static class BuscarParametros
        {
            public static string Xpath = "//tbody/tr[2]//button[text()='Buscar parâmetros']";
        }
        public static class ContratoNaoPossui
        {
            public static string Xpath = "//tbody/tr[6]//label[text()='Mensagem']/..//strong[text()='Contrato não possui Layout Pós Implantação parametrizado.']";
        }
        public static class ArquivoTxtSuccess
        {
            public static string Xpath = "//tbody/tr//label[text()='Mensagem']/..//strong[text()='Arquivo txt gerado com sucesso. ']";
        }
        public static class TxtFileLink
        {
            public static string Xpath = "//tbody/tr//label[text()='Mensagem']/../p/a";
        }



            #endregion
        }

}
