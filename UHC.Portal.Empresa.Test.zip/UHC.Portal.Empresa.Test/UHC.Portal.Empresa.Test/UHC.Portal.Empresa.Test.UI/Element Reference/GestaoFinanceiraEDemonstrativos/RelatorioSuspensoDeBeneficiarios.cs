﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraeDemonstrativos
{
    class RelatorioSuspensoDeBeneficiarios
    {
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class InitialPeriod
        {
            public static string Xpath = "//h2[text()='Relatório de suspensão de beneficiários']/..//following::label[text()='Selecione o contrato']/../../../../div[2]/div/div/div/div[1]//input";
        }
        public static class EndPeriod
        {
            public static string Xpath = "//h2[text()='Relatório de suspensão de beneficiários']/..//following::label[text()='Selecione o contrato']/../../../../div[2]/div/div/div/div[3]//input";
        }
        public static class TipoDeRelatorio
        {
            public static string Xpath = "//label[text()='Tipo de relatório']/../div/div/div/div";
        }
        public static class TipoDeRelatorioBtn
        {
            public static string Xpath = "//label[text()='Tipo de relatório']/../div/div/div/span/button";
        }
        public static class TipoDeRelatorioTxt
        {
            public static string Xpath = "//label[text()='Tipo de relatório']/../div/div/div[2]//input";
        }
        public static class TipoDeRelatorioLst
        {
            public static string Xpath = "//label[text()='Tipo de relatório']/../div/div/div[2]//ul/li";
        }
        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class Filtar
        {
            public static string Xpath = "//button[text()='Filtrar']";
        }
        public static class ListDosDadosPendentes
        {
            public static string Xpath = "//tr[@class='main-row undefined main-row--open']/td[5]/ul/li/span";
        }
        public static class Mensagem
        {
            public static string Xpath = "//tr[@class='collapsive-row'][1]//div[text()='Mensagem']";
        }
        public static class FimProcessamento
        {
            public static string Xpath = "//tr[@class='collapsive-row'][1]//div[text()='Fim processamento']";
        }
        public static class InicioProcessamento
        {
            public static string Xpath = "//tr[@class='collapsive-row'][1]//div[text()='Início processamento']";
        }
        public static class ListaDosDadosPendentes
        {
            public static string Xpath = "//h2[text()='Lista dos dados pendentes']";
        }
        public static class SelecioneOContratoHeading
        {
            public static string Xpath = "//label[text()='Selecione o contrato']";
        }
    }
}
