﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraeDemonstrativos
{
    class DemonstrativodeCoParticipacao
    {
        public static class SingleContrato
        {
            public static string Xpath = "//label[text()='Selecione o contrato: ']/following-sibling::p";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o contrato: ']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Selecione o contrato: ']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Selecione o contrato: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione o contrato: ']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class Buscar
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        public static class Referencia
        {
            public static string Xpath = "//th[text()='Referência']";
        }
        public static class Início
        {
            public static string Xpath = "//th[text()='Início']";
        }
        public static class Termino
        {
            public static string Xpath = "//th[text()='Término']";
        }
        public static class Vencimento
        {
            public static string Xpath = "//th[text()='Vencimento']";
        }
        public static class Valor
        {
            public static string Xpath = "//th[text()='Valor']";
        }
        public static class Grid_Faturas
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined custom-table table table-hover']/tbody/tr";
        }
        public static class Gerar_PDF
        {
            //table[@class='text-center  component-table--undefined custom-table table table-hover']/tbody/tr/td/a
            public static string Xpath = "//div[text()='Referência']//following-sibling::a";
        }
        public static class Loading_Icon
        {
            public static string Xpath = "//i[@class='icon icon-spinner2 loading-icon']";
        }
        public static class NaoFaturas_Alert
        {
            public static string Xpath = "//div[text()='Nenhum registro foi encontrado para a configuração informada.']";
        }
    }
}
