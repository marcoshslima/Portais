﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraEDemonstrativos
{
    class DemonstrativoDeMovimentacoesDosBeneficiario
    {
        public static class DemonstrativoHeading
        {
            public static string Xpath = "//h1[text()='Demonstrativo de movimentações dos beneficiários']";
        }
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Contrato']/../div/div/div[1]//button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Contrato']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Contrato']/../div/div/div[2]//ul/li";
        }
        public static class SingleContrato
        {
            public static string Xpath = "//label[text()='Selecione o ']/..//strong/span";
        }
        public static class ResultdoDoDemonstratio
        {
            public static string Xpath = "//h4[text()='Resultado do demonstrativo']";
        }
        public static class NumeroContratoTxtNum
        {
            public static string Xpath = "//label[text()='Número contrato']/../../div[1]/input";
        }
        public static class NumeroContratoTxtName
        {
            public static string Xpath = "//label[text()='Número contrato']/../../div[2]/input";
        }
        public static class Codigo
        {
            public static string Xpath = "//label[text()='Ordenação Beneficiário']/..//button[text()='Código']";
        }
        public static class Nome
        {
            public static string Xpath = "//label[text()='Ordenação Beneficiário']/..//button[text()='Nome']";
        }
        public static class Pdf
        {
            public static string Xpath = "//label[text()='Formato da Consulta']/..//button[text()='PDF']";
        }
        public static class Text
        {
            public static string Xpath = "//label[text()='Formato da Consulta']/..//button[text()='Texto']";
        }
        public static class Fatura
        {
            public static string Xpath = "//th[text()='Fatura']";
        }
        public static class Referencia
        {
            public static string Xpath = "//th[text()='Referência']";
        }
        public static class Inicio
        {
            public static string Xpath = "//th[text()='Início']";
        }
        public static class Termino
        {
            public static string Xpath = "//th[text()='Término']";
        }
        public static class Vencimento
        {
            public static string Xpath = "//th[text()='Vencimento']";
        }
        public static class Valor
        {
            public static string Xpath = "//th[text()='Valor']";
        }
        public static class FilaDeExecucao
        {
            public static string Xpath = "//h2[text()='Fila de execução']";
        }
        public static class ProcessTextMsg
        {
            public static string Xpath = "//p[text()='Processo:']/strong";
        }
        public static class StartPeriod
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[1]/div/div[1]/input";
        }
        public static class EndPeriod
        {
            public static string Xpath = "//p[text()='Período:']/../div/div[2]/div/div[1]/input";
        }
        public static class Refresh
        {
            public static string Xpath = "//p[text()='Processo:']/../div[2]//i";
        }
        public static class DataDeSolicitacao
        {
            public static string Xpath = "//th[text()='Data de Solicitação']";
        }
        public static class Usuário
        {
            public static string Xpath = "//th[text()='Usuário']";
        }
        public static class Status
        {
            public static string Xpath = "//th[text()='Status']";
        }
        public static class Mensagem
        {
            public static string Xpath = "//th[text()='Mensagem']";
        }

        public static class NenhumResult
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }
        
        public static class ExbirFilaDeExecao
        {
            public static string Xpath = "//button[text()='Exibir Fila de Execução']";
        }
      
       public static class Buscar
       {
           public static string Xpath = "//button[text()='Buscar']";
       }
        /*
     public static class
     {
         public static string Xpath = "";
     }
     public static class
     {
         public static string Xpath = "";
     }
     public static class
     {
         public static string Xpath = "";
     }
     public static class
     {
         public static string Xpath = "";
     }
     public static class
     {
         public static string Xpath = "";
     }
     public static class
     {
         public static string Xpath = "";
     }
     */
    }
}
