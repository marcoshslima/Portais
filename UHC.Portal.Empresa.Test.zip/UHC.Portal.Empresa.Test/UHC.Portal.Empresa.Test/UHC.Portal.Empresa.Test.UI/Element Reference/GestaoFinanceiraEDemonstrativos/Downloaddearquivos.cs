﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraeDemonstrativos
{
    class Downloaddearquivos
    {
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Grupo de Contrato/Contrato']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Grupo de Contrato/Contrato']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Grupo de Contrato/Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Grupo de Contrato/Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class Download_Lnk
        {
            public static string Xpath = "//a[text()='Download']";
        }
        public static class Datasolicitacao_Clmn
        {
            public static string Xpath = "//th[text()='Data solicitação']";
        }
        public static class Datageracao_Clmn
        {
            public static string Xpath = "//th[text()='Data geração']";
        }
        public static class Tipoarquivo_Clmn
        {
            public static string Xpath = "//th[text()='Tipo arquivo']";
        }
        public static class Download_Clmn
        {
            public static string Xpath = "//th[text()='Download']";
        }
        public static class Arquivosdisponíveis
        {
            public static string Xpath = "//h4[text()='Arquivos disponíveis']";
        }
        public static class Downloaddearquivos_tela
        {
            public static string Xpath = "//h1[text()='Download de arquivos']";
        }
        public static class Arquivospendentesdeprocessamento
        {
            public static string Xpath = "//h4[text()='Arquivos pendentes de processamento']";
        }
        public static class Arquivosdisponiveis_table
        {
            public static string Xpath = "//h4[text()='Arquivos disponíveis']//following-sibling::div/div/div/table/tbody/tr";
        }
        public static class Arquivospendentesdeprocessamento_table
        {
            public static string Xpath = "//h4[text()='Arquivos pendentes de processamento']//following-sibling::div/div/div/table/tbody/tr";
        }
        public static class DownloadFile_Expired
        {
            public static string Xpath = "//p[text()='Prazo para download expirado, arquivo não disponível.']";
        }
        public static class NaoexistemArquivospendentesdeprocessamento
        {
            public static string Xpath = "//h4[text()='Arquivos pendentes de processamento']//following-sibling::div/div/div/table/tbody/tr/td";
        }
    }
}
