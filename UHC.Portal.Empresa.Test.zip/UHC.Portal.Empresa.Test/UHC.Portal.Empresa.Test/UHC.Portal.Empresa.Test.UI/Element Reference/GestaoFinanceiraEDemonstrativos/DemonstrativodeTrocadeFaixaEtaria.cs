﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraeDemonstrativos
{
    class DemonstrativodeTrocadeFaixaEtaria
    {
        public static class TrocadeFaixaEtaria_Title
        {
            public static string Xpath = "//h1[text()='Demonstrativo de troca de faixa etária']";
        }
        public static class SingleContrato
        {
            public static string Xpath = "//label[text()='Contrato']/following-sibling::p";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
            public static string Xpath = "//label[text()='Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//li";
            public static string Xpath = "//label[text()='Contrato']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class PDF
        {
            public static string Xpath = "//div[text()='PDF']";
        }
        public static class TXT
        {
            public static string Xpath = "//div[text()='TXT']";
        }
        public static class Executar_btn
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class Mês_Anoreferência_BTN
        {
            public static string Xpath = "//label[text()='Mês/Ano referência']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class Downloading_icn
        {
            public static string Xpath = "//i[@class='icon icon-spinner2 loading-icon mt-2 ml-2']";
        }//p[text()='Não foi encontrado nenhum registro com os critérios informados.']
        public static class Naofoi_icn
        {
            public static string Xpath = "//p[text()='Não foi encontrado nenhum registro com os critérios informados.']";
        }
    }
}
