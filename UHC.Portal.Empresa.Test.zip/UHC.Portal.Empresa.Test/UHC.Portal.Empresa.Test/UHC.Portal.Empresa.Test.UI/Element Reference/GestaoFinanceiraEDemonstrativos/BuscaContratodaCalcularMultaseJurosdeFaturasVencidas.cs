﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaoFinanceiraeDemonstrativos
{
    class BuscaContratodaCalcularMultaseJurosdeFaturasVencidas
    {
        public static class SingleContrato
        {
            public static string Xpath = "//label[text()='Contrato *']/following-sibling::p";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Contrato *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
            public static string Xpath = "//label[text()='Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/div/input";
        }
        public static class ContratoComboBox_LST
        {
            //public static string Xpath = "//label[text()='Contrato']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//li";
            public static string Xpath = "//label[text()='Contrato *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class Competência_clmn
        {
            public static string Xpath = "//th[text()='Competência']";
        }
        public static class Vencimento_clmn
        {
            public static string Xpath = "//th[text()='Vencimento']";
        }
        public static class Valormensal_clmn
        {
            public static string Xpath = "//th[text()='Valor mensal']";
        }
        public static class Multa_clmn
        {
            public static string Xpath = "//th[text()='Multa']";
        }
        public static class Jurosaodia_clmn
        {
            public static string Xpath = "//th[text()='Juros ao dia']";
        }
        public static class Valortotal_clmn
        {
            public static string Xpath = "//th[text()='Valor total']";
        }
        public static class Current_date
        {
            public static string Xpath = "//input[@title='Selecionar Data']";
        }
        public static class Date_format
        {
            public static string Xpath = "//small[text()='dd/mm/aaaa']";
        }
        public static class Executar_btn
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class Faturasvencidas_table
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined custom-table table table-hover']/tbody/tr";
        }
        public static class Faturasvencidas_total
        {
            public static string Xpath = "//table[@class='text-center  component-table--undefined custom-table table table-hover']/tbody/tr/td[6]";
        }
        public static class Prorrogarfatura_popup
        {
            public static string Xpath = "//h5[text()='Prorrogar fatura(s)']";
        }
        public static class Prorrogarfaturapopup_mensagem
        {
            public static string Xpath = "//p[text()='Tem certeza que deseja prorrogar todas as faturas para o novo vencimento?']";
        }
        public static class Sim_btn
        {
            public static string Xpath = "//button[text()='Sim']";
        }
        public static class Não_btn
        {
            public static string Xpath = "//button[text()='Não']";
        }
        public static class Faturasprorrogadascomsucesso
        {
            public static string Xpath = "//p[text()='Faturas prorrogadas com sucesso']";
        }
        public static class DatadePagamento_Retroativa
        {
            public static string Xpath = "//div[text()='Data Pagamento não pode ser menor que a data de hoje']";
        }
        public static class SemRegistrosdeMultas
        {
            public static string Xpath = "//p[text()='Nenhum registro encontrado para o filtro selecionado.']";
        }
    }
}
