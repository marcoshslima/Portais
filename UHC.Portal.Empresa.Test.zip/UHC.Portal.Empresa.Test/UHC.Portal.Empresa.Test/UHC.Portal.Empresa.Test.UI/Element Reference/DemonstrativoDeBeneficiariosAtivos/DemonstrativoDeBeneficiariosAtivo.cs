﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.DemonstrativoDeBeneficiariosAtivos
{
    class DemonstrativoDeBeneficiariosAtivo
    {
        #region Heading
        public static class DemonstrativoDeBenfActivos
        {
            public static string Xpath = "//h1[text()='Demonstrativo de beneficiários ativos']";
        }
        public static class FilaDeExecucao
        {
            public static string Xpath = "//h2[text()='Fila de Execução']";
        }
            #endregion

            #region contrato
            public static class SingleContrato
        {
            public static string Xpath = "//label[text()='Contrato:']/../p";
        }
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Contrato:']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Contrato:']/..//button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Contrato:']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Contrato:']/../div/div/div[2]//ul/li";
        }
        public static class NoResultContrato
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }

        #endregion

        public static class BuscarBtn
        {
            public static string Xpath = "//button[text()='Buscar']";
        }
        #region Plano
        public static class PlanoCombo
        {
            public static string Xpath = "//label[text()='Plano: ']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class PlanoComboBtn
        {
            public static string Xpath = "//label[text()='Plano: ']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class PlanoComboTxt
        {
            public static string Xpath = "//label[text()='Plano: ']/../div/div/div[2]//input";
        }        
        public static class PlanoComboLst
        {
            public static string Xpath = "//label[text()='Plano: ']/../div/div/div[2]//ul/li";
        }
        #endregion


        #region Tipo beneficiário
        public static class Todos
        {
            public static string Xpath = "//div[text()='Todos']";
        }
        public static class BeneficiariosNormais
        {
            public static string Xpath = "//div[text()='Beneficiários Normais']";
        }
        public static class Suspensos
        {
            public static string Xpath = "//div[text()='Suspensos']";
        }
        public static class AposentadosDemitidos
        {
            public static string Xpath = "//div[text()='Aposentados/Demitidos']";
        }
        public static class Remissao
        {
            public static string Xpath = "//div[text()='Remissão']";
        }
        #endregion

        #region Ordenação
        public static class Numeros
        {
            public static string Xpath = "//div[text()='Números']";
        }
        public static class Nome
        {
            public static string Xpath = "Nome";
        }

        public static class ContratoText

        {
            public static string Xpath = "//label[text()='Contrato']";
        }
        #endregion

        #region Formato de saída
        public static class RelatorioPDF
        {
            public static string Xpath = "//div[text()='Relatório PDF']";
        }
        public static class ArquioDeTextoComDelimitador
        {
            public static string Xpath = "//div[text()='Arquivo de Texto com Delimitador (#)']";
        }
        #endregion

        #region FilaDeExecucao
        public static class SolicitacaoValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Solicitação']/../small";
        }
        public static class DataSolicitacaoValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Data Solicitação']/../small";
        }
        public static class InicioExecucaoValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Início Execução']/../small";
        }
        public static class TerminoExecucaoValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Término Execução']/../small";
        }
        public static class UsuarioValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Usuário']/../small";
        }
        public static class SituacaoValue
        {
            public static string Xpath = "//tbody/tr[1]//div[text()='Situação']/../small";
        }
        public static class RefreshValue
        {
            public static string Xpath = "//tbody/tr[1]/td[7]//i";
        }
        #endregion

        #region Messages
        public static class NaoInformados
        {
            public static string Xpath = "//p[text()='Não foi encontrado nenhum registro com os critérios informados.']";
        }
        public static class ReportQueueMsg
        {
            public static string Xpath = "//section[@class='alert__message ']/p";
        }
        public static class FileSucessoMsg
        {
            public static string Xpath = "//p[text()='Arquivo gerado com sucesso!']";
        }

        #endregion

        #region popup
        public static class GeracaoPopup
        {
            public static string Xpath = "//h5[text()='Geração de Relatório']";
        }
        public static class GeracaoConfirmaMsg
        {
            public static string Xpath = "//p[text()='Confirma a geração de relatório com os critérios de seleção informados?']";
        }
        public static class GeracaoSim
        {
            public static string Xpath = "//button[text()='Sim']";
        }
        public static class GeracaoNao
        {
            public static string Xpath = "//button[text()='Não']";
        }
            #endregion
    }
}
