﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios
{
    class DemonstrativoseDeclarações
    {
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class ContratoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//li";
        }
        public static class BeneficiarioComboBox
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class BeneficiarioComboBox_BTN
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//following::span[@class='rw-select']/button";
        }
        public static class BeneficiarioComboBox_TextBox
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/div/input";
        }
        public static class BeneficiarioComboBox_LST
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/ul/li";
        }
        public static class FormatodeSaida_Label
        {
            public static string Xpath = "//label[text()='Formato de Saída']";
        }
        public static class Correios_Radiobtn
        {
            public static string Xpath = "//label[text()='Correios']/div";
        }
        public static class Email_Radiobtn
        {
            public static string Xpath = "//label[text()='E-mail']/div";
        }
        public static class Tela_Radiobtn
        {
            public static string Xpath = "//label[text()='Tela']/div";
        }
        public static class Executar_btn
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class Gerarrelatório_btn
        {
            public static string Xpath = "//button[text()='Gerar relatório']";
        }
        public static class Nomedestinatário_inp
        {
            public static string Xpath = "//input[@name='contact.completeName']";
        }
        public static class Endereçodeemail_inp
        {
            public static string Xpath = "//input[@name='contact.email']";
        }
        public static class Loading_icon
        {
            public static string Xpath = "//i[@class='icon icon-spinner2 loading-icon mt-2 ml-2']";
        }
        public static class Email_Result_Alert
        {
            public static string Xpath = "//p[text()='A solicitação de envio de e-mail foi cadastrada com sucesso.']";
        }
        public static class Correios_Result_Alert
        {
            public static string Xpath = "//p[text()='A solicitação de envio de e-mail foi cadastrada com sucesso.']";
        }
        public static class CompetenciaComboBox
        {
            public static string Xpath = "//label[text()='Selecione a Competência']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class CompetenciaComboBox_BTN
        {
            public static string Xpath = "//label[text()='Selecione a Competência']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class CompetenciaComboBox_TXT
        {
            public static string Xpath = "//label[text()='Selecione a Competência']/..//following::div[@class='rw-dropdown-list rw-widget']/div[2]//input";
        }
        public static class CompetenciaComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione a Competência']/..//following::div[@class='rw-dropdown-list rw-widget']/div[2]//li";
        }
        public static class NaoseiCEP_btn
        {
            public static string Xpath = "//button[text()='Não sei o CEP']";
        }
        public static class BuscaCEP_PopupHeader
        {
            public static string Xpath = "//h5[text()='Busca CEP']";
        }
        public static class Tipodeconsulta_Select
        {
            public static string Xpath = "//label[text()='Tipo de consulta']/..//following::div[@class='wrapper-loading-input wrapper-loading-input--select']/select";
        }
        public static class EstadoComboBox
        {
            public static string Xpath = "//label[text()='Estado *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class EstadoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Estado *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class EstadoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Estado *']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//input";
        }
        public static class EstadoComboBox_LST
        {
            public static string Xpath = "//label[text()='Estado *']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//li";
        }
        public static class BairroComboBox
        {
            public static string Xpath = "//label[text()='Bairro']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class BairroComboBox_BTN
        {
            public static string Xpath = "//label[text()='Bairro']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class BairroComboBox_TXT
        {
            public static string Xpath = "//label[text()='Bairro']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//input";
        }
        public static class BairroComboBox_LST
        {
            public static string Xpath = "//label[text()='Bairro']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//li";
        }
        public static class TipoComboBox
        {
            public static string Xpath = "//label[text()='Tipo']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class TipoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Tipo']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class TipoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Tipo']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//input";
        }
        public static class TipoComboBox_LST
        {
            public static string Xpath = "//label[text()='Tipo']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//li";
        }
        public static class Título_PatenteComboBox
        {
            public static string Xpath = "//label[text()='Título/Patente']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class Título_PatenteComboBox_BTN
        {
            public static string Xpath = "//label[text()='Título/Patente']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class Título_PatenteComboBox_TXT
        {
            public static string Xpath = "//label[text()='Título/Patente']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//input";
        }
        public static class Título_PatenteComboBox_LST
        {
            public static string Xpath = "//label[text()='Título/Patente']/..//following::div[@class='test_combo_country_state rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//li";
        }
        public static class MunicipioComboBox
        {
            public static string Xpath = "//label[text()='Municipio *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class MunicipioComboBox_BTN
        {
            public static string Xpath = "//label[text()='Municipio *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class MunicipioComboBox_TXT
        {
            public static string Xpath = "//label[text()='Municipio *']/..//following::div[@class='test_combo_city rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//input";
        }
        public static class MunicipioComboBox_LST
        {
            public static string Xpath = "//label[text()='Municipio *']/..//following::div[@class='test_combo_city rw-dropdown-list rw-widget rw-state-focus rw-open']/div[2]//li";
        }
        public static class Númerocaixapostal_input
        {
            public static string Xpath = "//label[text()='Número caixa postal *']/..//following::div[@class='input-container']/div/input";
        }
        public static class BuscarCEP_btn
        {
            public static string Xpath = "//button[text()='Buscar CEP']";
        }
        public static class CEPnãoencontrado_Alrt
        {
            public static string Xpath = "//td[text()='CEP não encontrado.']";
        }
        public static class BuscarCEP_action
        {
            public static string Xpath = "//li[@class='component-table__actions__item']";
        }
        public static class BuscarCEP_results
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr";
        }
        public static class BuscarCEP_Logradouro
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr/td[1]";
        }
        public static class BuscarCEP_Bairro
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr/td[2]";
        }
        public static class BuscarCEP_Localidade
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr/td[3]";
        }
        public static class BuscarCEP_CEP
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr/td[4]";
        }
        public static class BuscarCEP_Complemento
        {
            public static string Xpath = "//table[@class='text-center test_table_zip_code_results component-table--small custom-table table table-hover']/tbody/tr/td[5]";
        }
        public static class Campoobrigatório
        {
            public static string Xpath = "//div[text()='Campo obrigatório']";
        }
        public static class Complemento_input
        {
            public static string Xpath = "//input[@name='address.complemento']";
        }
        public static class CEP_input
        {
            public static string Xpath = "//input[@name='address.cep']";
        }
        public static class Logradouro_input
        {
            public static string Xpath = "//input[@name='address.logradouro']";
        }
        public static class Bairro_input
        {
            public static string Xpath = "//input[@name='address.bairro']";
        }
        public static class Municipio_input
        {
            public static string Xpath = "//label[text()='Município']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class Uf_input
        {
            public static string Xpath = "//input[@name='address.uf']";
        }
        public static class CEP_popup_input
        {
            public static string Xpath = "//input[@name='zipCode']";
        }
        public static class Usuario_input
        {
            public static string Xpath = "//input[@name='user']";
        }
        public static class Localidade_input
        {
            public static string Xpath = "//input[@name='localityPubAreaSearch']";
        }
    }
}
