﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios
{
    class RegistrarSolicitações
    {

        string lo = "";
        #region Button
        public static class Endereço

        {
            public static string Xpath = "//*[text()=' Endereço']";
        }

        public static class PopupEnderco
        {
            public static string Xpath = "//div[@class='modal-body']";
        }

        public static class NaoSeioCEP

        {
            public static string Xpath = "//button[@class='test_link_search_cep pl-0 btn btn-link']";
        }
        #endregion

        #region DropdownandText


        public static class  Registrartela
        {

         public static string Xpath = "//h1[text()='Registrar solicitações']";
         }
        public static class TipoEnderco

        {
            public static string Xpath = "//*[@class='test_select_type_search form-control']";
        }


           public static class SelectBeneficiario

        {
            public static string Xpath = "//*[text()='Selecione o beneficiário']//following::div[@class='rw-input rw-dropdown-list-input']";
        }


        public static class BeneficiarioLst
         {

            public static string Xpath = "//div[text()='Selecione o beneficiário *']//following::ul[@id='rw_2_listbox']";

        }
        public static class Benefeciariotextbox
        {
            public static string Xpath = "//*[@placeholder='Digite o CPF (com pontuação), nome ou marca ótica.']";
        }
        public static class TipodeConsulta
        {
            public  static string Lo ="form-control";
            public static string Xpath = "//label[text()='Tipo de consulta']//following::*[@class ="+Lo+ "]";
        }

        public static class Tipogrid

        {
            public static string Xpath = "//div[@class='card-body']//following::div[@class='form-group'][5]";
        }


        public static class BuscaCEPPopup

        {
            public static string Xpath = "//div[@class='no-scroll modal-body']";
        }

        public static class CEPtextbox
        {
            public static string Name = "address.cep";
        }

        public  static class BuscaCEPText
        {
            public static string Xpath = "//*[text()='Busca CEP']";
        }


        public static class NaoCeptext
        {
            public static string Xpath = "//*[text()='CEP não encontrado.']";
        }

        public static class CEPtext

        {
            public static string Xpath = "//input[@class='test_input_zip_code is-invalid form-control']";
        }


        public static class BuscaCEPCheck

        {
            public static string Xpath = "//span[@class='icon icon-checkmark']";
        }

        
           #endregion
    }
}
