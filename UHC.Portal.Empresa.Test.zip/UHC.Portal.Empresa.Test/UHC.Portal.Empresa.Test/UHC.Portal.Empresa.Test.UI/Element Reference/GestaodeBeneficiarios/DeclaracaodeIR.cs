﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios
{
    class DeclaracaodeIR
    {
        #region Text
        public static class DeclarcaodeIRTela
        {
            public static string Xpath = "//h1[text()='Declaração de imposto de renda']";
        }

        public static class Errortext

        {
            public static string Xpath = "//span[text()='Nenhuma informação foi encontrada com o critério de seleção estabelecido']";
        }


        
        #endregion

        #region Button

        public static class AnoCalenderaio

        {
            public static string Xpath = "//input[@class='rw-widget-input rw-input']";
        }

        public static class GerarRelatario

        {
            public static string Xpath = "//button[@class='pdf btn btn-primary']";
        }
        #endregion
    }
}
