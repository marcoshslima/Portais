﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios.DemonstrativosEDeclaracoes
{
    class DeclaracaoDePagamento
    {
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[1]/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioCombo
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[1]/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[1]/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]//ul/li";
        }
        public static class DataInicial
        {
            public static string Xpath = "//label[text()='Data Inicial']/../div/div/input";
        }
        public static class Ate
        {
            public static string Xpath = "//label[text()='Até']/../div/div/input";
        }
        public static class Consultar
        {
            public static string Xpath = "//button[text()='Consultar']";
        }        
        public static class DeclaracoDePagamentoHeading
        {
            public static string Xpath = "//h1[text()='Declaração de pagamento]]";
        }
        
        public static class NoResultMsg
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }    
      
        public static class NenhumInfo
        {
            public static string Xpath = "   //section[text()='Nenhuma informação foi encontrada com o critério de seleção estabelecido.']";
        }        
        public static class BeneficiarioNaoEncontrado
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
    /*
          public static class
          {
              public static string Xpath = "";
          }
          public static class
          {
              public static string Xpath = "";
              public static class
          {
              public static string Xpath = "";
          }
          public static class
          {
              public static string Xpath = "";
          }
          public static class
          {
              public static string Xpath = "";
              public static class
          {
              public static string Xpath = "";
          }
          public static class
          {
              public static string Xpath = "";
          }
          }
          }
          */
}
}
