﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios.DemonstrativosEDeclaracoes
{
    class DemonstrativoDeReembolsoMedic
    {
        public static class NenInformacaoSelecaoEstabl
        {
            public static string Xpath = "//p[text()='Nenhuma informação foi encontrada com o critério de seleção estabelecido.']";
        }
        public static class DemonstrativoDeReembolsoMedicoHead
        {
            public static string Xpath = "//h1[text()='Demonstrativo de reembolso médico']";
        }
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o ']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioCombo
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/div/div/div/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário *']/div/div/div[2]//ul/li";
        }
        public static class Executar
        {
            public static string Xpath = "//button[text()='Executar']";
        }
        public static class BeneficiarioNaoEncontrado
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
    }
}
