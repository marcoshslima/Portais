﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios.Solicitacoes
{
    class ConsultarSolicitacoes
    {
        public static class ConsultarSolicitacoesMsg
        {
            public static string Xpath = "//h1[text()='Consultar solicitações']";
        }
        public static class ContratoCombo
        {
            public static string Xpath = "//label[text()='Selecione o contrato']/../div/div/div/div";
        }
        public static class ContratoComboBtn
        {
            public static string Xpath = "//label[text()='Selecione o contrato']/../div/div/div/span/button";
        }
        public static class ContratoComboTxt
        {
            public static string Xpath = "//label[text()='Selecione o contrato']/../div/div/div[2]//input";
        }
        public static class ContratoComboLst
        {
            public static string Xpath = "//label[text()='Selecione o contrato']/../div/div/div[2]//ul/li";
        }
        public static class BeneficiarioCombo
        {
            public static string Xpath = "//div[text()='Beneficiário']/div/div/div/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Beneficiário']/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Beneficiário']/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Beneficiário']/div/div/div[2]//ul/li";
        }
        
        public static class NenhumResultadoMsg
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }
        
        public static class OkButton
        {
            public static string Xpath = "//button[text()='Ok']";
        }
        
        public static class PendenciasPopup
        {
            public static string Xpath = "//h5[text()='Pendências']";
        }
        public static class BenificarioNaoMsg
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        
        }
        public static class Períodosolicitação
        {
            public static string Xpath = "//div//.//label[contains(text(),'Período solicitação *')]//following::input[1]";
        }
        public static class Períodosolicitaçãoate
        {
            public static string Xpath = "//div//.//label[contains(text(),'Período solicitação *')]//following::button[1]//following::input[1]";
        }
        public static class Enviarbtn
        {
            public static string Xpath = "//button[text()='Enviar']";
        }
        public static class Gridtab
        {
            public static string Xpath = "//div[@class='table-responsive']";
            public static class Contratocol
            {
                public static string Xpath = "//div[@class='table-responsive']//th[text()='Contrato']";

            }
            public static class Beneficiáriocol
            {
                public static string Xpath = "//div[@class='table-responsive']//th[text()='Beneficiário']";

            }
            public static class Tiposolicitaçãocol
            {
                public static string Xpath = "//div[@class='table-responsive']//th[text()='Tipo solicitação']";

            }
            public static class Datacol
            {
                public static string Xpath = "//div[@class='table-responsive']//th[text()='Data']";

            }
            public static class Usuáriocol
            {
                public static string Xpath = "//div[@class='table-responsive']//th[text()='Usuário']";

            }

        }

    }
}
