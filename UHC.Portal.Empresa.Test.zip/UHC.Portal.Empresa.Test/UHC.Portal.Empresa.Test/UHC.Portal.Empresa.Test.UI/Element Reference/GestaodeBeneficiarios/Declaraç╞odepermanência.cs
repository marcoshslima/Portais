﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios
{
    class Declaraçãodepermanência
    {

        public static class PermanciaScreen
        {
            public static string Xpath = "//h1[text()='Declaração de permanência']";
        }
        public static class ContratoComboBox
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class ContratoComboBox_BTN
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//button";
        }
        public static class Selecioneocontrato_CMBLST
        {
            public static string Xpath = "//label[text()='contrato *']/../div//following::ul/li";
        }
        public static class ContratoComboBox_TXT
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//input";
        }
        public static class SelecioneocontratoComBox_TXT
        {

            public static string Xpath = "//div//.//label[text()='contrato *']//following::button[1]//following::input[1]";
        }
        public static class ContratoComboBox_LST
        {
            public static string Xpath = "//label[text()='Selecione o contrato *']/..//following::div[@class='test_select_contract rw-dropdown-list rw-widget']/div[2]//li";
        }
        public static class SelecioneoBeneficario_CMBLST
        {
            public static string Xpath = "//label[text()='Beneficiário *']//following-sibling::div[@class='dropdownList dropdownList--with-reset wrapper-loading-input wrapper-loading-input--custom-combobox ']/div/div[2]/div/div/ul/li";
        }
        public static class BeneficiarioComboBox
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-input rw-dropdown-list-input']";
        }
        public static class BeneficiarioComboBox_BTN
        {
            public static string Xpath = "//label[text()='Beneficiário *']/..//following::div[@class='rw-widget-input rw-widget-picker rw-widget-container']//following::span[@class='rw-select']/button";
        }
        public static class BeneficiarioComboBox_TextBox
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/div/input";
        }
        public static class BeneficiarioComboBox_LST
        {
            public static string Xpath = "//label[text()='Beneficiário *']/../div/div/div[2]/div/div/ul/li";
        }

        public static class ExecutorButton
        {
            public static string Xpath = "//button[text()='Executar']";
        }

        public static class Nenhumerror

        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado']";
        }

        public static class OperacaoSucess
        {
            public static string Xpath = "//p[text()='Operação realizada com sucesso.']";
        }
    }
}
