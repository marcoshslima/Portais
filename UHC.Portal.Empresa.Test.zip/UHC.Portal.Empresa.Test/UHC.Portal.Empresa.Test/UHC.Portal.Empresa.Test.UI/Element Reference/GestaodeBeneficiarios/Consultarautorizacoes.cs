﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.GestaodeBeneficiarios
{
    class Consultarautorizacoes
    {
        public static class Consultarautorizaçõesheader
        {
            public static string Xpath = "//h1[text()='Consultar autorizações']";
        }
        public static class BeneficiarioCombo
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div/div";
        }
        public static class BeneficiarioComboBtn
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div/span/button";
        }
        public static class BeneficiarioComboTxt
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div[2]//input";
        }
        public static class BeneficiarioComboLst
        {
            public static string Xpath = "//div[text()='Selecione o beneficiário']/div/div/div[2]//ul/li";
        }
        public static class BenificarioNaoMsg
        {
            public static string Xpath = "//li[text()='Beneficiário não encontrado']";
        }
        
    }
}
