﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UHC.Portal.Empresa.Test.UI.Element_Reference.SolicitacaoDeArquivos
{
    class SolicitacaoDeArquivo
    {
        public static class Email
        {
            public static string Xpath = "//label[text()='E-mail']";
        }
        public static class EmailTxtBox
        {
            public static string Xpath = "//label[text()='E-mail']/..//following::input[@name='email']";
        }
        public static class ContratoGrupoDeContrato_Combo_Btn
        {
            public static string Xpath = "//label[text()='Contrato/Grupo de Contrato']/..//following::button";
        }
        public static class ContratoGrupoDeContrato_Combo_Txt
        {
            public static string Xpath = "//label[text()='Contrato/Grupo de Contrato']/../div/div/div[2]//input";
        }
        public static class ContratoGrupoDeContrato_Combo_Value
        {
            public static string Xpath = "//label[text()='Contrato/Grupo de Contrato']/../div/div/div/div";
        }
        public static class ContratoGrupoDeContrato_Combo_Lst
        {
            public static string Xpath = "//label[text()='Contrato/Grupo de Contrato']/../div/div/div[2]//ul/li";
        }
        public static class TipoDeSolicitacao_Combo_Btn
        {
            public static string Xpath = "//label[text()='Tipo de Solicitação:']/..//following::button";
        }
        public static class TipoDeSolicitacao_Combo_Txt
        {
            public static string Xpath = "//label[text()='Tipo de Solicitação:']/../div/div/div[2]//input";
        }
        public static class TipoDeSolicitacao_Combo_Lst
        {
            public static string Xpath = "//label[text()='Tipo de Solicitação:']/../div/div/div[2]//ul/li";
        }
        public static class Enviar
        {
            public static string Xpath = "//button[text()='Enviar']";
        }
        public static class DataDeCompetencia
        {
            public static string Xpath = "//label[text()='Data de competência']";
        }
        public static class DataDeCompetenciaTxtBox
        {
            public static string Xpath = "//label[text()='Data de competência']/..//input";
        }
        public static class DataDeCompetenciaFormat
        {
            public static string Xpath = "//small[text()='mm/aaaa']";
        }
        public static class DataDeCompetencia_Combo_Btn
        {
            public static string Xpath = "//label[text()='Data de competência']/..//following::button";
        }
        public static class DataDeCompetencia_Combo_Txt
        {
            public static string Xpath = "//label[text()='Tipo de Solicitação:']/../div/div/div[2]//input";
        }
        public static class DataDeCompetencia_Combo_Lst
        {
            public static string Xpath = "//label[text()='Tipo de Solicitação:']/../div/div/div[2]//ul/li";
        }

        #region messages
        public static class InvalidEmailTxt
        {
            public static string Xpath = "Email inválido";
        }
        public static class DataInvalidTxt
        {
            public static string Xpath = "//div[text()='Data inválida']";
        }
        public static class SucessMessage
        {
            public static string Xpath = "//div[text()='Operação realizada com sucesso.']";
        }
        public static class NenhumMsg
        {
            public static string Xpath = "//li[text()='Nenhum resultado encontrado.']";
        }
            #endregion



        }
}
