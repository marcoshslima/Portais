﻿using System.Text;
using CA.Test.FrontEnd.Helper;
using OGS.Framework.Utility;
using Oracle.ManagedDataAccess.Client;

namespace Test.Middleware.Bus.Helper
{
    public class SqlHelper
    {
        #region Agendamento
        public string UsuarioTitularPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularSuspensoPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE B.IND_SITUACAO = 'S' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularExcluidoPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependentePortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteSuspensoPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE B.IND_SITUACAO = 'S' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteExcluidoPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioPatrocinadorPortalAgendamento
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'P' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularExcluidoMoCpfMaior2Anos
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(num_cpf, 11,0), NOME_ASSOCIADO, TIPO_ASSOCIADO, b.IND_SITUACAO, B.DATA_EXCLUSAO FROM TS.BENEFICIARIO B");
                temp.Append("JOIN TS.BENEFICIARIO_ENTIDADE BE ON B.COD_ENTIDADE_TS = BE.COD_ENTIDADE_TS");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND DATA_EXCLUSAO < sysdate - (365 * 2+1) AND B.TIPO_ASSOCIADO= 'T' AND ROWNUM < 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularExcluidoMoCpfMenor2Anos
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(num_cpf, 11,0), NOME_ASSOCIADO,TIPO_ASSOCIADO, B.IND_SITUACAO,B.DATA_EXCLUSAO FROM TS.BENEFICIARIO B");
                temp.Append("JOIN TS.BENEFICIARIO_ENTIDADE BE ON B.COD_ENTIDADE_TS = BE.COD_ENTIDADE_TS");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND DATA_EXCLUSAO > sysdate - (365 * 2+1) AND B.TIPO_ASSOCIADO = 'D' AND ROWNUM < 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteExcluidoMoCpfMaior2Anos
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPDA(num_cpf, 11,0), NOME_ASSOCIADO,TIPO_ASSOCIADO, B.IND_SITUACAO,B.DATA_EXCLUSAO FROM TS.BENEFICIARIO B");
                temp.Append("JOIM TS.BENEFICIARIO_ENTIDADE BE ON B.COD_ENTIDADE_TS = BE.COD_ENTIDADE_TS");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND b.IND_SITUACAO = 'E' AND DATA_EXCLUSAO < sysdate - (365 * 2+1) AND B.TIPO_ASSOCIADO = 'D' AND ROWNUM < 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteExcluidoMoCpfMenor2anos

        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO,LPDA(num_cpf,11,0), NOME_ASSOCIADO,TIPO_ASSOCIADO, B.IND_SITUACAO,B.DATA_EXCLUSAO FROM TS.BENEFICIARIO B");
                temp.Append("JOIN TS.BENEFICIARIO_ENTIDADE BE ON B.COD_ENTIDADE_TS = BE.COD_ENTIDADE_TS");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND DATA_EXCLUSAO < sysdate - (365 * 2+1) AND B.TIPO_ASSOCIADO = 'D' AND ROWNUM < 1");
                return temp.ToString();

            }
        }

        #endregion

        #region Beneficiario
        public string UsuarioTitularPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND  B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND NUM_ASSOCIADO != '651913535' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularSuspensoPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE B.IND_SITUACAO = 'S' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND NUM_ASSOCIADO != '651913535' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioTitularExcluidoPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'T' AND NUM_ASSOCIADO != '651913535' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependentePortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteSuspensoPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE B.IND_SITUACAO = 'S' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioDependenteExcluidoPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND ID_USUARIO IS NULL AND NUM_CPF IS NOT NULL AND TIPO_ASSOCIADO = 'D' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioPatrocinadorPortalBeneficiario
        {
            get
            {
                var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                temp.Append("JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                temp.Append("JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS UB ON UB.MARCA_OTICA = B.NUM_ASSOCIADO ");
                temp.Append("LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                temp.Append("WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A' AND ID_USUARIO IS NULL AND TIPO_ASSOCIADO = 'P' AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public static string UserBeneficiarioExcluidoMaior2Anos(string tipo_beneficiario)
        {
            var temp = new StringBuilder("SELECT NUM_ASSOCIADO, CPF, NOME_ASSOCIADO");
            temp.Append(" FROM TS.MV_BENEFICIARIO_EXCLUIDO BE");
            temp.Append(" JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
            temp.Append(" WHERE BE.IND_SITUACAO = 'E' AND DATA_EXCLUSAO < sysdate - (365 * 2+1)");
            //temp.Append(" WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND BE.IND_SITUACAO = 'E' AND DATA_EXCLUSAO < sysdate - (365 * 2+1)");
            temp.Append(" AND BE.TIPO_ASSOCIADO=  '"+tipo_beneficiario+"' ");
            temp.Append(" AND ROWNUM = 1");
            return temp.ToString();
        }

        public static string UserBeneficiarioExcluidoMenor2Anos(string tipo_beneficiario)
        {
            var temp = new StringBuilder("SELECT NUM_ASSOCIADO, LPAD(num_cpf, 11,0),NOME_ASSOCIADO FROM TS.BENEFICIARIO B");
            temp.Append(" JOIN TS.BENEFICIARIO_ENTIDADE BE ON B.COD_ENTIDADE_TS = BE.COD_ENTIDADE_TS");
            temp.Append(" JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
            temp.Append(" WHERE SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'E' AND DATA_EXCLUSAO > sysdate - (365 * 2+1)");
            temp.Append(" AND be.num_cpf <> '0'");
            temp.Append(" AND B.TIPO_ASSOCIADO =  'D' ");
            temp.Append(" AND (  exists (select 1 from ts.beneficiario_contato bc ");
            temp.Append(" join ts.beneficiario_entidade ts on ts.cod_entidade_ts = bc.cod_entidade_ts");
            temp.Append(" where IND_CLASS_CONTATO = 'C'");
            temp.Append(" AND TS.NUM_CPF = bE.NUM_CPF )");
            temp.Append(" and  exists (select 1 from ts.beneficiario_contato bc ");
            temp.Append(" join ts.beneficiario_entidade ts on ts.cod_entidade_ts = bc.cod_entidade_ts");
            temp.Append(" where END_EMAIL IS NOT NULL");
            temp.Append(" AND TS.NUM_CPF = bE.NUM_CPF ))");
            temp.Append(" AND ROWNUM = 1");
            return temp.ToString();

        }

        public static string GetBeneficiarioSemConvivencia()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'BENEFICIARIO SEM CONVIVENCIA'";
        }

        #endregion

        #region Dental
        public string UsuarioPaiPortalDental
        {
            get
            {
                var temp = new StringBuilder("SELECT COD_USUARIO, NOME_PRESTADOR FROM TS.USUARIO U JOIN TS_ODO.ODO_PRESTADOR_SERVICO PS ON PS.COD_PRESTADOR_TS = COD_IDENTIFICACAO_TS");
                temp.Append(" LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS US ON COD_USUARIO = LOGIN_USUARIO");
                temp.Append(" WHERE U.TXT_SENHA = 'E076259533B781BA7E059D865B646F12' AND U.IND_ATIVO = 'S' AND US.ID_USUARIO IS NULL AND DATA_EXCLUSAO IS NULL AND COD_TIPO_USUARIO = 23 AND U.IND_SENHA_INICIAL = 'N' AND U.IND_TROCA_SENHA = 'N'");
                temp.Append(" AND COD_USUARIO_PAI IS NULL AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioFilhoPortalDental
        {
            get
            {
                var temp = new StringBuilder("SELECT COD_USUARIO, NOME_PRESTADOR FROM TS.USUARIO U JOIN TS_ODO.ODO_PRESTADOR_SERVICO PS ON PS.COD_PRESTADOR_TS = COD_IDENTIFICACAO_TS");
                temp.Append(" LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS US ON COD_USUARIO = LOGIN_USUARIO");
                temp.Append(" WHERE U.TXT_SENHA = 'E076259533B781BA7E059D865B646F12' AND U.IND_ATIVO = 'S' AND US.ID_USUARIO IS NULL AND DATA_EXCLUSAO IS NULL AND COD_TIPO_USUARIO = 23 AND U.IND_SENHA_INICIAL = 'N' AND U.IND_TROCA_SENHA = 'N'");
                temp.Append(" AND COD_USUARIO_PAI IS NOT NULL AND ROWNUM = 1");
                return temp.ToString();
            }
        }



        public static string GetUsuarioCredenciadoDentalFilhoComConvivencia()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CREDENCIADO DENTAL FILHO COM CONVIVENCIA'";
        }

        public static string GetUsuarioCredenciadoDentalFilhoSemConvivencia()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CREDENCIADO DENTAL FILHO SEM CONVIVENCIA'";
        }
        public static string GetUsuarioCredenciadoDentalPaiSemConvivencia()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CREDENCIADO DENTAL PAI SEM CONVIVENCIA'";
        }

        public static string GetUsuarioCredenciadoDentalPaiComConvivencia()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CREDENCIADO DENTAL PAI COM CONVIVENCIA'";
        }

        public static string GetCadastroCrendenciadoDentalPai()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CADASTRO USUARIO CREDENCIADO DENTAL PAI'";
        }

        public static string GetCadastroCrendenciadoDentalFilho()
        {
            return "SELECT CONSULTA FROM authogs.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CADASTRO USUARIO CREDENCIADO DENTAL FILHO'";
        }
        #endregion

        #region Empresa
        public string UsuarioPaiPortalEmpresa
        {
            get
            {
                var temp = new StringBuilder("SELECT COD_USUARIO, NOM_USUARIO FROM TS.USUARIO U LEFT JOIN AUTHOGS.USUARIO@LINK_PORTAIS US ON COD_USUARIO = LOGIN_USUARIO ");
                temp.Append("WHERE US.ID_USUARIO IS NULL AND DATA_EXCLUSAO IS NULL AND COD_TIPO_USUARIO = 6 AND U.IND_SENHA_INICIAL = 'N' ");
                temp.Append("AND U.IND_TROCA_SENHA = 'N' AND COD_USUARIO_PAI IS NULL AND ROWNUM = 1");
                return temp.ToString();
            }
        }

        public string UsuarioFilhoPortalEmpresa
        {
            get
            {
                var temp = new StringBuilder("SELECT COD_USUARIO, NOM_USUARIO FROM TS.USUARIO U LEFT JOIN AUTHOGS.USUARIO US ON COD_USUARIO = LOGIN_USUARIO ");
                temp.Append("WHERE US.ID_USUARIO IS NULL AND DATA_EXCLUSAO IS NULL AND COD_TIPO_USUARIO = 19 AND DT_INATIVO is null ");
                temp.Append("AND U.IND_SENHA_INICIAL = 'N' AND U.IND_TROCA_SENHA = 'N' AND COD_USUARIO_PAI IS NOT NULL AND ROWNUM = 1");
                return temp.ToString();
            }
        }


        public static string GetUsuarioEmpresaPaiComConvivencia()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'EMPRESA USUARIO PAI CONVIVENCIA'";
        }

        public static string GetUsuarioEmpresaPaiSemConvivencia()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'EMPRESA USUARIO PAI SEM CONVIVENCIA'";
        }

        public static string GetBeneficiarioConvivencia()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'BENEFICIARIO COM CONVIVENCIA'";
        }

        public static string GetUsuarioEmpresaFilhoSemConvivencia()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'EMPRESA USUARIO FILHO SEM CONVIVENCIA'";
        }

        public static string GetUsuarioEmpresaFilhoComConvivencia()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'EMPRESA USUARIO FILHO CONVIVENCIA'";
        }

        public static string GetCadastroEmpresaPai ()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CADASTRO USUARIO EMPRESA PAI'";
        }
        public static string GetCadastroEmpresaFilho()
        {
            return "SELECT CONSULTA FROM noptum_app.BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CADASTRO USUARIO EMPRESA FILHO'";
        }
        #endregion

        public static string UsuarioSenhaExpirada(string portal, string grau_parenteco, string beneficiario)
        {

            StringBuilder sql = new StringBuilder();
            string tipo_beneficiario = "";

            switch (portal)
            {
                case "Portal Empresa":
                    sql.Append("select");
                    sql.Append(" LOGIN_USUARIO ");
                    sql.Append(" from authogs.usuario@link_portais");
                    sql.Append(" where DT_INATIVACAO  is null");
                    sql.Append(" and DT_ULT_ALT_SENHA < sysdate - 90");
                    sql.Append(" and id_sistema = 500");
                    if (grau_parenteco.Equals("Filho")) sql.Append(" and id_usuario_pai is not null");
                    if (grau_parenteco.Equals("Pai")) sql.Append(" and id_usuario_pai is null");
                    sql.Append(" and SENHA_CRIP in('e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e','E076259533B781BA7E059D865B646F12')");
                    sql.Append(" and rownum = 1");
                    break;

                case "Portal Credenciado Dental":
                    sql.Append("select");
                    sql.Append(" LOGIN_USUARIO ");
                    sql.Append(" from authogs.usuario@link_portais");
                    sql.Append(" where DT_INATIVACAO  is null");
                    sql.Append(" and DT_ULT_ALT_SENHA < sysdate - 90");
                    sql.Append(" and id_sistema = 600");
                    if (grau_parenteco.Equals("Filho")) sql.Append(" and id_usuario_pai is not null");
                    if (grau_parenteco.Equals("Pai")) sql.Append(" and id_usuario_pai is null");
                    sql.Append(" and SENHA_CRIP in('e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e','E076259533B781BA7E059D865B646F12')");
                    sql.Append(" and rownum = 1");

                    break;

                default:

                    if (beneficiario.Equals("Titular"))
                    {
                        tipo_beneficiario = "T";
                    }
                    else
                    {
                        tipo_beneficiario = "D";
                    }

                    sql.Append("SELECT NUM_ASSOCIADO, LPAD(NUM_CPF, 11,0), NOME_ENTIDADE FROM TS.BENEFICIARIO_ENTIDADE BR ");
                    sql.Append(" JOIN TS.BENEFICIARIO B ON B.COD_ENTIDADE_TS = BR.COD_ENTIDADE_TS ");
                    sql.Append(" JOIN AUTHOGS.USUARIO@LINK_PORTAIS ON LOGIN_USUARIO = NUM_ASSOCIADO ");
                    sql.Append(" WHERE B.IND_SITUACAO = 'A' AND TIPO_ASSOCIADO = '" + tipo_beneficiario + "'");
                    sql.Append(" AND DT_INATIVACAO is null and DT_ULT_ALT_SENHA < sysdate - 90 and id_sistema = 400");
                    sql.Append(" AND SENHA_CRIP = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e'");
                    sql.Append(" AND ROWNUM = 1");

                    break;
            }

            return sql.ToString();

        }

        public static string UsuarioAtualizacaoCadastral(string portal, string grau_parenteco, string beneficiario)
        {

            StringBuilder sql = new StringBuilder();
            string tipo_beneficiario = "";

            switch (portal)
            {
                case "Portal Empresa":
                    if (grau_parenteco.Equals("Pai"))
                    {
                        sql.Append(" select ");
                        sql.Append("  cod_usuario, nom_usuario");
                        sql.Append(" from ts.usuario u");
                        sql.Append(" left JOIN AUTHOGS.USUARIO@link_portais AU ON LOGIN_USUARIO = u.COD_USUARIO");
                        sql.Append(" where cod_tipo_usuario  = 6 ");
                        sql.Append(" and TXT_SENHA = 'E076259533B781BA7E059D865B646F12' ");
                        sql.Append(" and U.IND_TROCA_SENHA = 'N' ");
                        sql.Append(" and U.IND_SENHA_INICIAL = 'N' and (DT_ULT_ALT_SENHA is null or DT_ULT_ALT_SENHA > sysdate - 90)");
                        sql.Append(" and ativo = 'S'");
                        sql.Append(" and (TXT_EMAIL is null or  TEL_USUARIO is null or  coalesce(to_char(CPF_USUARIO),CPF_CNPJ)is null)");
                        sql.Append(" and rownum = 1");
                    }
                    else
                    {
                        sql.Append(" select COD_USUARIO, NOM_USUARIO");
                        sql.Append(" from ts.usuario u");
                        sql.Append(" left JOIN AUTHOGS.USUARIO@link_portais AU ON LOGIN_USUARIO = u.COD_USUARIO");
                        sql.Append(" where cod_tipo_usuario  = 19 and cod_usuario_pai is not null");
                        sql.Append(" and TXT_SENHA = 'E076259533B781BA7E059D865B646F12' and U.IND_TROCA_SENHA = 'N' AND U.IND_SENHA_INICIAL = 'N' and (DT_ULT_ALT_SENHA is null or DT_ULT_ALT_SENHA > sysdate - 90)");
                        sql.Append(" and (TXT_EMAIL is null or  TEL_USUARIO is null or  coalesce(to_char(CPF_USUARIO),CPF_CNPJ)is null)");
                        sql.Append(" and rownum = 1");

                    }

                    break;

                case "Portal Credenciado Dental":

                    if (grau_parenteco.Equals("Pai"))
                    {
                        sql.Append("select ");
                        sql.Append("    u.COD_USUARIO,");
                        sql.Append("	u.NOM_USUARIO ");
                        sql.Append(" from ts.usuario u");
                        sql.Append(" join TS_ODO.ODO_ENDERECO_PRESTADOR ep");
                        sql.Append(" on COD_PRESTADOR_TS = COD_IDENTIFICACAO_TS");
                        sql.Append(" LEFT JOIN AUTHOGS.USUARIO@link_portais AU");
                        sql.Append(" on LOGIN_USUARIO = u.COD_USUARIO");
                        sql.Append(" where COD_TIPO_USUARIO = 23 and COD_USUARIO_pai is null and U.IND_TROCA_SENHA = 'N' AND U.IND_SENHA_INICIAL = 'N' and (DT_ULT_ALT_SENHA is null or DT_ULT_ALT_SENHA > sysdate - 90)");

                        sql.Append(" and (ep.END_EMAIL is null or NUM_DDD_TELEFONE_1 is null or NUM_TELEFONE_1 is null or coalesce(to_char(CPF_USUARIO),CPF_CNPJ)is null) and u.TXT_SENHA  = 'E076259533B781BA7E059D865B646F12'");

                        sql.Append(" AND ROWNUM = 1");
                    }
                    else
                    {
                        sql.Append("select COD_USUARIO, ");
                        sql.Append(" NOM_USUARIO ");
                        sql.Append(" from ts.usuario u");
                        sql.Append(" left JOIN AUTHOGS.USUARIO@link_portais AU ON LOGIN_USUARIO = u.COD_USUARIO");
                        sql.Append(" where cod_tipo_usuario  = 23 AND cod_usuario_pai is not null");
                        sql.Append(" and TXT_SENHA = 'E076259533B781BA7E059D865B646F12' and U.IND_TROCA_SENHA = 'N' AND U.IND_SENHA_INICIAL = 'N' and (DT_ULT_ALT_SENHA is null or DT_ULT_ALT_SENHA > sysdate - 90)");
                        sql.Append(" and ATIVO = 'S'");
                        sql.Append(" and (TXT_EMAIL is null or  TEL_USUARIO is null or  coalesce(to_char(CPF_USUARIO),CPF_CNPJ)is null)");
                        sql.Append(" AND ROWNUM = 1");

                    }
                    


                    break;

                default:

                    if (beneficiario.Equals("Titular"))
                    {
                        tipo_beneficiario = "T";
                    }
                    else
                    {
                        tipo_beneficiario = "D";
                    }

                    sql.Append("select  B.NUM_ASSOCIADO,LPAD(bE.NUM_CPF,11,0), B.NOME_ASSOCIADO ");
                    sql.Append(" from ts.beneficiario b");
                    sql.Append(" JOIN  ts.beneficiario_ENTIDADE bE ON B.COD_ENTIDADE_TS = bE.COD_ENTIDADE_TS");
                    sql.Append(" JOIN AMILFUNC2004.USUARIO_BENEFICIARIO@LINK_PORTAIS LP ON MARCA_OTICA = NUM_ASSOCIADO");
                    sql.Append(" LEFT JOIN AUTHOGS.USUARIO @LINK_PORTAIS UPO ON UPO.LOGIN_USUARIO = B.NUM_ASSOCIADO");
                    sql.Append(" where SENHA = 'e157667a560a32a549aea27832de1975ce4b99dea40819819c691a08c74cd21e' AND B.IND_SITUACAO = 'A'");
                    sql.Append(" and bE.NUM_CPF is not null");
                    sql.Append(" AND TIPO_ASSOCIADO = '" + tipo_beneficiario + "'");
                    sql.Append(" AND ( not exists (select 1 from ts.beneficiario_contato bc ");
                    sql.Append(" join ts.beneficiario_entidade ts on ts.cod_entidade_ts = bc.cod_entidade_ts");
                    sql.Append(" where IND_CLASS_CONTATO = 'C'");
                    sql.Append(" AND TS.NUM_CPF = bE.NUM_CPF )");
                    sql.Append(" OR not exists (select 1 from ts.beneficiario_contato bc ");
                    sql.Append(" join ts.beneficiario_entidade ts on ts.cod_entidade_ts = bc.cod_entidade_ts");
                    sql.Append(" where END_EMAIL IS NOT NULL");
                    sql.Append(" AND TS.NUM_CPF = bE.NUM_CPF ))");
                    sql.Append(" AND ROWNUM = 1");

                    break;
            }

            return sql.ToString();

        }


        public static string GetUsuarioIdSistemaEsqueceuSenha(string tipo_beneficiario)
        {
            StringBuilder sql = new StringBuilder();

            sql.Append("SELECT LOGIN_USUARIO,ID_SISTEMA,LPAD(CPF_CNPJ,11,0),NM_USUARIO FROM AUTHOGS.USUARIO@link_portais us");
            sql.Append(" inner join authogs.usuario_contato_beneficiario@link_portais cb on cb.id_usuario = us.id_usuario");
            sql.Append(" inner join TS.beneficiario be on be.num_associado = us.login_usuario");
            sql.Append(" where be.tipo_associado = '"+ tipo_beneficiario +"'  AND be.ind_situacao = 'A' ");
            sql.Append(" AND us.cpf_cnpj is not null and rownum = 1");

            return sql.ToString();
        }


        public static string GetToken(string login_usuario)
        {
            StringBuilder sql = new StringBuilder();

            sql.Append("SELECT TOKEN_REC_SENHA FROM AUTHOGS.USUARIO@link_portais");
            sql.Append(" where login_usuario = '" + login_usuario + "'");
            return sql.ToString();
            
        }

        public static string CadastreSe(string portal)
        {
            string resultado = "";

            switch (portal)
            {
                case "Portal Credenciado Dental":
                    resultado = "";
                    break;
                case "Portal Empresa":
                    resultado = "";
                    break;
                default:
                    resultado = "SELECT CONSULTA FROM BIBLIOTECA_CONSULTAS WHERE DESCRICAO = 'CADASTRAR USUARIO BENEFICIARIO/AGENDAMENTO ONLINE'";
                    break;
            }
            return resultado;
        }

    }
}