﻿using System.Configuration;

namespace CA.Test.FrontEnd.Helper
{
    public class AmbienteHelper
    {
        public static string Url;
        public static string Host;
        public static string Port;
        public static string Servicename;
        public static string User;
        public static string Password;
        public static string Ambiente;
        public static void ConexaoDB()
        {
            switch (ConfigurationManager.AppSettings["_ambiente"].ToUpper().ToString())
            {
                case "DEV":
                    /*
                     * 
                     * 
                    #region dbDEV
                    Host = "dsisamil.amil.com.br";
                    //Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    //Servicename = "srvdweb";
                    Servicename = "OGS";
                    User = "Noptum_app";
                    //User = "NPORTAIS_APP";
                    Password = "Optum@1234";
                    #endregion
                    break;
                    */
                ///Teste com o banco DBWEB
                    #region dbDEV
                    Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "srvdweb";
                    User = "NPORTAIS_APP";
                    Password = "Optum@1234";
                    Ambiente = "DEV";
                    #endregion
                    break;

                case "QA":
                    #region dbQA
                    Host = "sisamilteste6-db.grupoamil.com.br";
                    Port = "1521";
                    Servicename = "qa6";
                    User = "AUTHOGS";
                    Password = "123456";
                    Ambiente = "QA6";
                    #endregion
                    break;

                case "QA1":
                    #region dbQA1
                    Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "srvqweb";
                    User = "nportais_app";
                    Password = "Optum@1234";
                    Ambiente = "QA1";
                    #endregion
                    break;

                case "QA2":
                    #region dbQA2
                    Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "srvqweb";
                    User = "nportais_app";
                    Password = "Optum@1234";
                    Ambiente = "QA2";
                    #endregion
                    break;

                case "QA3":
                    #region dbQA3
                    Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "srvqweb";
                    User = "nportais_app";
                    Password = "Optum@1234";
                    Ambiente = "QA3";
                    #endregion
                    break;

                case "QA4":
                    #region dbQA4
                    Host = "hdweb-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "srvqweb";
                    User = "nportais_app";
                    Password = "Optum@1234";
                    Ambiente = "QA4";
                    #endregion
                    break;

                case "HOM":
                    #region dbHOM
                    Host = "hdsisamil-scan.amil.com.br";
                    Port = "1521";
                    Servicename = "hsisamil";
                    User = "SITEAMIL_INTEGRACAO";
                    Password = "64gfurGnnWiz58$nQzOuL#Xebg6dLx";
                    #endregion
                    break;
            }
        }

        public static string SetAmbiente(string portal)
        {
            switch (ConfigurationManager.AppSettings["_ambiente"].ToUpper().ToString())
            {
                case "DEV":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-dev.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-dev.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-dev.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-dev.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "QA":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-qa.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-qa.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-qa.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-qa.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "QA1":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-qa1.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-qa1.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-qa1.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-qa1.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "QA2":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-qa2.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-qa2.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-qa2.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-qa2.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "QA3":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-qa3.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-qa3.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-qa3.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-qa3.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "QA4":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-qa4.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-qa4.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-qa4.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-qa4.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;

                case "HOM":
                    switch (portal)
                    {
                        case "Portal Agendamento Online":
                            Url = "https://ogs-hom.amil.com.br/CanaisDigitais-AgendamentoOnline/";
                            break;

                        case "Portal Beneficiario":
                            Url = "https://ogs-hom.amil.com.br/CanaisDigitais-PortalBeneficiario/";
                            break;

                        case "Portal Credenciado Dental":
                            Url = "https://ogs-hom.amil.com.br/CanaisDigitais-PortalCredenciadoDental/";
                            break;

                        case "Portal Empresa":
                            Url = "https://ogs-hom.amil.com.br/CanaisDigitais-PortalEmpresa/";
                            break;
                    }
                    break;
            }
            return Url;
        }
    }
}