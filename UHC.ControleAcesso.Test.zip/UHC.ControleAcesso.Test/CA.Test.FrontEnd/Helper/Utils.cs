﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace CA.Test.FrontEnd.Helper
{
    class Utils: ConfigReports
    {
        public static int ShortWait = 10;
        public static int MediumWait = 60;
        public static int LongWait = 600;


        public static void PageDown(IWebDriver _driver)
        {
            Actions action = new Actions(_driver);
            action.SendKeys(Keys.PageDown).Build().Perform();
        }

        public static void WaitForElementLoad(IWebDriver _driver, By by, int seconds)
        {

            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(seconds));
            wait.Until(ExpectedConditions.ElementIsVisible(by));

        }

        public static void MoveToElement(IWebDriver _driver, By by)
        {
            IWebElement elemento = _driver.FindElement(by);
            Actions action = new Actions(_driver);
            action.MoveToElement(elemento).Build().Perform();
        }

        public static bool IsElementExists(By by, IWebDriver _driver)

        {
            try
            {
                _driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public static bool IsElementExists(By by, IWebDriver _driver,int seconds)

        {
            try
            {
                WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(seconds));
                wait.Until(ExpectedConditions.ElementIsVisible(by));
                return true;
            }
            catch (Exception )
            {
                return false;
            }
        }

        public static void VerifyPageContais(IWebDriver _driver, string expectedtext)
        {            
            if (_driver.PageSource.Contains(expectedtext))
            {
                Assert.IsTrue(true,"O valor " + expectedtext + " foi localizado na página");
                ReportStep(_driver, "O valor " + expectedtext + " foi localizado na página");
            }
            else
            {
                Assert.Fail("O valor " + expectedtext + " não foi localizado na página");
                ReportStep(_driver, "O valor " + expectedtext + " foi localizado na página");
            }

        }


       static List<TableDataCollection> _tableDataCollection = new List<TableDataCollection>();

        public static void ReadTable(IWebElement table)
        {

            //Lendo todas colunas da tabela

            var columns = table.FindElements(By.TagName("th"));

            // lendo as linhas

            var rows = table.FindElements(By.TagName("tr"));

            // criando os index


            int rowIndex = 0;

            foreach (var row in rows)
            {

                int colIndex = 0;

                var colDatas = row.FindElements(By.TagName("td"));

                foreach (var colValue in colDatas)
                {
                    _tableDataCollection.Add(new TableDataCollection
                    {

                        RowNumber = rowIndex,
                        ColumnName = columns[colIndex].Text,
                        ColumValue = colValue.Text
                    }
                        );
                    //mover para a proxima coluna
                    colIndex++;
                }
                rowIndex++;
            }          

        }

        public static string ReadCell(string columnName, int rownumber)
        {

            var data = (from e in _tableDataCollection
                        where e.ColumnName == columnName && e.RowNumber == rownumber
                        select e.ColumValue).SingleOrDefault();

            return data;

        }


        public static int ReturIndex(string columnName, string valueName)
        {

            var rowIndex = (from e in _tableDataCollection
                        where e.ColumnName == columnName && e.ColumValue == valueName
                        select e.RowNumber).SingleOrDefault();


            return rowIndex;

        }

    }


    public  class  TableDataCollection
    {
        public  int RowNumber { get; set; }
        public  string ColumnName { get; set; }
        public  string ColumValue { get; set; }

    }
}
