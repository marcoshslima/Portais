﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OGS.Framework.Utility;
using Oracle.ManagedDataAccess.Client;
using System.Data.SqlClient;
using OGS.Framework.Setup;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CA.Test.FrontEnd.Helper
{
    class ProcedureHelper:ConfigReports
    {
        public static Array ExecutarBiblioteca(string idBiblioteca = null, string nomeDescricao = null, string qdtLinha = "1") 
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao_proc = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            DataTable dt ;
                
                //Nome da proc q irá executar a procedure, a proc deve estar presente no banco de dados DEV e QA.

                var proc = new OracleCommand("CA_AUTOMACAO.EXECUTAR_BIBLIOTECA", conexao_proc.ConnectDataBase());
                proc.CommandType = CommandType.StoredProcedure;
                proc.CommandTimeout = 1;

                //Parametros de Entrada/Input
                proc.Parameters.Add("P_ID_BIBLIOTECA", OracleDbType.Varchar2).Value = idBiblioteca;
                proc.Parameters["P_ID_BIBLIOTECA"].Direction = ParameterDirection.Input;
                proc.Parameters.Add("P_DESCRICAO", OracleDbType.Varchar2).Value = nomeDescricao;
                proc.Parameters["P_DESCRICAO"].Direction = ParameterDirection.Input;
                proc.Parameters.Add("P_QTD_LINHA", OracleDbType.Int32).Value = qdtLinha;
                proc.Parameters["P_QTD_LINHA"].Direction = ParameterDirection.Input;
                proc.Parameters.Add("P_SERVIDOR", OracleDbType.Varchar2).Value = AmbienteHelper.Ambiente;
                proc.Parameters["P_SERVIDOR"].Direction = ParameterDirection.Input;

                //Parametros de Saída/OutPut
                proc.Parameters.Add("R_Cursor", OracleDbType.RefCursor, ParameterDirection.Output);

                //Executar a proc.
                try
                {
                    proc.ExecuteNonQuery();
                }
                catch (SqlException e)
                {
                    Console.WriteLine(e.ToString());
                } 

                //Criar DataTable
                dt = new DataTable();
                OracleDataAdapter dataAdapter = new OracleDataAdapter(proc);
                dataAdapter.Fill(dt);
                conexao_proc.CloseConnection();

                return dt.Rows[0].ItemArray.ToArray();

        }

        public static void PreencherContato(string mo, int idSistema)
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            try
            {
                conexao.ConnectDataBase();

                OracleParameter[] parametrosContatos = new OracleParameter[] {
                   new OracleParameter("P_LOGIN",mo),
                   new OracleParameter("P_SISTEMA",idSistema),
                   new OracleParameter("P_EMAIL","teste_email@prestadores.amil.com.br"),
                   new OracleParameter("P_DDD",11),
                   new OracleParameter("P_TELEFONE",945678965),
                   new OracleParameter("P_SERVIDOR",AmbienteHelper.Ambiente)
                };

                conexao.ExecuteProcedureParameter("CA_AUTOMACAO.PREENCHER_CONTATO", parametrosContatos.ToArray());
            }
            catch(Exception e)
            {
                Assert.Fail("Erro ao executar a proc Preencher Contato " + e.ToString());
                ReportStep("Erro ao executar a proc Preencher Contato " + e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }
        }

        public static void PreencherPerguntas(string mo)
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            try
            {
                conexao.ConnectDataBase();

                OracleParameter[] parametrosPerguntas = new OracleParameter[] {
                    new OracleParameter("P_LOGIN",mo),
                    new OracleParameter("P_RESP_01","TESTE"),
                    new OracleParameter("P_RESP_02","TESTE"),
                    new OracleParameter("P_RESP_03","TESTE"),
                   new OracleParameter("P_SERVIDOR",AmbienteHelper.Ambiente)
                };

                conexao.ExecuteProcedureParameter("CA_AUTOMACAO.PREENCHER_PERGUNTAS", parametrosPerguntas.ToArray());
            }
            catch (Exception e)
            {
                Assert.Fail("Erro ao executar a proc Preencher Perguntas " + e.ToString());
                ReportStep("Erro ao executar a proc Preencher Perguntas " + e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }
        }

        public static void AlterarSenha(string moCpf,int idSistema)
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            try
            {
                conexao.ConnectDataBase();

                OracleParameter[] parametrosAlterarSenha = new OracleParameter[] {
                    new OracleParameter("P_LOGIN",moCpf),
                    new OracleParameter("P_SISTEMA", idSistema),
                   new OracleParameter("P_SERVIDOR",AmbienteHelper.Ambiente)
                };
                conexao.ExecuteProcedureParameter("CA_AUTOMACAO.ALTERAR_SENHA", parametrosAlterarSenha.ToArray());
            }
            catch (Exception e)
            {
                Assert.Fail("Erro ao executar a proc Alterar Senha " + e.ToString());
                ReportStep("Erro ao executar a proc Alterar Senha " + e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }
        }

        public static void SenhaExpirada(string moCpf, int idSistema)
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            try
            {
                conexao.ConnectDataBase();

                OracleParameter[] parametrosAlterarSenha = new OracleParameter[] {
                    new OracleParameter("P_LOGIN",moCpf),
                    new OracleParameter("P_SISTEMA", idSistema)
                };
                conexao.ExecuteProcedureParameter("CA_AUTOMACAO.SENHA_EXPIRADA", parametrosAlterarSenha.ToArray());
            }
            catch (Exception e)
            {
                Assert.Fail("Erro ao executar a proc Alterar Senha " + e.ToString());
                ReportStep("Erro ao executar a proc Alterar Senha " + e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }
        }
    }
}
