﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoCadastreSe
    {

        #region Links
        public static class LinkCadastreSe
        {
            public static string ClassName = "test_button_first_access";
        }
        #endregion

        #region Campos
        public static class CampoCpfBeneficiario
        {
            public static string ClassName = "test_input_register_login";
        }

        public static class CampoDataNascimento
        {
            public static string ClassName = "test_input_register_birthday";
            public static string Xpath = "//input[@class='rw-widget-input rw-input']";
        }

        public static class CampoDataNascimentoPortalAgendamentoOnline
        {
            public static string Xpath = "//input[@title='Selecionar Data']";
        }


        public static class CampoDDD
        {
            public static string ClassName = "test_input_register_ddd";
        }
        
        public static class CampoCelular
        {
            public static string ClassName = "test_input_register_phone";
        }

        public static class CampoEmail
        {
            public static string ClassName = "test_input_register_email";
        }

        public static class CampoConfirmacaoEmail
        {
            public static string ClassName = "test_input_register_email_confirm";
        }

        public static class CampoSenha
        {
            public static string ClassName = "test_input_register_password";
        }

        public static class CampoConfirmaSenha
        {
            public static string ClassName = "test_input_register_password_confirm";
        }

        public static class CampoCPF
        {
            public static string ClassName = "test_input_register_cpf";

        }

        #endregion

        #region Button

        public static class BtnEnviar
        {
            public static string ClassName = "test_button_send_register";
        }

        public static class BtnIdentificacao
        {
            public static string Xpath = "//div[contains(text(),'Identificação')]";
        }

        public static class BtnContato
        {
            public static string Xpath = "//div[contains(text(),'Contato')]";
        }

        public static class BtnSenha
        {
            public static string Xpath = "//div[contains(text(),'Senha')]";
        }

        #endregion

        #region Mensagem

        public static class MensagemCadastro
        {
            public static string ClassName = "alert__message";
        }
        #endregion

    }
}
