﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoEsqueceuSenha
    {
        #region Botoes
        public static class BtnEsqueceuSenha
        {
            public static string ClassName = "test_button_password_recovery";
        }

        public static class BtnConfirmar
        {
            public static string ClassName = "test_button_identification_send";
        }

        public static class BtnConfirmarToken
        {
           public static string ClassName = "test_button_token";
        }

        public static class BtnConfirmarOperacao
        {
            public static string Xpath = "//section[@class='new-password']//button[@type='button'][contains(text(),'Confirmar')]";
            public static string ClassName = "test_input_newpassword_send";
        }

        public static class BtnConfirmarMeioRecuperacao
        {
            public static string ClassName = "test_button_emailtab";
        }

        public static class BtnConfirmarMeioRecuperacao_SMS
        {
            public static string ClassName = "test_button_smstab";
        }

        public static class BtnFaleConosco
        {
            public static string Xpath = "//span[contains(text(),'Fale Conosco')]";
        }

        public static class BtnEnviarFaleConosco
        {
            public static string ClassName = "test_button_send_register_update";
        }

        public static class BtnConfirmarPerguntas
        {
            public static string ClassName = "test_button_questions_tab";
        }

        

        #endregion

        #region Campos
        public static class CampoCPFouBeneficiario
        {
            public static string Classname = "test_input_identification";

            public static string GetValue(string option)
            {
                return "//li[contains(text(),'"+option+"')]";
            }
        }

        public static class CampoEmail
        {
            public static string ClassName = "test_dropdownList_emailtab";
        }

        public static class ComboEmailSms
        {
            public static string ClassName = "search-select";
        }

        public static class CampoToken
        {
            public static string ClassName = "test_input_token";
            public static string Xpath = "//input[@class='test_input_token  form-control']";
        }

        public static class CampoNovaSenha
        {
            public static string ClassName = "test_input_newpassword";
        }

        public static class CampoConfirmeNovaSenha
        {
            public static string ClassName = "test_input_newpassword_confirm";
            public static string Xpath = "//input[contains(@placeholder,'Confirmação de nova senha')]";

        }

        public static class CampoSMS
        {
            public static string ClassName = "test_dropdownList_smstab";
        }

        public static class CampoNovoEmail
        {
            public static string Name = "updateDataNewEmail";
        }

        public static class CampoConfirmeNovoEmail
        {
            public static string Classname = "test_input_register_update_email_confirm";
        }

        public static class CampoDDDCelular
        {
            public static string Classname = "test_input_register_update_ddd";
        }

        public static class CampoCelular
        {
            public static string Classname = "test_input_register_update_phone";
        }
        
        public static class CampoProtocoloBeneficiario
        {
            public static string Xpath = "//body//div[@id='root']//div[@class='app']//div[@id='login']//div[@class='card']//div[@class='card-body']//section[@class='authentication']//section[@class='login-form']//form//div[@class='form-group']//div[@class='row']//div[@class='col']//div//div//p[4]";
        }

        public static class CampoProtocoloAgendamentoOnline
        {
            public static string Xpath = "//body//div[@id='root']//div[@id='app']//div[@id='container']//div[@class='row']//div[@class='col-md-12']//div[@class='login-page']//div[@class='row']//div[@class='col-md-5']//div[@class='login']//div[@class='card']//div[@class='card-body']//div[@class='card__body--login']//section[@class='authentication']//section[@class='login-form']//form//div[@class='form-group']//div[@class='row']//div[@class='col']//div//div//p[4]";
        }

        public static class CampoPerguntas
        {
            public static string Classname = "test_dropdownList_questions_tab";
        }
        #endregion

        #region RadioButtons
        public static class OptEmail
        {
            public static string Xpath = "//section[@class='means-of-recovery']//label[1]//div[1]";
        }

        public static class OptSms
        {
            public static string Xpath = "//section[@class='means-of-recovery']//label[2]//div[1]";
        }

        public static class OptPerguntas
        {
            public static string Xpath = "//section[@class='means-of-recovery']//label[3]//div[1]";

        }

        public static class OptEmail_CredenciadoDental
        {
            public static string Xpath = "//*[@id='radio-email-undefined']";
        }
        public static class OptSms_CredenciadoDental
        {
            public static string Xpath = "//*[@id='radio-sms-undefined']";
        }

        #endregion

        #region Mensagens
        public static class Mensagens
        {
            public static string SenhaAlteradaSucesso = "alert__message";
        }
        #endregion
    }
}
