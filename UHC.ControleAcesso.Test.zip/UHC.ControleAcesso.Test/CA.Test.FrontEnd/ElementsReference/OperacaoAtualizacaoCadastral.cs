﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoAtualizacaoCadastral
    {

        #region Portais Empresa e Credenciado Dental

        #region Campos
        public static class CampoNomePrestador
        {
            public static string ClassName = "test_input_register_update_name";
        }

        public static class CampoCPF_CNPJ
        {
            public static string ClassName = "test_input_register_update_cpf";
        }

        public static class CampoDD
        {
            public static string ClassName = "test_input_register_update_ddd";
        }

        public static class CampoFone
        {
            public static string ClassName = "test_input_register_update_phone";
        }

        public static class CampoSenha
        {
            public static string ClassName = "test_input_register_update_password";
        }

        public static class CampoConfirmeSuaSenha
        {
            public static string Name = "registerUpdatePasswordConfirm";
        }
        public static class CampoEmail
        {
            public static string ClassName = "test_input_register_update_email";
        }

        public static class CampoConfirmeEmail
        {
            public static string ClassName = "test_input_register_update_email_confirm";
        }
        #endregion

        #region Botões
        public static class BtnIdentificacao
        {
            public static string Xpath = "//div[contains(text(),'Identificação')]";
        }

        public static class BtnContato
        {
            public static string Xpath = "//div[contains(text(),'Contato')]";
        }

        public static class BtnSenhaOpcional
        {
            public static string Xpath = "//div[contains(text(),'Senha (Opcional)')]";
        }

        public static class BtnPincel
        {
            public static string ClassName = "register-update__pencil";
        }

        public static class BtnPincel2
        {
            public static string ClassName = "icon-pencil";
        }

        public static class BtnAtualizar
        {
            public static string ClassName = "test_button_send_register_update";
        }


        #endregion

        #region mensagens
        public static class Mensagens
        {
            public static string MsgAtualizeseuCadastro(string msg)
            {
                return "//*[contains(text(),'" + msg + "')]";
            }

        }

        #endregion
        #endregion

        #region Portal Agendamento Online

        #region Campos

        public static class Email
        {
            public static string Id = "email";
        }

        public static class EmailCheckBox
        {
            public static string Id = "checkbox-email";
        }

        public static class TelefoneResidencial
        {
            public static string Name = "residencial";
        }

        public static class Celular1
        {
            public static string Id = "celular1";
        }

        public static class TelefoneComercial
        {
            public static string Name = "comercial";
        }

        public static class Celular2
        {
            public static string Id = "celular2";
        }

        #endregion

        #region Botões
        public static class Salvar
        {
            public static string Id = "button-save";
        }
        #endregion

        #endregion


    }
}
