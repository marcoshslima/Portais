﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
   public static class OperacaoSenhaExpirada
    {
        public static class ComponenteSenhaExpirada
        {
            public static string PropertieA = "div[class~='test_form_password_expired']";//Portal Empresa, Credenciado Dental
            public static string PropertieB = "div.form-group:nth-child(5) > div.row";//Agendamento
            public static string PropertieC = "section.login-form form:nth-child(1) > div.form-group:nth-child(6)";//Beneficiario
        }

        #region Campos
        public static class CampoUsuario
        {
            public static string Propertie = "input[class~='test_input_username']";
        }

        public static class CampoSenha
        {
            public static string Propertie = "input[class~='test_input_password']";
        }


        public static class CampoTrocaSenha
        {
            public static string ClassName = "test_input_password_expired_password";
        }

        public static class CampoConfirmeTrocaSenha
        {
            public static string ClassName = "test_input_password_expired_password_confirm";
        }

        #endregion

        #region Botões
        public static class BtnEntrar
        {
            public static string Propertie = "button[class~='test_button_login']";
        }

        public static class BtnAtualizar
        {
            public static string Class = "test_button_send_password_expired";
        }

        #endregion

        #region Mensagem
        public static class MsgObrigatório
        {
            public static string Propertie = "div[class~='invalid-feedback']";
        }

        public static class MsgInvalido
        {
            public static string Propertie = "//div[@class='[ test_ipt_notclient_cpf-error ] input-redux__control input-redux__control--active']//span[@class='input-redux__error'][text()='CPF inválido']";
        }

        public static class MsgValido
        {
            public static string Propertie = "//div[@class='[ test_ipt_notclient_cpf-error ] input-redux__control input-redux__control--active']//span[@class='input-redux__error'][text()='CPF inválido']";
        }

        public static class Mensagens
        {

            public static string SenhaExpiradaClassName = "alert__message";

        }


        #endregion
    }
}