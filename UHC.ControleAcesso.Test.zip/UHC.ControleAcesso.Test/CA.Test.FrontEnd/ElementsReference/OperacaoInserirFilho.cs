﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoInserirFilho
    {


        #region Empresas

        public static class MenuControleAcessoPortal
        {
            public static string Xpath = "//a[contains(text(),'Controle de Acesso ao Portal')]";
        }

        public static class AdicioanrAdministrador
        {
            public static string Xpath = "//a[@class='custom-link']";
        }

        #region Campos

        public static class CampoNome
        {
            public static string Name = "name";
        }
        public static class CampoEmail
        {
            public static string Name = "email";
        }

        public static class CampoTelefone
        {
            public static string Name = "phone";
        }

        public static class CampoNomeAlterar
        {
            public static string Xpath = "//div[@class='collapse show']//input[@name='name']";
        }
        public static class CampoEmailAlterar
        {
            public static string Xpath = "//div[@class='collapse show']//input[@name='email']";
        }

        public static class CampoTelefoneAlterar
        {
            public static string Xpath = "//div[@class='collapse show']//input[@name='phone']";
        }


        //div[@class='collapse show']//input[@name='phone']

        public static class LikSelecionarTodos
        {
            public static string Xpath = "//div[@class='mb-2 col-lg-12']//a";
        }

        public static class BtnSalvar
        {
            public static string Xpath = "//button[@type='submit']";
        }


        public static class BtnSalvarAlteracao
        {
            public static string Xpath = "//div[@class='collapse show']//button[@type='submit'][contains(text(),'Salvar')]";
        }
        

        public static class BtnSair
        {
            public static string Xpath = "//a[contains(text(),'Sair')]";
        }
            
        public static class BtnOk
        {
            public static string Xpath = "//button[text()='Ok']";
        }

        public static class BtnSim
        {
            public static string Xpath = "//button[text()='Sim']";
        }

        public static class BtnMenu
        {
            public static string Xpath = "//i[@class='icon icon-angle-down undefined']";
        }
        
        public static class CodigoUsuarioFilho
        {
            public static string Xpath = "//tbody//tr[1]//td[1]";
        }

        public static class Mensagens
        {
            public static string Xpath = "//div[@class='modal-body']";
        }


        public static class Table
        {
            public static string Xpath = "//div[@class='expansive-table']";
        }

        public static class EditarUsuarioFilho
        {
            public static string Xpath = "//tbody//tr[1]//td[5]//ul[1]//li[1]//span[1]";
        }

        public static class EditarUsuarioFilhoX
        {

            public static string Editar(int index)
            {
                return "//tbody//tr["+index+"]//td[5]//ul[1]//li[1]//span[1]";
            }
        }

        public static class ExcluirUsuarioFilhoX
        {

            public static string Excluir(int index)
            {
                return "//tbody//tr[" + index + "]//td[5]//ul[1]//li[2]//span[1]";
            }
        }

        public static class AlterarPerfilTodos
        {
            public static string XPath= "//div//div[@class='collapse show']//div[@class='custom-expansive-table-details']//div//div[1]//div[1]//a[1]";
        }

        public static class AlterarContratosTodos
        {
            public static string XPath = "//div//div[@class='collapse show']//div[@class='mb-4 mt-4']//div//div[2]//div[1]//a[1]";
        }
        #endregion

        #endregion


        #region Credenciado Dental

        public static class BtnNovoFuncionario
        {
            public static string Xpath = "//button[contains(text(),'Novo funcionário')]";
        }

        public static class BtnSalvarFuncionario
        {
            public static string Xpath = "//button[contains(text(),'Salvar')]";
        }

        public static class BtnVoltar
        {
            public static string Xpath = "//button[@class='back-button btn btn-secondary [ custom-button ]']";
        }

        public static class CampoNome_Completo
        {
            public static string Name = "userCreate.nome";            
        }

        public static class CampoCPF
        {
            public static string Name = "userCreate.cpf";
        }

        public static class CampoEmailDental
        {
            public static string Name = "userCreate.email";
        }

        public static class CampoPerfil
        {
            public static string Xpath = "//div[@id='rw_3_input']//span[@class='rw-placeholder'][contains(text(),'Selecione')]";

            public static string GetPerfil(string perfil)
            {
                return "//li[contains(text(),'"+perfil+"')]";
                
            }

            public static string GetNomePerfil(string nome_perfil)
            {
                return "//h4[contains(text(),'" + nome_perfil + "')]";
            }

        }


        public static class MenuCredenciadoDental
        {
           public static string Xpath = "//a[@class='title']"; 
        }

        public static class MenuConfiguracoes
        {
            public static string Xpath = "//a[contains(text(),'Configurar permissões')]";
        }

        public static class MsgSucessoDental
        {
            public static string Xpath = "//div[@class='access-manage-msg-success show']";

        }

        #endregion
        }
}
