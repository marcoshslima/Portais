﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoLogin
    {
        public static class ComponenteLogin
        {
            public static string Propertie = "section.authentication";
            //public static string PropertieA = "section[class~='test_form_login']";
            //public static string PropertieB = "div[class~='login']";//Credenciado Dental
        }

        #region Link
        public static class LinkEsqueceuSenha
        {
            public static string Propertie = "input[class~='test_button_password_recovery']";
        }
        public static class LinkCadastreSe
        {
            public static string Propertie = "input[id~='check-teste']";
        }
        #endregion

        #region checkbox
        public static class CheckLembrarDeMim
        {
            public static string Propertie = "input[id~='check-teste']";
        }
        #endregion

        #region Campos
        public static class CampoUsuario
        {
            public static string Propertie = "input[class~='test_input_username']";
        }

        public static class CampoSenha
        {
            public static string Propertie = "input[class~='test_input_password']";
        }
        #endregion

        #region Botões
        public static class BtnEntrar
        {
            public static string Propertie = "button[class~='test_button_login']";
        }
        #endregion        

        #region Mensagem
        public static class MsgObrigatório
        {
            public static string Propertie = "div[class~='invalid-feedback']";
        }

        public static class MsgInvalido
        {
            public static string Propertie = "//div[@class='[ test_ipt_notclient_cpf-error ] input-redux__control input-redux__control--active']//span[@class='input-redux__error'][text()='CPF inválido']";
        }
        #endregion

        #region WalkTrough
        public static class WalkTroughConhecaSeuNovoPortal
        {
            public static string Propertie = "div[class~='walktrough']";
        }

        public static class WalkTroughConhecaSeuNovoPortalBntFechar
        {
            public static string Propertie = "div[class~='walktrough'] > button";
        }

        public static class WalkTroughPendencias
        {
            public static string Propertie = "div[class~='modal-content']";
        }

        public static class WalkTroughPendenciasBntOK
        {
            public static string Propertie = "div[class~='modal-footer'] > button[class~='btn-primary']";
        }

        public static class WalkTroughPendenciasBtnFechar
        {
            public static string Propertie = "span[class~='close-modal']";
        }

        public static class WalkTroughAtualizeSeusDados
        {
            public static string Propertie = "div[class~='modal-content']";
        }

        public static class WalkTroughAtualizeSeusDadosBntContinue
        {
            public static string Propertie = "div[class~='modal-footer'] > button[class~='btn-primary']";
        }
        #endregion

        #region AreaLogada
        public static class AreaLogadaMenu
        {
            public static string Propertie = "div[class~='sidebar']:first-child";
        }

        public static class AreaLogadaBntSair
        {
            public static string PropertieA = "i[class~='icon-angle-down']";
            public static string PropertieB = "i[class~='icon-inputexpand']:first-child";//Agendamneto Online
            public static string PropertieC = "a[class~='title']";//Credenciado Dental            
        }

        public static class AreaLogadaDadosUsuarioNome
        {
            public static string PropertieA = "div[class~='navbar-default__content__user-name']";
            public static string PropertieB = "a[class~='title']";//CredenciadoDental
            public static string GetName(string name)
            {
                return  "//a[contains(text(),'"+name+"')]";
            }
                
                

        }

        public static class AreaLogadaDadosUsuarioMarcaOtica
        {
            public static string Propertie = "div[class='navbar-default__content__user-opticmark']";
        }




        #endregion

        #region Mensagens

        public static class Mensagens
        {
            public static string AlertaClassName = "alert__message";
        }

        #endregion
    }
}