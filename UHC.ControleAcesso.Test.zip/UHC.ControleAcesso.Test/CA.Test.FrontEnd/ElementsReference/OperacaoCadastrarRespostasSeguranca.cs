﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoCadastrarRespostasSeguranca
    {
        #region Menu
        public static class IconeMenu
        {
            public static string ClassName = "icon-angle-down";
        }

        public static class MenuCadastro
        {
            public static string Xpath = "//a[contains(text(),'Cadastro')]";
        }
        public static class MenuCadastrarRespostasSeguranca
        {
           public static string Xpath = "//p[@class='change-password__question-group__question']";
        }

        public static class MenuCliqueAqui
        {
            public static string Xpath = "//span[contains(text(),'clique aqui.')]";
        }

        
        #endregion

        #region Campos
        public static class Resposta01
        {
            public static string Name = "answer_one";
        }
        public static class Resposta02
        {
            public static string Name = "answer_two";
        }
        public static class Resposta03
        {
            public static string Name = "answer_three";
        }

        public static class Cep
        {
            public static string Id = "enderecoResidencial";
        }

        public static class Endereco
        {
            public static string Name = "personalData.enderecoResidencial.logradouroField";
        }

        public static class Bairro
        {
            public static string Name = "personalData.enderecoResidencial.bairroField";
        }
        public static class Cidade
        {
            public static string Name = "personalData.enderecoResidencial.cidadeField";
        }

        public static class UF
        {
            public static string Name = "personalData.enderecoResidencial.ufField";
        }


        public static class Numero
        {
            public static string Name = "personalData.enderecoResidencial.numeroField";
        }

        public static class Cep_Correspondencia
        {
            public static string Id = "enderecoCorrespondencia";
        }

        public static class Numero_Correspondencia
        {
            public static string Name = "personalData.enderecoCorrespondencia.numeroField";
        }

        public static class Cep_Cobranca
        {
            public static string Id = "enderecoCobranca";
        }

        public static class Numero_Cobranca
        {
            public static string Name = "personalData.enderecoCobranca.numeroField";
        }

        public static class CheckCorrespondencia
        {
            public static string Xpath = "//div[@class='form-group']//div[1]//label[1]//div[1]";
        }

        public static class CheckCobranca
        {
            public static string Xpath = "//div[@class='form-group']//div[2]//label[1]//div[1]";
        }


        public static class FieldValue          
        {
            public static string Campo(string valor)
            {
                return "//input[@value='"+valor+"']";
            } 
        }

        #endregion

        #region Botões
        public static class BtnSalvarCadastro
        {
            public static string Xpath = "//button[@type='submit']";
        }
        #endregion

        #region Mensagens
        public static class Msg
        {
            public static string ClassName =  "alert__message ";
        }
        #endregion
    }
}
