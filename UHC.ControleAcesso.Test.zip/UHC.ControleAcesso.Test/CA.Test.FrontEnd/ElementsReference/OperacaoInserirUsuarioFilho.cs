﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA.Test.FrontEnd.ElementsReference
{
    class OperacaoInserirUsuarioFilho
    {
        
        #region Credenciado Dental
            public static class Menu
            {
                public static string Xpath = "//li[contains(@class,'isSubordinate header__nav__submenu')]";
            }

            public static class ConfigurarPermissoes
            {
                public static string Xpath = "//a[contains(text(),'Configurar permissões')]";
            }
            #region Botoes

            public static class BtnNovoFuncionario
            {
                public static string ClassName = "guide__header-new-button";
            }

            public static class BtnSalvar
            {
                public static string ClassName = "save-button";
            }

            public static class BtnCancelar
            {
                public static string ClassName = "back-button";
            }
        #endregion

        #region Campos

        public static class CampoNomeCompleto
            {
                public static string Name = "userCreate.nome";
            }

            public static class CampoCPF
            {
                public static string ClassName = "userCreate.cpf";
            }
            public static class CampoEmail
            {
                public static string ClassName = "userCreate.email";
            }
            public static class CampoPerfil
            {

                public static string Xpath = "//div[@id='rw_3_input']//div[contains(@class,'rw-input rw-dropdown-list-input')]";
                public static string Perfil(string valor)
                {
                    return "//li[contains(text(),'"+valor+"')]";
                } 
            }
        #endregion

        #endregion

    }
}
