﻿using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using CA.Test.FrontEnd.Helper;
using CA.Test.FrontEnd.ElementsReference;
using OGS.Framework.Utility;
using Test.Middleware.Bus.Helper;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using OGS.Framework.Setup;
using TechTalk.SpecFlow.Assist;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Framework.Utilities;


namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class AtualizacaoCadastral :ConfigReports
    {
        IWebDriver _driver;
        private Array resultados;
        public AtualizacaoCadastral(IWebDriver _driver)
        {
            this._driver = _driver;
        }

        #region When

        [When(@"identificado Usuário com a senha '(.*)' expirada  '(.*)' com usuário onde precise efetuar a atualização de cadastral")]
        public void WhenIdentificadoUsuarioComASenhaExpiradaComUsuarioOndePreciseEfetuarAAtualizacaoDeCadastral(string portal, string tipo_acesso)
        {
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);

            try
            {
                //conexao.ConnectDataBase();
                //string usuarioSenhaExpirada = conexao.SelectCommand(SqlHelper.UsuarioAtualizacaoCadastral(portal, tipo_acesso, ""), null);
                //var usuario_aux = usuarioSenhaExpirada.Split(';').ToArray();

                switch (portal)
                {
                    case "Portal Credenciado Dental":
                        if (tipo_acesso.Equals("Pai"))
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL CREDENCIADO DENTAL PAI");
                        }
                        else
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL CREDENCIADO DENTAL FILHO");
                        }

                        break;
                    case "Portal Empresa":
                        if (tipo_acesso.Equals("Pai"))
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL EMPRESA PAI");
                        }
                        else
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL EMPRESA FILHO");
                        }

                        break;
                }

                ScenarioContext.Current.Add("Usuario", resultados.GetValue(0));
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1));
                ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0));

                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, resultados.GetValue(0).ToString(), 10);
                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);


            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
                Assert.Fail(e.ToString());
            }

        }



        [When(@"preencher os campos abaixo:")]
        public void WhenPreencherOsCamposAbaixo(Table table)
        {

            dynamic dados = table.CreateDynamicInstance();


            //if (Utils.IsElementExists(By.ClassName(OperacaoAtualizacaoCadastral.CampoNomePrestador.ClassName), _driver))
            //ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoNomePrestador.ClassName, "Fabio Junior de Almeida", 10);

            if (Utils.IsElementExists(By.ClassName(OperacaoAtualizacaoCadastral.CampoCPF_CNPJ.ClassName), _driver))
                ElementActions.SetText(_driver,"Classname",OperacaoAtualizacaoCadastral.CampoCPF_CNPJ.ClassName,Convert.ToString(CNPJgenerator.GeradorCPF()),10);

            if (Utils.IsElementExists(By.XPath(OperacaoAtualizacaoCadastral.BtnContato.Xpath), _driver))
                ElementActions.ClickOnElement(_driver,"Xpath" ,OperacaoAtualizacaoCadastral.BtnContato.Xpath, 2);

            Verification.Wait(2);

            if (Utils.IsElementExists(By.ClassName(OperacaoAtualizacaoCadastral.BtnPincel.ClassName), _driver)) ElementActions.ClickOnElement(_driver, "Classname", OperacaoAtualizacaoCadastral.BtnPincel.ClassName, 2);

            if (Utils.IsElementExists(By.ClassName(OperacaoAtualizacaoCadastral.BtnPincel2.ClassName), _driver)) ElementActions.ClickOnElement(_driver, "Classname", OperacaoAtualizacaoCadastral.BtnPincel2.ClassName, 2);


            ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoEmail.ClassName, dados.EMAIL, 10);
            ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoConfirmeEmail.ClassName, dados.CONFIRME_EMAIL, 10);

            Verification.Wait(2);

            ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoDD.ClassName, Convert.ToString(dados.DD), 10);
            ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoFone.ClassName, Convert.ToString(dados.TELEFONE), 10);

            if (Utils.IsElementExists(By.XPath(OperacaoAtualizacaoCadastral.BtnSenhaOpcional.Xpath), _driver))
            {
                ElementActions.ClickOnElement(_driver, "Xpath", OperacaoAtualizacaoCadastral.BtnSenhaOpcional.Xpath, 2);
                ElementActions.SetText(_driver, "Classname", OperacaoAtualizacaoCadastral.CampoSenha.ClassName, Convert.ToString(dados.SENHA), 10);
                //ElementActions.SetText(_driver, "Name", OperacaoAtualizacaoCadastral.CampoConfirmeSuaSenha.Name, Convert.ToString(dados.CONFIRMESUASENHA), 10);
                _driver.FindElement(By.Name("registerUpdatePasswordConfirm")).SendKeys(Convert.ToString(dados.CONFIRMESUASENHA));
            }

         }

        [When(@"clicar no botão Atualizar \[Atualize seu Cadastro]")]
        public void WhenClicarNoBotaoAtualizarAtualizeSeuCadastro()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoAtualizacaoCadastral.BtnAtualizar.ClassName, 2);

        }

        [When(@"identificado Usuário com a senha '(.*)' expirada  '(.*)' com usuário onde precise efetuar a atualização de cadastral ""(.*)""")]
        public void WhenIdentificadoUsuarioComASenhaExpiradaComUsuarioOndePreciseEfetuarAAtualizacaoDeCadastral(string portal, string tipo_acesso, string tipo_beneficiario)
        {

            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);

            try
            {
                //conexao.ConnectDataBase();
                //string usuarioSenhaExpirada = conexao.SelectCommand(SqlHelper.UsuarioAtualizacaoCadastral(portal, "", tipo_beneficiario), null);
                //var usuario_aux = usuarioSenhaExpirada.Split(';').ToArray();
                string usuarioSenhaExpirada;
                //string cpf = "";


                if (tipo_acesso.Equals("Titular"))
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL BENEFICIARIO TITULAR");
                }
                else
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ATUALIZACAO CADASTRAL BENEFICIARIO DEPENDENTE");
                }


                if (tipo_acesso.Equals("MO"))
                {
                    usuarioSenhaExpirada = resultados.GetValue(0).ToString();
                }
                else
                {
                    //cpf = Convert.ToInt64(resultados.GetValue(1));
                    usuarioSenhaExpirada = Convert.ToInt64(resultados.GetValue(1)).ToString(@"000\.000\.000\-00");
                    //usuarioSenhaExpirada = cpf.ToString("D11");
                    

                }

                ScenarioContext.Current.Add("Usuario", usuarioSenhaExpirada);
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(2));
                ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0));
                ScenarioContext.Current.Add("P_LOGIN", usuarioSenhaExpirada);
                

                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, usuarioSenhaExpirada, 10);
                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
            }
        }


        [When(@"preencher os campos abaixo da tela \[Dados Cadastrais]:")]
        public void WhenPreencherOsCamposAbaixoDaTelaDadosCadastrais(Table table)
        {
            //Preenchendo os campos da tela "Dados Cadastrais"

            dynamic tab = table.CreateDynamicInstance();

            
            ElementActions.SetText(_driver, "ID", OperacaoAtualizacaoCadastral.Email.Id, tab.E_mail, 10);

            if(tab.Tipo_Aviso == " E-mail")
                ElementActions.ClickOnElement(_driver, "ID", OperacaoAtualizacaoCadastral.EmailCheckBox.Id, 10);

            ElementActions.SetText(_driver, "NAME", OperacaoAtualizacaoCadastral.TelefoneResidencial.Name,Convert.ToString(tab.Telefone_Residecial) ,10);
            ElementActions.SetText(_driver, "ID", OperacaoAtualizacaoCadastral.Celular1.Id,Convert.ToString(tab.Celular_1) ,10);
            ElementActions.SetText(_driver, "NAME", OperacaoAtualizacaoCadastral.TelefoneComercial.Name, Convert.ToString(tab.Telefone_Comercial), 10);
            ElementActions.SetText(_driver, "ID", OperacaoAtualizacaoCadastral.Celular2.Id, Convert.ToString(tab.Celular_2), 10);

        }

        [When(@"clicar no botão Salvar da tela  \[Dados Cadastrais]")]
        public void WhenClicarNoBotaoSalvarDaTelaDadosCadastrais()
        {
            ElementActions.ClickOnElement(_driver, "ID", OperacaoAtualizacaoCadastral.Salvar.Id, 10);
        }
        
        #endregion

        #region Then
        [Then(@"o sistema deve exibir a mensagem ""(.*)""")]
        public void ThenOSistemaDeveExibirAMensagem(string msg)
        {
            Verification.VerifyElementExists(_driver, "Xpath",OperacaoAtualizacaoCadastral.Mensagens.MsgAtualizeseuCadastro(msg), 120);
        }


        [Then(@"o sistema deve exibir os campos abaixo")]
        public void ThenOSistemaDeveExibirOsCamposAbaixo(Table table)
        {
            //Campos do Portal Agendamento Online
            Verification.VerifyElementExists(_driver, "ID",OperacaoAtualizacaoCadastral.Email.Id, 10);
            Verification.VerifyElementExists(_driver, "ID", OperacaoAtualizacaoCadastral.EmailCheckBox.Id, 10);
            Verification.VerifyElementExists(_driver, "NAME", OperacaoAtualizacaoCadastral.TelefoneResidencial.Name, 10);
            Verification.VerifyElementExists(_driver, "ID", OperacaoAtualizacaoCadastral.Celular1.Id, 10);
            Verification.VerifyElementExists(_driver, "NAME", OperacaoAtualizacaoCadastral.TelefoneComercial.Name, 10);
            Verification.VerifyElementExists(_driver, "ID", OperacaoAtualizacaoCadastral.Celular2.Id, 10);
            

        }


        #endregion

    }
}
