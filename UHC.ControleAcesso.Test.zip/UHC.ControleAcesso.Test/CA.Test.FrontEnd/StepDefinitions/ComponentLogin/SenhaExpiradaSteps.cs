﻿using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using CA.Test.FrontEnd.Helper;
using CA.Test.FrontEnd.ElementsReference;
using OGS.Framework.Utility;
using Test.Middleware.Bus.Helper;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using OGS.Framework.Setup;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class SenhaExpiradaSteps : ConfigReports
    {
        IWebDriver _driver;
        private Array resultados;
        public SenhaExpiradaSteps(IWebDriver _driver)
        {
            this._driver = _driver;
        }

        #region When

        [When(@"clicar no botão Entrar com usuário senha expirada")]
        public void WhenClicarNoBotaoEntrarComUsuarioSenhaExpirada()
        {
            ElementActions.ClickOnElement(_driver,"CSS",OperacaoSenhaExpirada.BtnEntrar.Propertie,2);
            Verification.Wait(5);
        }
        
        [When(@"clicar no botão Atualizar")]
        public void WhenClicarNoBotaoAtualizar()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoSenhaExpirada.BtnAtualizar.Class,2);
        }

        [When(@"preencher o campo Senha ""(.*)"" e Confirme sua Senha ""(.*)""")]
        public void WhenPreencherOCampoSenhaEConfirmeSuaSenha(string senha, string confirme_senha)
        {
            ScenarioContext.Current.Add("NovaSenha",confirme_senha);
            ElementActions.SetText(_driver,"ClassName",OperacaoSenhaExpirada.CampoTrocaSenha.ClassName,senha,2);
            _driver.FindElement(By.ClassName(OperacaoSenhaExpirada.CampoTrocaSenha.ClassName)).SendKeys(Keys.Tab);
            Verification.Wait(2);
            ElementActions.SetText(_driver, "ClassName", OperacaoSenhaExpirada.CampoConfirmeTrocaSenha.ClassName,confirme_senha ,2);
            Verification.Wait(2);
        }


        [When(@"preecnher os campos \[NovaSenha] e \[ConfirmeSuaSenha]")]
        public void WhenPreecnherOsCamposNovaSenhaEConfirmeSuaSenha()
        {

            Random rdn = new Random();

            string senhaAleatoria = rdn.Next(101, 2999).ToString();
            string senha = "Amil@" + senhaAleatoria;
            ElementActions.SetText(_driver, "ClassName", OperacaoSenhaExpirada.CampoTrocaSenha.ClassName, senha, 2);
            Verification.Wait(2);
            _driver.FindElement(By.ClassName(OperacaoSenhaExpirada.CampoTrocaSenha.ClassName)).SendKeys(Keys.Tab);
            ElementActions.SetText(_driver, "ClassName", OperacaoSenhaExpirada.CampoConfirmeTrocaSenha.ClassName, senha, 2);
            ScenarioContext.Current.Add("NovaSenha", senha);
        }


        [When(@"identificado Usuário com a senha '(.*)' expirada  '(.*)'")]
        public void WhenIdentificadoUsuarioComASenhaExpirada(string portal, string tipo_acesso)
        {
           // string sql = "";
           // string resultado = "";
           try
            {
                switch (ScenarioContext.Current.Get<string>("portal"))
                {

                    case "Portal Empresa":

                        if (tipo_acesso.Contains("Pai"))
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaPaiSemConvivencia(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO PAI SEM CONVIVENCIA");
                        }
                        else
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaFilhoSemConvivencia(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO FILHO SEM CONVIVENCIA");

                        }
                        break;

                    case "Portal Credenciado Dental":
                        if (tipo_acesso.Contains("Pai"))
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalPaiSemConvivencia(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL PAI SEM CONVIVENCIA");
                        }
                        else
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalFilhoSemConvivencia(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO SEM CONVIVENCIA");
                        }
                        break;
                }

                //resultado = conexao.SelectCommand(sql, null);
                //var aux_resultado = resultado.Split(';').ToArray();

                //string usuarioSenhaExpirada = conexao.SelectCommand(SqlHelper.UsuarioSenhaExpirada(portal, tipo_acesso,""), null);
                ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Usuario", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1).ToString());

                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));
                ProcedureHelper.AlterarSenha(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));

                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, resultados.GetValue(0).ToString(), 10);
                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
                Assert.Fail(e.ToString());
            }
        }


        [When(@"prencher os campos com o usuário e senha alterada")]
        public void WhenPrencherOsCamposComOUsuarioESenhaAlterada()
        {

            string usuario = ScenarioContext.Current.Get<String>("Usuario");
            string nova_senha = ScenarioContext.Current.Get<String>("NovaSenha");
            
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, usuario, 10);
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, nova_senha, 10);

        }


        [When(@"identificado Usuário com a senha '(.*)' expirada '(.*)' E que seja um beneficiario '(.*)'")]
        public void WhenIdentificadoUsuarioComASenhaExpiradaEQueSejaUmBeneficiario(string portal, string tipo_acesso, string tipo_beneficiario)
        {
            //string sql = "";
            //string resultado = "";
            string  usuarioSenhaExpirada = "";
           try
            {
                 // sql = conexao.SelectCommand(SqlHelper.GetBeneficiarioSemConvivencia(),null);
                //resultado = conexao.SelectCommand(sql.Replace("tipo_beneficiario", tipo_beneficiario), null);

                if (tipo_beneficiario.Equals("T"))
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "BENEFICIARIO SEM CONVIVENCIA TITULAR");
                }
                else
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "BENEFICIARIO SEM CONVIVENCIA DEPENDENTE");
                }

                if (tipo_acesso.Equals("MO"))
                {
                    usuarioSenhaExpirada = resultados.GetValue(0).ToString();
                }
                else
                {
                    usuarioSenhaExpirada = Convert.ToInt64(resultados.GetValue(2)).ToString(@"000\.000\.000\-00");

                }

                ScenarioContext.Current.Add("Usuario", usuarioSenhaExpirada);
                ScenarioContext.Current.Add("UsuarioAux", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(3).ToString());
                ScenarioContext.Current.Add("P_LOGIN", usuarioSenhaExpirada);

                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(1)));
                ProcedureHelper.SenhaExpirada(resultados.GetValue(2).ToString(), Convert.ToInt32(resultados.GetValue(1)));


                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, usuarioSenhaExpirada, 10);
                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
            }
        }

        #endregion

        #region Then
        
        [Then(@"clicar no botão Atualizar")]
        public void ThenClicarNoBotaoAtualizar()
        {
            ElementActions.ClickOnElement(_driver, "ClassName",OperacaoSenhaExpirada.BtnAtualizar.Class,2);
        }

        
        [Then(@"o sistema deve exibir a mensagem ""(.*)""\.")]
        public void ThenOSistemaDeveExibirAMensagem_(string msg)
        {
            Verification.VerifyElementTextMatches(_driver, "ClassName", OperacaoSenhaExpirada.Mensagens.SenhaExpiradaClassName, 60, msg);
            Verification.Wait(5);
        }
        #endregion
    }
}
