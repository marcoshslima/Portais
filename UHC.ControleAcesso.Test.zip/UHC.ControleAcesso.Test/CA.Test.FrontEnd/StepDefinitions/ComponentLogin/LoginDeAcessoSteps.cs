﻿using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using CA.Test.FrontEnd.Helper;
using CA.Test.FrontEnd.ElementsReference;
using OGS.Framework.Utility;
using Test.Middleware.Bus.Helper;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;

namespace UHC.ControleAcesso.Test.StepDefinitions.ComponentLogin
{
    [Binding]
    public class LoginDeAcessoSteps : ConfigReports
    {
        IWebDriver driver;
        SqlHelper select = new SqlHelper();
        bool flag;
        int idportal;
        string logon;
        List<String> dadosUsuario = new List<string>();
        private Array resultados;

        public LoginDeAcessoSteps(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Given(@"que o usuário esteja na página inicial do Componente Controle de Acessos no portal '(.*)'")]
        public void DadoQueOUsuarioEstejaNaPaginaInicialDoComponenteControleDeAcessosNoPortal(string portal)
        {
            ScenarioContext.Current.Add("portal", portal);

            switch (portal)
            {
                case "Portal Agendamento Online":
                    idportal = 400;
                    driver.Navigate().GoToUrl(AmbienteHelper.SetAmbiente(portal));
                    break;

                case "Portal Beneficiario":
                    idportal = 400;
                    driver.Navigate().GoToUrl(AmbienteHelper.SetAmbiente(portal));
                    break;

                case "Portal Credenciado Dental":
                    idportal = 600;
                    driver.Navigate().GoToUrl(AmbienteHelper.SetAmbiente(portal));
                    break;

                case "Portal Empresa":
                    idportal = 500;
                    driver.Navigate().GoToUrl(AmbienteHelper.SetAmbiente(portal));
                    break;
            }

            Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.ComponenteLogin.Propertie, 10);
        }

        #region TitularDependente
        [When(@"identificado Usuario com '(.*)' e '(.*)'")]
        public void QuandoIdentificadoUsuarioComE(string TAcesso, string TBenecifiario)
        {


            switch (ScenarioContext.Current.Get<string>("portal"))
            {
                case "Portal Agendamento Online":
                    switch (TBenecifiario)
                    {
                        //Alteração no código para consumir as queries do banco.
                        case "Titular":
                            //selectSql = conexao.SelectCommand(select.UsuarioTitularPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO TITULAR PORTAL AGENDAMENTO ONLINE");
                            break;
                        case "Dependente":
                            //selectSql = conexao.SelectCommand(select.UsuarioDependentePortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO DEPENDENTE PORTAL AGENDAMENTO ONLINE");
                            break;
                        case "Patrocinador":
                           // selectSql = conexao.SelectCommand(select.UsuarioPatrocinadorPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO PATROCINADOR PORTAL AGENDAMENTO ONLINE");
                            break;
                    }
                    break;

                case "Portal Beneficiario":
                    switch (TBenecifiario)
                    {
                        case "Titular":
                            //selectSql = conexao.SelectCommand(select.UsuarioTitularPortalBeneficiario, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO TITULAR PORTAL AGENDAMENTO ONLINE");

                            break;
                        case "Dependente":
                            //selectSql = conexao.SelectCommand(select.UsuarioDependentePortalBeneficiario, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO DEPENDENTE PORTAL AGENDAMENTO ONLINE");

                            break;
                        case "Patrocinador":
                            //selectSql = conexao.SelectCommand(select.UsuarioPatrocinadorPortalBeneficiario, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO PATROCINADOR PORTAL AGENDAMENTO ONLINE");

                            break;
                    }
                    break;
            }

            //var aux = selectSql.Split(';').ToArray();
            //var cpf = aux[1];
            //var nome = aux[2];
            var marcaOtica = resultados.GetValue(0).ToString();
            var cpf = resultados.GetValue(1).ToString();          
            var nome = resultados.GetValue(2).ToString();

            switch (TAcesso)
            {
                case "MO":
                    ProcedureHelper.AlterarSenha(marcaOtica, idportal);
                    ProcedureHelper.PreencherContato(marcaOtica, idportal);
                    TAcesso = marcaOtica;
                    break;

                case "CPF":
                    ProcedureHelper.AlterarSenha(cpf, idportal);
                    ProcedureHelper.PreencherContato(cpf, idportal);
                    TAcesso = cpf;
                    break;
            }

            dadosUsuario.Add(marcaOtica);
            dadosUsuario.Add(cpf);
            dadosUsuario.Add(nome);

            logon = TAcesso;

            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, logon, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }
        #endregion

        #region PaiFilho
        [When(@"identificado Usuário com '(.*)'")]
        public void QuandoIdentificadoUsuarioCom(string TAcesso)
        {
            switch (TAcesso)
            {
                case "Pai":
                    switch (ScenarioContext.Current.Get<string>("portal"))
                    {
                        case "Portal Credenciado Dental":
                            //selectSql = conexao.SelectCommand(select.UsuarioPaiPortalDental, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL PAI COM CONVIVENCIA");
                            break;

                        case "Portal Empresa":
                            //selectSql = conexao.SelectCommand(select.UsuarioPaiPortalEmpresa, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO PAI CONVIVENCIA");

                            break;
                    }

                    // var aux = selectSql.Split(';').ToArray();
                    //var usuarioPai = aux[0];
                    // var nomePai = aux[1];

                    var usuarioPai = resultados.GetValue(0).ToString();
                    var nomePai = resultados.GetValue(1).ToString();

                    ProcedureHelper.AlterarSenha(usuarioPai, idportal);
                    ProcedureHelper.PreencherContato(usuarioPai, idportal);
                    TAcesso = usuarioPai;
                    logon = TAcesso;
                    dadosUsuario.Add(usuarioPai);
                    dadosUsuario.Add(nomePai);
                    break;

                case "Filho":
                    switch (ScenarioContext.Current.Get<string>("portal"))
                    {
                        case "Portal Credenciado Dental":
                            //selectSql = conexao.SelectCommand(select.UsuarioFilhoPortalDental, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO COM CONVIVENCIA");

                            break;

                        case "Portal Empresa":
                            //selectSql = conexao.SelectCommand(select.UsuarioFilhoPortalEmpresa, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO FILHO CONVIVENCIA");
                            break;
                    }

                    // var aux2 = selectSql.Split(';').ToArray();
                    //var usuarioFilho = aux2[0];
                    //var nomeFilho = aux2[1];

                    var usuarioFilho = resultados.GetValue(0).ToString();
                    var nomeFilho = resultados.GetValue(1).ToString();

                    ProcedureHelper.AlterarSenha(usuarioFilho, idportal);
                    ProcedureHelper.PreencherContato(usuarioFilho, idportal);

                    TAcesso = usuarioFilho;
                    logon = TAcesso;
                    dadosUsuario.Add(usuarioFilho);
                    dadosUsuario.Add(nomeFilho);
                    break;
            }

            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, logon, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }
        #endregion

        #region Suspenso
        [When(@"identificado Usuario Suspenso com '(.*)' e '(.*)'")]
        public void QuandoIdentificadoUsuarioSuspensoComE(string TAcesso, string TBenecifiario)
        {
            switch (ScenarioContext.Current.Get<string>("portal"))
            {
                case "Portal Agendamento Online":
                    switch (TBenecifiario)
                    {
                        case "Titular":
                            //selectSql = conexao.SelectCommand(select.UsuarioTitularSuspensoPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO TITULAR SUSPENSO PORTAL AGENDAMENTO ONLINE");
                            break;
                        case "Dependente":
                            //selectSql = conexao.SelectCommand(select.UsuarioDependenteSuspensoPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO DEPENDENTE SUSPENSO PORTAL AGENDAMENTO ONLINE");
                            break;
                    }
                    break;

                case "Portal Beneficiario":
                    switch (TBenecifiario)
                    {
                        case "Titular":
                            //selectSql = conexao.SelectCommand(select.UsuarioTitularSuspensoPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO TITULAR SUSPENSO PORTAL AGENDAMENTO ONLINE");
                            break;
                        case "Dependente":
                            //selectSql = conexao.SelectCommand(select.UsuarioDependenteSuspensoPortalAgendamento, null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "USUARIO DEPENDENTE SUSPENSO PORTAL AGENDAMENTO ONLINE");
                            break;
                    }
                    break;
            }

            //var aux = selectSql.Split(';').ToArray();
            //var marcaOtica = aux[0];
            //var cpf = aux[1];
            //var nome = aux[2];

            var marcaOtica = resultados.GetValue(0).ToString();
            var cpf = resultados.GetValue(1).ToString();
            var nome = resultados.GetValue(2).ToString();

            ProcedureHelper.AlterarSenha(marcaOtica, idportal);
            ProcedureHelper.PreencherContato(marcaOtica, idportal);

            if (TAcesso.Contains("CPF"))
            {
            TAcesso = cpf;
            }
            else
            {
                TAcesso = marcaOtica;
            }

            dadosUsuario.Add(marcaOtica);
            dadosUsuario.Add(cpf);
            dadosUsuario.Add(nome);

            logon = TAcesso;

            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, logon, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }
        #endregion

        #region Excluido

        [When(@"identificado Usuario com '(.*)' e '(.*)' \[Convivênia Excluído]")]
        public void QuandoIdentificadoUsuarioComEConviveniaExcluido(string TAcesso, string TBeneficiario)
        {
            string user = "";
            string nome_usuario = "";

            try
            {
            
                if (TAcesso.Contains(">"))
                {

                    //string resultado = conexao.SelectCommand(SqlHelper.UserBeneficiarioExcluidoMaior2Anos(TBeneficiario), null);
                    //var logon = resultado.Split(';').ToArray();

                    if (TBeneficiario.Contains("T"))
                    {
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "BENEFICIARIO DEPENDENTE TITULAR MAIOR QUE 2 ANOS");
                    }
                    else
                    {
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "BENEFICIARIO DEPENDENTE EXCLUIDO MAIOR QUE 2 ANOS");

                    }

                    //nome_usuario = logon[2];
                    nome_usuario = resultados.GetValue(2).ToString();

                    if (TAcesso.Contains("MO > 2"))
                    {
                        user = resultados.GetValue(0).ToString();
                    }
                    else if (TAcesso.Contains("CPF > 2"))
                    {
                        user = Convert.ToUInt64(resultados.GetValue(1)).ToString(@"000\.000\.000\-00"); ;
                    }

                }
                else
                {
                    //string resultado = conexao.SelectCommand(SqlHelper.UserBeneficiarioExcluidoMenor2Anos(TBeneficiario), null);
                    //var logon = resultado.Split(';').ToArray();
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "BENEFICIARIO EXCLUIDO MENOR QUE 2 ANOS");

                    nome_usuario = resultados.GetValue(2).ToString();

                    if (TAcesso.Contains("MO < 2"))
                    {
                        user = resultados.GetValue(0).ToString(); ;
                    }
                    else if (TAcesso.Contains("CPF < 2"))
                    {
                        user = Convert.ToUInt64(resultados.GetValue(1)).ToString(@"000\.000\.000\-00"); ;
                    }

                }

                ScenarioContext.Current.Add("Usuario", user);
                ScenarioContext.Current.Add("Nome_Usuario", nome_usuario);
                ScenarioContext.Current.Add("MARCA_OTICA", user);
                ScenarioContext.Current.Add("P_LOGIN", user);
                ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, user, 10);
                ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }

        [When(@"identificado Usuário com '(.*)' \[Excluido]")]
        public void QuandoIdentificadoUsuarioComExcluido(string tipoAcesso)
        {

            string user ="";
            if (ScenarioContext.Current.Get<string>("portal").Contains("Empresa"))
            {

                switch (tipoAcesso)
                {

                    case "Pai":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL EMPRESA (CONVIVÊNCIA EXCLUÍDO USUÁRIO PAI)");
                        break;

                    case "Filho":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL EMPRESA (CONVIVÊNCIA EXCLUÍDO USUÁRIO FILHO)");
                        break;

                    default:
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL EMPRESA (EXCLUÍDO USUÁRIO FILHO)");
                        break;
                }

            }
            else
            {
                switch (tipoAcesso)
                {

                    case "Pai":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL DENTAL (CONVIVÊNCIA EXCLUÍDO USUÁRIO PAI)");
                        break;

                    case "Filho":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL DENTAL (CONVIVÊNCIA EXCLUÍDO USUÁRIO FILHO)");
                        break;

                    default:
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL DENTAL (EXCLUÍDO USUÁRIO FILHO)");
                        break;
                }
            }
            

            user = resultados.GetValue(0).ToString();
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, user, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }

        [When(@"identificado Usuário com '(.*)' \[Inativo]")]
        public void QuandoIdentificadoUsuarioComInativo(string tipoAcesso)
        {
            string user = "";
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);


            if (ScenarioContext.Current.Get<string>("portal").Contains("Empresa"))
            {
                switch (tipoAcesso)
                {

                    case "Pai":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL EMPRESA (CONVIVÊNCIA INATIVO USUÁRIO PAI)");
                        break;

                    case "Filho":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL EMPRESA (CONVIVÊNCIA INATIVO USUÁRIO FILHO)");
                        break;
                }
            }
            else
            {
                switch (tipoAcesso)
                {

                    case "Filho/Com Convivencia":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO INATIVO");
                        break;

                    case "Filho/Sem Convivencia":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO INATIVO SEM CONVIVENCIA");
                        break;

                    case "Pai":
                        resultados = ProcedureHelper.ExecutarBiblioteca(null, "LOGIN DE ACESSO PORTAL DENTAL (CONVIVÊNCIA INATIVO USUÁRIO PAI)");
                        break;
                }
            }

            try
            {
                ProcedureHelper.AlterarSenha(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));
                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2).ToString()));
            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
            } 

            dadosUsuario.Add(resultados.GetValue(0).ToString());
            dadosUsuario.Add(resultados.GetValue(1).ToString());
            user = resultados.GetValue(0).ToString();

            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, user, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }
        #endregion

        #region When
        [When(@"clicar no botão Entrar")]
        public void QuandoClicarNoBotaoEntrar()
        {

            ElementActions.ClickOnElement(driver, "CSS", OperacaoLogin.BtnEntrar.Propertie, 10);

            if (Utils.IsElementExists(By.XPath("//p[contains(text(),'Senha expirada. Atualize seu cadastro com uma nova senha.')]"), driver,5))
            {
                Verification.Wait(8);
                Random rdn = new Random();
                string senhaAleatoria = rdn.Next(101, 2999).ToString();
                string senha = "Amil@" + senhaAleatoria;
                ElementActions.SetText(driver, "ClassName", OperacaoSenhaExpirada.CampoTrocaSenha.ClassName, senha, 2);
                Verification.Wait(2);
                driver.FindElement(By.ClassName(OperacaoSenhaExpirada.CampoTrocaSenha.ClassName)).SendKeys(Keys.Tab);
                ElementActions.SetText(driver, "ClassName", OperacaoSenhaExpirada.CampoConfirmeTrocaSenha.ClassName, senha, 2);

                ElementActions.ClickOnElement(driver, "ClassName", OperacaoSenhaExpirada.BtnAtualizar.Class, 2);


                Verification.VerifyElementTextMatches(driver, "ClassName", OperacaoSenhaExpirada.Mensagens.SenhaExpiradaClassName, 30, "Senha alterada com sucesso.");
                Verification.Wait(2);

                ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, senha, 10);
                QuandoClicarNoBotaoEntrar();

            }

        }
        #endregion

        #region Then
        [Then(@"o sistema deve exibir o recurso Walktrough Conheça seu novo portal")]
        public void EntaoOSistemaDeveExibirORecursoWalktroughConhecaSeuNovoPortal()
        {
            Verification.Wait(3);
            if (Utils.IsElementExists(By.CssSelector(OperacaoLogin.WalkTroughConhecaSeuNovoPortal.Propertie), driver, 20))
            {
                Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.WalkTroughConhecaSeuNovoPortal.Propertie, 1);
                ElementActions.ClickOnElement(driver, "CSS", OperacaoLogin.WalkTroughConhecaSeuNovoPortalBntFechar.Propertie, 10);
            }
        }

        [Then(@"pode exibir o recurso Walktrough Pendências somente no portal Empresa")]
        public void EntaoPodeExibirORecursoWalktroughPendenciasSomenteNoPortalEmpresa()
        {
            try
            {
                switch (ScenarioContext.Current.Get<string>("portal"))
                {
                    case "Portal Empresa":
                        Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.WalkTroughPendencias.Propertie, 10);
                        flag = true;
                        break;

                    default:
                        flag = false;
                        break;
                }
            }
            catch (Exception)
            {
                flag = false;
                //test.Log(AventStack.ExtentReports.Status.Skip, String.Format("Step fora do fluxo no recurso Walktrough Pendências!"));
            }

            if (flag == true)
            {
                ElementActions.ClickOnElement(driver, "CSS", OperacaoLogin.WalkTroughPendenciasBntOK.Propertie, 10);
            }
        }

        [Then(@"pode exibir o recurso Walktrough Atualize seus dados somente no portal do Beneficiário")]
        public void EntaoPodeExibirORecursoWalktroughAtualizeSeusDadosSomenteNoPortalDoBeneficiario()
        {
            try
            {
                Verification.Wait(2);
                switch (ScenarioContext.Current.Get<string>("portal"))
                {
                    case "Portal Beneficiario":
                        Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.WalkTroughAtualizeSeusDados.Propertie, 10);
                        flag = true;
                        break;

                    default:
                        flag = false;
                        break;
                }
            }
            catch (Exception)
            {
                flag = false;
                //test.Log(AventStack.ExtentReports.Status.Skip, String.Format("Step fora do fluxo no recurso Walktrough Atualize Seus Dados!"));
            }

            if (flag == true)
            {
                ElementActions.ClickOnElement(driver, "CSS", OperacaoLogin.WalkTroughAtualizeSeusDadosBntContinue.Propertie, 10);
            }
        }

        [Then(@"carregar a área Principal do Portal de acordo com o seu perfil de acesso")]
        public void ECarregarAAreaPrincipalDoPortalDeAcordoComOSeuPerfilDeAcesso()
        {
            switch (ScenarioContext.Current.Get<string>("portal"))
            {
                case "Portal Agendamento Online":
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaMenu.Propertie, 10);
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaBntSair.PropertieB, 10);
                    if (dadosUsuario.Count == 0)
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 10, ScenarioContext.Current.Get<string>("Nome_Usuario"));
                        string login = ScenarioContext.Current.Get<string>("P_LOGIN");


                        if (Utils.IsElementExists(By.XPath("//*[contains(text(),'" + login + "')]"), driver, 10))
                        {
                            Utils.VerifyPageContais(driver, login);
                        }
                        else
                        {
                            string user_aux = ScenarioContext.Current.Get<string>("UsuarioAux");
                            Utils.VerifyPageContais(driver, user_aux);
                        }
                                                
                    }
                    else
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 60, dadosUsuario[2].ToString().ToUpper());
                        Verification.VerifyElementTextMatches(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioMarcaOtica.Propertie, 60, dadosUsuario[0].ToString());
                    }
                    break;

                case "Portal Beneficiario":
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaMenu.Propertie, 60);
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaBntSair.PropertieA, 60);


                    if (dadosUsuario.Count ==0)
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 60, ScenarioContext.Current.Get<string>("Nome_Usuario"));
                        string login = ScenarioContext.Current.Get<string>("P_LOGIN");

                        if (Utils.IsElementExists(By.XPath("//*[contains(text(),'" + login + "')]"), driver, 10))
                        {
                            Utils.VerifyPageContais(driver, login);
                        }
                        else
                        {
                            string user_aux = ScenarioContext.Current.Get<string>("UsuarioAux");
                            Utils.VerifyPageContais(driver, user_aux);
                        }
                    }
                    else
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 60, dadosUsuario[2].ToString().ToUpper());

                        Verification.VerifyElementTextMatches(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioMarcaOtica.Propertie, 60, dadosUsuario[0].ToString());

                    }
                    break;

                case "Portal Credenciado Dental":
             
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaMenu.Propertie, 10);
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaBntSair.PropertieC, 10);
                    if (dadosUsuario.Count == 0)
                    {
                        //Verification.Wait(10);
                        //Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieB, 60, ScenarioContext.Current.Get<string>("Nome_Usuario").ToUpper());
                        Verification.VerifyElementExists(driver, "Xpath", OperacaoLogin.AreaLogadaDadosUsuarioNome.GetName(ScenarioContext.Current.Get<string>("Nome_Usuario").ToUpper()),120);
                    }
                    else
                    {
                        Verification.Wait(10);
                        // Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieB, 10, dadosUsuario[1].ToString().ToUpper());
                        Verification.VerifyElementExists(driver, "Xpath", OperacaoLogin.AreaLogadaDadosUsuarioNome.GetName(dadosUsuario[1].ToString().ToUpper()), 120);

                    }
                    break;

                case "Portal Empresa":
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaMenu.Propertie, 60);
                    Verification.VerifyElementExists(driver, "CSS", OperacaoLogin.AreaLogadaBntSair.PropertieA, 60);

                    if (dadosUsuario.Count == 0)
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 60, ScenarioContext.Current.Get<string>("Nome_Usuario").ToUpper());
                        Verification.VerifyElementTextMatches(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioMarcaOtica.Propertie, 60, ScenarioContext.Current.Get<string>("MARCA_OTICA"));
                    }
                    else
                    {
                        Verification.VerifyElementTextContains(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioNome.PropertieA, 60, dadosUsuario[1].ToString().ToUpper());
                        Verification.VerifyElementTextMatches(driver, "CSS", OperacaoLogin.AreaLogadaDadosUsuarioMarcaOtica.Propertie, 60, dadosUsuario[0].ToString());
                    }
           
                    break;
            }
        }

        [Then(@"o sistema deve apresentar a mensagem ""(.*)""")]
        public void EntaoOSistemaDeveApresentarAMensagem(string msg)
        {
            Verification.Wait(2);
            Verification.VerifyElementTextMatches(driver, "ClassName", OperacaoLogin.Mensagens.AlertaClassName, 60, msg);
        }

        #endregion
    }
}
