﻿using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using CA.Test.FrontEnd.Helper;
using CA.Test.FrontEnd.ElementsReference;
using OGS.Framework.Utility;
using Test.Middleware.Bus.Helper;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;

namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class CadastrarRespostasSeguranca
    {

        private IWebDriver _driver;

        public CadastrarRespostasSeguranca(IWebDriver _driver)
        {
            this._driver = _driver;
        }

        #region When
        [When(@"clicar no botão \[Salvar meu Cadastro]")]
        public void WhenClicarNoBotaoSalvarMeuCadastro()
        {
            ElementActions.ClickOnElement(_driver,"Xpath",OperacaoCadastrarRespostasSeguranca.BtnSalvarCadastro.Xpath,20);
        }

        #endregion

        #region Given
        [Then(@"clicar no menu \[Cadastro]")]
        public void ThenClicarNoMenuCadastro()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoCadastrarRespostasSeguranca.IconeMenu.ClassName, 2);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.MenuCadastro.Xpath, 2);
        }


        [Then(@"acessar o container \[Cadastrar respostas de segurança]")]
        public void ThenAcessarOContainerCadastrarRespostasDeSeguranca()
        {


            if (_driver.FindElement(By.Name("personalData.enderecoResidencial.logradouroField")).GetAttribute("value").Equals(""))
            {

                ElementActions.SetText(_driver,"ID",OperacaoCadastrarRespostasSeguranca.Cep.Id, "04711904",2);
                Verification.VerifyElementExists(_driver,"Xpath" ,OperacaoCadastrarRespostasSeguranca.FieldValue.Campo("OLAVO REDIG DE CAMPOS, 105") ,60);
                Verification.VerifyElementExists(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.FieldValue.Campo("VILA SAO FRANCISCO (ZONA SUL)"), 2);
                Verification.VerifyElementExists(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.FieldValue.Campo("SAO PAULO"), 2);
                Verification.VerifyElementExists(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.FieldValue.Campo("SP"), 2);
                ElementActions.SetText(_driver, "Name", OperacaoCadastrarRespostasSeguranca.Numero.Name, "105", 2);
                ElementActions.ClickOnElement(_driver,"Xpath",OperacaoCadastrarRespostasSeguranca.CheckCobranca.Xpath,2);
                ElementActions.ClickOnElement(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.CheckCorrespondencia.Xpath, 2);
            }



            Utils.MoveToElement(_driver,By.XPath(OperacaoCadastrarRespostasSeguranca.MenuCadastrarRespostasSeguranca.Xpath));
            if (_driver.FindElement(By.XPath(OperacaoCadastrarRespostasSeguranca.MenuCadastrarRespostasSeguranca.Xpath)).Text.Contains("Você já possui respostas cadastradas.")) 
            {
                ElementActions.ClickOnElement(_driver, "Xpath", OperacaoCadastrarRespostasSeguranca.MenuCliqueAqui.Xpath,2);
            }

        }


        [Then(@"preencher as respectivas perguntas com a respostas: ""(.*)"", ""(.*)"" e ""(.*)""")]
        public void ThenPreencherAsRespectivasPerguntasComARespostasE(string resp01, string resp02, string resp03)
        {
            ElementActions.SetText(_driver, "Name", OperacaoCadastrarRespostasSeguranca.Resposta01.Name, resp01, 2);
            ElementActions.SetText(_driver, "Name", OperacaoCadastrarRespostasSeguranca.Resposta02.Name, resp02, 2);
            ElementActions.SetText(_driver, "Name", OperacaoCadastrarRespostasSeguranca.Resposta03.Name, resp03, 2);
        }


        #endregion

    }
}
