﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CA.Test.FrontEnd.ElementsReference;
using CA.Test.FrontEnd.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Controller.Actions;
using OGS.Framework.Setup;
using OGS.Framework.Utility;
using OpenQA.Selenium;
using Oracle.ManagedDataAccess.Client;
using TechTalk.SpecFlow;
using Test.Middleware.Bus.Helper;

namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class EsqueciSenha: ConfigReports
    {

        IWebDriver _driver;
        private Array resultados;

        public EsqueciSenha(IWebDriver _driver)
        {
            this._driver = _driver;
        }

        #region Given


        #endregion

        #region When

        [When(@"identificado Usuário '(.*)' pela '(.*)' no qual o mesmo esqueceu a senha")]
        public void WhenIdentificadoUsuarioPelaNoQualOMesmoEsqueceuASenha(string tipo_beneficiario, string tipo_acesso)
        {
            try
            {
                 //string resultados = conexao.SelectCommand(SqlHelper.GetUsuarioIdSistemaEsqueceuSenha(tipo_beneficiario), null);
                 //var aux_result = resultados.Split(';').ToArray();

                if (tipo_beneficiario.Equals("T"))
                {
                     resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO TITULAR","1");
                }
               else
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO DEPENDENTE","1");
                }

                string cpf_mo = "";
                
                if (tipo_acesso.Contains("MO"))
                {
                    //cpf_mo = aux_result[0].ToString();
                    cpf_mo = resultados.GetValue(0).ToString();
                }
                else
                {
                   // cpf_mo = Convert.ToInt64(aux_result[2]).ToString(@"000\.000\.000\-00");
                    cpf_mo = Convert.ToInt64(resultados.GetValue(2)).ToString(@"000\.000\.000\-00");
                }
                ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0).ToString());
                //ScenarioContext.Current.Add("P_LOGIN", aux_result[0].ToString());
                ScenarioContext.Current.Add("CPF_MO",cpf_mo);
                ScenarioContext.Current.Add("Usuario", cpf_mo);
                ScenarioContext.Current.Add("MARCA_OTICA", cpf_mo);
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(3).ToString());
                //ScenarioContext.Current.Add("Nome_Usuario", aux_result[3].ToString());

                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(1)));
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }

        [When(@"clicar no botão \[Esqueceu a senha]")]
        public void WhenClicarNoBotaoEsqueceuASenha()
        {
           ElementActions.ClickOnElement(_driver,"ClassName",OperacaoEsqueceuSenha.BtnEsqueceuSenha.ClassName,2);
        }

        [When(@"preencher o campo \[Insira o CPF ou Nº do Beneficiario]")]
        public void WhenPreencherOCampoInsiraOCPFOuNºDoBeneficiario()
        {
            ElementActions.SetText(_driver,"ClassName",OperacaoEsqueceuSenha.CampoCPFouBeneficiario.Classname,ScenarioContext.Current.Get<string>("CPF_MO"),2);
        }

        [When(@"preencher o campo \[Insira o Usuário]")]
        public void WhenPreencherOCampoInsiraOUsuario()
        {
            ElementActions.SetText(_driver, "ClassName", OperacaoEsqueceuSenha.CampoCPFouBeneficiario.Classname, ScenarioContext.Current.Get<string>("Usuario"), 2);
        }


        [When(@"clicar no botão \[Confirmar] do accordion \[Valide o CPF ou Nº\. do Beneficiário]")]
        public void WhenClicarNoBotaoConfirmarDoAccordionValideOCPFOuNº_DoBeneficiario()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmar.ClassName, 2);
        }

        [When(@"selcionar a opção '(.*)'")]
        public void WhenSelcionarAOpcao(string recuperacao)
        {
            ScenarioContext.Current.Add("Recuperacao", recuperacao);


            if (ScenarioContext.Current.Get<string>("portal").Equals("Portal Credenciado Dental"))
            {
                switch (recuperacao)
                {
                    case "EMAIL":
                        Verification.Wait(3);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.OptEmail_CredenciadoDental.Xpath, 60);
                        ElementActions.ClickOnElement(_driver, "Classname", OperacaoEsqueceuSenha.ComboEmailSms.ClassName, 2);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.CampoCPFouBeneficiario.GetValue("t*********l@prestadores.amil.com.br"), 2);
                        break;

                    case "SMS":
                        Verification.Wait(3);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.OptSms_CredenciadoDental.Xpath, 60);
                        ElementActions.ClickOnElement(_driver, "Classname", OperacaoEsqueceuSenha.ComboEmailSms.ClassName, 2);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.CampoCPFouBeneficiario.GetValue("(11) ****-8965"), 2);
                        break;

                }

            }
            else
            {
                switch (recuperacao)
                {
                    case "EMAIL":
                        Verification.Wait(3);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.OptEmail.Xpath, 60);
                        ElementActions.ClickOnElement(_driver, "Classname", OperacaoEsqueceuSenha.CampoEmail.ClassName, 2);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.CampoCPFouBeneficiario.GetValue("t*********l@prestadores.amil.com.br"), 2);
                        break;

                    case "SMS":
                        Verification.Wait(3);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.OptSms.Xpath, 60);
                        ElementActions.ClickOnElement(_driver, "Classname", OperacaoEsqueceuSenha.CampoSMS.ClassName, 2);
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.CampoCPFouBeneficiario.GetValue("(11) ****-8965"), 2);
                        break;

                    case "FALECONOSCO":
                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.BtnFaleConosco.Xpath, 10);
                        break;
                    case "PERGUNTAS":
                        Verification.Wait(3);

                        ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.OptPerguntas.Xpath, 60);
                        break;
                }
            }
        }

        [When(@"clicar no botão \[Confirmar] do accordion \[Meio de Recuperação]")]
        public void WhenClicarNoBotaoConfirmarDoAccordionMeioDeRecuperacao()
        {
                switch (ScenarioContext.Current.Get<string>("Recuperacao"))
                {
                    case "EMAIL":
                        ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmarMeioRecuperacao.ClassName, 2);
                        break;
                    case "SMS":
                        ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmarMeioRecuperacao_SMS.ClassName, 2);
                        break;
                }
        }

        [When(@"preencher o campo \[Insira o token recebido]")]
        public void WhenPreencherOCampoInsiraOTokenRecebido()
        {


            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            try
            {
                conexao.ConnectDataBase();
                string token = conexao.SelectCommand(SqlHelper.GetToken(ScenarioContext.Current.Get<String>("P_LOGIN")), null);
                Verification.Wait(2);

                if(ScenarioContext.Current.Get<string>("portal") != "Portal Credenciado Dental")
                { 
                    ElementActions.SetText(_driver, "Xpath", OperacaoEsqueceuSenha.CampoToken.Xpath, token, 20);
                }
                else
                {
                    ElementActions.SetText(_driver, "ClassName", OperacaoEsqueceuSenha.CampoToken.ClassName, token, 20);
                }
                
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }

        }

        [When(@"clicar no botão \[Confirmar] do accordion \[Valide Código de Verificação]")]
        public void WhenClicarNoBotaoConfirmarDoAccordionValideCodigoDeVerificacao()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmarToken.ClassName, 10);
        }

        [When(@"preecnher os campos \[NovaSenha] e \[ConfirmeSenha]")]
        public void WhenPreecnherOsCamposNovaSenhaEConfirmeSenha()
        {
            Random rdn = new Random();

            string senhaAleatoria = rdn.Next(101,2000).ToString();
            string senha = "Amil@" + senhaAleatoria;
            ElementActions.SetText(_driver, "CLASSNAME", OperacaoEsqueceuSenha.CampoNovaSenha.ClassName, senha, 60);
            Verification.Wait(2);
            _driver.FindElement(By.ClassName(OperacaoEsqueceuSenha.CampoNovaSenha.ClassName)).SendKeys(Keys.Tab);
            if (ScenarioContext.Current.Get<string>("portal") != "Portal Credenciado Dental")
            {
                ElementActions.SetText(_driver, "CLASSNAME", OperacaoEsqueceuSenha.CampoConfirmeNovaSenha.ClassName, senha, 60);
            }
            else
            {
                ElementActions.SetText(_driver, "Xpath", OperacaoEsqueceuSenha.CampoConfirmeNovaSenha.Xpath, senha, 60);
            }
            


            ScenarioContext.Current.Add("NovaSenha",senha);

        }

        [When(@"clicar no botão \[Confirmar] do accordion \[Redefina a senha]")]
        public void WhenClicarNoBotaoConfirmarDoAccordionRedefinaASenha()
        {

            if (ScenarioContext.Current.Get<string>("portal") != "Portal Credenciado Dental")
            {
                ElementActions.ClickOnElement(_driver, "Xpath", OperacaoEsqueceuSenha.BtnConfirmarOperacao.Xpath, 60);
            }
            else
            {
                ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmarOperacao.ClassName, 60);
            }
            
        }

        [When(@"preencher os campos \[Novo E-mail] ""(.*)"", \[Confirme Novo E-mail] ""(.*)"", \[DD CELULAR], ""(.*)"" e \[Celular] ""(.*)""")]
        public void WhenPreencherOsCamposNovoE_MailConfirmeNovoE_MailDDCELULARECelular(string novo_email, string confirme_novo_email, string  ddd, string celular)
        {
            ElementActions.SetText(_driver, "Name", OperacaoEsqueceuSenha.CampoNovoEmail.Name, novo_email, 10);
            Verification.Wait(1);
            ElementActions.SetText(_driver, "Classname", OperacaoEsqueceuSenha.CampoConfirmeNovoEmail.Classname, confirme_novo_email, 10);
            Verification.Wait(1);
            ElementActions.SetText(_driver, "Classname", OperacaoEsqueceuSenha.CampoDDDCelular.Classname, ddd, 10);
            Verification.Wait(1);
            ElementActions.SetText(_driver, "Classname", OperacaoEsqueceuSenha.CampoCelular.Classname, celular, 10);
            Verification.Wait(2);

        }

        [When(@"clicar no botão \[Enviar]")]
        public void WhenClicarNoBotaoEnviar()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnEnviarFaleConosco.ClassName, 60);

        }


        [When(@"preencher o campo \[Insira o CPF ou Nº do Beneficiario] com convivência")]
        public void WhenPreencherOCampoInsiraOCPFOuNºDoBeneficiarioComConvivencia()
        {




        }

        [When(@"identificado Usuário '(.*)' pela '(.*)' no qual o mesmo esqueceu a senha com convivência")]
        public void WhenIdentificadoUsuarioPelaNoQualOMesmoEsqueceuASenhaComConvivencia(string tipo_beneficiario, string tipo_acesso)
        {
            #region comentário
            /*
             *
            AmbienteHelper.ConexaoDB();
            DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
             
            try
            {

                conexao.ConnectDataBase();
                string SQL = conexao.SelectCommand(SqlHelper.GetBeneficiarioConvivencia(), null);
                string resultados = conexao.SelectCommand(SQL.Replace("tipo_beneficiario", tipo_beneficiario), null);
                var aux_result = resultados.Split(';').ToArray();
                string cpf_mo = "";

                if (tipo_acesso.Contains("MO"))
                {
                    cpf_mo = aux_result[0].ToString();
                }
                else
                {
                    cpf_mo = Convert.ToInt64(aux_result[2]).ToString(@"000\.000\.000\-00");
                }
                ScenarioContext.Current.Add("P_LOGIN", aux_result[0].ToString());
                ScenarioContext.Current.Add("CPF_MO", cpf_mo);
                ScenarioContext.Current.Add("Usuario", cpf_mo);
                ScenarioContext.Current.Add("MARCA_OTICA", cpf_mo);
                ScenarioContext.Current.Add("Nome_Usuario", aux_result[3].ToString());

                OracleParameter[] parametros = new OracleParameter[] {
                    new OracleParameter("P_LOGIN",aux_result[0].ToString()),
                    new OracleParameter("P_SISTEMA",Convert.ToInt32(aux_result[1])),
                    new OracleParameter("P_EMAIL","teste_email@prestadores.amil.com.br"),
                    new OracleParameter("P_DDD",11),
                    new OracleParameter("P_TELEFONE",945678965)
                };

                conexao.ExecuteProcedureParameter("CA_AUTOMACAO.PREENCHER_CONTATO", parametros.ToArray());

            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
            finally
            {
                conexao.CloseConnection();
            }
            */
            #endregion

            try
            {
                if (tipo_beneficiario.Equals("T"))
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO COM CONVIVENCIA TITULAR", "1");
                }
                else
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO COM CONVIVENCIA DEPENDENTE", "1");
                }

                string cpf_mo = "";

                if (tipo_acesso.Contains("MO"))
                {
                    //cpf_mo = aux_result[0].ToString();
                    cpf_mo = resultados.GetValue(0).ToString();
                }
                else
                {
                    // cpf_mo = Convert.ToInt64(aux_result[2]).ToString(@"000\.000\.000\-00");
                    cpf_mo = Convert.ToInt64(resultados.GetValue(2)).ToString(@"000\.000\.000\-00");
                }
                ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0).ToString());
                //ScenarioContext.Current.Add("P_LOGIN", aux_result[0].ToString());
                ScenarioContext.Current.Add("CPF_MO", cpf_mo);
                ScenarioContext.Current.Add("Usuario", cpf_mo);
                ScenarioContext.Current.Add("MARCA_OTICA", cpf_mo);
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(3).ToString());
                //ScenarioContext.Current.Add("Nome_Usuario", aux_result[3].ToString());


                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(1)));

            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }


        [When(@"identificado Usuário '(.*)' pelo '(.*)' no qual o mesmo esqueceu a senha")]
        public void WhenIdentificadoUsuarioPeloNoQualOMesmoEsqueceuASenha(string tipo_beneficiario, string tipo_acesso)
        {
                               

            if (ScenarioContext.Current.Get<string>("portal").Equals("Portal Empresa"))
            {
                try
                {
                    switch (tipo_beneficiario)
                    {
                        case "CONVIVENCIA":
                            if (tipo_acesso.Equals("PAI"))
                            {

                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaPaiComConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO PAI CONVIVENCIA");
                            }
                            else
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaFilhoComConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO FILHO CONVIVENCIA");
                            }
                            break;

                        case "S/CONVIVENCIA":
                            if (tipo_acesso.Equals("PAI"))
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaPaiSemConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO PAI SEM CONVIVENCIA");
                            }
                            else
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioEmpresaFilhoSemConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "EMPRESA USUARIO FILHO SEM CONVIVENCIA");
                            }
                            break;
                    }

                    //var aux_resultados = resultados.Split(';').ToArray();
                    ScenarioContext.Current.Add("Usuario", resultados.GetValue(0));
                    ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0));
                    ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0));
                    ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1));

                    ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));

                }
                catch (Exception e)
                {
                    Assert.Fail(e.ToString());
                }
            }
            else
            {
                try
                {

                    switch (tipo_beneficiario)
                    {
                        case "CONVIVENCIA":
                            if (tipo_acesso.Equals("PAI"))
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalPaiComConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL PAI COM CONVIVENCIA");
                            }
                            else
                            {
                               // SQL = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalFilhoComConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO COM CONVIVENCIA");
                            }
                            break;

                        case "S/CONVIVENCIA":
                            if (tipo_acesso.Equals("PAI"))
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalPaiSemConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL PAI SEM CONVIVENCIA");
                            }
                            else
                            {
                                //SQL = conexao.SelectCommand(SqlHelper.GetUsuarioCredenciadoDentalFilhoSemConvivencia(), null);
                                //resultados = conexao.SelectCommand(SQL, null);
                                resultados = ProcedureHelper.ExecutarBiblioteca(null, "CREDENCIADO DENTAL FILHO SEM CONVIVENCIA");
                            }
                            break;
                    }

                   // var aux_resultados = resultados.Split(';').ToArray();
                    ScenarioContext.Current.Add("Usuario", resultados.GetValue(0));
                    ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0));
                    ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0));
                    ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1));

                    ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));
                }
                catch (Exception e)
                {
                    Assert.Fail(e.ToString());
                }
            }

        }

        [When(@"identificado Usuário '(.*)' pela '(.*)' no qual o mesmo esqueceu a senha SEM convivência")]
        public void WhenIdentificadoUsuarioPelaNoQualOMesmoEsqueceuASenhaSEMConvivencia(string tipo_beneficiario, string tipo_acesso)
        {
           
            try
            {
                if (tipo_beneficiario.Equals("T"))
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO SEM CONVIVENCIA TITULAR", "1");
                }
                else
                {
                    resultados = ProcedureHelper.ExecutarBiblioteca(null, "ESQUECEU A SENHA BENEFICIARIO SEM CONVIVENCIA DEPENDENTE", "1");
                }

                string cpf_mo = "";

                if (tipo_acesso.Contains("MO"))
                {
                    //cpf_mo = aux_result[0].ToString();
                    cpf_mo = resultados.GetValue(0).ToString();
                }
                else
                {
                    // cpf_mo = Convert.ToInt64(aux_result[2]).ToString(@"000\.000\.000\-00");
                    cpf_mo = Convert.ToInt64(resultados.GetValue(2)).ToString(@"000\.000\.000\-00");
                }
                ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0).ToString());
                //ScenarioContext.Current.Add("P_LOGIN", aux_result[0].ToString());
                ScenarioContext.Current.Add("CPF_MO", cpf_mo);
                ScenarioContext.Current.Add("Usuario", cpf_mo);
                ScenarioContext.Current.Add("MARCA_OTICA", cpf_mo);
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(3).ToString());
                //ScenarioContext.Current.Add("Nome_Usuario", aux_result[3].ToString());

                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(1)));
                ProcedureHelper.PreencherPerguntas(resultados.GetValue(0).ToString());

            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
            finally
            {
                _driver.Navigate().Refresh();
            }
        }

        [When(@"preencher a respectiva pergunta com o valor ""(.*)""")]
        public void WhenPreencherARespectivaPerguntaComOValor(string pergunta)
        {
            ElementActions.SetText(_driver, "ClassName", OperacaoEsqueceuSenha.CampoPerguntas.Classname, pergunta, 10);
        }

        [When(@"clicar no botão \[Confirmar]")]
        public void WhenClicarNoBotaoConfirmar()
        {
            ElementActions.ClickOnElement(_driver, "ClassName", OperacaoEsqueceuSenha.BtnConfirmarPerguntas.ClassName, 10);
        }

        #endregion

        #region Then
        [Then(@"apresentar o número do respectivo protocolo")]
        public void ThenApresentarONumeroDoRespectivoProtocolo()
        {

            Verification.Wait(2);
            switch (ScenarioContext.Current.Get<string>("portal"))
            {
                case "Portal Agendamento Online":
                    Verification.VerifyElementExists(_driver, "Xpath", OperacaoEsqueceuSenha.CampoProtocoloAgendamentoOnline.Xpath, 20);
                    
                    break;
                case "Portal Beneficiario":
                    Verification.VerifyElementExists(_driver, "Xpath", OperacaoEsqueceuSenha.CampoProtocoloBeneficiario.Xpath, 20);

                    break;
                case "Portal Empresa":
                    break;
                case "Portal Credenciado Dental":
                    break;
            }
        }

        #endregion

    }
}
