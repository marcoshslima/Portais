﻿using OGS.Framework.Controller.Actions;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using CA.Test.FrontEnd.Helper;
using CA.Test.FrontEnd.ElementsReference;
using OGS.Framework.Utility;
using Test.Middleware.Bus.Helper;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;
using TechTalk.SpecFlow.Assist;
using Framework.Utilities;

namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class CadastreSe : ConfigReports

    {
        IWebDriver driver;
        private  Array resultados;

        public CadastreSe(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Given(@"clicar no botão cadastre-se")]
        public void DadoClicarNoBotaoCadastre_Se()
        {
            ElementActions.ClickOnElement(driver,"classname",OperacaoCadastreSe.LinkCadastreSe.ClassName, 10);
        }


        [Given(@"preencher os campos do formuluario conforme o tipo de acessos ""(.*)"" e ""(.*)""")]
        public void DadoPreencherOsCamposDoFormuluarioConformeOTipoDeAcessoE(string tipo_acesso, string tipo_beneficiario, Table table)
        {
            //AmbienteHelper.ConexaoDB();
            //DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
            string cpf_mo = "";

            try
            {
                //conexao.ConnectDataBase();
                //string sql = conexao.SelectCommand(SqlHelper.CadastreSe(ScenarioContext.Current.Get<string>("portal")), null);
                // string resultado = conexao.SelectCommand(sql.Replace("tipo_beneficiario", tipo_beneficiario), null);
                if (tipo_beneficiario.Equals("T"))
                {
                     resultados = ProcedureHelper.ExecutarBiblioteca(null, "CADASTRAR USUARIO BENEFICIARIO/AGENDAMENTO ONLINE TITULAR");
                }
                else
                {
                     resultados = ProcedureHelper.ExecutarBiblioteca(null, "CADASTRAR USUARIO BENEFICIARIO/AGENDAMENTO ONLINE DEPENDENTE");
                }
                
                //string resultado = "";
                //var aux_result = resultado.Split(';').ToArray();

                if (tipo_acesso.Contains("MO"))
                {
                    //cpf_mo = aux_result[0].ToString();
                    cpf_mo = resultados.GetValue(0).ToString();
                }
                else
                {
                    //cpf_mo = Convert.ToInt64(aux_result[2]).ToString(@"000\.000\.000\-00");
                    cpf_mo = Convert.ToInt64(resultados.GetValue(2)).ToString(@"000\.000\.000\-00");
                }


                ScenarioContext.Current.Add("P_LOGIN", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("CPF_MO", cpf_mo);
                ScenarioContext.Current.Add("Usuario", cpf_mo);
                ScenarioContext.Current.Add("MARCA_OTICA", cpf_mo);
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1).ToString());

                dynamic dados = table.CreateDynamicInstance();
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCpfBeneficiario.ClassName, cpf_mo, 5);



                switch (ScenarioContext.Current.Get<string>("portal"))
                {
                    case "Portal Beneficiario":
                        driver.FindElement(By.ClassName(OperacaoCadastreSe.CampoCpfBeneficiario.ClassName)).SendKeys(Keys.Tab);
                        ElementActions.SetText(driver, "Xpath", OperacaoCadastreSe.CampoDataNascimento.Xpath, resultados.GetValue(3).ToString(), 5);
                        break;
                    case "Portal Agendamento Online":
                        driver.FindElement(By.ClassName(OperacaoCadastreSe.CampoCpfBeneficiario.ClassName)).SendKeys(Keys.Tab);
                        ElementActions.SetText(driver, "Xpath", OperacaoCadastreSe.CampoDataNascimentoPortalAgendamentoOnline.Xpath, resultados.GetValue(3).ToString(), 5);
                        driver.FindElement(By.XPath(OperacaoCadastreSe.CampoDataNascimentoPortalAgendamentoOnline.Xpath)).SendKeys(Keys.Tab);
                        break;
                }
                
                
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoDDD.ClassName, Convert.ToString(dados.DDD), 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCelular.ClassName, Convert.ToString(dados.Celular), 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoEmail.ClassName, dados.Email, 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoConfirmacaoEmail.ClassName, dados.ConfirmarEmail, 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoSenha.ClassName, dados.Senha, 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoConfirmaSenha.ClassName, dados.ConfirmaSenha, 5);

            } catch (Exception e)

            {
                Assert.Fail(e.ToString());
            }

        }



        [Given(@"preencher os campos do formuluario conforme o tipo de acesso ""(.*)""")]
        public void DadoPreencherOsCamposDoFormuluarioConformeOTipoDeAcesso(string tipo_acesso , Table table)
        {

            //string sql = "";
            //string resultado = "";
           //AmbienteHelper.ConexaoDB();
           //DataBase conexao = new DataBase(AmbienteHelper.Host, AmbienteHelper.Port, AmbienteHelper.Servicename, AmbienteHelper.User, AmbienteHelper.Password);
          try
            {

                switch (ScenarioContext.Current.Get<string>("portal"))
                {
                    case "Portal Empresa":
                        if (tipo_acesso.Contains("Pai"))
                        {
                            //CADASTRO USUARIO EMPRESA PAI
                            resultados =  ProcedureHelper.ExecutarBiblioteca(null, "CADASTRO USUARIO EMPRESA PAI");
                            //sql = conexao.SelectCommand(SqlHelper.GetCadastroEmpresaPai(), null);
                        }
                        else
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetCadastroEmpresaFilho(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CADASTRO USUARIO EMPRESA FILHO");
                        }
                        break;
                    case "Portal Credenciado Dental":
                        if (tipo_acesso.Contains("Pai"))
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetCadastroCrendenciadoDentalPai(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CADASTRO USUARIO CREDENCIADO DENTAL PAI");

                        }
                        else
                        {
                            //sql = conexao.SelectCommand(SqlHelper.GetCadastroCrendenciadoDentalFilho(), null);
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "CADASTRO USUARIO CREDENCIADO DENTAL FILHO");

                        }
                        break;


                }

                //resultado = conexao.SelectCommand(sql, null);
                //var aux_resultado = resultado.Split(';').ToArray();
                /*
                ScenarioContext.Current.Add("Usuario", aux_resultado[0].ToString());
                ScenarioContext.Current.Add("MARCA_OTICA", aux_resultado[0].ToString());
                ScenarioContext.Current.Add("Nome_Usuario", aux_resultado[1].ToString());
                */

                ScenarioContext.Current.Add("Usuario", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1).ToString());
                dynamic dados = table.CreateDynamicInstance();

                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCpfBeneficiario.ClassName, resultados.GetValue(0).ToString(), 5);

                if (resultados.GetValue(2).ToString().Equals(""))
                {
                    ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCPF.ClassName, CNPJgenerator.GeradorCPF(), 5);
                }
                else
                {
                    ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCPF.ClassName, resultados.GetValue(2).ToString(), 5);
                }

                if (ScenarioContext.Current.Get<string>("portal").Equals("Portal Credenciado Dental"))
                    ElementActions.ClickOnElement(driver, "Xpath", OperacaoCadastreSe.BtnContato.Xpath, 2);

                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoDDD.ClassName, Convert.ToString(dados.DDD), 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoCelular.ClassName, Convert.ToString(dados.Celular), 5);             
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoEmail.ClassName, dados.Email, 5);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoConfirmacaoEmail.ClassName, dados.ConfirmarEmail, 5);

                if (ScenarioContext.Current.Get<string>("portal").Equals("Portal Credenciado Dental"))
                    ElementActions.ClickOnElement(driver, "Xpath", OperacaoCadastreSe.BtnSenha.Xpath, 2);


                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoSenha.ClassName, dados.Senha, 5);
                driver.FindElement(By.ClassName(OperacaoCadastreSe.CampoSenha.ClassName)).SendKeys(Keys.Tab);
                ElementActions.SetText(driver, "Classname", OperacaoCadastreSe.CampoConfirmaSenha.ClassName, dados.ConfirmaSenha, 5);

            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());

            }

        }



        [When(@"clicar no botão enviar")]
        public void QuandoClicarNoBotaoEnviar()
        {
            ElementActions.ClickOnElement(driver, "Classname", OperacaoCadastreSe.BtnEnviar.ClassName, 5);

        }

        [When(@"prencher os campos com o usuário e senha cadastrada")]
        public void QuandoPrencherOsCamposComOUsuarioESenhaCadastrada()
        {
            string usuario = ScenarioContext.Current.Get<String>("Usuario");

            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, usuario, 10);
            ElementActions.SetText(driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);
        }



    }








}
