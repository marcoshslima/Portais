﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CA.Test.FrontEnd.ElementsReference;
using CA.Test.FrontEnd.Helper;
using Framework.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Controller.Actions;
using OGS.Framework.Setup;
using OGS.Framework.Utility;
using OpenQA.Selenium;
using Oracle.ManagedDataAccess.Client;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace CA.Test.FrontEnd.StepDefinitions.ComponentLogin
{
    [Binding]
    public sealed class InserirUsuarioFilho: ConfigReports
    {

        IWebDriver _driver;
        private Array resultados;

        public InserirUsuarioFilho(IWebDriver _driver)
        {
            this._driver = _driver;
        }

        [Given(@"prencher os campos \[Usuario]  e \[Senha] conforme o ""(.*)""")]
        public void DadoPrencherOsCamposUsuarioESenhaConformeO(string tipo_acesso)
        {
           try
            {
                switch (ScenarioContext.Current.Get<string>("portal"))
                {

                    case "Portal Empresa":

                        if (tipo_acesso.Contains("Pai"))
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "INSERIR USUARIO FILHO EMPRESA");
                        }
                        else
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ALTERAR USUARIO EMPRESA FILHO");
                            ScenarioContext.Current.Add("Usuario_Filho", resultados.GetValue(3).ToString());

                        }

                        break;
                    case "Portal Credenciado Dental":
                        if (tipo_acesso.Contains("Pai"))
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "INSERIR USUARIO FILHO CREDENCIADO DENTAL");
                        }
                        else
                        {
                            resultados = ProcedureHelper.ExecutarBiblioteca(null, "ALTERAR USUARIO CREDENCIADO DENTAL");
                            ScenarioContext.Current.Add("Cod_Usuario_Filho", resultados.GetValue(3).ToString());
                            ScenarioContext.Current.Add("Usuario_Filho", resultados.GetValue(4).ToString());
                        }

                        break;
                }

                ScenarioContext.Current.Add("MARCA_OTICA", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Usuario", resultados.GetValue(0).ToString());
                ScenarioContext.Current.Add("Nome_Usuario", resultados.GetValue(1).ToString());

                ProcedureHelper.PreencherContato(resultados.GetValue(0).ToString(), Convert.ToInt32(resultados.GetValue(2)));

                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, resultados.GetValue(0).ToString(), 10);
                ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

            }
            catch (Exception e)
            {
                ReportStep(e.ToString());
                Assert.Fail(e.ToString());
            }
        }

        [Then(@"selecionar o menu \[Controle de Acesso ao Portal]")]
        public void DadoSelecionarOMenuControleDeAcessoAoPortal()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.MenuControleAcessoPortal.Xpath, 60);
        }
        
        [Then(@"clicar no botão \[Adicionar novo Administrador]")]
        public void DadoClicarNoBotaoAdicionarNovoAdministrador()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.AdicioanrAdministrador.Xpath, 60);
        }

        [Then(@"preencher os campos abaixo:")]
        public void DadoPreencherOsCamposAbaixo(Table table)
        {

            dynamic dados = table.CreateDynamicInstance();

            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoNome.Name, dados.Nome,120);
            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoEmail.Name, dados.Email, 120);
            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoTelefone.Name, Convert.ToString(dados.Telefone), 120);

            ScenarioContext.Current.Add("NomeUsuario", dados.Nome);

            _driver.FindElements(By.XPath(OperacaoInserirFilho.LikSelecionarTodos.Xpath))[0].Click();
            Verification.Wait(2);
            _driver.FindElements(By.XPath(OperacaoInserirFilho.LikSelecionarTodos.Xpath))[1].Click();

        }

        [When(@"clicar no botão \[Salvar]")]
        public void QuandoClicarNoBotaoSalvar()
        {
            ElementActions.ClickOnElement(_driver,"Xpath", OperacaoInserirFilho.BtnSalvar.Xpath, 2);
        }


        [Then(@"o sistema deve exibir a mensagem: ""(.*)""\.")]
        public void EntaoOSistemaDeveExibirAMensagem_(string msg)
        {

            
            Verification.VerifyElementTextMatches(_driver, "Xpath", OperacaoInserirFilho.Mensagens.Xpath, 240,msg);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnOk.Xpath, 2);
            string uSuario_Filho = _driver.FindElement(By.XPath(OperacaoInserirFilho.CodigoUsuarioFilho.Xpath)).Text;
            ScenarioContext.Current.Add("Usuario_Filho",uSuario_Filho);

        }

        [Given(@"clicar no botão Entrar")]
        public void DadoClicarNoBotaoEntrar()
        {
            ElementActions.ClickOnElement(_driver, "CSS", OperacaoLogin.BtnEntrar.Propertie, 10);
        }

        [When(@"clicar no botão \[Menu] e \[Sair]")]
        public void QuandoClicarNoBotaoMenuESair()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnMenu.Xpath, 2);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnSair.Xpath, 2);
        }


        [When(@"clicar no botão cadastre-se")]
        public void QuandoClicarNoBotaoCadastre_Se()
        {
            ElementActions.ClickOnElement(_driver, "classname", OperacaoCadastreSe.LinkCadastreSe.ClassName, 10);

        }


        [When(@"preencher os campos do formuluario abaixo:")]
        public void QuandoPreencherOsCamposDoFormuluarioAbaixo(Table table)
        {
            string nome = ScenarioContext.Current.Get<string>("NomeUsuario");
            string user = ScenarioContext.Current.Get<string>("Usuario_Filho");

            ScenarioContext.Current.Remove("Usuario");
            ScenarioContext.Current.Remove("MARCA_OTICA");
            ScenarioContext.Current.Remove("Nome_Usuario");

            ScenarioContext.Current.Add("Usuario", user);
            ScenarioContext.Current.Add("MARCA_OTICA", user);
            ScenarioContext.Current.Add("Nome_Usuario", nome);

            dynamic dados = table.CreateDynamicInstance();

            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoCpfBeneficiario.ClassName, user, 5);

            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoCPF.ClassName, CNPJgenerator.GeradorCPF(), 5);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoDDD.ClassName, Convert.ToString(dados.DDD), 5);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoCelular.ClassName, Convert.ToString(dados.Celular), 5);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoEmail.ClassName, dados.Email, 5);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoConfirmacaoEmail.ClassName, dados.ConfirmarEmail, 5);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoSenha.ClassName, dados.Senha, 5);
            _driver.FindElement(By.ClassName(OperacaoCadastreSe.CampoSenha.ClassName)).SendKeys(Keys.Tab);
            ElementActions.SetText(_driver, "Classname", OperacaoCadastreSe.CampoConfirmaSenha.ClassName, dados.ConfirmaSenha, 5);


        }


        [When(@"clicar no botão \[Salvar] do Credenciado Dental")]
        public void QuandoClicarNoBotaoSalvarDoCredenciadoDental()
        {
            ElementActions.ClickOnElement(_driver,"Xpath", OperacaoInserirFilho.BtnSalvarFuncionario.Xpath, 2);
        }

        [Then(@"selecionar o respectivo usuário filho na tabela \[Controle de acesso ao portal] e clicar no botão Alterar")]
        public void EntaoSelecionarORespectivoUsuarioFilhoNaTabelaControleDeAcessoAoPortalEClicarNoBotaoAlterar()

        {
            Utils.WaitForElementLoad(_driver, By.XPath(OperacaoInserirFilho.EditarUsuarioFilho.Xpath), 60);
            string userFilho = ScenarioContext.Current.Get<String>("Usuario_Filho");
            Utils.ReadTable(_driver.FindElement(By.XPath(OperacaoInserirFilho.Table.Xpath)));
            int indexRows = Utils.ReturIndex("Código / Senha Primeiro Acesso", userFilho);
            ElementActions.ClickOnElement(_driver,"Xpath",OperacaoInserirFilho.EditarUsuarioFilhoX.Editar(indexRows),2);
        }


        [Then(@"alterar os todos os perfis e contratos")]
        public void EntaoAlterarOsTodosOsPerfisEContratos()
        {
            ElementActions.SetText(_driver, "Xpath", OperacaoInserirFilho.CampoTelefoneAlterar.Xpath, "99947856547", 120);
            //ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.AlterarPerfilTodos.XPath, 120);
            //ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.AlterarContratosTodos.XPath, 120);
            
        }

        [Then(@"alterar os campos Nome ""(.*)"", email ""(.*)"" e telefone ""(.*)""")]
        public void EntaoAlterarOsCamposNomeEmailETelefone(string nome, string email, string telefone)
        {
            ElementActions.SetText(_driver, "Xpath", OperacaoInserirFilho.CampoNomeAlterar.Xpath, nome, 120);
            ElementActions.SetText(_driver, "Xpath", OperacaoInserirFilho.CampoEmailAlterar.Xpath, email, 120);
            ElementActions.SetText(_driver, "Xpath", OperacaoInserirFilho.CampoTelefoneAlterar.Xpath, telefone, 120);
            ScenarioContext.Current.Remove("Nome_Usuario");
            ScenarioContext.Current.Add("Nome_Usuario", nome);
        }

        [When(@"clicar no botão \[Salvar] após alterar os perfis e contrato")]
        public void QuandoClicarNoBotaoSalvarAposAlterarOsPerfisEContrato()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnSalvarAlteracao.Xpath,20);
        }

        [Then(@"o sistema deve exibir a mensagem de alteração: ""(.*)""\.")]
        public void EntaoOSistemaDeveExibirAMensagemDeAlteracao_(string msg)
        {
            Verification.VerifyElementTextMatches(_driver, "Xpath", OperacaoInserirFilho.Mensagens.Xpath, 60, msg);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnOk.Xpath, 2);
        }

        [When(@"prencher os campos com o usuário Filho")]
        public void QuandoPrencherOsCamposComOUsuarioFilho()

        {
            string usuario = ScenarioContext.Current.Get<String>("Usuario_Filho");
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, usuario, 10);
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

            try
            {
                ProcedureHelper.PreencherContato(usuario, Convert.ToInt32(resultados.GetValue(2)));
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
                ReportStep(_driver, e.ToString());
            }
        }

        [When(@"clicar no botão \[Menu] e \[Sair] do Credenciado Dental")]
        public void QuandoClicarNoBotaoMenuESairDoCredenciadoDental()
        {
            ElementActions.ClickOnElement(_driver,"Xpath",OperacaoInserirFilho.MenuCredenciadoDental.Xpath,2);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnSair.Xpath, 2);
        }

        [When(@"prencher os campos com o usuário e senha cadastrada do usuário filho")]
        public void QuandoPrencherOsCamposComOUsuarioESenhaCadastradaDoUsuarioFilho()
        {
            string user = ScenarioContext.Current.Get<string>("Usuario");
            ProcedureHelper.AlterarSenha(user, 600);

            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, user, 10);
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);

        }

        [Then(@"selecionar o respectivo usuário filho na tabela \[Controle de acesso ao portal] e clicar no botão Excluir")]
        public void EntaoSelecionarORespectivoUsuarioFilhoNaTabelaControleDeAcessoAoPortalEClicarNoBotaoExcluir()
        {
            Utils.WaitForElementLoad(_driver, By.XPath(OperacaoInserirFilho.EditarUsuarioFilho.Xpath), 60);
            string userFilho = ScenarioContext.Current.Get<String>("Usuario_Filho");
            Utils.ReadTable(_driver.FindElement(By.XPath(OperacaoInserirFilho.Table.Xpath)));
            int indexRows = Utils.ReturIndex("Código / Senha Primeiro Acesso", userFilho);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.ExcluirUsuarioFilhoX.Excluir(indexRows), 2);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.BtnSim.Xpath, 10);
        }


        [Then(@"selecionar o menu dp Credenciado Dental")]
        public void EntaoSelecionarOMenuDpCredenciadoDental()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.MenuCredenciadoDental.Xpath, 2);
        }

        [Then(@"clicar no botão \[Configurações]")]
        public void EntaoClicarNoBotaoConfiguracoes()
        {
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.MenuConfiguracoes.Xpath, 2);
        }

        [Then(@"clicar no botão \[Novo Funcionario]")]
        public void EntaoClicarNoBotaoNovoFuncionario()
        {
            ElementActions.ClickOnElement(_driver,"Xpath",OperacaoInserirFilho.BtnNovoFuncionario.Xpath,20);
        }


        [Then(@"preencher os campos abaixo do usuario filho \[Credenciado Dental]:")]
        public void EntaoPreencherOsCamposAbaixoDoUsuarioFilhoCredenciadoDental(Table table)
        {

            ScenarioContext.Current.Remove("Usuario");
            ScenarioContext.Current.Remove("MARCA_OTICA");
            ScenarioContext.Current.Remove("Nome_Usuario");

            dynamic dados = table.CreateDynamicInstance();

            Random rdn = new Random();

            string NumeroAleatorio = rdn.Next(1, 5000).ToString();
            string email = "user" + NumeroAleatorio + dados.Email;
            string nome = dados.Nome;


            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoNome_Completo.Name, nome, 10);
            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoCPF.Name, CNPJgenerator.GeradorCPF(), 10);
            ElementActions.SetText(_driver, "Name", OperacaoInserirFilho.CampoEmailDental.Name, email, 10);
           
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.CampoPerfil.Xpath, 10);
            ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.CampoPerfil.GetPerfil(dados.Perfil), 2);

            ScenarioContext.Current.Add("Nome_Usuario", nome);

        }


        [Then(@"o sistema deve incluir o usuário filho na lista de funcionários")]
        public void EntaoOSistemaDeveIncluirOUsuarioFilhoNaListaDeFuncionarios()
        {
            
            string nome_perfil = ScenarioContext.Current.Get<string>("Nome_Usuario");
            Verification.VerifyElementExists(_driver,"Xpath",OperacaoInserirFilho.CampoPerfil.GetNomePerfil(nome_perfil),60);
            

            bool achou = false;
            int count = 0;
            while (!achou)
            {
                if (_driver.FindElements(By.XPath("//h4"))[count].Text == nome_perfil)
                {
                    
                    achou = true;
                    ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.CampoPerfil.GetNomePerfil(nome_perfil), 2);

                }
                count++;

            }

            count = count - 1;
            string usuario = _driver.FindElement(By.Name("user"+count+".codigo")).GetAttribute("value");
            ScenarioContext.Current.Add("Usuario", usuario);

        }



        [Then(@"inativar o usuário filho")]
        public void EntaoInativarOUsuarioFilho()
        {

            string nome_usuarioFilho = ScenarioContext.Current.Get<string>("Usuario_Filho");
            Utils.WaitForElementLoad(_driver, By.XPath("//h4"),60);

            bool achou = false;
            int count = 0;
            while (!achou)
            {
                if (_driver.FindElements(By.XPath("//h4"))[count].Text == nome_usuarioFilho)
                {
                    achou = true;
                    ElementActions.ClickOnElement(_driver, "Xpath", OperacaoInserirFilho.CampoPerfil.GetNomePerfil(nome_usuarioFilho), 2);
                }
                count++;
            }

            count--;
            Verification.Wait(3);
            int comboPerfil = 3 + (count * 2);
            int comboStatus = 4 + (count * 2);
            try
            {
                _driver.FindElements(By.XPath("//div//span//button[@type='button']"))[comboPerfil].Click();
                Verification.Wait(2);
                _driver.FindElement(By.XPath(OperacaoInserirFilho.CampoPerfil.GetPerfil("Geral"))).Click();
                Verification.Wait(2);
                _driver.FindElements(By.XPath("//div//span//button[@type='button']"))[comboStatus].Click();
                _driver.FindElement(By.XPath(OperacaoInserirFilho.CampoPerfil.GetPerfil("Inativo"))).Click();
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
            

            ScenarioContext.Current.Add("count", count);
         }


        [When(@"clicar no botão \[Salvar] do Credenciado Dental para refletir as alterações")]
        public void QuandoClicarNoBotaoSalvarDoCredenciadoDentalParaRefletirAsAlteracoes()
        {
            int count = ScenarioContext.Current.Get<int>("count") + 1;
            _driver.FindElements(By.XPath(OperacaoInserirFilho.BtnSalvarFuncionario.Xpath))[count].Click();

        }


        [Then(@"o sistema apresentar a mensagem ""(.*)""\.")]
        public void EntaoOSistemaApresentarAMensagem_(string  msg)
        {
            Verification.VerifyElementTextContains(_driver, "Xpath", OperacaoInserirFilho.MsgSucessoDental.Xpath, 10, msg);
        }

        [When(@"prencher os campos com o usuário Filho Inativo")]
        public void QuandoPrencherOsCamposComOUsuarioFilhoInativo()
        {

            String user = ScenarioContext.Current.Get<string>("Cod_Usuario_Filho");

            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoUsuario.Propertie, user, 10);
            ElementActions.SetText(_driver, "CSS", OperacaoLogin.CampoSenha.Propertie, "Amil@1234", 10);            
        }
    }

}
       
