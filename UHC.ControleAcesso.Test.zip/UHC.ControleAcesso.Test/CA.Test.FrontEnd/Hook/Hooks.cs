﻿using BoDi;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;
using OpenQA.Selenium;
using System.Configuration;
using TechTalk.SpecFlow;

namespace UHC.Portal.AgendamentoOnline.Test.UI.Hooks
{
    [Binding]
    public class Hook : ConfigReports
    {
        private readonly IObjectContainer _objectContainer;
        private IWebDriver _driver;
        private TestContext _testContext;
        private bool testCreated = false;
        private int stepCounter = 1;


        public Hook(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [BeforeFeature]
        public static void FeatureSetUp()
        {
            InitLog(FeatureContext.Current.FeatureInfo.Title);
        }

        [BeforeScenario]
        public void ScenarioSetup()
        {
            _driver = InitBrowser(_driver, ConfigurationManager.AppSettings["_browser"].ToUpper());
            _objectContainer.RegisterInstanceAs(_driver);
        }

        [BeforeStep]
        public void StepSetup()
        {
            if (_testContext == null)
            {
                _testContext = ScenarioContext.Current.ScenarioContainer.Resolve<TestContext>();
            }

            if (!testCreated)
            {
                _testContext = ScenarioContext.Current.ScenarioContainer.Resolve<TestContext>();
                TestCaseName(_testContext, ScenarioContext.Current.ScenarioInfo.Title);
                testCreated = true;
            }
        }

        [AfterStep]
        public void StepTeardown()
        {
            ReportStep(_driver, "Passo: " + ScenarioStepContext.Current.StepInfo.Text + " executado com sucesso.");
            Screenshot ss = ((ITakesScreenshot)_driver).GetScreenshot();
            string path = _testContext.TestName + "_Step" + stepCounter + ".png";
            ss.SaveAsFile(path);
            _testContext.AddResultFile(path);
            stepCounter++;
        }

        [AfterScenario]
        public void ScenarioTeardown()
        {
            GenerateLog(_testContext, _driver);
            CloseBrowser(_driver);
        }

        [AfterFeature]
        public static void FeatureTeardown()
        {
            CloseLog();
        }
    }
}